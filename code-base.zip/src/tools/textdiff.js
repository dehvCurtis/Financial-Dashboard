// Visible text by element id, two pages on the same data: what a reader sees changed, card by card.
// usage: node tools/textdiff.js <pageA.html[:dataA]> <pageB.html[:dataB]> [datadir] [--out report.md]   (a side's own data wins over datadir)
// Every element with an id inside a tab (each tab opened, every fold opened, in a 390 wide light page) is read with innerText; ids whose
// text differs are listed with both texts (trimmed), and ids present on one side only are named.
'use strict';
const fs=require('fs');const path=require('path');const W=require('../tests/lib/web');
const [A,B,data]=process.argv.slice(2).filter(x=>!x.startsWith('--'));const outI=process.argv.indexOf('--out');const out=outI>0?process.argv[outI+1]:null;
(async()=>{const dd=data||W.ROOT+'/data_all';const sp=s=>{const [p,d]=s.split(':');return [p,d||dd];};const [pa,da]=sp(A),[pb,db]=sp(B);const ha=W.harness('td_a',da,pa),hb=W.harness('td_b',db,pb);const b=await W.launch();
  const grab=async h=>{const p=await W.open(b,h);const res={};const tabs=await W.pagesOf(p);
    for(const t of tabs){await W.tab(p,t);await W.openAll(p,t);Object.assign(res,await p.evaluate(t=>{const o={};const pg=document.getElementById('page-'+t);if(!pg)return o;
      pg.querySelectorAll('[id]').forEach(e=>{if(e.closest('[id]')!==e&&e.parentElement.closest('.mo-card[id],[data-source][id]'))return;o[e.id]=(e.innerText||'').replace(/\s+/g,' ').trim();});return o;},t));}
    await p.close();return res;};
  const ta=await grab(ha),tb=await grab(hb);await b.close();
  const ids=[...new Set(Object.keys(ta).concat(Object.keys(tb)))].sort();const rows=[];
  for(const id of ids){if(!(id in ta))rows.push([id,'(not on A)',tb[id].slice(0,240)]);else if(!(id in tb))rows.push([id,ta[id].slice(0,240),'(not on B)']);else if(ta[id]!==tb[id]){let i=0;while(i<ta[id].length&&ta[id][i]===tb[id][i])i++;const s=Math.max(0,i-60);rows.push([id,'...'+ta[id].slice(s,s+220),'...'+tb[id].slice(s,s+220)]);}}
  const md=['# Visible text by element id','','A: `'+A+'`','B: `'+B+'`','Data: `'+dd+'`','',rows.length+' of '+ids.length+' ids differ','','| id | A | B |','|---|---|---|'].concat(rows.map(r=>'| '+r.map(x=>String(x).replace(/\|/g,'/')).join(' | ')+' |')).join('\n');
  if(out)fs.writeFileSync(out,md);console.log(rows.length+' of '+ids.length+' ids differ'+(rows.length?': '+rows.map(r=>r[0]).slice(0,40).join(', '):''));})();
