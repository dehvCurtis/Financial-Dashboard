// Split the page's single script into N files that each stay under the store limits.
// Each part is wrapped in its own function scope: (function(){'use strict'; ...})();
// Shared top-level names are exported on window: functions at the start of a part (they are hoisted), consts and classes at its end.
// Mutable top-level names (let, var) are never exported: every declaration and every use of one must sit in the same part, so cuts are
// only allowed outside the span from the first to the last token of each such name.
// usage as module: split(scriptSource, {limit, target}) -> {parts:[code...], cuts, sizes, counts}; parts are minified by whitespace and comment removal only.
const acorn=require('acorn');
const esbuild=require('esbuild');
const P={ecmaVersion:2022,sourceType:'script'};
function names(ast){const fn=[],cs=[],mut=[];
 for(const n of ast.body){
  if(n.type==='FunctionDeclaration')fn.push(n.id.name);
  else if(n.type==='VariableDeclaration')for(const d of n.declarations){if(d.id.type!=='Identifier')throw new Error('destructuring at top level');(n.kind==='const'?cs:mut).push(d.id.name);}
  else if(n.type==='ClassDeclaration')cs.push(n.id.name);
 }return {fn,cs,mut};}

/* scope-aware references: positions of identifiers that resolve to a top-level binding named in want */
function topRefs(ast,want){const W=new Set(want);const out={};want.forEach(m=>out[m]=[]);
 const pnames=(p,acc)=>{if(!p)return acc;if(p.type==='Identifier')acc.push(p.name);else if(p.type==='ObjectPattern')p.properties.forEach(q=>pnames(q.type==='RestElement'?q.argument:q.value,acc));else if(p.type==='ArrayPattern')p.elements.forEach(e=>pnames(e,acc));else if(p.type==='RestElement')pnames(p.argument,acc);else if(p.type==='AssignmentPattern')pnames(p.left,acc);return acc;};
 const varsIn=(node,acc)=>{if(!node||typeof node!=='object')return acc;if(Array.isArray(node)){node.forEach(n=>varsIn(n,acc));return acc;}
  if(/Function/.test(node.type)&&node.type!=='FunctionDeclaration')return acc;if(node.type==='FunctionDeclaration'){return acc;}
  if(node.type==='VariableDeclaration'&&node.kind==='var')node.declarations.forEach(d=>pnames(d.id,acc));
  for(const k in node){if(k==='type'||k==='start'||k==='end')continue;const v=node[k];if(v&&typeof v==='object')varsIn(v,acc);}return acc;};
 const blockDecl=(list)=>{const acc=[];list.forEach(n=>{if(n.type==='VariableDeclaration'&&n.kind!=='var')n.declarations.forEach(d=>pnames(d.id,acc));else if(n.type==='ClassDeclaration'||n.type==='FunctionDeclaration')acc.push(n.id.name);});return acc;};
 const shadowed=(stack,n)=>stack.some(s=>s.has(n));
 const walk=(node,stack,parent,key)=>{if(!node||typeof node!=='object')return;if(Array.isArray(node)){node.forEach(n=>walk(n,stack,parent,key));return;}
  const t=node.type;
  if(t==='Identifier'){if(W.has(node.name)&&!shadowed(stack,node.name)){
     const skip=(parent&&((parent.type==='MemberExpression'&&key==='property'&&!parent.computed)||((parent.type==='Property'||parent.type==='MethodDefinition'||parent.type==='PropertyDefinition')&&key==='key'&&!parent.computed)||(parent.type==='LabeledStatement'||parent.type==='BreakStatement'||parent.type==='ContinueStatement')));
     if(!skip)out[node.name].push(node.start);}return;}
  if(/Function/.test(t)){const sc=new Set();node.params.forEach(p=>pnames(p,[]).forEach(n=>sc.add(n)));if(node.id&&t!=='FunctionDeclaration')sc.add(node.id.name);
    if(node.body.type==='BlockStatement'){varsIn(node.body.body,[]).forEach(n=>sc.add(n));blockDecl(node.body.body).forEach(n=>sc.add(n));}
    const st=stack.concat([sc]);node.params.forEach(p=>walk(p,st,node,'params'));if(node.body.type==='BlockStatement')node.body.body.forEach(n=>walk(n,st,node.body,'body'));else walk(node.body,st,node,'body');return;}
  if(t==='BlockStatement'||t==='StaticBlock'){const sc=new Set(blockDecl(node.body));const st=sc.size?stack.concat([sc]):stack;node.body.forEach(n=>walk(n,st,node,'body'));return;}
  if(t==='ForStatement'||t==='ForInStatement'||t==='ForOfStatement'){const d=t==='ForStatement'?node.init:node.left;const sc=new Set(d&&d.type==='VariableDeclaration'&&d.kind!=='var'?d.declarations.flatMap(x=>pnames(x.id,[])):[]);const st=sc.size?stack.concat([sc]):stack;
    for(const k of ['init','test','update','left','right','body'])if(node[k])walk(node[k],st,node,k);return;}
  if(t==='CatchClause'){const sc=new Set(node.param?pnames(node.param,[]):[]);walk(node.body,stack.concat([sc]),node,'body');return;}
  if(t==='ClassExpression'||t==='ClassDeclaration'){const sc=new Set(node.id&&t==='ClassExpression'?[node.id.name]:[]);const st=stack.concat([sc]);if(node.superClass)walk(node.superClass,st,node,'superClass');walk(node.body,st,node,'body');return;}
  if(t==='VariableDeclarator'){walk(node.id,stack,node,'id');if(node.init)walk(node.init,stack,node,'init');return;}
  for(const k in node){if(k==='type'||k==='start'||k==='end')continue;const v=node[k];if(v&&typeof v==='object')walk(v,stack,node,k);}};
 walk(ast.body,[],ast,'body');return out;}
const min=c=>esbuild.transformSync(c,{minifyWhitespace:true,target:'es2020',legalComments:'none'}).code;
const ex=l=>l.length?'Object.assign(window,{'+l.join(',')+'});':'';
/* hotfix v4.1: each top-level const or class is exported right after its declaration, not at the end of its part, because the runtime
   calls an onData callback at once and a part's own draw code may run before that part has finished */
function wrap(code){const ast=acorn.parse(code,P);const n=names(ast);let src=code;
 const at=[];for(const s of ast.body){if(s.type==='VariableDeclaration'&&s.kind==='const')at.push([s.end,s.declarations.map(d=>d.id.name)]);else if(s.type==='ClassDeclaration')at.push([s.end,[s.id.name]]);}
 at.sort((x,y)=>y[0]-x[0]).forEach(([e,l])=>{src=src.slice(0,e)+'\n'+ex(l)+src.slice(e);});
 const body='\'use strict\';'+ex(n.fn)+'\n'+src.replace(/^\s*'use strict';/,'')+'\n';
 return {code:'(function(){'+min(body).replace(/\n$/,'')+'})();\n',n};}
function sizeOk(code,limit){return Buffer.byteLength(code)<=limit&&JSON.stringify(code).length<=256*1024;}
exports.split=function(src,opt){
 opt=opt||{};const hard=opt.limit||200*1024;const limit=Math.min(hard,opt.target||170*1024);/* plan against the target for headroom, verify against the hard limit */
 const ast=acorn.parse(src,P);const all=names(ast);
 /* spans of mutable names: from the first to the last reference that resolves to the top-level binding (scope aware) */
 const refs=topRefs(ast,all.mut);
 const spans=all.mut.map(m=>{const ps=refs[m];return {m,a:Math.min(...ps),b:Math.max(...ps)};});
 const starts=ast.body.map(n=>n.start).filter(s=>s>0&&!spans.some(sp=>sp.a<s&&s<=sp.b));
 /* greedy: each part takes the longest run of statements that still fits once wrapped and minified */
 const cuts=[];let from=0;
 while(true){
  const rest=wrap(src.slice(from));if(sizeOk(rest.code,limit))break;
  const cand=starts.filter(s=>s>from);if(!cand.length)throw new Error('no legal cut point after '+from);
  let lo=0,hi=cand.length-1,best=-1;
  while(lo<=hi){const mid=(lo+hi)>>1;const w=wrap(src.slice(from,cand[mid]));if(sizeOk(w.code,limit)){best=mid;lo=mid+1;}else hi=mid-1;}
  if(best<0)throw new Error('a single statement run is over the limit at '+from);
  cuts.push(cand[best]);from=cand[best];
 }
 /* balance: spread the same number of parts evenly when the greedy split leaves a small tail */
 const N=cuts.length+1;
 if(N>1){const even=[];let ok=true;for(let k=1;k<N;k++){const target=src.length*k/N;const c=starts.filter(s=>s>(even[k-2]||0)).reduce((b,s)=>Math.abs(s-target)<Math.abs(b-target)?s:b,Infinity);if(!isFinite(c)){ok=false;break;}even.push(c);}
  if(ok){const bounds=[0,...even,src.length];const ws=bounds.slice(0,-1).map((a,i)=>wrap(src.slice(a,bounds[i+1])));if(ws.every(w=>sizeOk(w.code,limit))){cuts.length=0;cuts.push(...even);}}}
 const bounds=[0,...cuts,src.length];const parts=[],counts=[];
 bounds.slice(0,-1).forEach((a,i)=>{const w=wrap(src.slice(a,bounds[i+1]));parts.push(w.code);counts.push(w.n);});
 /* a mutable name may not appear in any other part */
 const bad=[];counts.forEach((c,i)=>c.mut.forEach(m=>{parts.forEach((p,j)=>{if(j===i)return;const r=topRefs(acorn.parse(p,P),[m]);if(r[m].length)bad.push(m+' used in part '+j);});}));
 if(bad.length)throw new Error('mutable top-level name used outside its part: '+[...new Set(bad)].join(', '));
 parts.forEach((p,i)=>{if(!sizeOk(p,hard))throw new Error('part '+i+' over the hard limit');});
 if(parts.some(p=>p.includes('</script')))throw new Error('script end tag in code');
 return {parts,cuts,sizes:parts.map(p=>Buffer.byteLength(p)),json_sizes:parts.map(p=>JSON.stringify(p).length),counts};
};
exports.wrap=wrap;
