// Screenshots of every page on a data folder (default data_all, the invented example data), 390 px wide like a phone, light theme, folds
// closed as a person first sees them, plus Home in the dark theme. One PNG per page.
// usage: node tools/make_shots.js <outdir> [--data dir]
'use strict';
const fs=require('fs');const path=require('path');const W=require('../tests/lib/web');
const ROOT=W.ROOT;const out=process.argv[2];const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
if(!out){console.log('usage: node tools/make_shots.js <outdir> [--data dir]');process.exit(2);}
const data=arg('--data')||ROOT+'/data_all';
const texts=d=>{const t={};for(const f of fs.readdirSync(d))if(f.endsWith('.json'))t[f.slice(0,-5)]=fs.readFileSync(path.join(d,f),'utf8');return t;};
fs.mkdirSync(out,{recursive:true});
(async()=>{const b=await W.launch();const h=W.harness('shots',texts(data));const made=[];
  for(const dark of [false,true]){const p=await W.open(b,h,{viewport:{width:390,height:5200},dark});
    for(const t of await W.pagesOf(p)){if(dark&&t!=='home')continue;await W.tab(p,t);await p.waitForTimeout(400);
      const bottom=await p.evaluate(t=>{const pg=document.getElementById('page-'+t);const r=pg.getBoundingClientRect();let m=r.bottom;pg.querySelectorAll('*').forEach(e=>{const q=e.getBoundingClientRect();if(q.height&&q.bottom>m&&q.bottom<9000)m=q.bottom;});return Math.ceil(m);},t);
      const f=path.join(out,(dark?'dark_':'')+t+'.png');await p.screenshot({path:f,clip:{x:0,y:0,width:390,height:Math.min(5200,bottom+24)}});made.push(f);}
    await p.close();}
  await b.close();console.log('shots: '+made.length+' into '+out);})().catch(e=>{console.error(e);process.exit(1);});
