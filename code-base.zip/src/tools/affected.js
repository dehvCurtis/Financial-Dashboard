// Plan for an affected-only run: compares the tree with the last clean full run (work/last_full.json).
// Prints {"unit": "calc1,calc2" | "" (all) | null (none), "browser": "parity,render" | "" (all) | null (none)}.
const fs=require('fs');const path=require('path');const D=path.resolve(__dirname,'..');const now=require('./tree_hash.js').hashes();
const lf=D+'/work/last_full.json';if(!fs.existsSync(lf)){console.log(JSON.stringify({unit:'',browser:''}));process.exit(0);}
const old=JSON.parse(fs.readFileSync(lf,'utf8')).hashes||{};const changed=[...new Set(Object.keys(now).concat(Object.keys(old)))].filter(k=>now[k]!==old[k]);
const code=changed.filter(k=>!k.startsWith('data_all/'));const data=changed.filter(k=>k.startsWith('data_all/')).map(k=>path.basename(k,'.json'));
if(code.length){console.log(JSON.stringify({unit:'',browser:'parity,render,marks,behavior,nav,links,quick,about',why:'code or tests changed: '+code.slice(0,5).join(', ')}));process.exit(0);}
if(!data.length){console.log(JSON.stringify({unit:null,browser:null,why:'nothing changed since the last full run'}));process.exit(0);}
const A=require('./depmap.js').affected(data,{});console.log(JSON.stringify({unit:A.calcs.length?A.calcs.join(','):null,browser:'parity,render',why:'data changed: '+data.join(', ')}));
