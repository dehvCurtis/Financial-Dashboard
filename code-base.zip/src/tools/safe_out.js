// Guard for tools that empty an output folder before writing: refuses a folder that is a filesystem root, the home folder, the working
// folder, the code base itself, or one of their parents, so a typo in --out cannot delete something that matters.
'use strict';
const fs=require('fs');const os=require('os');const path=require('path');
exports.safeOut=function(dir){const abs=path.resolve(dir);const ROOT=path.resolve(__dirname,'..');
  const protectedDirs=[path.parse(abs).root,os.homedir(),process.cwd(),ROOT].map(d=>path.resolve(d));
  const bad=protectedDirs.some(p=>p===abs||p.startsWith(abs+path.sep));
  if(bad){console.error('refusing to empty '+abs+': it is, or contains, a protected folder. Use a new or scratch folder.');process.exit(2);}
  return abs;};
