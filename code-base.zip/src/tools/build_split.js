// Production files: node tools/build_split.js [page.html] [outdir]
// out/split/index.html is the page with its script replaced by plain script src tags in order (app_a.js, app_b.js, ...).
// If the shell (CSS plus markup) would pass 200 KB, the CSS moves to app.css and the shell links it.
const fs=require('fs');const path=require('path');
const D=path.resolve(__dirname,'..');
const PG=process.argv[2]||D+'/out/index_page.html',OUT=process.argv[3]||D+'/out/split';
const page=fs.readFileSync(PG,'utf8');const m=page.match(/<script>([\s\S]*)<\/script>/);
const SP=require('./split.js').split(m[1]);
fs.rmSync(OUT,{recursive:true,force:true});fs.mkdirSync(OUT,{recursive:true});
const names=SP.parts.map((p,i)=>'app_'+String.fromCharCode(97+i)+'.js');
SP.parts.forEach((p,i)=>fs.writeFileSync(path.join(OUT,names[i]),p));
/* selftest.js (the self-test rules) is its own page file, listed last; it only defines window.MOC_SELFTEST */
const ST=require('./selftest_build.js').text();fs.writeFileSync(path.join(OUT,'selftest.js'),ST);
let shell=page.replace(m[0],names.concat(['selftest.js']).map(n=>'<script src="'+n+'"></script>').join(''));
const LIM=200*1024;let css=null;
if(Buffer.byteLength(shell)>LIM||JSON.stringify(shell).length>256*1024){const s=shell.match(/<style>([\s\S]*?)<\/style>/);css=s[1];shell=shell.replace(s[0],'<link rel="stylesheet" href="app.css">');fs.writeFileSync(path.join(OUT,'app.css'),css);}
fs.writeFileSync(path.join(OUT,'index.html'),shell);
const rep={files:[{name:'index.html',bytes:Buffer.byteLength(shell),json:JSON.stringify(shell).length}].concat(css?[{name:'app.css',bytes:Buffer.byteLength(css),json:JSON.stringify(css).length}]:[]).concat(names.map((n,i)=>({name:n,bytes:SP.sizes[i],json:SP.json_sizes[i]}))).concat([{name:'selftest.js',bytes:Buffer.byteLength(ST),json:JSON.stringify(ST).length}]),cuts:SP.cuts,mutable:SP.counts.map((c,i)=>({part:names[i],mut:c.mut}))};
fs.writeFileSync(path.join(path.dirname(OUT),'split_report.json'),JSON.stringify(rep,null,1));
console.log(rep.files.map(f=>f.name+' '+f.bytes+' bytes, '+f.json+' json').join('\n'));
