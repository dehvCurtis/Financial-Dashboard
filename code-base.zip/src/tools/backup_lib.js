// The backup serializers, written to produce byte-for-byte what page/js/90_wiring.js produces in the browser (JSON.stringify with one
// space indent plus a newline for dataset files; the page's csvCell/toCsv; sha256 over the UTF-8 bytes). Used by tools/verify_backup.js
// to recompute hashes, and by tools/make_synthetic_backup.js to build a backup without a browser.
'use strict';
const crypto=require('crypto');const zlib=require('zlib');
exports.SCHEMA_VERSION='mo-backup-2';
exports.sha256=b=>crypto.createHash('sha256').update(b).digest('hex');
exports.datasetText=rows=>JSON.stringify(rows,null,1)+'\n';
const csvCell=v=>{if(v==null)return '';if(typeof v==='object')v=JSON.stringify(v);v=String(v);return /[",\n\r]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;};
exports.csvCell=csvCell;
exports.toCsv=d=>{const list=Array.isArray(d)?d:(d&&typeof d==='object'?[d]:[{value:d}]);const keys=[];list.forEach(r=>{if(r&&typeof r==='object')Object.keys(r).forEach(k=>{if(keys.indexOf(k)<0)keys.push(k);});else if(keys.indexOf('value')<0)keys.push('value');});
  return [keys.map(csvCell).join(',')].concat(list.map(r=>keys.map(k=>csvCell(r&&typeof r==='object'?r[k]:(k==='value'?r:''))).join(','))).join('\r\n')+'\r\n';};
exports.schemaOf=v=>{const list=Array.isArray(v)?v:[v];const f={};list.forEach(r=>{if(r&&typeof r==='object')Object.keys(r).forEach(k=>{const x=r[k];const t=x===null?'null':Array.isArray(x)?'array':typeof x;(f[k]=f[k]||[]).indexOf(t)<0&&f[k].push(t);});});
  return Object.keys(f).map(k=>({field:k,types:f[k].sort()}));};
/* a minimal zip reader (stored and deflated entries, from the central directory) and writer (stored, like the page) */
exports.ZIP_LIMITS={entries:2000,fileBytes:64*1024*1024,totalBytes:256*1024*1024};
exports.readZip=buf=>{const LIM=exports.ZIP_LIMITS;let e=buf.length-22;while(e>=0&&buf.readUInt32LE(e)!==0x06054b50)e--;if(e<0)throw new Error('not a zip file (no end record)');
  const n=buf.readUInt16LE(e+10),cdOff=buf.readUInt32LE(e+16);if(n>LIM.entries)throw new Error('zip has too many entries ('+n+')');
  const out=Object.create(null);let p=cdOff,total=0;
  const need=(o,len)=>{if(o<0||len<0||o+len>buf.length)throw new Error('zip entry points outside the file');};
  for(let i=0;i<n;i++){need(p,46);if(buf.readUInt32LE(p)!==0x02014b50)throw new Error('bad central directory');const method=buf.readUInt16LE(p+10),csize=buf.readUInt32LE(p+20),usize=buf.readUInt32LE(p+24),nl=buf.readUInt16LE(p+28),xl=buf.readUInt16LE(p+30),cl=buf.readUInt16LE(p+32),lo=buf.readUInt32LE(p+42);
    need(p+46,nl);const name=buf.slice(p+46,p+46+nl).toString('utf8');need(lo,30);const lnl=buf.readUInt16LE(lo+26),lxl=buf.readUInt16LE(lo+28);need(lo+30+lnl+lxl,csize);
    if(usize>LIM.fileBytes||csize>LIM.fileBytes)throw new Error('zip entry too large: '+name);const data=buf.slice(lo+30+lnl+lxl,lo+30+lnl+lxl+csize);
    /* names are only ever used as map keys, never as file paths; a name that could escape a folder is refused anyway */
    if(name.startsWith('/')||name.split('/').includes('..')||name.includes('\\')||name.includes('\0'))throw new Error('unsafe zip entry name: '+JSON.stringify(name.slice(0,60)));
    const bytes=method===0?data:method===8?zlib.inflateRawSync(data,{maxOutputLength:LIM.fileBytes}):(()=>{throw new Error('unsupported zip method '+method);})();
    total+=bytes.length;if(total>LIM.totalBytes)throw new Error('zip expands to more than the allowed total size');out[name]=bytes;p+=46+nl+xl+cl;}
  return out;};
const crcT=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t.push(c>>>0);}return t;})();
const crc=b=>{let c=0xFFFFFFFF;for(let i=0;i<b.length;i++)c=crcT[(c^b[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;};
exports.writeZip=files=>{const parts=[],cen=[];let off=0;
  files.forEach(f=>{const nm=Buffer.from(f.name),d=Buffer.from(f.bytes),c=crc(d);const lh=Buffer.alloc(30);lh.writeUInt32LE(0x04034b50,0);lh.writeUInt16LE(20,4);lh.writeUInt16LE(0x0800,6);lh.writeUInt32LE(c,14);lh.writeUInt32LE(d.length,18);lh.writeUInt32LE(d.length,22);lh.writeUInt16LE(nm.length,26);parts.push(lh,nm,d);
    const ch=Buffer.alloc(46);ch.writeUInt32LE(0x02014b50,0);ch.writeUInt16LE(20,4);ch.writeUInt16LE(20,6);ch.writeUInt16LE(0x0800,8);ch.writeUInt32LE(c,16);ch.writeUInt32LE(d.length,20);ch.writeUInt32LE(d.length,24);ch.writeUInt16LE(nm.length,28);ch.writeUInt32LE(off,42);cen.push(ch,nm);off+=30+nm.length+d.length;});
  const cs=cen.reduce((s,x)=>s+x.length,0);const e=Buffer.alloc(22);e.writeUInt32LE(0x06054b50,0);e.writeUInt16LE(files.length,8);e.writeUInt16LE(files.length,10);e.writeUInt32LE(cs,12);e.writeUInt32LE(off,16);return Buffer.concat(parts.concat(cen,[e]));};
