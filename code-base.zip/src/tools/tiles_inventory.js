// Tile inventory generated from the rendered page (never typed). Renders every page on a data folder with every fold and view open,
// and records each tile (.mo-tile), card (.mo-card), chart (.mo-chart), table and About fold: id or key, page, label, value slot text,
// source-on-tap text, chips, link target, Needs lines, the data sources named on it, and the About-this text.
// usage: node tools/tiles_inventory.js [--data dir] [--out work/tiles_now.json]
'use strict';
const fs=require('fs');const path=require('path');const W=require('../tests/lib/web');
const ROOT=W.ROOT;const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const data=arg('--data')||ROOT+'/data_all';const blank=process.argv.includes('--blank');const out=arg('--out')||ROOT+(blank?'/work/tiles_blank.json':'/work/tiles_now.json');
const texts=d=>{const t={};for(const f of fs.readdirSync(d))if(f.endsWith('.json'))t[f.slice(0,-5)]=fs.readFileSync(path.join(d,f),'utf8');return t;};
/* --blank: every dataset keeps its columns but one row with every field null (the starter shape), so every card shows its own Needs line */
const sent=t=>{const raw=JSON.parse(t);const rows=Array.isArray(raw)?raw:raw.rows;const s={};Object.keys(rows[0]||{}).forEach(k=>s[k]=null);return JSON.stringify(Array.isArray(raw)?[s]:{rows:[s]});};
const load=d=>{const t=texts(d);if(!blank)return t;const o={};for(const k in t)o[k]=sent(t[k]);return o;};
/* wait until the page has stopped changing: lazily drawn cards and the lazily loaded self-test card appear late on a busy machine, so a fixed wait made the inventory (and the docs check that reads it) flaky */
const settle=async(p,t)=>{let last='',same=0;for(let i=0;i<80&&same<4;i++){await p.waitForTimeout(150);const sig=await p.evaluate(t=>{const pg=document.getElementById('page-'+t);return pg?pg.querySelectorAll('*').length+':'+pg.textContent.length:'none';},t);if(sig===last)same++;else{same=0;last=sig;}}};
(async()=>{const b=await W.launch();const h=W.harness(blank?'tiles_blank':'tiles',load(data));const p=await W.open(b,h);const res=[];
  for(const t of await W.pagesOf(p)){await W.tab(p,t);await W.openAll(p,t);
    await p.evaluate(()=>{const x=document.querySelector('#po-basis button[data-v="plan"]');if(x)x.click();});await settle(p,t);
    const items=await p.evaluate(t=>{const pg=document.getElementById('page-'+t);const o=[];const txt=e=>(e&&e.textContent||'').replace(/\s+/g,' ').trim();
      const chips=e=>[...e.querySelectorAll('.mx-chip,.mo-chip')].map(txt).filter(Boolean);
      const needs=e=>[...e.querySelectorAll('p,span,li,div')].filter(x=>!x.children.length&&/^Needs:/.test(txt(x))).map(txt);
      const srcs=e=>[...new Set([...(e.matches('[data-source]')?[e]:[]),...e.querySelectorAll('[data-source]')].flatMap(x=>x.getAttribute('data-source').split(/\s+/)))];
      const about=e=>{const d=e.querySelector('details.mx-about')||(e.nextElementSibling&&e.nextElementSibling.matches('details.mx-about')?e.nextElementSibling:null);return d?txt(d.querySelector('.mx-aboutbody')):'';};
      pg.querySelectorAll('.mo-tile').forEach(e=>{const l=e.querySelector('.mo-tl'),v=e.querySelector('.mo-tv');const card=e.closest('.mo-card');
        o.push({page:t,kind:'tile',key:e.getAttribute('data-tile-key')||'',label:txt(l),value:txt(v),source_tap:(v&&v.getAttribute('title'))||'',link_id:e.getAttribute('data-goto-id')||'',link_name:e.getAttribute('data-goto-name')||'',
          chips:chips(e),needs:needs(e),card:card?card.id:'',about:''});});
      pg.querySelectorAll('.mo-card').forEach(e=>{const hd=e.querySelector('h2,h3,.mo-collt');o.push({page:t,kind:'card',key:e.id||'',label:txt(hd),value:'',source_tap:e.querySelector('[data-tbase]')?e.querySelector('[data-tbase]').getAttribute('title')||'':'',
        link_id:e.getAttribute('data-goto-id')||'',link_name:e.getAttribute('data-goto-name')||'',chips:chips(e),needs:needs(e),sources:srcs(e),about:about(e)});});
      pg.querySelectorAll('.mo-chart[id]').forEach(e=>{const s=e.querySelector('svg');o.push({page:t,kind:'chart',key:e.id,label:(s&&s.getAttribute('aria-label'))||'',value:'',source_tap:'',link_id:'',link_name:'',chips:[],needs:needs(e),sources:srcs(e),about:''});});
      pg.querySelectorAll('table[id]').forEach(e=>{const c=e.closest('.mo-card');o.push({page:t,kind:'table',key:e.id,label:(e.getAttribute('aria-label')||(e.caption&&txt(e.caption))||''),value:'',source_tap:'',link_id:'',link_name:'',chips:[],needs:needs(e),sources:srcs(e),about:'',card:c?c.id:''});});
      return o;},t);
    res.push(...items);}
  await b.close();fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(res,null,1));console.log('tiles inventory: '+res.length+' rows ('+['tile','card','chart','table'].map(k=>res.filter(x=>x.kind===k).length+' '+k+'s').join(', ')+') -> '+path.relative(ROOT,out));})();
