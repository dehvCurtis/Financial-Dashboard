// Key metrics before and after, to the cent: one table per stage. Reads only calc outputs (tools/engine.js), so it works on any data.
// usage: node tools/numbers.js --a pageA.html[:dataA] --b pageB.html[:dataB] [--out table.md]
'use strict';
const fs=require('fs');const E=require('./engine.js');const path=require('path');const D=path.resolve(__dirname,'..');
const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const side=s=>{const [p,d]=s.split(':');return {page:p,data:d||D+'/data_all'};};
const M=[['Net worth','nw_rows',v=>(v.find(r=>r.item==='Net worth')||{}).amount],['Total debts','dti_calc',v=>v[0].total_balance],['Cash, savings and checking','nw_rows',v=>(v.find(r=>/^Cash/.test(r.item))||{}).amount],
 ['Debt to income, headline (no rent while a mortgage is on file) %','dti_calc',v=>v[0].back_end_pct],['Debt to income with rent %','dti_calc',v=>v[0].back_end_with_rent_pct],['Debt to income with card estimate %','dti_calc',v=>v[0].back_end_est_pct],
 ['Housing ratio %','dti_calc',v=>v[0].front_end_pct],['Debt payments a month','dti_calc',v=>v[0].debt_payments],['Debts missing a payment','dti_calc',v=>v[0].missing_payments],
 ['Total monthly obligations, a month','dti_calc',v=>v[0].obligations_monthly],['Total monthly obligations, a year','dti_calc',v=>v[0].obligations_annual],
 ['Bills a month','bills_calc',v=>v[0].total_monthly],['Take-home a month (payoff plan)','payoff_engine',v=>v[0].take_home],['Minimum payments a month','payoff_engine',v=>v[0].mins],['Surplus a month','payoff_engine',v=>v[0].surplus],
 ['Extra used by the plan','payoff_engine',v=>v[0].extra],['Smart plan total interest','payoff_engine',v=>Math.round(v[0].plans.smart.total_interest*100)/100],['Smart plan debt free month','payoff_engine',v=>v[0].plans.smart.end],
 ['Minimums only total interest','payoff_engine',v=>Math.round(v[0].plans.minimums.total_interest*100)/100],['Must-pay a month (runway)','runway_calc',v=>Math.round(v[0].mustpay*100)/100],['Cash runway, months','runway_calc',v=>Math.round(v[0].months*1000)/1000],
 ['Financial score','scores_calc',v=>v[0].financial.score==null?null:Math.round(v[0].financial.score*100)/100],['Risk score','scores_calc',v=>v[0].risk.score==null?null:Math.round(v[0].risk.score*100)/100],
 ['Retirement accounts now','retire_model',v=>v[0].start],['Balance at the target age, today, base path','age60_calc',v=>v[0].now_end],['Balance at the target age, every account maxed','age60_calc',v=>v[0].plan_end],
 ['Base path as % of the low goal (every account)','pace_calc',v=>v[0].pct_low_goal],['401(k) limit as % of pay','pct_calc',v=>Math.round(v[0].cap_pct*100)/100],['401(k) per paycheck to max','contrib_calc',v=>(v.find(r=>/401/.test(r.account))||{}).per_paycheck_max],
 ['Loan to value, combined %','ltv_calc',v=>v[0].combined_pct],['Home equity','home_calc',v=>v[0].equity],['Coverage: picture %','coverage_calc',v=>v[0].picture_pct],['Open tasks','task_rank_calc',v=>v[0].open_count],['Data requests still needed','task_rank_calc',v=>v[0].data_needed]];
function table(a,b){const ra=E.run(a).calcs,rb=E.run(b).calcs;const g=(r,c,f)=>{try{return r[c]&&r[c].status==='ok'&&r[c].value.length?f(r[c].value):null;}catch(e){return null;}};
  return M.map(([n,c,f])=>{const x=g(ra,c,f),y=g(rb,c,f);return {metric:n,calc:c,before:x,after:y,same:JSON.stringify(x)===JSON.stringify(y)};});}
exports.table=table;
if(require.main===module){const a=side(arg('--a')),b=side(arg('--b'));const t=table(a,b);const fmt=v=>v==null?'n/a':typeof v==='number'?v.toLocaleString('en-US',{maximumFractionDigits:3}):String(v);
  const md=['| Metric | Before | After | Changed |','|---|---|---|---|'].concat(t.map(r=>'| '+r.metric+' | '+fmt(r.before)+' | '+fmt(r.after)+' | '+(r.same?'':'changed')+' |')).join('\n');
  if(arg('--out'))fs.writeFileSync(arg('--out'),md+'\n');console.log(md);}
