// Three-way row merge of staged data folders onto a base, by row id (generic: any dataset with an id column).
// usage: node tools/merge_data.js --base <published dir> --into <starting dir> --add <staged dir> [--add <dir> ...] --out <dir> [--report r.md]
//   For each dataset: rows of --into are kept; each --add folder's changes relative to --base are applied row by row: a row only the
//   staged folder changed is taken from it; a row both changed differently is a conflict (listed, the --into version kept); a new row
//   whose id is free is appended; a new row whose id is taken by a different new row gets the next free id of the same prefix and every
//   reference to its old id inside that staged folder's new or changed rows (task_id, queue_id, linked_event) is rewritten.
'use strict';
const fs=require('fs');const path=require('path');
const A=process.argv;const arg=k=>{const i=A.indexOf(k);return i>0?A[i+1]:null;};const adds=A.map((x,i)=>x==='--add'?A[i+1]:null).filter(Boolean);
const base=arg('--base'),into=arg('--into'),out=arg('--out'),rep=arg('--report');
const ID={liabilities:'liability_id',bills:'bill_id',assets_other:'asset_id',tasks:'id',data_queue:'queue_id',cash_events:'event_id',balance_log:'log_id',card_transactions:'txn_id',contributions:'account_id',income_pay:'income_id',savings_goals:'goal_id',milestones:'milestone_id',drift_history:'check_id',card_statements:'statement_id',bill_statements:null,profile_answers:'question_id',assumptions:'item',retirement_plan:'item'};
const rd=(d,f)=>{const p=path.join(d,f);if(!fs.existsSync(p))return null;const t=fs.readFileSync(p,'utf8');const raw=JSON.parse(t);return {raw,rows:Array.isArray(raw)?raw:raw.rows,nl:t.endsWith('\n')};};
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
require('./safe_out').safeOut(out);fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true});
const files=[...new Set([into,...adds].flatMap(d=>fs.readdirSync(d).filter(f=>f.endsWith('.json'))))].sort();const log=[];const conflicts=[];
for(const f of files){const id=f.slice(0,-5);const key=ID[id];const B0=rd(base,f),I=rd(into,f);let cur=I?JSON.parse(JSON.stringify(I.rows)):null;let wrapped=I?!Array.isArray(I.raw):false,nl=I?I.nl:true;
  for(const d of adds){const S=rd(d,f);if(!S)continue;if(!cur){cur=JSON.parse(JSON.stringify(S.rows));wrapped=!Array.isArray(S.raw);nl=S.nl;log.push(id+': new dataset from '+path.basename(path.dirname(d)));continue;}
    if(B0&&same(B0.rows,S.rows))continue;
    if(!key){if(B0&&!same(B0.rows,cur)&&!same(S.rows,cur))conflicts.push(id+': no id column and both sides changed; kept the starting version');else cur=JSON.parse(JSON.stringify(S.rows));continue;}
    const bmap=new Map((B0?B0.rows:[]).map(r=>[r[key],r]));const rename={};
    for(const r of S.rows){const k=r[key];const b=bmap.get(k);if(b&&same(b,r))continue;const ci=cur.findIndex(x=>x[key]===k);
      if(b){/* changed by the staged folder */if(ci<0){cur.push(r);log.push(id+' '+k+': changed row (missing from start) appended');}else if(same(cur[ci],b)){cur[ci]=r;log.push(id+' '+k+': changed ('+path.basename(path.dirname(d))+')');}else if(!same(cur[ci],r)){conflicts.push(id+' '+k+': changed on both sides; kept the starting version');}}
      else{/* new row */if(ci<0){cur.push(r);log.push(id+' '+k+': added ('+path.basename(path.dirname(d))+')');}else if(!same(cur[ci],r)){const m=String(k).match(/^([A-Za-z_]*)(\d+)$/);let n=m?+m[2]:0;let nk;do{n++;nk=(m?m[1]:k+'_')+n;}while(cur.some(x=>x[key]===nk)||S.rows.some(x=>x[key]===nk));
        rename[k]=nk;const r2=Object.assign({},r,{[key]:nk});cur.push(r2);log.push(id+' '+k+': id taken, added as '+nk);}}}
    if(Object.keys(rename).length)log.push(id+': renamed '+JSON.stringify(rename)+' (references in the other datasets of that folder are rewritten below)'),(global.__ren=global.__ren||[]).push({dir:d,id,rename});}
  if(cur&&I&&same(cur,I.rows)){fs.copyFileSync(path.join(into,f),path.join(out,f));continue;}
  if(cur){const t=JSON.stringify(wrapped?Object.assign({},I?I.raw:{},{rows:cur}):cur,null,1)+(nl?'\n':'');fs.writeFileSync(path.join(out,f),t);}}
/* rewrite references to renamed ids (task_id, queue_id, linked_event) in rows that came from the same staged folder */
for(const R of global.__ren||[]){for(const f of fs.readdirSync(out)){const p=path.join(out,f);const t=fs.readFileSync(p,'utf8');const raw=JSON.parse(t);const rows=Array.isArray(raw)?raw:raw.rows;let ch=false;
  rows.forEach(r=>{['task_id','queue_id','linked_event'].forEach(c=>{if(typeof r[c]==='string'){const v=r[c].replace(/\b[A-Z]+\d+\b/g,x=>R.rename[x]&&R.id!==f.slice(0,-5)?R.rename[x]:x);if(v!==r[c]){r[c]=v;ch=true;}}});});
  if(ch){fs.writeFileSync(p,JSON.stringify(raw,null,1)+(t.endsWith('\n')?'\n':''));log.push(f+': references rewritten for '+JSON.stringify(R.rename));}}}
const md=['# Data merge report','','Base (published): `'+base+'`','Start: `'+into+'`','Added: '+adds.map(a=>'`'+a+'`').join(', '),'','## Row changes','',...log.map(l=>'- '+l),'','## Conflicts','',...(conflicts.length?conflicts.map(c=>'- '+c):['None'])].join('\n')+'\n';
if(rep)fs.writeFileSync(rep,md);console.log(log.length+' row changes, '+conflicts.length+' conflicts');conflicts.forEach(c=>console.log('CONFLICT '+c));
