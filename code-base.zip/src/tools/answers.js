// Answers index: the headline numbers, every asset and debt row, the drift parts, the Needs list and what changed since the last index,
// each with value, unit, calc, the stored row it comes from, basis, as_of and source. Written to out/answers/answers.json after each build.
// It is a CACHE for fast answers. It is never a calc input and never a source of truth: the stored rows are. It carries the hash of data_all.
// usage: node tools/answers.js [--today YYYY-MM-DD] [--out file] [--data dir]     write the index (refuses when any calc is not ok)
//        node tools/answers.js --check [--today YYYY-MM-DD]          prints STALE and exits 1 when data_all or the date changed since the index was written
// Rule for answering from it: run --check first; if it prints STALE, rebuild it; always state basis and as_of with a number.
'use strict';
const fs=require('fs');const path=require('path');const crypto=require('crypto');const D=path.resolve(__dirname,'..');
const E=require('./engine.js');const TODAY=require('./today.js');
const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const OUT=arg('--out')||D+'/out/answers/answers.json';const DATADIR=arg('--data')||D+'/data_all';const today=TODAY.today(arg('--today'));
const RANK=['reported','stated','derived','expected','estimated'];/* strongest to weakest */
/* hash of every file in data_all (names and bytes): the index is valid only for this exact data */
function dataHash(){const h=crypto.createHash('sha256');fs.readdirSync(DATADIR).filter(f=>f.endsWith('.json')).sort().forEach(f=>{h.update(f+'\n');h.update(fs.readFileSync(DATADIR+'/'+f));});return h.digest('hex');}
if(process.argv.includes('--check')){let idx;try{idx=JSON.parse(fs.readFileSync(OUT,'utf8'));}catch(e){console.log('STALE: no index at '+path.relative(D,OUT)+' (run node tools/answers.js)');process.exit(1);}
  const why=[];if(idx.data_hash!==dataHash())why.push('data_all changed since the index was written');if(arg('--today')&&idx.as_of_today!==today)why.push('built for '+idx.as_of_today+', asked for '+today);
  if(why.length){console.log('STALE: '+why.join('; ')+' (run node tools/answers.js)');process.exit(1);}console.log('FRESH: index built '+idx.built_at+' for '+idx.as_of_today+', data hash '+idx.data_hash.slice(0,12));process.exit(0);}

const PAGE=D+'/out/index_page.html';const R=E.run({page:PAGE,data:DATADIR,today});
const bad=Object.keys(R.calcs).filter(k=>R.calcs[k].status!=='ok');if(bad.length){console.error('Not written: calcs not ok: '+bad.join(', '));process.exit(1);}
const v1=k=>{const c=R.calcs[k];return (c&&c.value&&c.value[0])||{};};
const rowsOf=k=>(R.calcs[k]&&R.calcs[k].value)||[];
const DATA={};const ds=id=>DATA[id]||(DATA[id]=JSON.parse(fs.readFileSync(DATADIR+'/'+id+'.json','utf8')));
const IDK={assets_other:'asset_id',liabilities:'liability_id',bills:'bill_id',income_pay:'income_id',networth_history:'date',balance_log:'log_id',payoff_settings:'setting_id',cash_events:'event_id',data_queue:'queue_id',tasks:'id'};
/* a row path is dataset/id.field; id may be * for every row of the dataset */
function rowsFor(p){const m=/^([a-z_]+)\/([^.]+)\.(.+)$/.exec(p);if(!m)return [];const rows=ds(m[1]),k=IDK[m[1]];return rows.filter(r=>m[2]==='*'||String(r[k])===m[2]).map(r=>({r,field:m[3]}));}
function basisOf(paths){const rs=paths.flatMap(rowsFor).map(x=>x.r).filter(r=>r.value_basis);if(!rs.length)return {basis:null,as_of:null,source:null};
  const weakest=rs.map(r=>r.value_basis).sort((a,b)=>RANK.indexOf(b)-RANK.indexOf(a))[0];const dates=rs.map(r=>r.as_of_date).filter(Boolean).sort();
  return {basis:weakest,as_of:dates[0]||null,source:rs.length===1?(rs[0].source||null):rs.length+' stored rows'};}
const r2=x=>x==null?null:Math.round(x*100)/100;
const nw=n=>(rowsOf('nw_rows').find(r=>r.item===n)||{});
const pe=v1('payoff_engine'),dti=v1('dti_calc'),bl=v1('bills_calc'),rw=v1('runway_calc'),sc=v1('scores_calc'),dr=v1('drift_all'),cv=v1('coverage_calc');
const latestNW=ds('networth_history').slice().sort((a,b)=>a.date<b.date?-1:1).pop();
const sur=pe.surplus;
const H=[];/* headline: id, label, unit, calc, value, rows (stored), basis override */
const add=(id,label,unit,calc,value,rows,o)=>{o=o||{};const b=o.basis?{basis:o.basis.weakest||o.basis,as_of:o.basis.oldest_as_of||o.as_of||null,source:o.source||null}:basisOf(rows||[]);
  H.push(Object.assign({id,label,value:value==null?null:(typeof value==='number'?Math.round(value*10000)/10000:value),unit,calc,rows:rows||[],basis:b.basis,as_of:b.as_of||o.as_of||null,source:b.source||o.source||'calculation from the stored rows'},o.extra||{}));};
/* rows are found by type and name, never by a fixed id: a user may have no house, no mortgage or no separate checking account */
const realRows=id=>ds(id).filter(r=>Object.values(r).some(v=>v!=null));
const cashRows=realRows('assets_other').filter(r=>r.type==='Cash');
const savA=cashRows.find(r=>/sav/i.test(r.name||''))||null,chkA=cashRows.find(r=>/check/i.test(r.name||''))||null,houseA=realRows('assets_other').find(r=>r.type==='Real estate')||null;
const homeDebts=realRows('liabilities').filter(r=>r.type==='Mortgage'||r.type==='HELOC');
const A=(r,f)=>r?['assets_other/'+r.asset_id+'.'+(f||'value_point')]:[],Lb=r=>r?['liabilities/'+r.liability_id+'.balance']:[];
const homeRows=A(houseA).concat(...homeDebts.map(Lb)),mortRow=realRows('liabilities').find(r=>r.type==='Mortgage')||null;
add('net_worth','Net worth','USD','nw_rows',nw('Net worth').amount,['networth_history/'+latestNW.date+'.net_worth'],{basis:{weakest:nw('Net worth').basis,oldest_as_of:nw('Net worth').oldest_as_of},source:'networth_history row for '+latestNW.date+' (equals the sum of the item rows, check C1)'});
add('total_debts','Total debts (sum of reported balances)','USD','dti_calc',dti.total_balance,['liabilities/*.balance'],{basis:dti.basis_balances});
add('cash_total','Cash, savings and checking (net worth line)','USD','nw_rows',nw('Cash, savings and checking').amount,A(savA).concat(A(chkA)),{basis:{weakest:nw('Cash, savings and checking').basis,oldest_as_of:nw('Cash, savings and checking').oldest_as_of}});
add('savings_balance','Savings balance','USD','nw_rows',savA?savA.value_point:null,A(savA));
add('checking_posted','Checking posted balance','USD','nw_rows',chkA?chkA.value_point:null,A(chkA));
add('retirement_accounts','Retirement accounts','USD','nw_rows',nw('Retirement accounts').amount,[]);
add('home_equity','Home equity','USD','home_calc',v1('home_calc').equity,homeRows);
add('ltv_combined_pct','Loan to value, combined','percent','ltv_calc',v1('ltv_calc').combined_pct,homeRows);
add('dti_headline_pct','Debt to income (no rent while a mortgage is on file)','percent','dti_calc',dti.back_end_pct,['liabilities/*.monthly_payment','bills/*.amount'],{basis:dti.basis_payments});
add('dti_with_rent_pct','Debt to income with rent','percent','dti_calc',dti.back_end_with_rent_pct,['liabilities/*.monthly_payment','bills/*.amount'],{basis:dti.basis_payments});
add('housing_ratio_pct','Housing ratio','percent','dti_calc',dti.front_end_pct,mortRow?['liabilities/'+mortRow.liability_id+'.monthly_payment']:[]);
add('debt_payments_month','Debt payments a month','USD','dti_calc',dti.debt_payments,['liabilities/*.monthly_payment'],{basis:dti.basis_payments});
add('bills_month','Bills a month','USD','bills_calc',bl.total_monthly,['bills/*.amount'],{basis:{weakest:bl.basis,oldest_as_of:bl.oldest_as_of}});
add('take_home_month','Take-home a month (payoff plan)','USD','payoff_engine',pe.take_home,['income_pay/*.per_paycheck']);
add('surplus_month','Monthly surplus (take-home less bills less debt payments)','USD','payoff_engine',sur,[],{basis:{weakest:'estimated',oldest_as_of:null},source:'budget figure: take-home '+pe.take_home+' less bills '+pe.bills+' less debt payments '+pe.mins+'; other spending and the unexplained drift are not in it'});
add('plan_extra_steady','Extra a month the plan pays (steady)','USD','payoff_engine',pe.extra,[]);
add('plan_extra_first','Extra in the first month (after the cash cushion hold)','USD','payoff_engine',pe.extra_first,[]);
add('cushion_hold','One-time cash cushion shortfall held out of the first month','USD','payoff_engine',pe.cushion_hold,A(savA));
add('smart_interest','Smart plan total interest','USD','payoff_engine',r2(((pe.plans||{}).smart||{}).total_interest),[],{extra:{depends_on:['surplus_month']}});
add('smart_debt_free','Smart plan debt free month','month','payoff_engine',((pe.plans||{}).smart||{}).end,[],{extra:{depends_on:['surplus_month'],note:'This date moves with the monthly surplus input. If the surplus is not real cash left each month, the date is later.'}});
add('minimums_interest','Minimums only total interest','USD','payoff_engine',r2(((pe.plans||{}).minimums||{}).total_interest),[]);
add('mustpay_month','Must-pay a month (runway)','USD','runway_calc',r2(rw.mustpay),['bills/*.amount','liabilities/*.monthly_payment']);
add('runway_cash','Runway cash (spendable)','USD','runway_calc',r2(rw.liquid),A(savA));
add('runway_months','Cash runway, months','months','runway_calc',Math.round(rw.months*1000)/1000,A(savA));
add('financial_score','Financial score','points','scores_calc',!sc.financial||sc.financial.score==null?null:r2(sc.financial.score),[]);
add('risk_score','Risk score','points','scores_calc',!sc.risk||sc.risk.score==null?null:r2(sc.risk.score),[]);
add('unexplained_drift_total','Unexplained drift, total of the shortfalls','USD','coverage_calc',cv.unexplained,['balance_log/*.balance','cash_events/*.amount']);
add('explained_share_pct','Explained share of the drift checks','percent','coverage_calc',r2(cv.explained_pct),[],{extra:{note:'Known outflow excludes internal transfers and includes confirmed waiting payments.'}});
const lo=(dr.left_over||[])[0];
add('checking_left_over','Checking left over once the waiting payments clear (should be 0)','USD','drift_all',lo?lo.left_over:null,['cash_events/*.amount'].concat(A(chkA)),{basis:{weakest:'derived',oldest_as_of:lo?lo.posted_date:null},source:'posted Checking less the payments waiting to clear',extra:{waiting_rows:lo?lo.rows:[]}});
add('open_tasks','Open tasks','count','task_rank_calc',v1('task_rank_calc').open_count,['tasks/*.status']);
add('data_needed','Data requests still needed','count','task_rank_calc',v1('task_rank_calc').data_needed,['data_queue/*.status']);
add('retire_target_now','Balance at the target age, today, base path','USD','age60_calc',v1('age60_calc').now_end,[]);
add('retire_target_max','Balance at the target age, every account maxed','USD','age60_calc',v1('age60_calc').plan_end,[]);
const unitless=H.filter(h=>h.value==null);
/* every asset and debt row */
const accounts=ds('assets_other').map(r=>({kind:'asset',id:r.asset_id,name:r.name,value:r.value_point,row:'assets_other/'+r.asset_id,basis:r.value_basis||null,as_of:r.as_of_date||null,source:r.source||null}))
 .concat(ds('liabilities').map(r=>({kind:'debt',id:r.liability_id,name:r.name,value:r.balance,monthly_payment:r.monthly_payment,rate_pct:r.rate_pct,row:'liabilities/'+r.liability_id,basis:r.value_basis||null,as_of:r.as_of_date||null,source:r.source||null,payment_basis:r.payment_basis||null})));
/* secondary number: the expected-balance total. Expected balances are not reported readings, so the headline stays the reported sum. */
const expRows=ds('liabilities').filter(r=>r.expected_balance!=null&&r.balance!=null&&r.expected_balance!==r.balance);
const expTotal=r2(ds('liabilities').reduce((s,r)=>s+(r.balance==null?0:(r.expected_balance!=null?r.expected_balance:r.balance)),0));
const secondary=[{id:'total_debts_expected',label:'Total debts if every expected balance were the balance (secondary, not the headline)',value:expTotal,unit:'USD',basis:'expected',as_of:expRows.map(r=>r.expected_date).filter(Boolean).sort()[0]||null,rows:expRows.map(r=>'liabilities/'+r.liability_id+'.expected_balance'),
  note:'Headline total debts is the sum of reported balances ('+dti.total_balance+'). Difference '+r2(expTotal-dti.total_balance)+'. Rows with an expected balance: '+expRows.map(r=>r.liability_id).join(', ')+'.'}];
/* drift parts */
const drift={explained_pct:r2(dr.explained_pct==null?cv.explained_pct:dr.explained_pct),unexplained_total:dr.unexplained_total,known_outflow:dr.known_outflow,left_over:dr.left_over||[],
 pairs:(dr.accounts||[]).flatMap(a=>(a.points||[]).map(p=>({account:a.account,from:p.from,to:p.to,opening:p.opening,inflows:p.inflows,outflows:p.outflows,transfers_in:p.transfers_in,transfers_out:p.transfers_out,waiting_out:p.waiting_out,expected:p.expected,reported:p.reported,drift:p.drift})))};
const needs=rowsOf('needs_calc').filter(n=>!n.ready).map(n=>({key:n.key,subject:n.subject,text:n.text,queue_id:n.queue_id||null,task_id:n.task_id||null,request_status:n.request_status||null}));
/* what changed since the last index */
let prev=null;try{prev=JSON.parse(fs.readFileSync(OUT,'utf8'));}catch(e){}
const same=prev&&prev.data_hash===dataHash()&&prev.as_of_today===today;/* same data: keep the list of changes against the index before it */
const changes=same?null:prev?H.filter(h=>{const p=(prev.headlines||[]).find(x=>x.id===h.id);return !p||JSON.stringify(p.value)!==JSON.stringify(h.value);}).map(h=>{const p=(prev.headlines||[]).find(x=>x.id===h.id);return {id:h.id,before:p?p.value:null,after:h.value};}):[];
const out={_what:'Answers index. A cache of calc outputs, never a calc input. Source of truth is the stored rows. Run node tools/answers.js --check first; always state basis and as_of with a number.',
 schema:1,as_of_today:today,built_at:new Date().toISOString().slice(0,10)===today?today:new Date().toISOString().slice(0,10),data_hash:dataHash(),
 headlines:H,secondary,accounts,drift,needs,changes_since_previous:same?prev.changes_since_previous:{previous_built_for:prev?prev.as_of_today:null,previous_hash:prev?prev.data_hash.slice(0,12):null,items:changes}};
const txt=JSON.stringify(out);if(/[\u2013\u2014]/.test(txt)){console.error('Not written: dash in output');process.exit(1);}
fs.mkdirSync(path.dirname(OUT),{recursive:true});/* one line per key, and one line per row of a list: readable and small */
const ser=Object.keys(out).map(k=>Array.isArray(out[k])?JSON.stringify(k)+':[\n'+out[k].map(x=>' '+JSON.stringify(x)).join(',\n')+'\n]':JSON.stringify(k)+':'+JSON.stringify(out[k]));
fs.writeFileSync(OUT,'{\n'+ser.join(',\n')+'\n}\n');
console.log('answers index: '+H.length+' headlines, '+accounts.length+' accounts, '+needs.length+' Needs rows, '+Math.round(fs.statSync(OUT).size/1024*10)/10+' KB, '+(same?'unchanged data':out.changes_since_previous.items.length+' changed since the last index')+(unitless.length?' (no value: '+unitless.map(h=>h.id).join(', ')+')':''));
