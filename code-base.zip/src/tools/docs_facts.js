// Collects the facts the generated documents are built from, all read from the code and the working data (never typed):
// datasets (ids, doc title and description, field names with the value types seen), calcs (title, description, inputs, readers, output shape),
// the check list (checks_calc and checks_more_calc), the profile questions (PROFILE_CATS), the score components and the tile inventory.
// usage: node tools/docs_facts.js [--data dir] [--out work/facts.json]
'use strict';
const fs=require('fs');const path=require('path');const E=require('./engine');
const ROOT=path.resolve(__dirname,'..');const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const data=arg('--data')||ROOT+'/data_all';const out=arg('--out')||ROOT+'/work/facts.json';const page=ROOT+'/out/index_page.html';
const html=fs.readFileSync(page,'utf8');const script=E.pageScript(page);
const r=E.run({page,data});
const DS=JSON.parse(script.match(/const DS=\/\*DATASET_IDS[^*]*\*\/(\[[^\]]*\])/)[1]);
const DOCS=JSON.parse(script.match(/const DOCS=(\{.*?\});\n/)[1]);
const PROFILE=[...script.matchAll(/\{q:'([a-z_]+)',cat:'([^']+)',kind:'([a-z]+)'/g)].map(m=>({q:m[1],cat:m[2],kind:m[3]}));
const ASK={};[...script.matchAll(/(\w+):'((?:a|an|any|rent|utility|insurance|transportation|subscriptions|childcare|pet|food)[^']*)'/g)].forEach(m=>{ASK[m[1]]=m[2];});
const askBlock=script.match(/const PROFILE_ASK=\{([\s\S]*?)\};/)[1];const ASK2={};[...askBlock.matchAll(/(\w+):'([^']*)'/g)].forEach(m=>{ASK2[m[1]]=m[2];});
const types=v=>v===null?'null':Array.isArray(v)?'array':typeof v;
const datasets={};
for(const id of DS){const f=path.join(data,id+'.json');const raw=JSON.parse(fs.readFileSync(f,'utf8'));const isObj=!Array.isArray(raw);const rows=isObj?(raw.rows||raw.data||raw.results):raw;
  const fields={};rows.forEach(row=>Object.keys(row).forEach(k=>{(fields[k]=fields[k]||new Set()).add(types(row[k]));}));
  datasets[id]={id,title:DOCS[id]&&DOCS[id].title,description:DOCS[id]&&DOCS[id].description,shape:isObj?'object with rows':'array',rows:rows.length,fields:Object.fromEntries(Object.entries(fields).map(([k,v])=>[k,[...v].sort()]))};}
const calcs={};for(const id of Object.keys(r.inputs)){const v=r.calcs[id].value;let shape=null;
  if(Array.isArray(v)){const first=v.find(x=>x&&typeof x==='object')||{};shape={kind:'array',rows:v.length,keys:Object.keys(first)};}else if(v&&typeof v==='object')shape={kind:'object',keys:Object.keys(v)};else shape={kind:typeof v};
  calcs[id]={id,title:r.metas[id].title,description:r.metas[id].description,inputs:r.inputs[id],status:r.calcs[id].status,shape};}
for(const id in calcs)calcs[id].readers=Object.keys(calcs).filter(c=>calcs[c].inputs.includes(id));
for(const id in datasets)datasets[id].calcs=Object.keys(calcs).filter(c=>calcs[c].inputs.includes(id));
const checks=[];for(const id of ['checks_calc','checks_more_calc'])(r.calcs[id].value||[]).forEach(c=>checks.push({id:c.id,name:c.name,calc:id}));
const cfg=JSON.parse(fs.readFileSync(path.join(data,'scores_config.json'),'utf8')).rows[0];
const comps=['financial','risk'].flatMap(s=>cfg[s].components.map(c=>({score:s,id:c.id,name:c.name,weight:c.weight,best:c.best,worst:c.worst,unit:c.unit,gated:!!c.gated})));
const tiles=fs.existsSync(ROOT+'/work/tiles_now.json')?JSON.parse(fs.readFileSync(ROOT+'/work/tiles_now.json','utf8')):[];
const invariants=[...fs.readFileSync(ROOT+'/page/invariants.js','utf8').matchAll(/\bI(\d+)\b[^\n]{0,0}/g)].length;
const facts={datasets,calcs,checks,profile:PROFILE.map(p=>Object.assign(p,{ask:ASK2[p.q]||null})),score_components:comps,tiles,ds_order:DS,calc_order:Object.keys(r.inputs)};
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(facts,null,1));
console.log('facts: '+DS.length+' datasets, '+Object.keys(calcs).length+' calcs, '+checks.length+' checks, '+PROFILE.length+' profile questions, '+tiles.length+' tile rows');
