// Dependency map: dataset -> calc -> card, generated from the code (never typed by hand).
//   calc inputs come from the page's own dash.calc registrations (tools/engine.js);
//   cards come from data-source attributes in the markup and from each draw function's reads (rows('x'), one('x'), dash.data('x'))
//   paired with the element ids it fills ($('id'), getElementById('id')), found by parsing the script with acorn.
// usage: node tools/depmap.js [page.html] [--json out.json] [--changed ds1,ds2]  (prints the affected calcs, cards and unit tests)
// module: affected(changed, {page}) -> {datasets, calcs, cards, tests}
'use strict';
const fs=require('fs');const path=require('path');const ROOT=path.resolve(__dirname,'..');
const acorn=require('acorn');
function build(page){page=page||ROOT+'/out/index_page.html';const html=fs.readFileSync(page,'utf8');const E=require('./engine.js');
  const r=E.run({page,data:ROOT+'/data_all'});const inputs=r.inputs;const calcs=Object.keys(inputs);const datasets=Object.keys(r.datasets);
  const known=new Set(calcs.concat(datasets));
  /* markup data-source */
  const cards={};const addCard=(id,src)=>{if(!known.has(src))return;(cards[id]=cards[id]||new Set()).add(src);};
  for(const m of html.matchAll(/id="([^"]+)"[^>]*data-source="([^"]+)"|data-source="([^"]+)"[^>]*id="([^"]+)"/g)){const id=m[1]||m[4],src=m[2]||m[3];src.split(/[ ,]+/).forEach(s=>addCard(id,s));}
  /* draw functions: reads and element ids */
  const script=html.match(/<script>([\s\S]*)<\/script>/)[1];const ast=acorn.parse(script,{ecmaVersion:2022,sourceType:'script'});
  const lit=n=>n&&n.type==='Literal'&&typeof n.value==='string'?n.value:null;
  const walk=(n,f)=>{if(!n||typeof n!=='object')return;if(Array.isArray(n)){n.forEach(x=>walk(x,f));return;}f(n);for(const k in n)if(k!=='type'&&n[k]&&typeof n[k]==='object')walk(n[k],f);};
  const fnReads={};
  for(const s of ast.body){if(s.type!=='FunctionDeclaration')continue;const reads=new Set(),ids=new Set();
    walk(s.body,n=>{if(n.type!=='CallExpression')return;const c=n.callee;const name=c.type==='Identifier'?c.name:c.type==='MemberExpression'&&c.property?c.property.name:null;const a=lit(n.arguments[0]);if(!a)return;
      if(['rows','one','data','calcWhy'].includes(name)&&known.has(a))reads.add(a);if(name==='$'||name==='getElementById')ids.add(a);});
    fnReads[s.id.name]={reads:[...reads],ids:[...ids]};
    if(reads.size)ids.forEach(id=>reads.forEach(rd=>addCard(id,rd)));}
  /* reverse: what each dataset or calc feeds */
  const feeds={};calcs.forEach(c=>inputs[c].forEach(i=>{(feeds[i]=feeds[i]||new Set()).add(c);}));
  const out={page:path.relative(ROOT,page),datasets,calcs,inputs,cards:Object.fromEntries(Object.entries(cards).map(([k,v])=>[k,[...v].sort()])),feeds:Object.fromEntries(Object.entries(feeds).map(([k,v])=>[k,[...v].sort()])),draw_functions:fnReads};
  return out;}
function affected(changed,opt){const M=build(opt&&opt.page);const calcs=new Set();const q=[...changed];
  while(q.length){const x=q.shift();(M.feeds[x]||[]).forEach(c=>{if(!calcs.has(c)){calcs.add(c);q.push(c);}});}
  const hit=new Set(changed.concat([...calcs]));const cards=Object.keys(M.cards).filter(id=>M.cards[id].some(s=>hit.has(s))).sort();
  return {datasets:changed,calcs:[...calcs].sort(),cards,tests:{unit_only:[...calcs].sort(),always:['inv_run','data_rules','static_scan']}};}
exports.build=build;exports.affected=affected;
if(require.main===module){const a=process.argv.slice(2);const page=a[0]&&!a[0].startsWith('--')?a[0]:undefined;const i=a.indexOf('--json'),j=a.indexOf('--changed');
  if(j>=0){const r=affected(a[j+1].split(','),{page});console.log(JSON.stringify(r,null,1));}
  else{const M=build(page);if(i>=0)fs.writeFileSync(a[i+1],JSON.stringify(M,null,1));console.log(M.datasets.length+' datasets, '+M.calcs.length+' calcs, '+Object.keys(M.cards).length+' cards with a data source');}}
