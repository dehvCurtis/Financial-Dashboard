// Dead code sweep over a built page: node tools/deadcode.js [page.html] [datadir] > report.json
// Lists (1) top-level functions and consts that nothing else references, (2) calcs no reader names, (3) CSS class and id selectors that
// no markup or script string uses, (4) element ids in the markup that no script, CSS rule, data-open or label points at (informational),
// (5) dataset fields the page code never names (user data: listed, never deleted).
const fs=require('fs');const path=require('path');
const acorn=require('acorn');
const walk={full(node,cb){const go=n=>{if(!n||typeof n!=='object')return;if(Array.isArray(n)){n.forEach(go);return;}if(typeof n.type==='string')cb(n);for(const k in n){if(k==='start'||k==='end'||k==='loc')continue;const v=n[k];if(v&&typeof v==='object')go(v);}};go(node);}};
const D=path.resolve(__dirname,'..');const PG=process.argv[2]||D+'/out/index_page.html';const DATA=process.argv[3]||D+'/data_all';
const page=fs.readFileSync(PG,'utf8');const m=page.match(/<script>([\s\S]*)<\/script>/);const js=m[1];const html=page.replace(m[0],'');
const css=(html.match(/<style>([\s\S]*?)<\/style>/)||['',''])[1];const markup=html.replace(/<style>[\s\S]*?<\/style>/,'');
const ast=acorn.parse(js,{ecmaVersion:2022,sourceType:'script'});
const decl=[];ast.body.forEach(n=>{if(n.type==='FunctionDeclaration')decl.push({name:n.id.name,kind:'function',start:n.start,end:n.end});
  else if(n.type==='VariableDeclaration')n.declarations.forEach(d=>{if(d.id.type==='Identifier')decl.push({name:d.id.name,kind:n.kind,start:d.start,end:d.end});});});
const refs=Object.create(null);walk.full(ast,node=>{if(node.type==='Identifier'){(refs[node.name]=refs[node.name]||[]).push(node.start);}});
const unusedTop=decl.filter(d=>{const r=(refs[d.name]||[]).filter(s=>s<d.start||s>=d.end);return r.length===0;}).map(d=>d.name+' ('+d.kind+')');
// calcs and their readers
const calcIds=[...js.matchAll(/dash\.calc\('([A-Za-z0-9_]+)'/g)].map(x=>x[1]);
const strs=[];walk.full(ast,node=>{if(node.type==='Literal'&&typeof node.value==='string')strs.push(node.value);if(node.type==='TemplateElement')strs.push(node.value.cooked||'');});
const allText=strs.join('\n')+'\n'+markup;
const calcReaders=Object.create(null);calcIds.forEach(id=>{let n=0;const re=new RegExp("(^|[^A-Za-z0-9_])"+id+"($|[^A-Za-z0-9_])");
  strs.forEach(s=>{if(s===id||(/ /.test(s)&&s.split(/\s+/).includes(id)))n++;});(markup.match(new RegExp('data-source="[^"]*\\b'+id+'\\b','g'))||[]).forEach(()=>n++);calcReaders[id]=n-1;});
const noReader=calcIds.filter(id=>calcReaders[id]<=0);
// CSS selectors
const classes=new Set(),ids=new Set();css.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\{[^{}]*\}/g,'{}').split('{}').forEach(sel=>{(sel.match(/\.[A-Za-z][\w-]*/g)||[]).forEach(c=>classes.add(c.slice(1)));(sel.match(/#[A-Za-z][\w-]*/g)||[]).forEach(i=>ids.add(i.slice(1)));});
const used=w=>new RegExp('(^|[^\\w-])'+w.replace(/[-]/g,'\\-')+'($|[^\\w-])').test(allText);
const unusedClasses=[...classes].filter(c=>!used(c)).sort();
const unusedCssIds=[...ids].filter(i=>!used(i)).sort();
// markup ids nothing refers to (informational: many ids exist so readers and tests can find a card)
const mids=[...markup.matchAll(/\sid="([^"]+)"/g)].map(x=>x[1]);const jsText=strs.join('\n');
const loneIds=mids.filter(i=>!jsText.includes(i)&&!ids.has(i)&&!new RegExp('(data-open|for|aria-controls|aria-labelledby|href)="#?'+i+'"').test(markup)).sort();
// dataset fields never named by the page code
const fields=Object.create(null);for(const f of fs.readdirSync(DATA).filter(f=>f.endsWith('.json'))){let v=JSON.parse(fs.readFileSync(DATA+'/'+f,'utf8'));if(!Array.isArray(v))v=v.rows||v.data||v.results||[v];
  const keys=new Set();v.forEach(r=>{if(r&&typeof r==='object')Object.keys(r).forEach(k=>keys.add(k));});
  const un=[...keys].filter(k=>!new RegExp('(\\.|\\[\\\'|\\\'|"|\\b)'+k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b').test(js));if(un.length)fields[f.replace('.json','')]=un;}
const rep={page:PG,unused_top_level:unusedTop,calcs:calcIds.length,calcs_without_reader:noReader,unused_css_classes:unusedClasses,unused_css_ids:unusedCssIds,markup_ids_not_referenced:loneIds,dataset_fields_not_named_in_code:fields};
console.log(JSON.stringify(rep,null,1));
