// Writes data_all/ (the working data folder the tests and tools read) as an INVENTED example household.
// Source: tests/fixtures/base (invented round numbers). The seed renames every vendor, account and store to an "Example ..." name and
// scales the money fields, so the working data differs from the unit-test fixture and the "no user term, no user figure in tests" scan
// has something real to compare against. Nothing here is a real person's data.
// usage: node tools/seed_example.js [outdir]   (default data_all)
'use strict';
const fs=require('fs');const path=require('path');
const ROOT=path.resolve(__dirname,'..');const SRC=ROOT+'/tests/fixtures/base';const OUT=process.argv[2]||ROOT+'/data_all';
const REF=new Set(['age_benchmarks','age_metrics_config','scores_config','dti_benchmarks','ltv_benchmarks','contribution_limits']);
const NAMES=[['Card A','Example Card Alpha'],['Card B','Example Card Beta'],['Store A','Example Market'],['Store B','Example Outlet'],['Account A','Example Checking Alpha'],['Account B','Example Savings Beta'],
 ['Home loan','Example Home Loan'],['Credit line','Example Credit Line'],['Car loan','Example Auto Loan'],['Clinic','Example Provider Group'],['Phone plan','Example Phone Plan'],['Apartment rent','Example Landlord LLC'],['Streaming','Example Streaming'],
 ['FUND A STOCK INDEX','EXAMPLE TOTAL STOCK FUND'],['FUND B BOND INDEX','EXAMPLE TOTAL BOND FUND'],['Index Fund One','Example Growth Fund'],['Index Fund Two','Example Income Fund'],['Index One','Ex Growth'],['Index Two','Ex Income'],
 ['First account','Example Plan One'],['Second account','Example Plan Two'],['First 401(k)','Example Plan One'],['Second 401(k)','Example Plan Two'],['Old plan 401(k)','Example Old Plan']];
const MONEY=/(amount|balance|value|gross|net|tax|fica|k401|hsa|benefit|garnish|payment|interest|principal|escrow|salary|price|cost|fee|limit|ytd|total|credits|debits|dividends|opening|closing|inflow|outflow|expected|reported|drift|assets|debts|retirement|per_paycheck|annual|target|saved|contribution|monthly|purchase|advance|quantity|basis|gain|due)/i;
const NOT=/(pct|rate|day|count|year|apr|apy|age|months|ratio|priority|score|weight|points|order|period|paychecks|days|id$)/i;
const scale=(v,k)=>typeof v==='number'&&MONEY.test(k||'')&&!NOT.test(k||'')?Math.round(v*1.35*100)/100:v;
const rename=s=>NAMES.reduce((x,[a,b])=>x.split(a).join(b),s).replace(/\bfixture text\b/g,'Example note').replace(/\bfixture\b/g,'example');
function tr(o,k,top){if(Array.isArray(o))return o.map(x=>tr(x,k,top));
  if(o&&typeof o==='object'){const r={};
    /* settings rows (item, value): ages, rates and percents keep their value; only dollar settings are scaled */
    if((top==='retirement_plan'||top==='assumptions')&&'item' in o&&'value' in o){for(const x in o)r[x]=x==='value'?(top==='retirement_plan'&&/goal|annual|payroll|backdoor|hsa/.test(o.item)&&typeof o.value==='number'?Math.round(o.value*1.35):o.value):tr(o[x],x,top);return r;}
    for(const x in o)r[x]=tr(o[x],x,top);return r;}
  return typeof o==='string'?rename(o):scale(o,k);}
fs.mkdirSync(OUT,{recursive:true});let n=0;
for(const f of fs.readdirSync(SRC).filter(f=>f.endsWith('.json'))){const id=f.slice(0,-5);let t=fs.readFileSync(path.join(SRC,f),'utf8');
  if(!REF.has(id)){t=JSON.stringify(tr(JSON.parse(t),null,id),null,1)+'\n';}
  /* the demo limits differ from the unit-test fixture so no test literal equals a demo figure (invented numbers, refresh them every year) */
  if(id==='contributions'){const j=JSON.parse(t);j.forEach(r=>{if(/401/.test(r.account||''))r.limit_annual=23000;});t=JSON.stringify(j,null,1)+'\n';}
  if(id==='contribution_limits'){const j=JSON.parse(t);j.forEach(r=>{r.k401_deferral=23000;r.hsa_self=4300;r.hsa_family=8550;r.k401_total_additions=69000;r.ira=7500;});t=JSON.stringify(j,null,1)+'\n';}
  fs.writeFileSync(path.join(OUT,f),t);n++;}
console.log('seeded '+n+' datasets into '+path.relative(ROOT,OUT));
