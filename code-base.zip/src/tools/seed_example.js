// Writes data_all/ (the working data folder the tests and tools read) as an INVENTED example household.
// Source: tests/fixtures/base (invented round numbers). The seed renames every vendor, account and store to an "Example ..." name and
// scales the money fields, so the working data differs from the unit-test fixture and the "no user term, no user figure in tests" scan
// has something real to compare against. Nothing here is a real person's data.
// usage: node tools/seed_example.js [outdir]   (default data_all)
'use strict';
const fs=require('fs');const path=require('path');
const ROOT=path.resolve(__dirname,'..');const SRC=ROOT+'/tests/fixtures/base';const OUT=process.argv[2]||ROOT+'/data_all';
const REF=new Set(['age_benchmarks','age_metrics_config','scores_config','dti_benchmarks','ltv_benchmarks','contribution_limits']);
const NAMES=[['Card A','Example Card Alpha'],['Card B','Example Card Beta'],['Store A','Example Market'],['Store B','Example Outlet'],['Account A','Example Checking Alpha'],['Account B','Example Savings Beta'],
 ['Home loan','Example Home Loan'],['Credit line','Example Credit Line'],['Car loan','Example Auto Loan'],['Clinic','Example Provider Group'],['Phone plan','Example Phone Plan'],['Apartment rent','Example Landlord LLC'],['Streaming','Example Streaming'],
 ['FUND A STOCK INDEX','EXAMPLE TOTAL STOCK FUND'],['FUND B BOND INDEX','EXAMPLE TOTAL BOND FUND'],['Index Fund One','Example Growth Fund'],['Index Fund Two','Example Income Fund'],['Index One','Ex Growth'],['Index Two','Ex Income'],
 ['First account','Example Plan One'],['Second account','Example Plan Two'],['First 401(k)','Example Plan One'],['Second 401(k)','Example Plan Two'],['Old plan 401(k)','Example Old Plan']];
const MONEY=/(amount|balance|value|gross|net|tax|fica|k401|hsa|benefit|garnish|payment|interest|principal|escrow|salary|price|cost|fee|limit|ytd|total|credits|debits|dividends|opening|closing|inflow|outflow|expected|reported|drift|assets|debts|retirement|per_paycheck|annual|target|saved|contribution|monthly|purchase|advance|quantity|basis|gain|due)/i;
const NOT=/(pct|rate|day|count|year|apr|apy|age|months|ratio|priority|score|weight|points|order|period|paychecks|days|id$)/i;
const scale=(v,k)=>typeof v==='number'&&MONEY.test(k||'')&&!NOT.test(k||'')?Math.round(v*1.35*100)/100:v;
const rename=s=>NAMES.reduce((x,[a,b])=>x.split(a).join(b),s).replace(/\bfixture text\b/g,'Example note').replace(/\bfixture\b/g,'example');
function tr(o,k,top){if(Array.isArray(o))return o.map(x=>tr(x,k,top));
  if(o&&typeof o==='object'){const r={};
    /* settings rows (item, value): ages, rates and percents keep their value; only dollar settings are scaled */
    if((top==='retirement_plan'||top==='assumptions')&&'item' in o&&'value' in o){for(const x in o)r[x]=x==='value'?(top==='retirement_plan'&&/goal|annual|payroll|backdoor|hsa/.test(o.item)&&typeof o.value==='number'?Math.round(o.value*1.35):o.value):tr(o[x],x,top);return r;}
    for(const x in o)r[x]=tr(o[x],x,top);return r;}
  return typeof o==='string'?rename(o):scale(o,k);}

/* Stage 6o columns. The unit fixtures stay minimal; the demo folder gets the basis columns and a two sided transfer so every page and rule has something to show.
   Every value is invented. value_basis: reported, stated, derived, expected, estimated. source_kind: statement, app_screen, document, owner_stated, calculation, assumption. */
const KIND_BASIS={Cash:['reported','app_screen'],HSA:['reported','app_screen'],'Real estate':['estimated','assumption'],Vehicle:['estimated','assumption'],Receivable:['stated','owner_stated']};
function post(id,rows){
  if(!Array.isArray(rows))return rows;
  const set=(r,o)=>{for(const k in o)if(r[k]===undefined)r[k]=o[k];};
  if(id==='assets_other')rows.forEach(r=>{const b=KIND_BASIS[r.type]||['stated','owner_stated'];set(r,{value_basis:b[0],source_kind:b[1],value_basis_note:null,spendable_value:null});r.source='example '+(b[1]==='assumption'?'estimate':b[1]==='app_screen'?'bank app':'note');
    /* pass-through model: paychecks land in Savings and money moves to Checking before each payment, so part of the posted Savings value is in transit */
    if(r.asset_id==='A4')r.spendable_value=Math.round(r.value_point*0.9*100)/100;});
  if(id==='liabilities')rows.forEach(r=>{set(r,{value_basis:'reported',source_kind:'statement',payment_basis:r.monthly_payment!=null?'reported':null});r.source='example statement';});
  if(id==='bills')rows.forEach(r=>{set(r,{value_basis:'stated',source_kind:'owner_stated',as_of_date:'2026-10-13',source:'example note'});});
  if(id==='balance_log')rows.forEach(r=>{set(r,{value_basis:'reported',source_kind:'app_screen'});r.source='example bank app';});
  if(id==='cash_events')rows.forEach(r=>{set(r,{value_basis:'reported',source_kind:'statement',source:'example statement',kind_label:r.kind_label||r.kind,to_account:null,from_account:null,transfer_pair:null,clearing:null,funding_source:null});});
  if(id==='cash_events'&&!rows.some(r=>r.kind==='transfer')){
    const base=rows[0];const mk=(n,acct,amt)=>Object.assign({},base,{event_id:n,date:'2026-10-14',account:acct,kind:'transfer',kind_label:'Transfer Savings to Checking',amount:amt,counts_as_spend:'N',recurring:'N',note:'example',status:'Confirmed',in_balances:'N',value_basis:'reported',source_kind:'app_screen',source:'example bank app',from_account:'Savings',to_account:'Checking',transfer_pair:null,clearing:'cleared'});
    const a=mk('E3','Savings',-1350),b=mk('E4','Checking',1350);a.transfer_pair='E4';b.transfer_pair='E3';rows.push(a,b);}
  if(id==='data_queue'||id==='tasks')rows.forEach(r=>{set(r,{merged_from:null});if(id==='data_queue')set(r,{waits_for:null});});
  if(id==='mortgage_statements')rows.forEach(r=>{set(r,{expected_after_next_payment:null});});
  return rows;}
fs.mkdirSync(OUT,{recursive:true});let n=0;
for(const f of fs.readdirSync(SRC).filter(f=>f.endsWith('.json'))){const id=f.slice(0,-5);let t=fs.readFileSync(path.join(SRC,f),'utf8');
  if(!REF.has(id)){t=JSON.stringify(post(id,tr(JSON.parse(t),null,id)),null,1)+'\n';}
  /* the demo limits differ from the unit-test fixture so no test literal equals a demo figure (invented numbers, refresh them every year) */
  if(id==='contributions'){const j=JSON.parse(t);j.forEach(r=>{if(/401/.test(r.account||''))r.limit_annual=23000;});t=JSON.stringify(j,null,1)+'\n';}
  if(id==='contribution_limits'){const j=JSON.parse(t);j.forEach(r=>{r.k401_deferral=23000;r.hsa_self=4300;r.hsa_family=8550;r.k401_total_additions=69000;r.ira=7500;});t=JSON.stringify(j,null,1)+'\n';}
  fs.writeFileSync(path.join(OUT,f),t);n++;}
/* data_offpage/notes_log: datasets the page does not load. Invented rows: a long note moved whole, a merged repeated request and its alias. */
if(!process.argv[2]){fs.mkdirSync(ROOT+'/data_offpage',{recursive:true});const L=(log_id,kind,dataset,row_id,field,text,merged_into)=>({log_id,kind,dataset,row_id,field,text,merged_into,moved_on:'2026-10-17',stage:'6o'});
  fs.writeFileSync(ROOT+'/data_offpage/notes_log.json',JSON.stringify([L('N1','long_note','liabilities','L2','notes','Example long note: the full text that used to sit in the notes cell, moved here whole so the loaded row keeps only its latest short note.',null),
    L('N2','merged_row','data_queue','Q9',null,'Example repeated request, kept whole: please send the downloaded statement.','Q3'),L('N3','alias','data_queue','Q9',null,'Q9 is now Q3','Q3')],null,1)+'\n');}
console.log('seeded '+n+' datasets into '+path.relative(ROOT,OUT));
