// Writes the starter files: one JSON per dataset, ready to upload as an asset.
//   user, history and queue datasets: ONE row with every field set to null (an empty array cannot load in the runtime; calcs strip this row)
//   reference and config datasets: the shipped content (published reference statistics, settings with defaults), copied from data_all
// Also writes planned/metric_snapshots.json (a PLANNED dataset, not read by the page) and README.md.
// usage: node tools/make_templates.js <outdir>
'use strict';
const fs=require('fs');const path=require('path');
const ROOT=path.resolve(__dirname,'..');const out=process.argv[2];if(!out){console.log('usage: node tools/make_templates.js <outdir>');process.exit(2);}
const F=JSON.parse(fs.readFileSync(ROOT+'/work/facts.json','utf8'));const DN=JSON.parse(fs.readFileSync(ROOT+'/docs_src/dataset_notes.json','utf8'));
fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out+'/planned',{recursive:true});
const j=o=>JSON.stringify(o,null,1)+'\n';const SHIPPED=['reference','config'];const rows=[];
for(const id of F.ds_order){const src=JSON.parse(fs.readFileSync(ROOT+'/data_all/'+id+'.json','utf8'));const cls=DN[id].class;
  if(SHIPPED.includes(cls)){fs.writeFileSync(out+'/'+id+'.json',j(src));rows.push([id,cls,'shipped content',(Array.isArray(src)?src:src.rows).length]);continue;}
  const list=Array.isArray(src)?src:(src.rows||src.data||src.results);const keys=[];list.forEach(r=>Object.keys(r).forEach(k=>{if(!keys.includes(k))keys.push(k);}));
  const row={};keys.forEach(k=>row[k]=null);const body=Array.isArray(src)?[row]:{rows:[row]};fs.writeFileSync(out+'/'+id+'.json',j(body));rows.push([id,cls,'one row, every field null',1]);}
const MS=['snapshot_id','as_of_date','net_worth','total_assets','total_debt','dti_pct','monthly_obligations','cash_runway_months','financial_score','risk_score','coverage_pct','source','note'];
const ms={};MS.forEach(k=>ms[k]=null);fs.writeFileSync(out+'/planned/metric_snapshots.json',j([ms]));
const R=['# templates: starter files, one per dataset','',
'Every file is a valid dataset for the Money Operations Center: upload it as an asset (one per publish call), write its dataset document (title of 30 characters or less, description), and the page loads.','',
'- User, history and queue datasets hold one row with every field null. The runtime cannot load an empty array, so this row stands in for "nothing yet"; the calcs strip it. Replace it with your first real row, or add rows and remove it. Never leave a dataset with zero rows.',
'- Reference and config datasets (age_benchmarks, dti_benchmarks, ltv_benchmarks, contribution_limits, age_metrics_config, scores_config, assumptions) ship with content: published statistics with their source and year, and settings with defaults. Confirm the limits and statistics against the source each year (SOURCES_AND_BENCHMARKS.md); the contribution limits and assumptions here are examples.',
'- planned/metric_snapshots.json is a PLANNED dataset. No page reads it yet (CORRELATIONS.md). Do not upload it until it is built.','',
'Field meanings, units and which calcs read each dataset: DATA_MODEL.md. What to ask for each: INTAKE_GUIDE.md and QUESTIONS.md.','',
'| Dataset | Class | Content | Rows |','|---|---|---|---|'].concat(rows.map(r=>'| '+r.join(' | ')+' |'),['| planned/metric_snapshots | history | PLANNED, one row, every field null | 1 |','']);
fs.writeFileSync(out+'/README.md',R.join('\n'));
console.log('templates: '+rows.length+' datasets + 1 planned into '+out);
