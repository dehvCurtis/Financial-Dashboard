// Validates a backup against BACKUP_FORMAT.md. Accepts the JSON file (schema mo-backup-2), the rebuild kit zip, or a legacy Claude-made
// JSON ({exported, datasets} with an optional note). Checks: required keys, schema version, one entry per dataset, row counts against the
// manifest statuses, sha256 of every file in the manifest (recomputed from the rows for the JSON form, from the bytes for the zip), CSV
// row counts, no dash characters, no forbidden identifier fields. Exit code 0 when every check passes.
// usage: node tools/verify_backup.js <file.json|file.zip> [--expect-datasets id1,id2,...] [--quiet]
'use strict';
const fs=require('fs');const path=require('path');const L=require('./backup_lib');
const REQUIRED_JSON=['schema_version','exported','manifest','docs','meta','schema','datasets'];
const REQUIRED_MANIFEST=['schema_version','exported','day','dataset_count','datasets_ok','statuses','files'];
const BAD_FIELD=/^(account_?(number|no|num)|acct_?(number|no)|routing.*|ssn|tax_?id|tin|loan_?(id|number|no))$/i;
function verifyInner(file,opt){opt=opt||{};const res=[];const ok=(name,pass,detail)=>res.push({name,pass:!!pass,detail:pass?'':String(detail||'')});
  const buf=fs.readFileSync(file);const isZip=buf.slice(0,2).toString()==='PK';let man,datasets={},fileMap=null,form;
  if(isZip){form='kit zip';let z;try{z=L.readZip(buf);}catch(e){ok('zip readable',false,e.message);return res;}ok('zip readable',true);fileMap=z;
    ok('manifest.json present',!!z['manifest.json'],'missing manifest.json');ok('RESTORE.md present',!!z['RESTORE.md'],'missing RESTORE.md');ok('schema.json present',!!z['schema.json'],'missing schema.json');ok('docs/datasets.json present',!!z['docs/datasets.json'],'missing docs/datasets.json');ok('dash/meta.json present',!!z['dash/meta.json'],'missing dash/meta.json');
    if(!z['manifest.json'])return res;try{man=JSON.parse(z['manifest.json'].toString('utf8'));}catch(e){ok('manifest parses',false,e.message);return res;}
    Object.keys(z).filter(n=>/^datasets\/.+\.json$/.test(n)).forEach(n=>{try{datasets[n.slice(9,-5)]=JSON.parse(z[n].toString('utf8'));}catch(e){ok('dataset parses '+n,false,e.message);}});}
  else{let j;try{j=JSON.parse(buf.toString('utf8'));}catch(e){ok('json parses',false,e.message);return res;}ok('json parses',true);
    if(!('schema_version' in j)){form='legacy json';ok('legacy form has exported and datasets',typeof j.exported==='string'&&j.datasets&&typeof j.datasets==='object','needs exported and datasets');datasets=j.datasets||{};
      ok('legacy datasets are arrays or objects with rows',Object.values(datasets).every(d=>Array.isArray(d)||(d&&Array.isArray(d.rows))),'a dataset is neither an array nor {rows}');
      Object.keys(datasets).forEach(k=>{if(!Array.isArray(datasets[k]))datasets[k]=datasets[k].rows;});
      ok('legacy form has no manifest: hashes not checked',true);}
    else{form='json';REQUIRED_JSON.forEach(k=>ok('key '+k,k in j,'missing top-level key '+k));ok('schema_version is mo-backup-2',j.schema_version===L.SCHEMA_VERSION,'found '+j.schema_version+' (see BACKUP_FORMAT.md section 7 for older versions)');
      man=j.manifest;datasets=j.datasets||{};if(!man)return res;}}
  if(man){REQUIRED_MANIFEST.forEach(k=>ok('manifest key '+k,k in man,'missing manifest key '+k));
    const ids=Object.keys(datasets).sort();ok('dataset_count equals datasets present',man.dataset_count===ids.length,'manifest '+man.dataset_count+', found '+ids.length);
    ok('datasets_ok equals dataset_count',man.datasets_ok===man.dataset_count,'datasets_ok '+man.datasets_ok+' of '+man.dataset_count);
    (man.statuses||[]).forEach(s=>{ok('status ok '+s.id,s.status==='ok','status '+s.status);const d=datasets[s.id];ok('rows '+s.id,d&&Array.isArray(d)&&d.length===s.rows,'manifest '+s.rows+', found '+(d&&d.length));});
    ok('every dataset has a status',ids.every(i=>(man.statuses||[]).some(s=>s.id===i)),'dataset without a status');
    for(const f of man.files||[]){let bytes=null;
      if(fileMap){bytes=fileMap[f.path];}else{let m;if((m=f.path.match(/^datasets\/(.+)\.json$/))&&datasets[m[1]])bytes=Buffer.from(L.datasetText(datasets[m[1]]),'utf8');else if((m=f.path.match(/^csv\/(.+)\.csv$/))&&datasets[m[1]])bytes=Buffer.from(L.toCsv(datasets[m[1]]),'utf8');}
      if(!bytes){if(!fileMap&&!/^(datasets|csv)\//.test(f.path))continue;ok('file present '+f.path,false,'listed in the manifest, not found');continue;}
      ok('sha256 '+f.path,L.sha256(bytes)===f.sha256,'hash differs: the file changed after the export');ok('bytes '+f.path,bytes.length===f.bytes,'manifest '+f.bytes+', found '+bytes.length);}
    if(fileMap)ids.forEach(id=>{const c=fileMap['csv/'+id+'.csv'];if(!c)return ok('csv present '+id,false,'missing csv/'+id+'.csv');const lines=c.toString('utf8').split('\r\n').filter((x,i,a)=>!(i===a.length-1&&x===''));
      /* a CSV record can span lines when a cell holds a line break: count records by quote parity */
      let rec=0,inq=false;for(const ch of c.toString('utf8')){if(ch==='"')inq=!inq;else if(ch==='\n'&&!inq)rec++;}ok('csv rows '+id,rec-1===datasets[id].length,'csv has '+(rec-1)+' rows, dataset has '+datasets[id].length);});}
  const ids=Object.keys(datasets);
  if(opt.expect){const miss=opt.expect.filter(i=>!ids.includes(i));ok('expected datasets present',!miss.length,'missing: '+miss.join(', '));}
  const dash=ids.filter(i=>/[\u2013\u2014]/.test(JSON.stringify(datasets[i])));ok('no em or en dash in any dataset',!dash.length,dash.join(', '));
  const bad=[];ids.forEach(i=>(datasets[i]||[]).forEach(r=>r&&typeof r==='object'&&Object.keys(r).forEach(k=>{if(BAD_FIELD.test(k)&&!bad.includes(i+'.'+k))bad.push(i+'.'+k);})));ok('no account number, routing, tax id or loan id fields',!bad.length,bad.join(', '));
  ids.forEach(i=>ok('dataset is a non-empty array of row objects: '+i,Array.isArray(datasets[i])&&datasets[i].length>0&&datasets[i].every(r=>r&&typeof r==='object'&&!Array.isArray(r)),'the store cannot load an empty file or a non-object row'));
  res.form=form;return res;}
/* any structure the checks above did not expect (a hostile or damaged file) is a failed check, never a crash or a pass */
function verify(file,opt){let st;try{st=fs.statSync(file);}catch(e){return Object.assign([{name:'file readable',pass:false,detail:e.message}],{form:'unreadable'});}
  if(st.size>L.ZIP_LIMITS.totalBytes)return Object.assign([{name:'file size within limit',pass:false,detail:st.size+' bytes'}],{form:'too large'});
  try{return verifyInner(file,opt);}catch(e){return Object.assign([{name:'backup structure is valid',pass:false,detail:String(e&&e.message||e).slice(0,160)}],{form:'invalid'});}}
exports.verify=verify;
if(require.main===module){const a=process.argv.slice(2);const file=a.find(x=>!x.startsWith('--')&&a[a.indexOf(x)-1]!=='--expect-datasets');if(!file){console.log('usage: node tools/verify_backup.js <file.json|file.zip> [--expect-datasets a,b] [--quiet]');process.exit(2);}
  const ei=a.indexOf('--expect-datasets');const r=verify(file,{expect:ei>=0?a[ei+1].split(','):null});const fails=r.filter(x=>!x.pass);
  if(!a.includes('--quiet'))r.forEach(x=>console.log((x.pass?'PASS ':'FAIL ')+x.name+(x.pass?'':' : '+x.detail)));
  console.log('backup ('+r.form+'): '+(r.length-fails.length)+' checks pass, '+fails.length+' fail');process.exit(fails.length?1:0);}
