// The as-of date for tools: the real date today (local clock), or an explicit YYYY-MM-DD argument. No hard coded date anywhere.
// Tests pass their own fixed date explicitly (tests/lib/fx.js) so a test never depends on the clock.
exports.today=function(explicit){
  if(explicit!=null&&explicit!==''){if(!/^\d{4}-\d\d-\d\d$/.test(String(explicit)))throw new Error('as-of date must be YYYY-MM-DD, got '+explicit);return String(explicit);}
  const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');};
