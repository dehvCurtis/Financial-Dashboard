// Checks the generated documents against the code and the render. Fails (exit 1) when
//   - a tile, card, chart or table that the page renders is missing from TILES.md, or TILES.md lists one that does not render;
//   - a dataset id or calc id in the built page is missing from DATA_MODEL.md or CALCS.md, or a document names one that does not exist;
//   - a correlation check id or profile question id differs between the code and CORRELATIONS.md or QUESTIONS.md;
//   - the hand notes (docs_src/*_notes.json) lack an entry for a dataset, or carry an entry for a tile or dataset that is gone;
//   - a document still holds an unexpanded {{marker}}, an em or en dash, or names a bundle file that is not there.
// usage: node tools/check_docs.js [--docs dir] [--no-render] [--quiet]
//   --no-render reuses work/tiles_now.json and work/facts.json as they are; without it the page is rendered again (needs Chromium).
'use strict';
const fs=require('fs');const path=require('path');const {execFileSync}=require('child_process');
const ROOT=path.resolve(__dirname,'..');const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const DOCS=path.resolve(arg('--docs')||ROOT+'/docs_out');const quiet=process.argv.includes('--quiet');
const run=(f,a)=>execFileSync('node',[ROOT+'/tools/'+f].concat(a||[]),{cwd:ROOT,stdio:'pipe',env:process.env}).toString();
if(!process.argv.includes('--no-render')){run('tiles_inventory.js');run('tiles_inventory.js',['--blank']);run('docs_facts.js');}
const F=JSON.parse(fs.readFileSync(ROOT+'/work/facts.json','utf8'));
const res=[];const ok=(name,pass,detail)=>res.push({name,pass:!!pass,detail:pass?'':String(detail||'')});
const rd=f=>fs.existsSync(path.join(DOCS,f))?fs.readFileSync(path.join(DOCS,f),'utf8'):null;
const diff=(a,b)=>[...a].filter(x=>!b.has(x));
/* ---- tiles ---- */
const T=rd('TILES.md');ok('TILES.md exists',T!=null,'missing '+DOCS+'/TILES.md');
if(T){const rows=[];let page=null,kind=null;
  for(const l of T.split('\n')){let m;if((m=l.match(/^## Page: (\w+)/)))page=m[1];else if((m=l.match(/^### (\w+): (card|tile|chart|table)s/)))kind=m[2];
    else if(page&&kind&&l.startsWith('| ')&&!l.startsWith('| Tile id')&&!/^\|[-| ]+\|$/.test(l)){const c=l.split(' | ');rows.push({page,kind,key:c[0].replace(/^\| /,'').trim(),label:(c[1]||'').trim()});}
    else if(l.startsWith('## ')&&!l.startsWith('## Page:')){page=null;kind=null;}}
  const rendered=F.tiles;const cnt=a=>{const o={};a.forEach(t=>{const k=t.page+'|'+t.kind;o[k]=(o[k]||0)+1;});return o;};
  const cr=cnt(rendered),cd=cnt(rows);
  ok('TILES.md has the same number of rows per page and kind as the render',JSON.stringify(Object.entries(cr).sort())===JSON.stringify(Object.entries(cd).sort()),'render '+JSON.stringify(cr)+' docs '+JSON.stringify(cd));
  const kr=new Set(rendered.filter(t=>t.key).map(t=>t.page+'|'+t.kind+'|'+t.key)),kd=new Set(rows.filter(r=>r.key!=='(no id)').map(r=>r.page+'|'+r.kind+'|'+r.key));
  ok('every rendered tile id is in TILES.md',!diff(kr,kd).length,'missing from the doc: '+diff(kr,kd).slice(0,8).join(', '));
  ok('TILES.md lists no tile that does not render',!diff(kd,kr).length,'not rendered: '+diff(kd,kr).slice(0,8).join(', '));}
/* ---- datasets and calcs ---- */
const heads=(f)=>{const t=rd(f);return t==null?null:new Set([...t.matchAll(/^### ([a-z0-9_]+)\s*$/gm)].map(m=>m[1]));};
const DM=heads('DATA_MODEL.md'),CA=heads('CALCS.md');
const dsFiles=new Set(fs.readdirSync(ROOT+'/data_all').filter(f=>f.endsWith('.json')).map(f=>f.slice(0,-5)));
const dsPage=new Set(F.ds_order);
ok('the page dataset list equals the files in data_all',!diff(dsPage,dsFiles).length&&!diff(dsFiles,dsPage).length,'page only: '+diff(dsPage,dsFiles)+' files only: '+diff(dsFiles,dsPage));
if(DM){ok('DATA_MODEL.md has a section for every dataset',!diff(dsPage,DM).length,'missing: '+diff(dsPage,DM).join(', '));ok('DATA_MODEL.md names no dataset that does not exist',!diff(DM,dsPage).length,'unknown: '+diff(DM,dsPage).join(', '));}else ok('DATA_MODEL.md exists',false,'missing');
const calcIds=new Set(Object.keys(F.calcs));
if(CA){ok('CALCS.md has a section for every calc',!diff(calcIds,CA).length,'missing: '+diff(calcIds,CA).join(', '));ok('CALCS.md names no calc that does not exist',!diff(CA,calcIds).length,'unknown: '+diff(CA,calcIds).join(', '));}else ok('CALCS.md exists',false,'missing');
/* ---- checks and profile questions ---- */
const C=rd('CORRELATIONS.md');if(C){const ids=new Set([...C.matchAll(/^\| (C\d+) \|/gm)].map(m=>m[1]));const want=new Set(F.checks.map(c=>c.id));
  ok('CORRELATIONS.md lists every check the page runs',!diff(want,ids).length,'missing: '+diff(want,ids).join(', '));
  const extra=diff(ids,want);ok('CORRELATIONS.md table lists no check the page does not run',!extra.length,'unknown: '+extra.join(', '));}else ok('CORRELATIONS.md exists',false,'missing');
const Q=rd('QUESTIONS.md');if(Q){const ids=new Set([...Q.matchAll(/^\| \d+ \| ((?:debt|bill|acct|ret)_[a-z]+) \|/gm)].map(m=>m[1]));const want=new Set(F.profile.map(p=>p.q));
  ok('QUESTIONS.md lists every profile question in the code',!diff(want,ids).length&&!diff(ids,want).length,'missing: '+diff(want,ids)+' unknown: '+diff(ids,want));}else ok('QUESTIONS.md exists',false,'missing');
/* ---- notes ---- */
const DN=JSON.parse(fs.readFileSync(ROOT+'/docs_src/dataset_notes.json','utf8'));
ok('dataset_notes.json covers every dataset and no other',!diff(dsPage,new Set(Object.keys(DN))).length&&!diff(new Set(Object.keys(DN)),dsPage).length,'missing: '+diff(dsPage,new Set(Object.keys(DN)))+' stale: '+diff(new Set(Object.keys(DN)),dsPage));
const TN=JSON.parse(fs.readFileSync(ROOT+'/docs_src/tiles_notes.json','utf8'));const idents=new Set(execFileSync('node',[ROOT+'/tools/gen_docs.js','--idents'],{cwd:ROOT}).toString().split('\n').filter(Boolean));
const stale=Object.keys(TN).filter(k=>!idents.has(k));ok('tiles_notes.json has no entry for a tile that is gone',!stale.length,'stale: '+stale.slice(0,8).join(', '));
/* ---- every document ---- */
if(fs.existsSync(DOCS)){const mds=fs.readdirSync(DOCS).filter(f=>f.endsWith('.md'));
  const bad=[],dash=[],missing=[];
  for(const f of mds){const t=rd(f);if(/\{\{(GEN|N):/.test(t))bad.push(f);if(/[\u2013\u2014]/.test(t))dash.push(f);}
  ok('no unexpanded marker in any document',!bad.length,bad.join(', '));ok('no em or en dash in any document',!dash.length,dash.join(', '));
  const R=rd('README.md')||'';const named=[...new Set([...R.matchAll(/\b([A-Z][A-Z_]+\.md)\b/g)].map(m=>m[1]))];
  named.forEach(n=>{if(!fs.existsSync(path.join(DOCS,n)))missing.push(n);});ok('every document README.md names exists',!missing.length,'missing: '+missing.join(', '));}
const IX=rd('INDEX.md');if(IX&&fs.existsSync(DOCS)){const un=fs.readdirSync(DOCS).filter(f=>f.endsWith('.md')&&!IX.includes('| '+f+' |'));ok('INDEX.md lists every document',!un.length,'not listed: '+un.join(', '));}
const fails=res.filter(r=>!r.pass);
if(!quiet)res.forEach(r=>console.log((r.pass?'PASS ':'FAIL ')+r.name+(r.pass?'':' : '+r.detail)));
console.log('check_docs: '+(res.length-fails.length)+' pass, '+fails.length+' fail');process.exit(fails.length?1:0);
