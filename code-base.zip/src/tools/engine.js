// Browser-free calc engine. Runs every calc of a built page on a data folder through the live Dashboard runtime's own parser and calc
// engine (tools/runtime/runtime_extract.js: xa0 file parser, M_0 calc engine), exactly as build.js wires them for the harness:
// nested object cells arrive as JSON text, missing keys are null, a file with no rows fails to load, a calc that throws is status error,
// its dependents are "<calc> didn't run.", calc results reach dependents as structured clones.
// The page script runs in a Node vm with a permissive DOM stub; draw callbacks (dash.onData) are recorded and never called.
// usage (module): const E=require('./engine'); const r=E.run({page:'out/index_page.html', data:'data_all', today:'2026-10-17'});
//   r.calcs: {id:{status, value, message}}, r.datasets: {id:{status, rows, message}}, r.inputs: {calcId:[inputs]}
// usage (cli): node tools/engine.js <page.html> <datadir> [today] [out.json]
'use strict';
const fs=require('fs');const path=require('path');const vm=require('vm');
const ROOT=path.resolve(__dirname,'..');
const RT=fs.readFileSync(path.join(__dirname,'runtime','runtime_extract.js'),'utf8');
const D3=fs.readFileSync(path.join(ROOT,'node_modules','d3','dist','d3.min.js'),'utf8');
const SCRIPT_CACHE=new Map();
function pageScript(page){const t=fs.readFileSync(page,'utf8');const m=t.match(/<script>([\s\S]*)<\/script>/);if(!m)throw new Error('no script in '+page);return m[1];}
function stub(){const f=function(){};const p=new Proxy(f,{get:(t,k)=>{if(k===Symbol.toPrimitive)return ()=>'';if(k===Symbol.iterator)return function*(){};
  if(k==='length')return 0;if(k==='then')return undefined;return p;},apply:()=>p,construct:()=>p,set:()=>true,has:()=>true});return p;}
function readData(data){if(typeof data==='object'&&data)return data;const texts={};
  for(const f of fs.readdirSync(data))if(f.endsWith('.json'))texts[f.slice(0,-5)]=fs.readFileSync(path.join(data,f),'utf8');return texts;}
function run(opt){
  const script=opt.script||(SCRIPT_CACHE.get(opt.page)||(SCRIPT_CACHE.set(opt.page,pageScript(opt.page)),SCRIPT_CACHE.get(opt.page)));
  const texts=readData(opt.data);const S=stub();
  const ctx={console:opt.quiet===false?console:{log(){},warn(){},error(){},info(){}},structuredClone,Map,Set,Date,Math,JSON,Promise,
    setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,clearInterval(){},requestAnimationFrame:()=>0,cancelAnimationFrame(){},queueMicrotask(){},
    document:S,navigator:{userAgent:'node'},location:{hash:'',href:'file:///',search:''},history:S,localStorage:S,sessionStorage:S,
    matchMedia:()=>({matches:false,addEventListener(){},addListener(){}}),IntersectionObserver:function(){return S;},ResizeObserver:function(){return S;},
    MutationObserver:function(){return S;},getComputedStyle:()=>S,addEventListener(){},removeEventListener(){},innerWidth:390,innerHeight:844,
    performance:{now:()=>0},Blob:function(){return S;},URL:{createObjectURL:()=>'',revokeObjectURL(){}},CSS:{escape:x=>String(x)},HTMLElement:function(){},Element:function(){},Node:function(){},
    TextEncoder,TextDecoder,crypto:require('crypto').webcrypto,__TODAY:opt.today===undefined?'2026-10-17':opt.today};
  ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;
  vm.createContext(ctx);
  vm.runInContext(D3,ctx,{filename:'d3.min.js'});
  vm.runInContext(RT+'\n;globalThis.__RT={xa0,M_0,ZH,b95,lS,u1};',ctx,{filename:'runtime_extract.js'});
  const RTF=ctx.__RT;const runs=new Map();
  for(const id of Object.keys(texts)){let G=null;try{G=RTF.xa0(texts[id],'json');}catch(e){G=null;}
    if(G===null||G.columns.length===0)runs.set(id,{status:'failed',message:'The file has no rows this dashboard can read.'});else runs.set(id,{status:'ok',table:G});}
  const f95=Z=>{const $=RTF.b95(Z);return {status:'ok',data:$,columns:[...Z.columns],rows:$,message:'',refreshing:false,meta:RTF.lS(Z)};};
  const Cs=id=>{if(!runs.has(id))return RTF.ZH('missing','No dataset “'+id+'” in this dashboard.');const Q=runs.get(id);return Q.status==='ok'?f95(Q.table):RTF.ZH('error',Q.message);};
  const q=RTF.M_0({has:B=>runs.has(B),input:Cs,stateOf:B=>[runs.get(B),runs.get(B)],post:()=>{}});
  const draws=[];const inputs={};const metas={};
  ctx.dash={data(B){if(!RTF.u1(B))return Cs(B);const H=q.under(B);if(H===void 0)return Cs(B);const M=q.data(B);return {status:M.status,data:M.value,value:M.value,message:M.message,columns:[],rows:[],meta:[]};},
    onData(B){draws.push(B);},calc(B,H){inputs[B]=(H&&H.inputs||[]).slice();metas[B]={title:H&&H.title||'',description:H&&H.description||''};q.define(B,H);},loader(){},format:x=>String(x),
    colors:['#2a6fdb','#e0783a','#2f9e6f','#8b5cc7','#c8a415','#d1477a','#3b9ab2','#7a7a7a'],refresh(){},params:()=>({}),setParams(){},resetParams(){},setLink(){},scale:{},ticks:{},path:{},svg:{}};
  let stopped=null;
  try{vm.runInContext('(function(){'+script+'\n}).call(this);',ctx,{filename:'page.js'});}catch(e){stopped=e&&e.stack||String(e);}
  const calcs={};for(const id of Object.keys(inputs)){if(opt.only&&!opt.only.includes(id))continue;const d=q.data(id);calcs[id]={status:d.status,value:d.status==='ok'?JSON.parse(JSON.stringify(d.value)):null,message:d.message||''};}
  const datasets={};for(const [id,r] of runs)datasets[id]=r.status==='ok'?{status:'ok',rows:RTF.b95(r.table),columns:[...r.table.columns]}:{status:r.status,message:r.message};
  return {calcs,datasets,inputs,metas,stopped,draws:draws.length,ctx};
}
exports.run=run;exports.pageScript=pageScript;
if(require.main===module){const [pg,dd,today,out]=process.argv.slice(2);const r=run({page:pg,data:dd,today:today||'2026-10-17'});
  const bad=Object.entries(r.calcs).filter(([k,v])=>v.status!=='ok');
  console.log(Object.keys(r.calcs).length+' calcs, '+bad.length+' not ok'+(r.stopped?'\nSTOPPED '+r.stopped:''));bad.forEach(([k,v])=>console.log('  '+k+': '+v.message));
  if(out)fs.writeFileSync(out,JSON.stringify({calcs:Object.fromEntries(Object.entries(r.calcs).map(([k,v])=>[k,v])),inputs:r.inputs},null,1));}
