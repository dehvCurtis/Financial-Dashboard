// Builds out/index_page.html (the single page the split tool cuts into the published files) from the flat source tree page/:
// style.css, markup.html and the scripts in page/parts.json order. A separate lazily executed file (page/selftest.js) is not part of
// the single page; tools/build_split.js copies it next to the parts and index.html loads it last.
// usage: node tools/build_page.js [pagedir] [out.html]
const fs=require('fs');const path=require('path');const D=path.resolve(__dirname,'..');
/* the backup list of dataset ids is generated from the data folder, so a new dataset is never left out of a backup */
function datasetIds(){return fs.readdirSync(D+'/data_all').filter(f=>f.endsWith('.json')).map(f=>f.slice(0,-5)).sort();}
function assemble(dir){const P=JSON.parse(fs.readFileSync(dir+'/parts.json','utf8'));const r=f=>fs.readFileSync(path.join(dir,f),'utf8');
  return '<style>\n'+r(P.style)+'</style>\n'+r(P.markup)+'<script>\n'+P.scripts.map(r).join('').replace(/const DS=\/\*DATASET_IDS[^*]*\*\/\[[^\]]*\]/,m=>m.slice(0,m.indexOf('[')) + JSON.stringify(datasetIds()))+'</script>'+(P.tail!=null&&P.tail!==false?'\n'+P.tail:'');}
exports.assemble=assemble;
if(require.main===module){const dir=process.argv[2]||D+'/page',out=process.argv[3]||D+'/out/index_page.html';const page=assemble(dir);
  if(/[\u2013\u2014]/.test(page))throw new Error('em or en dash in the page source');
  fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,page);fs.writeFileSync(out.replace(/\.html$/,'.json'),JSON.stringify({text:page}));console.log('page chars',page.length);}
