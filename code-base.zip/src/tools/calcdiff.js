// Ingest and diff report: every calc output before and after a data change (or a code change, or both), field by field.
// usage: node tools/calcdiff.js --page-a A.html --data-a dirA [--page-b B.html] [--data-b dirB] [--out report.md] [--json out.json]
//   B defaults to A for whichever side is not given. Each calc result is flattened to path = value (arrays by index; long numeric
//   series are summarized), and every path that differs is listed with old and new value. Also lists datasets whose bytes changed and
//   the calcs and cards that depend on them (tools/depmap.js), so the report says which numbers a data update moves and why.
'use strict';
const fs=require('fs');const path=require('path');const crypto=require('crypto');const E=require('./engine.js');
const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const pa=arg('--page-a'),da=arg('--data-a');const pb=arg('--page-b')||pa,db=arg('--data-b')||da;const today=require('./today.js').today(arg('--today'));
function flat(v,p,o){o=o||{};if(Array.isArray(v)){if(v.length>40&&v.every(x=>typeof x==='number')){o[p+'[len]']=v.length;o[p+'[sum]']=Math.round(v.reduce((s,x)=>s+x,0)*100)/100;o[p+'[last]']=v[v.length-1];return o;}
  v.forEach((x,i)=>flat(x,p+'['+i+']',o));if(!v.length)o[p]='[]';return o;}
  if(v&&typeof v==='object'){const ks=Object.keys(v);if(!ks.length)o[p]='{}';ks.forEach(k=>flat(v[k],p?p+'.'+k:k,o));return o;}o[p]=v;return o;}
function diff(A,B){const ids=[...new Set(Object.keys(A.calcs).concat(Object.keys(B.calcs)))].sort();const rows=[];
  for(const id of ids){const a=A.calcs[id],b=B.calcs[id];
    if(!a||!b){rows.push({calc:id,path:'(calc)',a:a?a.status:'absent',b:b?b.status:'absent'});continue;}
    if(a.status!==b.status||a.message!==b.message)rows.push({calc:id,path:'(status)',a:a.status+(a.message?' '+a.message:''),b:b.status+(b.message?' '+b.message:'')});
    const fa=flat(a.value,''),fb=flat(b.value,'');for(const k of [...new Set(Object.keys(fa).concat(Object.keys(fb)))]){const x=fa[k],y=fb[k];
      const same=typeof x==='number'&&typeof y==='number'?Math.abs(x-y)<1e-9:JSON.stringify(x)===JSON.stringify(y);if(!same)rows.push({calc:id,path:k,a:x,b:y});}}
  return rows;}
const sha=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
function changedData(a,b){if(typeof a!=='string'||typeof b!=='string')return [];const fs_=d=>fs.readdirSync(d).filter(f=>f.endsWith('.json'));const all=[...new Set(fs_(a).concat(fs_(b)))].sort();
  return all.filter(f=>!fs.existsSync(path.join(a,f))||!fs.existsSync(path.join(b,f))||sha(path.join(a,f))!==sha(path.join(b,f))).map(f=>f.slice(0,-5));}
function report(o){const A=E.run({page:o.pa,data:o.da,today:o.today}),B=E.run({page:o.pb,data:o.db,today:o.today});const rows=diff(A,B);const ch=changedData(o.da,o.db);
  let dep=null;try{dep=require('./depmap.js').affected(ch,{page:o.pb});}catch(e){dep=null;}
  return {changed_datasets:ch,affected:dep,calcs_changed:[...new Set(rows.map(r=>r.calc))],rows,a_not_ok:Object.keys(A.calcs).filter(k=>A.calcs[k].status!=='ok'),b_not_ok:Object.keys(B.calcs).filter(k=>B.calcs[k].status!=='ok')};}
exports.report=report;exports.flat=flat;exports.diff=diff;
if(require.main===module){if(!pa||!da){console.log('usage: node tools/calcdiff.js --page-a A.html --data-a dirA [--page-b B.html] [--data-b dirB] [--out r.md] [--json r.json]');process.exit(2);}
  const R=report({pa,da,pb,db,today});const fmt=v=>v===undefined?'(none)':typeof v==='number'?String(Math.round(v*1e6)/1e6):JSON.stringify(v);
  const md=['# Calc diff report','','A: page `'+pa+'`, data `'+da+'`','B: page `'+pb+'`, data `'+db+'`','','Datasets changed: '+(R.changed_datasets.join(', ')||'none'),
    R.affected?'Dependent calcs: '+(R.affected.calcs.join(', ')||'none')+'\n\nDependent cards: '+(R.affected.cards.join(', ')||'none'):'',
    '','Calcs not ok: A '+(R.a_not_ok.join(', ')||'none')+'; B '+(R.b_not_ok.join(', ')||'none'),'','Calcs with a changed output: '+R.calcs_changed.length+' ('+(R.calcs_changed.join(', ')||'none')+'), '+R.rows.length+' fields','',
    '| Calc | Field | Before | After |','|---|---|---|---|'].concat(R.rows.map(r=>'| '+r.calc+' | `'+r.path+'` | '+fmt(r.a).replace(/\|/g,'/').slice(0,120)+' | '+fmt(r.b).replace(/\|/g,'/').slice(0,120)+' |')).join('\n');
  if(arg('--out'))fs.writeFileSync(arg('--out'),md);if(arg('--json'))fs.writeFileSync(arg('--json'),JSON.stringify(R,null,1));
  console.log('datasets changed '+R.changed_datasets.length+', calcs changed '+R.calcs_changed.length+', fields '+R.rows.length+(R.calcs_changed.length?': '+R.calcs_changed.join(', '):''));}
