// Builds the published selftest.js from page/selftest.js with page/invariants.js inlined at its INVARIANTS marker (one source of rules
// for the in-page panel and tests/inv_run.js). Fails over 60 KB or on an em or en dash. usage: require('./selftest_build').text()
const fs=require('fs');const path=require('path');const D=path.resolve(__dirname,'..');
exports.text=()=>{const s=fs.readFileSync(D+'/page/selftest.js','utf8');const inv=fs.readFileSync(D+'/page/invariants.js','utf8');
  if(!s.includes('/*INVARIANTS*/'))throw new Error('selftest.js has no INVARIANTS marker');const t=s.replace('/*INVARIANTS*/',()=>inv);
  if(Buffer.byteLength(t)>60*1024)throw new Error('selftest.js over 60 KB');if(/[\u2013\u2014]/.test(t))throw new Error('dash in selftest.js');
  if(t.includes('</script'))throw new Error('script end tag in selftest.js');return t;};
