// Collects tests/results/*.json from this run, prints one line per suite and the total, writes out/TEST_RESULTS.md, and after a clean
// full run records work/last_full.json (tree hashes, counts, runtime) for the affected-only planner and the publish script.
// usage: node tools/results.js <full 0|1> <seconds>
const fs=require('fs');const path=require('path');const D=path.resolve(__dirname,'..');const [full,secs]=process.argv.slice(2);
const dir=D+'/tests/results';const t0=fs.statSync(D+'/out/index_page.html').mtimeMs-1000;
const files=fs.readdirSync(dir).filter(f=>f.endsWith('.json')).map(f=>path.join(dir,f)).filter(f=>fs.statSync(f).mtimeMs>=t0);
let pass=0,fail=0;let rows=files.map(f=>{const r=JSON.parse(fs.readFileSync(f,'utf8'));pass+=r.pass;fail+=r.fail;return r;});
/* browser shards (browser_<sections>.json, one Chromium process each) count as one suite named browser */
{const sh=rows.filter(r=>/^browser_/.test(r.file));if(sh.length){rows=rows.filter(r=>!/^browser_/.test(r.file));const old=rows.find(r=>r.file==='browser');if(old)rows=rows.filter(r=>r!==old);const res=sh.flatMap(r=>r.results);rows.push({file:'browser',pass:res.filter(x=>x.ok).length,fail:res.filter(x=>!x.ok).length,results:res,shards:sh.map(r=>r.file)});}}
const lines=rows.map(r=>r.file+': '+r.pass+' pass, '+r.fail+' fail').concat(['total: '+pass+' pass, '+fail+' fail in '+secs+' s'+(full==='1'?' (full run)':' (affected only)')]);
console.log(lines.join('\n'));rows.forEach(r=>r.results.filter(x=>!x.ok).forEach(x=>console.log('  FAIL '+r.file+': '+x.name+(x.info?' ('+String(x.info).slice(0,200)+')':''))));
fs.writeFileSync(D+'/out/TEST_RESULTS.md','# Test results\n\n'+new Date().toISOString()+'\n\n'+lines.map(l=>'- '+l).join('\n')+'\n'+(fail?'\nFailures:\n\n'+rows.flatMap(r=>r.results.filter(x=>!x.ok).map(x=>'- '+r.file+': '+x.name+(x.info?' ('+String(x.info).slice(0,300)+')':''))).join('\n')+'\n':''));
const suites=['unit','inv_run','data_rules','static_scan','backup_verify','docs_check','browser','inject'];
if(full==='1'&&!fail&&suites.every(s=>rows.some(r=>r.file===s)))fs.writeFileSync(D+'/work/last_full.json',JSON.stringify({at:new Date().toISOString(),seconds:+secs,pass,fail,suites:rows.map(r=>({file:r.file,pass:r.pass,fail:r.fail})),hashes:require('./tree_hash.js').hashes()},null,1));
/* a suite that stopped before writing its results (a crash) fails the run instead of dropping out of the total */
const missing=full==='1'?suites.filter(s=>!rows.some(r=>r.file===s)):[];missing.forEach(s=>console.log('  MISSING '+s+': no results from this run (see tests/logs/'+s+'.log)'));
process.exit(fail||missing.length?1:0);
