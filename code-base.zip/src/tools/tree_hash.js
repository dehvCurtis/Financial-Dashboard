// sha256 of every file that decides a test result: page sources, tests, tools, build.js and the data. Shared by tools/affected.js,
// tools/results.js (writes work/last_full.json after a clean full run) and tools/publish.js (refuses a stale tree).
const fs=require('fs');const path=require('path');const crypto=require('crypto');const D=path.resolve(__dirname,'..');
const walk=d=>fs.existsSync(d)?fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?(['results','logs','node_modules'].includes(e.name)?[]:walk(path.join(d,e.name))):[path.join(d,e.name)]):[];
exports.hashes=()=>{const o={};['page','tests','tools','data_all'].forEach(d=>walk(path.join(D,d)).filter(f=>/\.(js|json|html|css|py|txt|sh)$/.test(f)).forEach(f=>{o[path.relative(D,f)]=crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');}));
  o['build.js']=crypto.createHash('sha256').update(fs.readFileSync(D+'/build.js')).digest('hex');return o;};
