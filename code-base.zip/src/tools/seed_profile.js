// Seeds profile_answers for a data folder: one row per category in the page's PROFILE_CATS, answer yes (with the row count) where the
// data already holds rows of that category, unknown elsewhere (never no: only the user can say no), plus the placeholder row.
// Existing answers are kept. usage: node tools/seed_profile.js <datadir> [today]
const fs=require('fs');const path=require('path');const E=require('./engine.js');const D=path.resolve(__dirname,'..');
const dir=process.argv[2];const today=process.argv[3]||'2026-10-17';const f=path.join(dir,'profile_answers.json');
const old=fs.existsSync(f)?JSON.parse(fs.readFileSync(f,'utf8')).filter(r=>r.question_id&&r.question_id!=='none'):[];
const t={};for(const x of fs.readdirSync(dir))if(x.endsWith('.json'))t[x.slice(0,-5)]=fs.readFileSync(path.join(dir,x),'utf8');
t.profile_answers=JSON.stringify([{question_id:'none',category:null,answer:'unknown',count:null,asked_at:null,note:'placeholder'}]);
const r=E.run({page:D+'/out/index_page.html',data:t,today});const pf=r.calcs.profile_calc;if(pf.status!=='ok')throw new Error('profile_calc: '+pf.message);
const rows=[{question_id:'none',category:null,answer:'unknown',count:null,asked_at:null,note:'Placeholder row so the store can load the file; every reader skips it'}].concat(pf.value.map(p=>{const o=old.find(x=>x.question_id===p.question_id);
  if(o)return Object.assign({},o,{count:p.rows});return {question_id:p.question_id,category:p.category,answer:p.rows?'yes':'unknown',count:p.rows,asked_at:null,note:p.rows?'Yes because rows of this category are on file':'Not asked yet'};}));
fs.writeFileSync(f,JSON.stringify(rows,null,1)+'\n');console.log(rows.length+' rows: '+rows.filter(x=>x.answer==='yes').length+' yes, '+rows.filter(x=>x.answer==='unknown').length+' unknown');
