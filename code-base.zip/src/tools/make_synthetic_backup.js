// Builds a backup set (the JSON file and the rebuild kit zip) from a data folder without a browser, in the shapes the page writes
// (BACKUP_FORMAT.md). Used by tests/backup_verify.js with the invented demo data. usage: node tools/make_synthetic_backup.js <datadir> <outdir> [YYYY-MM-DD]
'use strict';
const fs=require('fs');const path=require('path');const L=require('./backup_lib');
function build(dir,day){const ids=fs.readdirSync(dir).filter(f=>f.endsWith('.json')).map(f=>f.slice(0,-5)).sort();
  const datasets={},schema={},statuses=[];
  ids.forEach(id=>{const raw=JSON.parse(fs.readFileSync(path.join(dir,id+'.json'),'utf8'));const rows=Array.isArray(raw)?raw:raw.rows;datasets[id]=rows;schema[id]=L.schemaOf(rows);statuses.push({id,status:'ok',rows:rows.length,message:null});});
  const docs={};ids.forEach(id=>{docs[id]={title:id.slice(0,30),description:'Example dataset '+id,source_name:id+'.json',source_kind:'file',updated:{at:day+'T00:00:00.000Z',by:'Claude'}};});
  const meta={title:'Money Operations Center'};const enc=s=>Buffer.from(s,'utf8');const files=[];const add=(name,text)=>{const b=enc(text);files.push({name,bytes:b,sha256:L.sha256(b)});};
  ids.forEach(id=>add('datasets/'+id+'.json',L.datasetText(datasets[id])));ids.forEach(id=>add('csv/'+id+'.csv',L.toCsv(datasets[id])));
  add('docs/datasets.json',JSON.stringify(docs,null,1)+'\n');add('dash/meta.json',JSON.stringify(meta,null,1)+'\n');add('schema.json',JSON.stringify({schema_version:L.SCHEMA_VERSION,datasets:schema},null,1)+'\n');add('RESTORE.md','# Restore (synthetic test kit)\n');
  const exported=day+'T12:00:00.000Z';
  const manifest={schema_version:L.SCHEMA_VERSION,exported,day,dataset_count:ids.length,datasets_ok:ids.length,calc_count:0,statuses,docs_source:'synthetic',page_source:'not readable in this view: ask Claude for the page source',task_overlay:'none',check_values:{net_worth:1000},files:files.map(f=>({path:f.name,bytes:f.bytes.length,sha256:f.sha256}))};
  const mtext=JSON.stringify(manifest,null,1)+'\n';files.push({name:'manifest.json',bytes:enc(mtext)});
  const json={schema_version:L.SCHEMA_VERSION,exported,manifest,docs,meta,schema,restore_steps:'# Restore (synthetic test kit)\n',datasets,calcs:{},page_files:null,task_overlay:null};
  return {json,files,day};}
exports.build=build;
if(require.main===module){const [dir,out,day]=process.argv.slice(2);if(!dir||!out){console.log('usage: node tools/make_synthetic_backup.js <datadir> <outdir> [YYYY-MM-DD]');process.exit(2);}
  const d=day||'2026-01-01';const b=build(dir,d);fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'dashboard-backup-'+d+'.json'),JSON.stringify(b.json,null,1));fs.writeFileSync(path.join(out,'dashboard-kit-'+d+'.zip'),L.writeZip(b.files));console.log('wrote dashboard-backup-'+d+'.json and dashboard-kit-'+d+'.zip in '+out);}
