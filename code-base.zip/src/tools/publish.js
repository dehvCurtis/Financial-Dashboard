// One publish script: builds the files, checks them and writes PUBLISH_LIST.md plus a payload per file. It never writes to the store.
// usage: node tools/publish.js --stage <n> [--pins pins.json] [--ref-data <published data dir>] [--ref-split <published split dir>] [--title "..."]
//   pins.json: {"index.html":29,"app_a.js":3,...,"datasets":{"liabilities":7}} as read from the live store by the coordinator; a file
//   with no pin is CREATE; a dataset with no pin says "unknown, read before writing".
// Checks (any failure stops the script, nothing is written):
//   1. the last full run (work/last_full.json) passed and matches the tree as it is (no edit since);
//   2. every page file at most 200 KB and its JSON text at most 256 KB; selftest.js at most 60 KB;
//   3. live shape: every dataset loads in the real runtime parser and every calc is ok on it (tools/engine.js); every nested cell sits in a
//      column the page parses;
//   4. no em or en dash in any file to publish;
// Writes out/stage_<n>/PUBLISH_LIST.md (the format of the hotfix list), out/stage_<n>/payload/<file>.json ({"text": ...}) and copies the
// files to out/stage_<n>/files/.
'use strict';
const fs=require('fs');const path=require('path');const crypto=require('crypto');const {execFileSync}=require('child_process');
const D=path.resolve(__dirname,'..');const S=path.resolve(D,'..');const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const stage=arg('--stage');if(stage==null){console.log('usage: node tools/publish.js --stage <n> [--pins pins.json] [--ref-data dir] [--ref-split dir]');process.exit(2);}
const pf=arg('--pins');const pins=pf&&fs.existsSync(pf)?JSON.parse(fs.readFileSync(pf,'utf8')):{};
const refData=arg('--ref-data')||D+'/work/published/data_all',refSplit=arg('--ref-split')||D+'/work/published/split';
const fail=m=>{console.error('PUBLISH STOPPED: '+m);process.exit(1);};
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
/* 1 */const lf=D+'/work/last_full.json';if(!fs.existsSync(lf))fail('no clean full run on record: run bash runall.sh --full');
{const L=JSON.parse(fs.readFileSync(lf,'utf8'));const now=require('./tree_hash.js').hashes();const ch=[...new Set(Object.keys(now).concat(Object.keys(L.hashes)))].filter(k=>now[k]!==L.hashes[k]);
 if(L.fail||ch.length)fail('the tree changed after the last full run ('+ch.slice(0,6).join(', ')+'): run bash runall.sh --full again');}
execFileSync('node',[D+'/tools/build_page.js'],{stdio:'pipe'});execFileSync('node',[D+'/tools/build_split.js'],{stdio:'pipe'});
const split=D+'/out/split';const files=['index.html'].concat(fs.readdirSync(split).filter(f=>f!=='index.html').sort());
/* 2, 4 */const F=files.map(f=>{const t=fs.readFileSync(path.join(split,f),'utf8');const j=JSON.stringify({text:t});const ref=path.join(refSplit,f);
  return {f,bytes:Buffer.byteLength(t),json:JSON.stringify(t).length,sha:sha(t),pin:pins[f]==null?'CREATE':pins[f],refBytes:fs.existsSync(ref)?fs.statSync(ref).size:null,same:fs.existsSync(ref)&&sha(fs.readFileSync(ref))===sha(t),t,j};});
F.forEach(x=>{if(x.bytes>200*1024)fail(x.f+' is '+x.bytes+' bytes, over 200 KB');if(x.json>256*1024)fail(x.f+' JSON text is '+x.json+', over 256 KB');if(x.f==='selftest.js'&&x.bytes>60*1024)fail('selftest.js over 60 KB');if(/[\u2013\u2014]/.test(x.t))fail('em or en dash in '+x.f);});
/* 3 */{const E=require('./engine.js');const r=E.run({page:D+'/out/index_page.html',data:D+'/data_all'});const bad=Object.keys(r.calcs).filter(k=>r.calcs[k].status!=='ok').concat(Object.keys(r.datasets).filter(k=>r.datasets[k].status!=='ok'));
 if(bad.length||r.stopped)fail('live shape: not ok on the real runtime parser: '+bad.join(', ')+(r.stopped?' (script stopped)':''));}
/* datasets that differ from the published ones */
const dsNow=fs.readdirSync(D+'/data_all').filter(f=>f.endsWith('.json')).sort();const titles=JSON.parse(fs.readFileSync(D+'/tests/doc_titles.json','utf8'));
const DS=dsNow.map(f=>{const b=fs.readFileSync(path.join(D,'data_all',f));const rf=path.join(refData,f);const id=f.slice(0,-5);const isNew=!fs.existsSync(rf);
  return {id,bytes:b.length,sha:sha(b),isNew,changed:isNew||sha(fs.readFileSync(rf))!==sha(b),pin:(pins.datasets||{})[id]};}).filter(x=>x.changed);
const removed=fs.existsSync(refData)?fs.readdirSync(refData).filter(f=>f.endsWith('.json')&&!dsNow.includes(f)).map(f=>f.slice(0,-5)):[];
const out=D+'/out/stage_'+stage;fs.mkdirSync(out+'/payload',{recursive:true});fs.mkdirSync(out+'/files',{recursive:true});
F.forEach(x=>{fs.writeFileSync(out+'/payload/'+x.f+'.json',x.j);fs.writeFileSync(out+'/files/'+x.f,x.t);});
fs.mkdirSync(out+'/datasets',{recursive:true});DS.forEach(x=>fs.copyFileSync(path.join(D,'data_all',x.id+'.json'),path.join(out,'datasets',x.id+'.json')));
const L=JSON.parse(fs.readFileSync(lf,'utf8'));const title=arg('--title')||('stage '+stage);
const md=['# Publish list ('+title+')','',
 'Built '+new Date().toISOString().slice(0,10)+' from '+path.basename(D)+' (`bash runall.sh --full`: '+L.pass+' checks pass, 0 fail, '+L.seconds+' s, recorded '+L.at+'). Write each file as collection `files`, field `text` = the whole file (ready payloads: `out/stage_'+stage+'/payload/<file>.json`), pinned with `if_version` to the version below; a file marked CREATE has no live version yet (write it without a pin, before index.html). Write all page files in one batch, index.html last.','',
 '| File | Source path | Bytes | JSON text length | sha256 | Pin (current live version) | Published bytes |','|---|---|---|---|---|---|---|']
 .concat(F.map(x=>'| `files/'+x.f+'` | `'+path.basename(D)+'/out/stage_'+stage+'/files/'+x.f+'` | '+x.bytes+' | '+x.json+' | `'+x.sha+'` | '+x.pin+' | '+(x.refBytes==null?'new':x.refBytes+(x.same?' (unchanged)':''))+' |'))
 .concat(['','index.html loads '+F.filter(x=>x.f!=='index.html').map(x=>x.f).join(', ')+' in that order. Each file is under 200 KB and its JSON text under 256 KB.','','## Datasets','',
  DS.length?'Upload each JSON below as an asset (one per publish call), then write all `datasets/<id>` docs in one batch with `if_version` from a fresh read. New datasets need a new doc (title, description, source {kind file, format json, name <id>.json, url /_blob/<asset>}).':'None. Every file in `'+path.basename(D)+'/data_all` is byte equal to the published data (`'+path.relative(S,refData)+'`).','']
  .concat(DS.length?['| Dataset | Source path | Bytes | sha256 | Doc title | Pin |','|---|---|---|---|---|---|'].concat(DS.map(x=>'| `'+x.id+'` | `'+path.basename(D)+'/out/stage_'+stage+'/datasets/'+x.id+'.json` | '+x.bytes+' | `'+x.sha+'` | '+(titles[x.id]||'(needs a title)')+(x.isNew?' (new doc)':'')+' | '+(x.pin==null?(x.isNew?'CREATE':'unknown, read before writing'):x.pin)+' |')):[])
  .concat(removed.length?['','Removed datasets (delete their docs only after the page files are live): '+removed.join(', ')]:[]))
 .concat(['','## After publishing','','1. Ask the user to open the page, then read the page's `runs` doc in the Artifact store: no entry with `calc: true`, every dataset `status: "ok"`, no `errors`.',
  '2. More, Self-test: press Run the self-test; it must say every check passes.','3. Triple tap the page title: "calcs that did not run: none".']).join('\n')+'\n';
fs.writeFileSync(out+'/PUBLISH_LIST.md',md);console.log('wrote '+path.relative(D,out)+'/PUBLISH_LIST.md: '+F.length+' page files ('+F.filter(x=>!x.same).length+' changed), '+DS.length+' datasets');
