// Builds the documents. Hand-written text lives in docs_src/*.md; every table that can come from the code or the data is generated
// here and substituted at {{GEN:name}} markers, so a document cannot drift from the code without the check (tools/check_docs.js) failing.
// usage: node tools/gen_docs.js [--out dir]   (run tools/tiles_inventory.js, tools/tiles_inventory.js --blank and tools/docs_facts.js first)
'use strict';
const fs=require('fs');const path=require('path');
const ROOT=path.resolve(__dirname,'..');const arg=k=>{const i=process.argv.indexOf(k);return i>0?process.argv[i+1]:null;};
const OUT=arg('--out')||ROOT+'/docs_out';const SRC=ROOT+'/docs_src';
const F=JSON.parse(fs.readFileSync(ROOT+'/work/facts.json','utf8'));
const BLANK=fs.existsSync(ROOT+'/work/tiles_blank.json')?JSON.parse(fs.readFileSync(ROOT+'/work/tiles_blank.json','utf8')):[];
const DN=JSON.parse(fs.readFileSync(SRC+'/dataset_notes.json','utf8'));
const TN=fs.existsSync(SRC+'/tiles_notes.json')?JSON.parse(fs.readFileSync(SRC+'/tiles_notes.json','utf8')):{};
const QN=fs.existsSync(SRC+'/question_notes.json')?JSON.parse(fs.readFileSync(SRC+'/question_notes.json','utf8')):{};
const ON=fs.existsSync(SRC+'/offpage_notes.json')?JSON.parse(fs.readFileSync(SRC+'/offpage_notes.json','utf8')):{};
const CN=fs.existsSync(SRC+'/calc_notes.json')?JSON.parse(fs.readFileSync(SRC+'/calc_notes.json','utf8')):{};
const md=s=>String(s==null?'':s).replace(/\|/g,'/').replace(/\n+/g,' ');
const tbl=(head,rows)=>['| '+head.join(' | ')+' |','|'+head.map(()=>'---').join('|')+'|'].concat(rows.map(r=>'| '+r.map(md).join(' | ')+' |')).join('\n');
const mask=s=>String(s||'').replace(/\$\s?[\d,]+(\.\d+)?[kM]?/g,'$N').replace(/\b\d[\d,]*(\.\d+)?%/g,'N%').replace(/\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.? \d{1,2}(, \d{4})?/g,'DATE').replace(/\b20\d\d\b/g,'YEAR').replace(/\b\d+(\.\d+)?\b/g,'N');
const unitOf=(f,t)=>{const T=t.filter(x=>x!=='null');const isNum=T.includes('number'),isStr=T.includes('string');
  if(T.includes('boolean'))return 'true/false';if(T.includes('object')||T.includes('array'))return 'JSON text (nested)';
  if(/(^|_)pct(_|$)|percent|(^|_)rate$|apr|apy/.test(f)&&isNum)return 'percent';
  if(isStr&&/^month$/.test(f))return 'month YYYY-MM';
  if(isStr&&/(date|_on$|_at$|^date$|^from$|period_(start|end)|^closing|maturity|late_after|^next_due$|^due$)/.test(f))return 'date YYYY-MM-DD';
  if(isNum&&/(count|^n_|rows|days|months|^year$|plan_year|paychecks|age$|priority|order|weight|points)/.test(f))return 'count or year';
  if(isNum&&/(amount|balance|value|gross|net|tax|fica|k401|hsa|benefit|garnish|payment|interest|principal|escrow|salary|price|cost|fee|limit|ytd|total|credit|debit|dividend|opening|closing|inflow|outflow|expected|reported|drift|assets|debts|retirement|per_paycheck|annual|target|saved|contribution|monthly|purchase|advance|quantity|basis|gain|due|deferral|catchup|ira|spent|minimum|available|subject)/i.test(f))return 'USD';
  if(/_id$|^id$/.test(f))return 'id';if(isNum)return 'number';return isStr?'text':'';};
/* a dataset note may name the unit of a field (field_units) where the name heuristic would say only text or number, for example an enum */
const unitFor=(id,f,t)=>((DN[id]||{}).field_units||{})[f]||unitOf(f,t);
/* ---- page of each dataset and calc: from the data-source attributes of the rendered cards, charts and tables ---- */
const PAGE_OF={calc:{},ds:{}};
{const add=(o,k,p)=>{(o[k]=o[k]||new Set()).add(p);};
 const closure=id=>{const seen=new Set();const q=[id];while(q.length){const x=q.pop();if(seen.has(x))continue;seen.add(x);(F.calcs[x]?F.calcs[x].inputs:[]).forEach(i=>q.push(i));}return seen;};
 F.tiles.filter(t=>t.sources).forEach(t=>t.sources.forEach(s=>closure(s).forEach(x=>add(F.calcs[x]?PAGE_OF.calc:PAGE_OF.ds,x,t.page))));}
const pages=o=>o?[...o].sort().join(', '):'(not drawn directly; read by other calcs)';
/* ---- generated blocks ---- */
const G={};
G.counts=()=>`${F.ds_order.length} datasets, ${Object.keys(F.calcs).length} calcs, ${F.checks.length} correlation checks, ${F.profile.length} profile questions`;
G.dataset_index=()=>tbl(['Dataset id','Class','Key field','Needed for a first build','Rows in the demo','Doc title (max 30)','Read by (calcs)'],
  F.ds_order.map(id=>{const d=F.datasets[id],n=DN[id]||{};return [id,n.class,n.key,n.required?'yes':'optional',d.rows,d.title,d.calcs.join(', ')||'(drawn directly)'];}));
G.dataset_sections=()=>F.ds_order.map(id=>{const d=F.datasets[id],n=DN[id]||{};
  const fr=Object.entries(d.fields).map(([f,t])=>[f,t.join(' or '),unitFor(id,f,t)]);
  return [`### ${id}`,'',`${n.purpose||d.description}`,'',
   `- Class: ${n.class}. Key field: ${n.key}. File shape: ${d.shape}. ${n.required?'Needed for a first build.':'Optional: add it when the situation applies.'}`,
   `- Doc title: "${d.title}" (${(d.title||'').length} characters). Description: ${d.description}`,
   `- Intake: ${n.intake}. CSV view: ${n.csv}. Starter template: templates/${id}.json`,
   `- Read by calcs: ${d.calcs.join(', ')||'none (drawn directly by the page)'}`,
   `- Shown on pages: ${pages(PAGE_OF.ds[id])}`,'',
   tbl(['Field','Value types seen','Unit (heuristic)'],fr),''].join('\n');}).join('\n');
/* datasets kept in data_offpage/: in the database and the file backup, not loaded by the page (no calc reads them). Fields come from the files. */
G.offpage_sections=()=>Object.keys(ON).map(id=>{const n=ON[id],f=ROOT+'/data_offpage/'+id+'.json';const raw=fs.existsSync(f)?JSON.parse(fs.readFileSync(f,'utf8')):[];const list=Array.isArray(raw)?raw:(raw.rows||[]);
  const types={};list.forEach(r=>Object.keys(r).forEach(k=>{(types[k]=types[k]||new Set()).add(r[k]===null?'null':Array.isArray(r[k])?'array':typeof r[k]);}));
  const fr=Object.keys(types).map(k=>{const T=[...types[k]];return [k,T.join(' or '),unitOf(k,T)];});
  return [`#### ${id}`,'',n.purpose,'',`- Class: ${n.class}. Key field: ${n.key}. Not loaded by the page. Starter template: templates/offpage/${id}.json`,`- Intake: ${n.intake}. CSV view: ${n.csv}`,'',tbl(['Field','Value types seen','Unit (heuristic)'],fr),''].join('\n');}).join('\n');
G.calc_index=()=>tbl(['Calc id','Title','Inputs','Shown on'],F.ds_order.length?Object.values(F.calcs).map(c=>[c.id,c.title,c.inputs.join(', '),pages(PAGE_OF.calc[c.id])]):[]);
G.calc_sections=()=>Object.values(F.calcs).map(c=>{const sh=c.shape;const out=sh.kind==='array'?`array of row objects (${sh.keys.length?sh.keys.slice(0,24).join(', ')+(sh.keys.length>24?', ...':''):'no keys'})`:sh.kind==='object'?`object (${sh.keys.slice(0,24).join(', ')})`:sh.kind;
  const extra=CN[c.id];
  return [`### ${c.id}`,'',`- Title: ${c.title}`,`- Rule: ${c.description}`,extra?`- Notes: ${extra}`:'',`- Inputs: ${c.inputs.join(', ')}`,`- Feeds: ${c.readers.join(', ')||'drawn by the page only'}`,`- Output: ${out}`,`- Shown on: ${pages(PAGE_OF.calc[c.id])}`,''].filter(x=>x!=='').join('\n')+'\n';}).join('\n');
G.checks_table=()=>tbl(['Check','Name','Calc that runs it'],F.checks.map(c=>[c.id,c.name,c.calc]));
G.score_components=()=>tbl(['Score','Id','Component','Weight','Best','Worst','Unit','Needs gating'],F.score_components.map(c=>[c.score,c.id,c.name,c.weight,c.best,c.worst,c.unit,c.gated?'yes':'']));
G.profile_table=()=>{const order=F.profile;return tbl(['#','Question id','Category','Kind','Asked in Claude as','Counts as yes when the data has','Unanswered: the Needs text','Feeds'],
  order.map((p,i)=>{const n=QN[p.q]||{};return [i+1,p.q,p.cat,p.kind,'Do you have '+(p.ask||p.cat.toLowerCase())+'?',n.match||'',(p.kind==='debt'?'Needs: your '+p.cat.toLowerCase()+' details (balance, rate, payment and due date)':p.kind==='bill'?'Needs: your '+p.cat.toLowerCase()+' details (name, amount a month and due day)':p.kind==='retirement'?'Needs: your '+p.cat.toLowerCase()+' details (what goes in each paycheck)':'Needs: your '+p.cat.toLowerCase()+' details (balance and as-of date)'),n.feeds||'profile_calc, needs_calc'];}));};
G.backup_dataset_table=()=>tbl(['Dataset id','Purpose','Row fields (type, unit)','Key field','Used by calcs','Shown on pages','First build','CSV file'],
  F.ds_order.map(id=>{const d=F.datasets[id],n=DN[id]||{};return [id,n.purpose,Object.entries(d.fields).map(([f,t])=>f+' ('+t.filter(x=>x!=='null').join('/')+(unitFor(id,f,t)&&unitFor(id,f,t)!=='text'&&unitFor(id,f,t)!=='number'?', '+unitFor(id,f,t):'')+')').join('; '),n.key,d.calcs.join(', ')||'-',pages(PAGE_OF.ds[id]),n.required?'required':'optional','csv/'+id+'.csv'];}));
/* tiles */
const ident=t=>t.page+'|'+t.kind+'|'+(t.key||mask(t.label).slice(0,50));
G.tile_idents=()=>F.tiles.map(ident);
/* written synchronously: process.exit right after console.log can cut a piped stdout short, which made the docs check flaky */
if(process.argv.includes('--idents')){fs.writeSync(1,F.tiles.map(ident).join('\n')+'\n');process.exit(0);}
const blankMap={};BLANK.forEach(t=>{blankMap[ident(t)]=t;});
const sourcesOf=t=>{if(t.sources&&t.sources.length)return t.sources;const n=TN[ident(t)];return n&&n.sources?n.sources:[];};
G.tiles=()=>{const pagesOrder=['home','debt','bills','cash','investments','retirement','progress','tasks','pay','data'];let out=[];
  for(const pg of pagesOrder){const rows=F.tiles.filter(t=>t.page===pg);if(!rows.length)continue;out.push(`## Page: ${pg}`,'');
    for(const kind of ['card','tile','chart','table']){const rs=rows.filter(t=>t.kind===kind);if(!rs.length)continue;out.push(`### ${pg}: ${kind}s`,'');
      out.push(tbl(['Tile id or key','Label','Key number or chart (example shape)','Calcs and datasets','Formula in words','Unit','Source on tap','Chips','Links to','About this fold','Needs when empty'],
       rs.map(t=>{const id=ident(t),n=TN[id]||{};const src=sourcesOf(t);const b=blankMap[id];
         const calcsOf=src.filter(s=>F.calcs[s]),dsOf=src.filter(s=>F.datasets[s]);const only=calcsOf.length===1?F.calcs[calcsOf[0]]:null;
         return [t.key||'(no id)',mask(t.label).slice(0,60),n.number||(t.kind==='tile'?mask(t.value):t.kind==='chart'?'chart: '+mask(t.label).slice(0,50):t.kind==='table'?'table':'card'),
           (calcsOf.concat(dsOf)).join(', ')||n.calcs||'(static text)',n.formula||(only?only.description:''),n.unit||(t.kind==='tile'?(/\$/.test(t.value)?'USD':/%/.test(t.value)?'percent':/months?/.test(t.value)?'months':/^\d+( of \d+)?$/.test(t.value)?'count':'text'):''),
           mask(t.source_tap).slice(0,120),t.chips.map(mask).filter((x,i,a)=>a.indexOf(x)===i).join('; ').slice(0,100),t.link_id?t.link_id+' ('+t.link_name+')':(n.nolink?'none: '+n.nolink:(t.kind==='tile'?'none: '+(n.nolink||'no larger chart or table exists for this number'):'target of tile links')),
           mask(t.about).slice(0,200),b&&b.needs.length?mask([...new Set(b.needs)].join(' / ')).slice(0,160):(blankMap[id]?'':'hidden until data exists')];}))
      ,'');}}
  return out.join('\n');};
G.tiles_nolink=()=>{const rs=F.tiles.filter(t=>t.kind==='tile'&&!t.link_id);return tbl(['Page','Tile','Why it has no link'],rs.map(t=>[t.page,mask(t.label),(TN[ident(t)]||{}).nolink||'no larger chart or table exists for this number']));};
/* ---- expand markers ---- */
const expand=text=>text.replace(/\{\{GEN:([a-z_]+)\}\}/g,(m,k)=>{if(!G[k])throw new Error('unknown marker '+k);return G[k]();}).replace(/\{\{N:([a-z_]+)\}\}/g,(m,k)=>({datasets:F.ds_order.length,calcs:Object.keys(F.calcs).length,checks:F.checks.length,profile:F.profile.length,tiles:F.tiles.filter(t=>t.kind==='tile').length,cards:F.tiles.filter(t=>t.kind==='card').length,charts:F.tiles.filter(t=>t.kind==='chart').length,tables:F.tiles.filter(t=>t.kind==='table').length}[k]));
fs.mkdirSync(OUT,{recursive:true});let n=0;
for(const f of fs.readdirSync(SRC).filter(f=>f.endsWith('.md'))){fs.writeFileSync(path.join(OUT,f),expand(fs.readFileSync(path.join(SRC,f),'utf8')));n++;}
fs.writeFileSync(OUT+'/.gen_ok',new Date().toISOString());
console.log('generated '+n+' documents into '+path.relative(ROOT,OUT));
