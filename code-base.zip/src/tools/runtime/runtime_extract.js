// Verbatim extracts from the live artifact-type/app.js (prettified), sha256 1bf5600158ec...
var nV = 8388608;
var yr0 = /^[A-Za-z0-9_-]{1,64}$/;
var Od = new Set(["__proto__", "constructor", "prototype"]);
var xr0 = new RegExp("[\\x00-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]", "g");
function u1(Z) {
    return typeof Z === "string" && yr0.test(Z) && !Od.has(Z);
  }
function m1(Z, J = 1 / 0) {
    if (typeof Z !== "string") return "";
    let Q = Z.replace(xr0, " ");
    return Q.length <= J ? Q : Array.from(Q).slice(0, J).join("");
  }
function g7(Z, J = 1 / 0) {
    return m1(Z, J)
      .replace(/[\r\n]+/g, " ")
      .trim();
  }
function a3(Z) {
    return typeof Z === "object" && Z !== null && !Array.isArray(Z) ? Z : {};
  }
function q6(Z, J) {
    return Object.hasOwn(Z, J) ? Z[J] : void 0;
  }
var LQ = (Z) => ({ ...Z, cut: "rows" });
function aV(Z) {
    let J = [];
    return (
      Z.forEach((Q, $) => {
        let X =
          g7(typeof Q === "number" || typeof Q === "boolean" ? String(Q) : Q) ||
          "column_" + String($ + 1);
        while (J.includes(X)) X += "_";
        J.push(X);
      }),
      J
    );
  }
function UL(Z) {
    if (typeof Z === "number") return Number.isFinite(Z) ? Z : null;
    if (typeof Z === "string") return m1(Z);
    if (typeof Z === "boolean") return Z;
    return null;
  }
function Jn0(Z) {
    if (typeof Z !== "object" || Z === null) return UL(Z);
    if (
      !Array.isArray(Z) &&
      Object.hasOwn(Z, "value") &&
      typeof Z.value !== "object"
    )
      return UL(Z.value);
    try {
      return JSON.stringify(Z);
    } catch {
      return null;
    }
  }
function h9(Z) {
    let J = Z,
      Q = [];
    if (!Array.isArray(Z) && typeof Z === "object" && Z !== null) {
      let z = Z;
      J = ["rows", "data", "results"]
        .map((V) => (Object.hasOwn(z, V) ? z[V] : void 0))
        .find(Array.isArray);
      let W = Object.hasOwn(z, "columns") ? z.columns : void 0;
      if (Array.isArray(W)) Q = W.filter((V) => typeof V === "string");
    }
    if (!Array.isArray(J)) return null;
    let $ = [];
    for (let z of J)
      if (typeof z === "object" && z !== null && !Array.isArray(z)) $.push(z);
    let X = new Set();
    for (let z of $) for (let W of Object.keys(z)) X.add(W);
    let Y = [...new Set(Q)].filter((z) => X.has(z)),
      q = [...Y, ...[...X].filter((z) => !Y.includes(z))],
      G = aV(q),
      K = $.map((z) => {
        let W = Object.create(null);
        return (
          G.forEach((V, U) => {
            let B = q[U];
            W[V] = Object.hasOwn(z, B) ? Jn0(z[B]) : null;
          }),
          W
        );
      });
    return { columns: G, rows: K };
  }
var QB = (Z) =>
      Z.length < 3
        ? Z.join(" and ")
        : Z.slice(0, -1).join(", ") + ", and " + Z[Z.length - 1];
var d7 = (Z) => typeof Z === "object" && Z !== null && !Array.isArray(Z);
var sF0 = (Z) => Array.isArray(Z) && Z.every(d7);
function NL(Z) {
    return sF0(Z) || (d7(Z) && sF0(Z.rows));
  }
function Ea0(Z) {
    if (!d7(Z)) return [];
    let { label: J, value: Q, type: $, lang: X } = Z;
    if (
      typeof J !== "string" ||
      typeof Q !== "string" ||
      J.trim() === "" ||
      Q.trim() === ""
    )
      return [];
    if ($ !== "code") return [{ label: J, value: Q, type: "text" }];
    return [
      X === "sql"
        ? { label: J, value: Q, type: $, lang: X }
        : { label: J, value: Q, type: $ },
    ];
  }
function sd(Z) {
    try {
      return Array.isArray(Z) ? Z.flatMap(Ea0) : [];
    } catch {
      return [];
    }
  }
function AQ(Z, J) {
    let Q = sd(J);
    return Q.length === 0 ? Z : { ...Z, meta: Q };
  }
var lS = (Z) => (Z?.meta ?? []).map((J) => ({ ...J }));
function wa0(Z, J) {
    let Q = Z.charCodeAt(0) === 65279 ? Z.slice(1) : Z,
      $ = [],
      X = [],
      Y = "",
      q = !1;
    for (let G = 0; G < Q.length; G++) {
      let K = Q[G];
      if (q) {
        if (K !== '"') Y += K;
        else if (Q[G + 1] === '"') (Y += '"'), G++;
        else q = !1;
        continue;
      }
      if (K === '"' && Y === "") q = !0;
      else if (K === J) X.push(Y), (Y = "");
      else if (
        K ===
          `
` ||
        K === "\r"
      ) {
        if (
          K === "\r" &&
          Q[G + 1] ===
            `
`
        )
          G++;
        X.push(Y), (Y = ""), $.push(X), (X = []);
      } else Y += K;
    }
    if (Y !== "" || X.length > 0) X.push(Y), $.push(X);
    return $;
  }
function Ra0(Z, J) {
    let Q = wa0(Z, J).filter(
        (q) => !(q.length === 1 && (q[0] ?? "").trim() === ""),
      ),
      $ = Q[0];
    if ($ === void 0) return null;
    let X = aV($),
      Y = Q.slice(1).map((q) => {
        let G = Object.create(null);
        return (
          X.forEach((K, z) => {
            G[K] = UL((q[z] ?? "").trim()) || null;
          }),
          G
        );
      });
    return { columns: X, rows: Y };
  }
function ya0(Z) {
    try {
      let J = JSON.parse(Z),
        Q = h9(J);
      return Q === null || !d7(J) ? Q : AQ(Q, J.meta);
    } catch {
      return null;
    }
  }
function xa0(Z, J) {
    return J === "json" ? ya0(Z) : Ra0(Z, J === "tsv" ? "\t" : ",");
  }
var Pl = (Z) => ({
      data: { status: "error", value: null, message: Z },
      text: "",
      withheld: "",
    });
var kl = (Z) => ({ ...Pl(Z), cantRun: !0 });
var Fs0 = (Z) =>
      Z.length === 1
        ? String(Z[0]) + " uses itself, so it can’t run."
        : QB(Z) + " use each other, so they can’t run.";
function F_0(Z) {
    try {
      return { copy: structuredClone(Z) };
    } catch {
      return {};
    }
  }
function WB(Z, J, Q = new Set()) {
    for (let $ of Z) {
      if (Q.has($)) continue;
      Q.add($), WB(J($) ?? [], J, Q);
    }
    return Q;
  }
function Cl(Z) {
    try {
      return typeof Z === "function" ? Function.prototype.toString.call(Z) : "";
    } catch {
      return "";
    }
  }
function Ms0(Z) {
    let J;
    try {
      J = JSON.stringify(Z);
    } catch {
      J = void 0;
    }
    if (typeof J !== "string")
      return {
        error:
          "Its result isn’t plain data (numbers, text, true or false, null, lists and objects), so it isn’t shown here.",
      };
    return { text: J };
  }
function M_0(Z) {
    let J = Z.now ?? Date.now,
      Q = new Map(),
      $ = new Map(),
      X = new Map(),
      Y = (H) => (Z.has(H) ? void 0 : Q.get(H)?.inputs);
    function q(H) {
      let M = Q.get(H);
      return M === void 0 ? void 0 : [...WB(M.inputs, Y)];
    }
    function G(H, M) {
      let F = WB(M.inputs, Y);
      if (Y(H) === void 0 || !F.has(H)) return [];
      return [...F].filter((_) => WB(Y(_) ?? [], Y).has(H)).sort();
    }
    function K(H, M) {
      if (!u1(H)) return;
      let F = typeof M === "object" && M !== null ? M : {},
        _ = F.inputs,
        L = typeof F.fn === "function" ? F.fn : null,
        N =
          L === null || !Array.isArray(_)
            ? "dash.calc takes an id and {inputs, fn, description}."
            : _.length === 0 || !_.every(u1) || new Set(_).size !== _.length
              ? "dash.calc takes one or more ids, each once."
              : "",
        D = N === "" ? [..._] : [];
      Q.set(H, {
        inputs: D,
        fn: L,
        code: Cl(L),
        title: g7(F.title),
        description: typeof F.description === "string" ? g7(F.description) : "",
        problem: N,
      }),
        $.delete(H);
    }
    function z(H, M) {
      if (H.problem !== "") return kl(H.problem);
      let F = H.inputs.filter(
        (A, I) => M[I]?.data.status === "ok" && !Object.hasOwn(M[I], "copy"),
      );
      if (F.length > 0)
        return kl(
          "What " + QB(F) + " returned isn’t plain data, so this didn’t run.",
        );
      let _ = H.inputs.map((A, I) => {
          let O = M[I] ?? null;
          if (O !== null)
            return {
              status: O.data.status,
              stopped: A + " didn’t run",
              give: () => structuredClone(O.copy),
            };
          let k = Z.input(A);
          return {
            status: k.status,
            stopped:
              A +
              (k.status === "missing"
                ? " isn’t in this dashboard"
                : " didn’t load"),
            give: () => [...k.rows],
          };
        }),
        L = _.filter((A) => A.status !== "ok" && A.status !== "loading");
      if (L.length > 0) return Pl(L.map((A) => A.stopped).join(", ") + ".");
      if (_.some((A) => A.status === "loading"))
        return {
          data: { status: "loading", value: null, message: "" },
          text: "",
          withheld: "",
        };
      let N;
      try {
        N = H.fn(..._.map((A) => A.give()));
      } catch (A) {
        let I = m1(A instanceof Error ? A.message || A.name : String(A));
        return Pl(I.trim() === "" ? "It threw an error with no message." : I);
      }
      let D = { status: "ok", value: N, message: "" },
        j = Ms0(N);
      if ("error" in j)
        return { data: D, text: "", withheld: j.error, ...F_0(N) };
      return { data: D, text: j.text, withheld: "", ...F_0(N) };
    }
    function W(H, M, F) {
      let _ = JSON.stringify([
        M.inputs,
        M.code,
        M.title,
        M.description,
        F.data.status,
        F.text,
        F.data.message,
        F.withheld,
        F.cantRun,
      ]);
      if (X.get(H) === _) return;
      X.set(H, _),
        Z.post({
          id: H,
          inputs: M.inputs,
          code: M.code,
          ...(M.title !== "" ? { title: M.title } : {}),
          description: M.description,
          status: F.data.status,
          value: F.text,
          error: F.data.message,
          at: J(),
          ...(F.withheld !== "" ? { withheld: F.withheld } : {}),
          ...(F.cantRun ? { cantRun: !0 } : {}),
        });
    }
    function V(H, M, F) {
      let _ = $.get(H);
      if (
        _ !== void 0 &&
        _.keys.length === M.length &&
        _.keys.every((N, D) => N === M[D])
      )
        return _.out;
      let L = F();
      return $.set(H, { keys: M, out: L }), W(H, Q.get(H), L), L;
    }
    function U(H, M, F) {
      let _ = F.get(H);
      if (_ !== void 0) return _;
      let L = G(H, M);
      for (let j of L)
        F.set(
          j,
          V(j, L, () => kl(Fs0(L))),
        );
      if (L.length > 0) return F.get(H);
      let N = M.inputs.map((j) => (Y(j) === void 0 ? null : U(j, Q.get(j), F))),
        D = V(
          H,
          M.inputs.flatMap((j, A) => (N[A] ? [N[A]] : Z.stateOf(j))),
          () => z(M, N),
        );
      return F.set(H, D), D;
    }
    function B(H) {
      let M = Q.get(H);
      if (M === void 0)
        return {
          status: "error",
          value: null,
          message: "No calculation “" + H + "” on this page.",
        };
      return U(H, M, new Map()).data;
    }
    return { define: K, data: B, under: q, ids: () => Q.keys() };
  }
function b95(Z) {
    return Z.rows.map((J) => ({ ...J }));
  }
var ZH = (Z, J) => ({
    status: Z,
    data: [],
    columns: [],
    rows: [],
    message: J,
    refreshing: !1,
    meta: [],
  });
