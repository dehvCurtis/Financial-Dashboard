# DATA_MODEL: every dataset

{{N:datasets}} datasets. Each is one JSON file: a non-empty array of flat row objects (or `{ "rows": [...] }`). A key missing from a row arrives as null on the page. Nested cells are limited to an allow-list (config datasets); everywhere else rows are flat scalars. Rules and the reasoning are in ARCHITECTURE.md sections 3 to 6.

## Classes

| Class | Meaning | Example |
|---|---|---|
| user | the user's own figures, from statements or answers | bills, liabilities, paystubs |
| history | dated rows that accumulate | balance_log, scores_history, networth_history, drift_history, price_history |
| reference | published statistics, with source | age_benchmarks, dti_benchmarks |
| config | settings with defaults | scores_config, assumptions, payoff_settings |
| derived | stored results that Claude refreshes | plan_summary, plan_stats |

## Common rules

- Money is a number in dollars; percent is a number like 4.5 (not 0.045); dates are YYYY-MM-DD; months YYYY-MM.
- Money rows carry `source` and `as_of_date` where the dataset has those fields.
- A correction replaces the old value in place (history datasets keep dated rows).
- Ids are stable and never reused (L1, B3, T7 ...).
- No account numbers, loan ids, SSNs, tax ids or addresses. Use the user's own labels.
- A dataset with nothing real yet ships one starter row with every value null (templates/). Calcs strip it (`realRows`).
- Dataset document title: 30 characters at most. Each document at most 256 KB.
- The Unit column below is a heuristic from the field name; the calc text and DATA_MODEL notes are the truth when they differ.

## Index

{{GEN:dataset_index}}

## Datasets in detail

{{GEN:dataset_sections}}
