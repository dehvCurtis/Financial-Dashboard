# DATA_MODEL: every dataset

{{N:datasets}} datasets. Each is one JSON file: a non-empty array of flat row objects (or `{ "rows": [...] }`). A key missing from a row arrives as null on the page. Nested cells are limited to an allow-list (config datasets); everywhere else rows are flat scalars. Rules and the reasoning are in ARCHITECTURE.md sections 3 to 6.

## Classes

| Class | Meaning | Example |
|---|---|---|
| user | the user's own figures, from statements or answers | bills, liabilities, paystubs |
| history | dated rows that accumulate | balance_log, scores_history, networth_history, drift_history, price_history |
| reference | published statistics, with source | age_benchmarks, dti_benchmarks |
| config | settings with defaults | scores_config, assumptions, payoff_settings |
| derived | stored results that Claude refreshes | plan_summary, plan_stats |

## Common rules

- Money is a number in dollars; percent is a number like 4.5 (not 0.045); dates are YYYY-MM-DD; months YYYY-MM.
- Money rows carry `source` and `as_of_date` where the dataset has those fields. Money rows of assets_other, liabilities, bills, cash_events and balance_log also carry `value_basis` and `source_kind` (Value basis below).
- A correction replaces the old value in place (history datasets keep dated rows).
- Ids are stable and never reused (L1, B3, T7 ...).
- No account numbers, loan ids, SSNs, tax ids or addresses. Use the user's own labels.
- A dataset with nothing real yet ships one starter row with every value null (templates/). Calcs strip it (`realRows`).
- Dataset document title: 30 characters at most. Each document at most 256 KB.
- The Unit column below is a heuristic from the field name; the calc text and DATA_MODEL notes are the truth when they differ.

## Value basis

Every money row (assets_other, liabilities, bills, cash_events, balance_log) carries `value_basis`, `source_kind`, `source` and `as_of_date`; liabilities also carry `payment_basis` for the monthly payment. tests/data_rules.js checks that each is present and from the fixed lists.

| value_basis | Meaning |
|---|---|
| reported | a number read from a statement or an app screen |
| stated | the user's own figure, used until a statement proves otherwise |
| derived | arithmetic on stored rows |
| expected | a balance the stored rows predict but no one has read |
| estimated | a guess or a budget figure; a row with no real source is estimated and has a Needs item |

| source_kind | Meaning |
|---|---|
| statement | a downloaded statement (PDF or CSV) |
| app_screen | a bank or servicer app screen or a screenshot |
| document | another document, such as a tax form or a pay stub |
| owner_stated | the user said it in chat |
| calculation | worked out from other rows |
| assumption | a setting or estimate with no document behind it |

Calc outputs that sum or combine rows report the weakest value_basis and the oldest as_of of the rows they used (fields basis and oldest_as_of), and the answers index repeats them with every number. The free text note that older bundles kept in assets_other.value_basis is now `value_basis_note`; liabilities.balance_basis stays free text. The `expected_is_reported` flag is gone: a row whose value is a prediction has `value_basis` expected.

## Account flow: a pass-through checking account (standing workflow)

The workflow rule (standing, generic): every paycheck lands in Savings, and money moves from Savings to Checking before each payment. The user pays with the debit card tied to Checking. Checking is a pass-through account: it is exactly 0 once everything clears. Record each payment as a transfer plus a Checking spend; never record the funding account as the payer.

Each payment is two facts in `cash_events`:

1. A transfer between the user's own accounts, stored as two rows: the sending account negative and the receiving account positive, same date, each naming the other in `transfer_pair`, with `from_account` and `to_account`. A transfer changes the expected balance of both accounts and is never a known outflow. `in_balances` is Y once a balance reading that already includes it exists.
2. A payment on Checking (`kind` payment). `clearing` is waiting until the payment posts, then cleared. A waiting payment counts as a known outflow once confirmed. `funding_source` names the account that funded a pass-through payment.

`kind` is a fixed list: pay_deposit, transfer, payment, purchase, hold, cash (checked by tests/data_rules.js and invariant I37). The words shown on the page live in `kind_label`.

Rules:

- Until a payment clears its money is in transit and still inside the posted Checking balance. The posted balance is stored as `value_point` (net worth counts it as an asset).
- `spendable_value` (optional, assets_other, cash rows): what can be spent now. A pass-through Checking row sets it to 0. The runway and the payoff plan cushion read `spendable_value` when it is set and `value_point` otherwise, so in-transit money is never counted as spendable. Net worth always reads `value_point`. Spendable cash is never above the posted value (invariant I35), and moving money between the user's own accounts leaves net worth unchanged (unit test). The Cash card shows spendable cash as its one key number with a chip for the amount in transit.
- A debt keeps its last reported balance until the payment posts (the balance the schedule gives after the payment is kept in `expected_balance` and, for a mortgage, in `expected_after_next_payment`). When the payment posts, the debt falls by its principal part and the posted Checking falls by the whole payment; net worth changes only by the part that is not principal (interest, fees, escrow), which is a real cost.
- Pending holds are inside the posted balance. Posted minus pending holds is a candidate available balance; the app's available balance replaces it.
- Check C30 (Checking left over) is the latest posted reading less the payments still waiting. It should be 0; when it is not, the gap is shown and never hidden.
- Do not force a stated transfer total to equal the sum of the payments. Keep it as an unreconciled note with its date and ask for the statements.

## Datasets kept off the page (data_offpage)

The folder `data_offpage/` holds datasets that stay in the database and in every file backup but are NOT loaded by the page, because no calc or card reads them: `notes_log`, `bank_flows` and `bank_statements`. Keeping them off the page cuts the data the page loads at every open. Starter files are in templates/offpage/. They follow the same rules as the loaded datasets (flat rows, no identifiers, no dashes; tests/data_rules.js scans them).

`notes_log` holds long free text notes moved whole out of the loaded datasets, and merged request or task rows. A loaded row keeps its latest short note and ends with "(earlier notes: notes_log <row id>)". When repeated requests are merged, the survivor keeps the clearest wording and the union of `needs_key`; the removed row is kept whole in notes_log with an alias row (old id to survivor). Nothing is deleted and every original text can be found. Because the page does not load these files, the in-page backup kit lists only the loaded datasets: copy data_offpage with the rest of the database (BACKUP_FORMAT.md).

{{GEN:offpage_sections}}

## Index

{{GEN:dataset_index}}

## Datasets in detail

{{GEN:dataset_sections}}
