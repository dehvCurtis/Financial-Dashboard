# QUESTIONS: what Claude asks, in order, and where each answer goes

Two kinds of question exist. The profile questions are in the page code (`PROFILE_CATS` in page/js/65_calcs_profile_needs.js): the table below is generated from that code, so it cannot drift. The interview topics are the first-run script in ARCHITECTURE.md section 15, summarized here.

## Rules for asking

1. Ask in plain words, one topic per turn, a few questions at a time. Give an example of where to find the answer.
2. Never assume a debt, bill or account exists. The profile question comes first: "Do you have a mortgage?" The answer is yes, no or unknown.
3. A no is final. The category is left out of every calc and is not asked again. A no with rows in the data is a conflict (check C28) and is shown, not hidden.
4. A yes with no rows shows a Needs line and becomes a task and a data request. An unknown with no rows is a question for Claude to ask in chat. Rows in the data count as yes.
5. Accept a screenshot, PDF, CSV export or pasted text. Read every attachment fully, read the numbers back, then save with source and as-of date.
6. After each topic say in one sentence what it unlocks.
7. Never ask for account numbers, SSN, routing numbers, loan ids or street addresses.

## How an answer is stored

Dataset `profile_answers`, one row per question: `question_id` (the id in the table), `category`, `answer` (yes, no or unknown), `count` (rows the user says exist, optional), `asked_at` (date YYYY-MM-DD, optional), `note`. Rows already in liabilities, bills, assets_other or contributions count as yes without an answer row.

## Profile questions ({{N:profile}})

The question is always "Do you have X?" where X is the phrase in column "Asked in Claude as". Order is the order the page checks them.

{{GEN:profile_table}}

Status values the calc `profile_calc` returns per question: `have` (rows exist), `no`, `needs_entries` (answered yes, no rows), `ask` (unknown, no rows), `conflict` (answered no, rows exist). `needs_calc` turns `needs_entries` and `ask` into rows of the Needs list.

## Interview topics (ARCHITECTURE.md section 15)

| # | Topic | Stored in | Unlocks |
|---|---|---|---|
| 0 | Welcome, reminders preference | page preferences, reminders | habits |
| 1 | Names of bank, card issuers, lenders, plan, payroll | labels across datasets | readable labels |
| 2 | Age, target retirement age, income goal | retirement_plan | retirement model, age ladder |
| 3 | Filing status, state, tax bracket | assumptions | take-home cost estimate |
| 4 | Pay frequency, gross, next payday, latest stub | income_pay, paystubs | take-home, payoff surplus, Pay page |
| 5 | Rent or own, payment, balance, rate | bills or liabilities | housing in DTI |
| 6 | Every monthly bill | bills | Bills page, runway |
| 7 | Everyday spending estimate | bills (spending kind) | left over estimate |
| 8 | Balance of each bank and savings account on one day | balance_log, assets_other | cash, runway, drift |
| 9 | Each card and loan: balance, rate, minimum from the statement, due date | liabilities | DTI, payoff plan, scores |
| 10 | Money withheld from pay | liabilities | payoff surplus |
| 11 | Retirement and investment accounts, percent to 401(k), match, HSA | contributions, holding_snapshots, contribution_plan | Retirement page |
| 12 | Home, vehicle, other valuables | assets_other | net worth, loan to value |
| 13 | Upcoming expenses | savings_goals (and Save for when built) | goals, runway |
| 14 | Tax refund or tax owed | liabilities, assets_other | net worth |
| 15 | Insurance | bills, liabilities | score components |
| 16 | Layout preference | page config | layout |
| 17 | Check-in day, reminder time | milestones, reminders | check-ins |
| 18 | Confirm assumptions (growth, inflation, high rate line, card minimum estimate) | assumptions, scores_config | projections, scores |
| 19 | Read back one page and ask for corrections | all | trust |

## Wording library

| Situation | Say |
|---|---|
| Missing minimum payment | "Please read the minimum payment due from your latest statement, or send a screenshot. I will not estimate it." |
| Rate from memory | "Is this rate from a statement? I will mark it confirm on statement until it is." |
| Two balances disagree | "Statement A says X and the dashboard says Y. Which date is right?" |
| User says no to a category | "Understood. I will leave it out and not ask again." |
| Unknown | "No problem. I will keep a task for it and ask again on the next check-in." |

## Debit card payments (standing workflow)

| Situation | Say |
|---|---|
| A debit card payment is reported | "Was that moved from Savings to Checking first? I will record the transfer and the Checking spend and keep Checking as a pass-through." |
| Funding balance after the transfer unknown | "What is the Savings balance now? I will not guess it." |
| A payment has not cleared | "Has it cleared yet? Until it does I keep the debt as it is and count the money as in transit." |
| Transfer total does not match the payments | "The transfer of X does not add up to the payments I have (Y). Which payments did it cover? I keep it as unreconciled until the statement." |
| Posted and available balance differ | "What does the app show as the available balance, after the pending holds?" |
| The user says they moved money and paid from Checking | "Got it. I record the transfer and the Checking spend. Tell me each time you move money, and I will not assume a transfer you did not mention." |

## Basis of a number

| Situation | Say |
|---|---|
| A figure has no statement yet | "I will use your amount now and mark it stated until a statement proves otherwise. Can you send the downloaded statement?" |
| A figure came from a screenshot | "I used the screenshot now. Please send the downloaded statement (PDF or CSV) so I can confirm it." |
| A number is a budget or a guess | "That is an estimate. I will label it estimated and keep a Needs item until you have a real source." |
| A plan depends on a monthly left over amount | "The payoff date depends on the extra you really expect to pay each month. What amount should I save as your extra?" |
