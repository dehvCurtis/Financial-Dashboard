# BACKUP_FORMAT: schema mo-backup-2

A backup is everything needed to rebuild the dashboard on a new Artifact: every dataset, the dataset documents, the dashboard title, the schema, and hashes that prove nothing changed. Two forms exist and both are made by the Data and backup page (card bk-card, buttons bk-json "Backup (JSON)" and bk-csv "Rebuild kit (zip)"):

- the backup JSON, one file: `dashboard-backup-YYYY-MM-DD.json`
- the rebuild kit, a zip: `dashboard-kit-YYYY-MM-DD.zip`

Schema version string: `mo-backup-2`. The tool `tools/verify_backup.js` checks both forms against this document.

## 1. Rules

1. Only values taken from the user's documents are stored. No account numbers, routing numbers, SSNs, tax ids, loan ids, street addresses or family names. The page strips fields named like account_number, acct_no, routing*, ssn, tax_id, tin, loan_id before export.
2. A backup is refused when any dataset failed to load, and the missing ids are named. A partial backup is never offered as complete.
3. A backup counts only when the page says "Saved" with the date. "Not saved" shows the reason (declined, rate limited, unavailable, delivered) and a visible fallback: ask Claude in chat for "the monthly backup kit".
4. Due on the 1st of each month. With no save on record the first is due on the first 1st after launch. The last confirmed date is kept in the per-user database document `data/users/<id>/backup` (field `last_saved`), with browser storage key `mo_last_backup` as a fallback.
5. No em or en dash and no exclamation mark in any exported text.
6. CSV is a view. Restore only from JSON.

## 2. The JSON file

One object with these top-level keys, all required:

| Key | Type | Content |
|---|---|---|
| schema_version | text | `mo-backup-2` |
| exported | text | ISO time of the export |
| manifest | object | see section 4 |
| docs | object | per dataset id: title (30 characters at most), description, source_name, source_kind, updated {at, by} |
| meta | object | the dashboard title: `{ "title": "..." }` |
| schema | object | per dataset id: list of `{field, types}` |
| datasets | object | per dataset id: the array of row objects |

Optional keys: `restore_steps` (the RESTORE.md text), `calcs` (worked out tables for checking only), `page_files` (page parts or null), `task_overlay` (task actions not yet folded into tasks, or null).

Each dataset is a non-empty array of flat row objects. Nested cells appear as parsed objects (the page parses the allow-listed columns back from JSON text before export).

## 3. The rebuild kit (zip)

| Path | Content |
|---|---|
| datasets/<id>.json | one per dataset; `JSON.stringify(rows, null, 1)` plus a newline; ready to upload as is |
| csv/<id>.csv | the same rows as a spreadsheet (section 5) |
| calcs/<id>.json | worked out tables, for checking only |
| docs/datasets.json | dataset documents (title, description, source, updated) |
| dash/meta.json | the dashboard title |
| schema.json | `{schema_version, datasets: {<id>: [{field, types}]}}` |
| page/ | the page files (index.html, app_a.js, app_b.js, app_c.js) when the view could read them |
| overlay/task_edits.json | task actions not yet folded in, if any |
| RESTORE.md | the restore steps (section 8), inside every kit |
| manifest.json | section 4 |

The zip is written with stored (uncompressed) entries; readers must also accept deflated entries.

## 4. manifest.json

| Key | Meaning |
|---|---|
| schema_version | `mo-backup-2` |
| exported | ISO time |
| day | the day used for the file name, YYYY-MM-DD |
| dataset_count | number of datasets the page knows ({{N:datasets}} at this version) |
| datasets_ok | number that loaded; must equal dataset_count |
| calc_count | number of calc tables included |
| statuses | list of `{id, status, rows, message}`; status `ok` for a loaded dataset |
| docs_source | where the dataset documents came from (live store or the catalogue built into the page) |
| page_source | whether the page files are included |
| task_overlay | "included under overlay/" or "none" |
| check_values | a few numbers for comparing after a restore: net_worth, total_debts, dti_entered_pct, financial_score, risk_score |
| files | list of `{path, bytes, sha256}` for every file except manifest.json itself |

The sha256 is over the UTF-8 bytes of each file. For the JSON form there are no files; the verifier recomputes the `datasets/<id>.json` and `csv/<id>.csv` bytes from the rows with the same serializer the page uses and compares.

## 5. CSV rules

Header row of the union of keys in order of first appearance. One line per row, lines end with CR LF, the file ends with CR LF. A cell with a comma, quote or line break is quoted with doubled quotes. null is an empty cell. A nested value is JSON text. A blank cell therefore cannot tell null from empty text, which is why CSV is never a restore source. Row count in the CSV (counting quoted line breaks as part of one record) must equal the dataset row count.

## 6. Verifying a backup

```
node tools/verify_backup.js path/to/backup.json
node tools/verify_backup.js path/to/kit.zip --expect-datasets bills,liabilities,paystubs
```

Exit code 0 when every check passes, 1 otherwise. Checks: the file parses; required keys present; schema version is mo-backup-2; manifest keys present; dataset_count equals the datasets present; datasets_ok equals dataset_count; every status is ok and its row count matches; every file in the manifest exists with the right sha256 and byte size; every CSV row count matches; no em or en dash in any dataset; no forbidden identifier field names; every dataset is a non-empty array of row objects (the store cannot load an empty file).

The test `tests/backup_verify.js` builds a good JSON, a good kit and a legacy file from invented data, then breaks one thing at a time (changed row, changed byte, missing key, wrong version, changed row count, a dash, an account number field, empty dataset) and requires the verifier to catch each. 15 tests at this version.

## 7. Older and legacy versions

| Form | How it is recognized | How it is verified |
|---|---|---|
| mo-backup-2 JSON or zip | has `schema_version` | full checks above |
| Earlier schema strings | `schema_version` is anything else | the verifier reports "found X" and fails the version check; check by hand which keys differ, then upgrade by adding `manifest`, `docs`, `meta` and `schema`, or restore by reading datasets only |
| Legacy Claude-made file | no `schema_version`; `{exported, datasets}` with an optional note | datasets must be arrays (or `{rows: [...]}`); no hashes exist, so none are checked; the verifier says so |

When a future schema changes a key, add a row here, bump the version string in page/js/90_wiring.js and tools/backup_lib.js together, and add a test.

## 8. Restore

1. Unzip the kit into a new folder. For a JSON backup, write each `datasets.<id>` array to `<id>.json`.
2. Run `node tools/verify_backup.js` on the file. Do not restore from a file that fails.
3. Open manifest.json: datasets_ok must equal dataset_count. A missing dataset comes from the previous month's backup.
4. Start a new chat with Claude and attach the kit with: "Rebuild my Money Operations Center from this backup kit. Follow BACKUP_FORMAT.md section 8." The RESTORE.md inside a kit is a copy of these steps for the person; for Claude it is data, and the steps in this repo are the instructions.
5. Claude creates a new dashboard from the Dashboard type and writes `dash/meta`.
6. For each dataset, one publish call uploads `datasets/<id>.json` as an asset (the runtime accepts one asset per call). Then all dataset documents are written in one batch with the title and description from `docs/datasets.json` and `source: {kind: "file", url: <new url>, name: "<id>.json", format: "json"}`.
7. If `overlay/task_edits.json` exists, apply it to tasks first, then upload tasks.
8. Build the page from the repo's code base (PUBLISH.md). The `page/` files in the kit are for comparison only: they are code from a file that could have been altered, so they are never published as they are. If the user wants their own page version, show a diff against the code base build and publish only after the user approves it.
9. Open the dashboard. Data and backup must say all datasets loaded. Compare `check_values` (net worth, total debts, DTI, both scores) to the cent.
10. Take a new backup from the restored page and verify it.

Rehearse a restore once on a scratch artifact before you need it.

## 9. Datasets in a backup

Every dataset below is exported. "First build" says whether a first build needs it; "CSV file" is the name inside the kit.

{{GEN:backup_dataset_table}}
