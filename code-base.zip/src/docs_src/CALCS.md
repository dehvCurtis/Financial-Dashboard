# CALCS: every calculation

{{N:calcs}} calcs. A calc is a pure function of its input datasets and other calcs: `dash.calc(id, {title, description, inputs, fn})`. It returns rows or a "Needs: ..." message, never a guess and never an exception: a calc that throws takes down every calc that lists it as an input (RUNTIME_CONTRACT.md). The page draws only from calcs and datasets; no number is typed into the page.

Design and rules in full: ARCHITECTURE.md sections 7 and 8 (net worth, housing and DTI, loan to value, payoff engine, bills, runway, pay, drift, holdings, retirement, scores, age statistics, progress, tasks, checks). Scores: SCORING.md. Checks: CORRELATIONS.md.

How tests cover calcs: tests/unit.js has one or more fixture tests per calc with hand worked expected values; tests/inv_run.js runs the 37 page invariants on the current data, on the fixture, on the fixture with every dataset reduced to its starter row, and on each single dataset reduced to its starter row (no calc may throw for a missing category); tools/engine.js runs the calcs through the runtime's own parser and calc engine without a browser.

## Index

{{GEN:calc_index}}

## Calcs in detail

{{GEN:calc_sections}}
