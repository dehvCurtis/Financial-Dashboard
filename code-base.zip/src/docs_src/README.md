# Money Operations Center: starter bundle

A private personal finance dashboard that Claude builds for you as one Claude Artifact (Dashboard type), then keeps current from what you tell it and from the statements you upload. This bundle is everything a Claude agent needs to build it, fill it, test it and back it up. It contains no real data: every name is "Example ...", every amount is invented.

It is a planning tool built from numbers you enter. It is not financial, tax or legal advice.

## What you get

- A dashboard with 10 pages: Home, Debt, Bills, Cash, Investments, Retirement, Progress, Tasks, Pay, Data and backup. Counts at this version: {{GEN:counts}}.
- A missing-data protocol: nothing is guessed. A card without its inputs shows "Needs: X", the agent makes a task, and asks you in plain words.
- Statement intake: upload a PDF or CSV statement (pay stub, card, bank, mortgage, 401(k)), Claude reads it, saves every figure with its source and date, and the dashboard updates.
- A monthly backup (JSON plus a rebuild kit) with a verify tool, and a procedure to keep copies in Google Drive.
- A test suite and a documentation check, so changes do not break what already works.

## How to use it (three steps)

1. Start a new chat with Claude (Claude Code or a chat with the Artifact tool enabled). Attach this bundle, or at least README.md, CLAUDE.md, ARCHITECTURE.md and the templates folder. Paste the first prompt from PROMPTS.md.
2. Answer the interview (INTAKE_GUIDE.md and QUESTIONS.md). Skip anything you like; skipped items become tasks.
3. Upload statements whenever you have them. Take a backup on the 1st of each month (BACKUP_FORMAT.md, BACKUP_GOOGLE_DRIVE.md).

To see what a filled dashboard looks like before you enter anything, look at demo_data/ and the screenshots in demo_data/shots/. The demo is invented: Example Bank, Example Plan One, a round 1,000.00 style of amounts.

## Reading order

| Order | File | For |
|---|---|---|
| 1 | README.md | this page |
| 2 | CLAUDE.md | the working rules for the agent |
| 3 | ARCHITECTURE.md | how it is built, section by section (numbers stable) |
| 4 | ENVIRONMENT.md, RUNTIME_CONTRACT.md | what the machine and the Artifact runtime need and do |
| 5 | DATA_MODEL.md, CALCS.md, SCORING.md | every dataset, calc and score |
| 6 | TILES.md, CORRELATIONS.md | every tile, and the checks that tie the numbers together |
| 7 | QUESTIONS.md, INTAKE_GUIDE.md, PROMPTS.md | asking and intake |
| 8 | PUBLISH.md, RUNBOOK.md, SCHEDULED_TASKS.md | publishing and routine work |
| 9 | BACKUP_FORMAT.md, BACKUP_GOOGLE_DRIVE.md | backup and restore |
| 10 | SECURITY_AND_PRIVACY.md, SOURCES_AND_BENCHMARKS.md, LOCALIZATION.md, GLOSSARY.md | rules, sources, other countries, words |
| 11 | CHANGELOG.md, OPEN_ITEMS.md, REPORT.md, DEMO_DATA.md | history, what is not done, verification, the invented demo |
| 12 | INDEX.md, MANIFEST.json, CHECKSUMS.sha256, VERSION | the map and integrity |

Other folders: templates/ (one empty starter row per dataset), demo_data/ (the full invented dataset and screenshots), code-base.zip (page, tools, tests with synthetic fixtures).

## What it does not do

- It does not connect to your bank. You upload statements or type numbers.
- It does not store account numbers, SSNs, routing numbers, loan ids or street addresses (SECURITY_AND_PRIVACY.md).
- It does not publish or share anything without you asking (PUBLISH.md).
- It is built for US style finance (401(k), HSA, IRS limits, US benchmarks). LOCALIZATION.md says what to change elsewhere.

## License

TODO: the owner of this bundle has not chosen a license. Until one is added here, no license is granted.
