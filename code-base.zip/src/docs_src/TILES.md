# TILES: every card, tile, chart and table the page draws

This file is generated from the rendered page (tools/tiles_inventory.js builds the page with the example data, opens each of the 10 pages and records every card, number tile, chart and table) together with hand notes (docs_src/tiles_notes.json). tools/check_docs.js fails when a rendered tile is missing here or this file lists a tile that does not render. Do not edit the tables by hand; edit the notes file or the code and regenerate.

Counts at this version: {{N:tiles}} number tiles, {{N:cards}} cards, {{N:charts}} charts, {{N:tables}} tables.

## How to read the tables

| Column | Meaning |
|---|---|
| Tile id or key | the element id in the page, or "(no id)" |
| Label | the label on screen; amounts, percents and dates are masked as $N, N% and DATE |
| Key number or chart (example shape) | what the tile shows, in words or shape |
| Calcs and datasets | the calcs and datasets the tile reads (its Source on tap list) |
| Formula in words | how the number is worked out |
| Unit | USD, percent, months, count, date or text |
| Source on tap | the text shown when you tap the number |
| Chips | the small status words that can appear (Needs, Planned, Limit reached, Stale) |
| Links to | the larger chart or table the tile jumps to (the tile link rule, ARCHITECTURE.md section 13), or why there is none |
| About this fold | the closed "About this" text of the card |
| Needs when empty | what the tile says when it has no data, from the render of the all-empty starter (templates) |

Rules: every number tile links to the larger chart or table that shows the same number unless none exists (listed in the last section). Each card shows one key number or chart, short labels and chips; explanations sit in the closed About this fold; warnings and decision items stay visible.

{{GEN:tiles}}

## Tiles without a link

{{GEN:tiles_nolink}}
