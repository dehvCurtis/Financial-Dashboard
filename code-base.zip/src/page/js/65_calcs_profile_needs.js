/* ---------- what the user has (profile answers) and what every card is waiting for ---------- */
/* User rule: never assume a debt, bill or account exists. Each category below is one question; profile_answers holds the answer
   (yes, no or unknown). Rows in the data count as yes. No: the category is left out and never asked again. Yes with no rows: a Needs
   line and a data request. Unknown with no rows: ask in Claude. Categories are matched by type or category, never by a name. */
const PROFILE_CATS=[
 {q:'debt_mortgage',cat:'Mortgage',kind:'debt',t:l=>l.type==='Mortgage'},{q:'debt_heloc',cat:'Home equity line',kind:'debt',t:l=>l.type==='HELOC'},
 {q:'debt_card',cat:'Credit card',kind:'debt',t:l=>/credit card/i.test(l.type||'')},{q:'debt_auto',cat:'Auto loan',kind:'debt',t:l=>l.type==='Auto'},
 {q:'debt_student',cat:'Student loan',kind:'debt',t:l=>/student/i.test(l.type||'')},{q:'debt_personal',cat:'Personal loan',kind:'debt',t:l=>l.type==='Personal'},
 {q:'debt_medical',cat:'Medical bill',kind:'debt',t:l=>l.type==='Medical'},{q:'debt_tax',cat:'Tax owed',kind:'debt',t:l=>l.type==='Tax'},
 {q:'debt_support',cat:'Support order',kind:'debt',t:l=>l.type==='Support'},
 {q:'bill_housing',cat:'Rent or housing bill',kind:'bill',t:b=>b.category==='Housing'},{q:'bill_utilities',cat:'Utilities',kind:'bill',t:b=>b.category==='Utilities'},
 {q:'bill_phone',cat:'Phone',kind:'bill',t:b=>b.category==='Phone'},{q:'bill_insurance',cat:'Insurance',kind:'bill',t:b=>b.category==='Insurance'},
 {q:'bill_transport',cat:'Transportation',kind:'bill',t:b=>b.category==='Transportation'},{q:'bill_food',cat:'Food',kind:'bill',t:b=>b.category==='Food'},
 {q:'bill_pets',cat:'Pets',kind:'bill',t:b=>b.category==='Pets'},{q:'bill_childcare',cat:'Childcare',kind:'bill',t:b=>/child/i.test(b.category||'')},
 {q:'bill_subscriptions',cat:'Subscriptions',kind:'bill',t:b=>/subscri|streaming|entertain/i.test(b.category||'')},
 {q:'acct_checking',cat:'Checking account',kind:'account',t:a=>a.type==='Cash'&&/check/i.test(a.name||'')},{q:'acct_savings',cat:'Savings account',kind:'account',t:a=>a.type==='Cash'&&/saving/i.test(a.name||'')},
 {q:'acct_hsa',cat:'HSA',kind:'account',t:a=>a.type==='HSA'},{q:'acct_brokerage',cat:'Brokerage account',kind:'account',t:a=>a.type==='Brokerage'},
 {q:'acct_home',cat:'Home you own',kind:'account',t:a=>a.type==='Real estate'},{q:'acct_vehicle',cat:'Vehicle you own',kind:'account',t:a=>a.type==='Vehicle'},
 {q:'debt_other',cat:'Other debt',kind:'debt',t:null},{q:'bill_other',cat:'Other monthly bill',kind:'bill',t:null},
 {q:'ret_workplace',cat:'Workplace retirement plan',kind:'retirement',t:c=>/401|403|457/.test(c.account||'')},{q:'ret_ira',cat:'IRA',kind:'retirement',t:c=>/IRA/.test(c.account||'')}];
const PROFILE_ASK={debt_mortgage:'a mortgage',debt_heloc:'a home equity line',debt_card:'any credit cards',debt_auto:'an auto loan',debt_student:'any student loans',debt_personal:'a personal loan',debt_medical:'any medical bills owed',debt_tax:'any tax owed',debt_support:'a support order',debt_other:'any other debt',
 bill_housing:'rent or another housing bill',bill_utilities:'utility bills',bill_phone:'a phone bill',bill_insurance:'insurance bills',bill_transport:'transportation costs',bill_food:'a food budget',bill_pets:'pet costs',bill_childcare:'childcare costs',bill_subscriptions:'subscriptions',bill_other:'any other monthly bill',
 acct_checking:'a checking account',acct_savings:'a savings account',acct_hsa:'an HSA',acct_brokerage:'a brokerage account',acct_home:'a home you own',acct_vehicle:'a vehicle you own',ret_workplace:'a workplace retirement plan',ret_ira:'an IRA'};
dash.calc('profile_calc',CR("profile_calc",{title:'What you have',description:'One row per category of debt, bill, account and retirement plan: your answer (yes, no or unknown), how many rows the data holds, and what follows. No leaves the category out; yes with no rows asks for the details; unknown with no rows is a question to ask in Claude. Rows in the data count as yes. A no with rows on file is a conflict to resolve.',inputs:['profile_answers','liabilities','bills','assets_other','contributions'],
 fn:(pa,liab,bills,assets,contrib)=>{
  const ans={};realRows(pa).forEach(r=>{if(r.question_id)ans[r.question_id]=r;});
  const src={debt:realRows(liab).filter(l=>l.balance!=null||l.monthly_payment!=null),bill:realRows(bills),account:realRows(assets),retirement:realRows(contrib)};
  const other=c=>x=>!PROFILE_CATS.some(o=>o.kind===c.kind&&o.t&&o.t(x));
  return PROFILE_CATS.map(c=>{const n=src[c.kind].filter(c.t||other(c)).length;const a=ans[c.q];const answer=a&&['yes','no','unknown'].includes(a.answer)?a.answer:'unknown';
    const status=answer==='no'?(n?'conflict':'no'):n?'have':answer==='yes'?'needs_entries':'ask';
    const needs=status==='needs_entries'?'Needs: your '+c.cat.toLowerCase()+' details ('+(c.kind==='debt'?'balance, rate, payment and due date':c.kind==='bill'?'name, amount a month and due day':c.kind==='retirement'?'what goes in each paycheck':'balance and as-of date')+')':status==='ask'?'Ask in Claude: do you have '+(PROFILE_ASK[c.q]||'any '+c.cat.toLowerCase())+'?':status==='conflict'?'Check: you answered no, but '+n+' row'+(n===1?' is':'s are')+' on file':null;
    return {question_id:c.q,category:c.cat,kind:c.kind,answer,answered:!!a,asked_at:a?a.asked_at||null:null,rows:n,status,needs};});
 }}));
/* words that say nothing about which debt a request is for, and the request words each Needs field may appear as */
const NEED_GENERIC=new Set(['credit','card','loan','balance','bill','the','and','account','debt','personal','unsecured','doctor','line']);
const NEED_SYN={minimum:['minimum','payment'],payment:['payment','minimum'],interest:['rate','apr','interest'],rate:['rate','apr','interest'],days:['late','past','current'],credit:['limit'],whether:['full','statement'],date:['due','date'],original:['original','opened']};
dash.calc('needs_calc',CR("needs_calc",{title:'What the cards are waiting for',description:'Every Needs line the calcs give, one row each with the data request (data_queue) and task that cover it: matched by the request needs_key when set, else by the subject and field words in the request text. Categories answered no are left out. A Needs row without a request is listed so Claude can add one; a request whose need is gone is listed as ready to mark Provided.',inputs:['profile_calc','payoff_engine','dti_calc','goals_calc','drift_calc','plan_year_calc','runway_calc','paycheck_plan','data_queue','tasks'],
 fn:(pf,pe,dti,gl,dr,py,rw,pk,dq,tk)=>{
  const out=[];const add=(key,area,subject,text,from)=>{if(!out.some(o=>o.key===key))out.push({key,area,subject,text:String(text).replace(/^Needs:\s*/i,''),from});};
  const no=new Set(pf.filter(p=>p.status==='no').map(p=>p.category));
  pf.forEach(p=>{if(p.needs&&p.status!=='have')add('profile.'+p.question_id,p.kind==='debt'?'Debt':p.kind==='bill'?'Bills':p.kind==='retirement'?'Retirement':'Accounts',p.category,p.needs,'profile_calc');});
  const P=pe[0]||{};(P.debts||[]).forEach(d=>(d.needs||[]).forEach(n=>add('liabilities.'+d.id+'.'+n.split(' ')[0].toLowerCase(),'Debt',d.name,n,'payoff_engine')));(P.needs||[]).forEach(n=>add('payoff.'+n.slice(0,24),'Pay',null,n,'payoff_engine'));
  ((dti[0]||{}).missing_names||[]).forEach(nm=>add('dti.payment.'+nm,'Debt',nm,'monthly payment for '+nm,'dti_calc'));
  gl.filter(g=>g.kind==='goal'&&g.needs&&g.needs.length).forEach(g=>add('goals.'+g.goal_id,'Save for',g.name,g.needs.join(', '),'goals_calc'));
  dr.filter(r=>r.needs&&r.needs.length).forEach(r=>r.needs.forEach(n=>add('drift.'+r.scope+'.'+String(n).slice(0,30),'Cash',r.scope,n,'drift_calc')));
  py.filter(y=>y.status==='needs').forEach(y=>add('plan_year.'+y.year,'Retirement',String(y.year),'the '+y.year+' plan year inputs (limit row or pay dates)','plan_year_calc'));
  if((pk[0]||{}).needs_pay)add('pay.schedule','Pay',null,pk[0].needs_pay,'paycheck_plan');
  const dnames=new Set((P.debts||[]).map(d=>d.name));((rw[0]||{}).coming_needs||[]).forEach(c=>{const nm=typeof c==='string'?c:c.name||c.text;add('due.'+nm,dnames.has(nm)?'Debt':'Bills',nm,'due date for '+nm,'runway_calc');});/* a due date the runway lacks belongs to a debt in the payoff plan, else to a bill */
  /* match to data requests and tasks */
  const Q=realRows(dq),T=realRows(tk);const words=s=>String(s||'').toLowerCase().match(/[a-z0-9]+/g)||[];
  const open=Q.filter(q=>q.status==='Needed'||q.status==='Statement requested');
  const nkeys=x=>String(x.needs_key||'').split(',').map(s=>s.trim()).filter(Boolean);
  out.forEach(o=>{let q=Q.find(x=>nkeys(x).includes(o.key));let how=q?'key':null;
    if(!q&&o.subject){const sw=words(o.subject).filter(w=>w.length>2&&!NEED_GENERIC.has(w));const fw=[].concat(...words(o.text).filter(w=>w.length>3).map(w=>NEED_SYN[w]||[w]));
      q=open.find(x=>{const t=words(x.item+' '+(x.why||''));return sw.length&&sw.some(w=>t.includes(w))&&fw.some(w=>t.includes(w));});if(q)how='text';}
    const t=q&&q.task_id?T.find(x=>x.id===q.task_id):null;o.queue_id=q?q.queue_id:null;o.task_id=t?t.id:null;o.request_status=q?q.status:null;o.match=how;});
  const ready=Q.filter(q=>nkeys(q).length&&(q.status==='Needed'||q.status==='Statement requested')&&!nkeys(q).some(k=>out.some(o=>o.key===k))).map(q=>({key:nkeys(q).join(','),area:q.area,subject:null,text:q.item,from:'data_queue',queue_id:q.queue_id,task_id:q.task_id||null,request_status:q.status,match:'key',ready:true}));
  return out.filter(o=>!(o.subject&&no.has(o.subject))).concat(ready);
 }}));
dash.calc('checks_more_calc',CR("checks_more_calc",{title:'More correlation checks',description:'C25 bills and debts not double counted (no counted bill shares a name with a debt or is paid through one); C26 totals identity (total monthly obligations = every bill + every debt payment entered; payoff surplus = take-home - bills - minimums); C27 every bill statement belongs to a bill (bill_id, else the same name); C28 existence rule (no category answered no has rows; every category answered yes without rows has a data request); C29 every card statement belongs to a card on file and its latest minimum matches the minimum entered. Kept apart from the core checks so a new dataset that has not loaded cannot stop them.',inputs:['bills','liabilities','bill_statements','dti_calc','payoff_engine','profile_calc','needs_calc','card_statements'],
 fn:(bills,liab,bs,dti,pe,pf,nd,cst)=>{const out=[];const add=(id,name,status,detail)=>out.push({id,name,status,detail,blocks:false});const near=(a,b,t)=>Math.abs(a-b)<=(t||0.01);
  const B=realRows(bills),L=realRows(liab),S=realRows(bs).filter(s=>s.bill||s.bill_id);const ln=new Set(L.map(l=>String(l.name||'').toLowerCase()));
  {const dup=B.filter(b=>b.paid_by_liability_id==null&&ln.has(String(b.name||'').toLowerCase()));const via=B.filter(b=>b.paid_by_liability_id!=null);
   add('C25','Bills and debts not double counted',dup.length?'fail':'pass',dup.length?'Bill with a debt name: '+dup.map(b=>b.name).join(', '):B.length+' bills, none named like a debt'+(via.length?'; '+via.length+' paid through a debt and left out of bill totals':''));}
  {const d=dti[0]||{};const P=pe[0]||{};const bt=B.filter(b=>b.paid_by_liability_id==null).reduce((s,b)=>s+(b.monthly_amount||0),0);
   const ok1=d.obligations_monthly!=null&&near(d.obligations_monthly,Math.round((bt+(d.obligations_debts||0))*100)/100,0.011);const ok2=P.surplus==null||near(P.surplus,P.take_home-P.bills-P.mins,0.005);
   add('C26','Totals identity',P.take_home==null?'needs':ok1&&ok2?'pass':'fail','Obligations '+(d.obligations_monthly!=null?d.obligations_monthly.toFixed(2):'n/a')+' = bills '+bt.toFixed(2)+' + debt payments '+(d.obligations_debts||0).toFixed(2)+(P.surplus!=null?'; surplus '+P.surplus.toFixed(2)+' = take-home - bills - minimums':'; Needs: take-home'));}
  {const byId=new Set(B.map(b=>b.bill_id)),byName=new Set(B.map(b=>String(b.name||'').toLowerCase()));const orphan=S.filter(s=>!(s.bill_id&&byId.has(s.bill_id))&&!byName.has(String(s.bill||'').toLowerCase()));
   add('C27','Bill statements belong to a bill',!S.length?'needs':orphan.length?'fail':'pass',!S.length?'Needs: a bill statement':orphan.length?'Not matched to a bill: '+[...new Set(orphan.map(s=>s.bill))].join(', ')+' (add bill_id)':S.length+' statements, each matched to a bill');}
  {const conf=pf.filter(p=>p.status==='conflict');const want=pf.filter(p=>p.status==='needs_entries');const noReq=want.filter(p=>{const n=nd.find(x=>x.key==='profile.'+p.question_id);return !n||!n.queue_id;});const ask=pf.filter(p=>p.status==='ask').length;
   add('C28','Nothing assumed to exist',conf.length?'fail':noReq.length?'needs':'pass',(conf.length?'Answered no but on file: '+conf.map(p=>p.category).join(', ')+'. ':'')+(noReq.length?'Answered yes, no rows and no data request yet: '+noReq.map(p=>p.category).join(', ')+'. ':'')+pf.filter(p=>p.status==='have').length+' categories on file, '+pf.filter(p=>p.status==='no').length+' answered no, '+ask+' still to ask');}
  {const CS=realRows(cst).filter(s=>s.statement_id);const cards=L.filter(isCard);const orphan=CS.filter(s=>!cards.some(l=>l.liability_id===s.liability_id));const diff=[];
   cards.forEach(l=>{const mine=CS.filter(s=>s.liability_id===l.liability_id&&s.closing_date).sort((a,b)=>a.closing_date<b.closing_date?-1:1);const last=mine[mine.length-1];if(last&&last.minimum_payment_due!=null&&l.monthly_payment!=null&&Math.abs(last.minimum_payment_due-l.monthly_payment)>0.005)diff.push(l.name+' statement minimum '+last.minimum_payment_due.toFixed(2)+', entered '+l.monthly_payment.toFixed(2));});
   add('C29','Card statements belong to a card',!CS.length?'needs':orphan.length?'fail':diff.length?'needs':'pass',!CS.length?'Needs: a card statement':orphan.length?orphan.length+' statement'+(orphan.length===1?'':'s')+' with no card on file (add liability_id)':diff.length?diff.join('; ')+' (the amount you gave is used until a statement proves otherwise)':CS.length+' statements, each tied to a card; latest minimums match');}
  return out;}}));
