/* ---------- retirement centerpiece ---------- */
const RC={you:C[0],plan:C[2],today:C[1]};
const retModel=()=>{const r=rows('retire_model');return r&&r[0];};
const unitDiv=m=>state.ret.unit==='month'?12:m.paychecks;
const near=(a,b)=>Math.abs(a-b)<0.5;
dash.calc('goals_calc',CR("goals_calc",{title:'Savings goals',description:'Per goal: progress, months to goal at the current monthly amount, monthly amount needed to hit the target date, a month by month forecast and a status. The first row is a summary across goals. Any missing required field gives a Needs list and no number. Interest is monthly compounding on the opening balance with the deposit at month end; no rate means 0 percent.',inputs:['savings_goals','assets_other'],
 fn:(goalsIn,assets)=>{
  const goals=goalsIn.filter(g=>g&&g.goal_id!=='none'&&g.status!=='none');
  const r2=x=>Math.round(x*100)/100;
  const num=v=>typeof v==='number'&&isFinite(v);
  const valid=s=>typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s);
  const pd=s=>{const p=s.split('-').map(Number);return {y:p[0],m:p[1],d:p[2]};};
  const mb=(a,b)=>(b.y-a.y)*12+(b.m-a.m)-(b.d<a.d?1:0);
  const addm=(s,k)=>{const a=pd(s);const t=a.y*12+(a.m-1)+k;const y=Math.floor(t/12),m=t%12;const dim=new Date(Date.UTC(y,m+1,0)).getUTCDate();return y+'-'+String(m+1).padStart(2,'0')+'-'+String(Math.min(a.d,dim)).padStart(2,'0');};
  const LIMIT=1200;
  const out=[];
  goals.forEach(g=>{
    const needs=[];
    if(!num(g.target_amount)||g.target_amount<=0)needs.push('target amount');
    if(!valid(g.target_date))needs.push('target date');
    if(!num(g.saved_so_far)||g.saved_so_far<0)needs.push('amount saved so far');
    if(!num(g.monthly_contribution)||g.monthly_contribution<0)needs.push('monthly contribution');
    if(!valid(g.as_of_date))needs.push('date of the saved amount');
    const rateGiven=num(g.interest_rate_pct);
    const row={kind:'goal',goal_id:g.goal_id,name:g.name,goal_status:g.status,account:g.account,needs,rate_given:rateGiven,rate_pct:rateGiven?g.interest_rate_pct:0,
      target:g.target_amount,target_date:g.target_date,saved:g.saved_so_far,monthly:g.monthly_contribution,as_of:g.as_of_date,state:needs.length?'needs':null};
    if(!needs.length){
      const T=g.target_amount,S=g.saved_so_far,c=g.monthly_contribution,r=row.rate_pct/1200,gr=1+r;
      const n=mb(pd(g.as_of_date),pd(g.target_date));
      const all=[S];let b=S;
      for(let k=1;k<=LIMIT;k++){b=b*gr+c;all.push(b);}
      let m=null;for(let k=0;k<=LIMIT;k++){if(all[k]>=T-1e-9){m=k;break;}}
      const H=Math.min(LIMIT,Math.max(n,m==null?0:m,1));
      row.n_target=n;row.months_to_goal=m;row.goal_date=m==null?null:addm(g.as_of_date,m);
      row.series=all.slice(0,H+1).map((v,k)=>({k,date:addm(g.as_of_date,k),balance:r2(v)}));
      row.pct=Math.min(1,S/T);
      if(n>=1){const gn=Math.pow(gr,n);const fv0=S*gn;
        row.needed_monthly=fv0>=T?0:Math.ceil(((r>0?(T-fv0)*r/(gn-1):(T-S)/n))*100-1e-6)/100;}
      else row.needed_monthly=null;
      row.balance_at_target=n>=1&&n<=LIMIT?r2(all[n]):null;
      if(S>=T)row.state='reached';
      else if(n<1){row.state='late';row.shortfall=r2(T-S);}
      else if(m!=null&&m<n){row.state='ahead';row.early_months=n-m;row.extra_monthly=r2(c-row.needed_monthly);}
      else if(m===n)row.state='on';
      else{row.state='behind';row.gap_monthly=r2(row.needed_monthly-c);}
    }
    out.push(row);
  });
  const cashA=(assets||[]).filter(a=>a.type==='Cash');const sv=cashA.find(a=>/saving/i.test(a.name||''))||cashA[0];
  const live=out.filter(g=>g.goal_status!=='Done');
  const sum={kind:'summary',count:out.length,savings_balance:sv?sv.value_point:null,savings_asof:sv?sv.as_of_date:null,saved_needs:[],monthly_needs:[]};
  out.forEach(g=>{if(!num(g.saved)||g.saved<0)sum.saved_needs.push(g.name);});
  live.forEach(g=>{if(g.goal_status==='Active'&&(!num(g.monthly)||g.monthly<0))sum.monthly_needs.push(g.name);});
  sum.total_saved=sum.saved_needs.length?null:r2(out.reduce((s,g)=>s+g.saved,0));
  sum.total_monthly=sum.monthly_needs.length?null:r2(out.filter(g=>g.goal_status==='Active').reduce((s,g)=>s+g.monthly,0));
  const isSav=a=>typeof a==='string'&&/^savings( account)?$/i.test(a.trim());
  const unk=live.filter(g=>!g.account||g.account==='Not confirmed');
  sum.earmark_needs=null;sum.earmarked=null;sum.unassigned=null;
  if(!live.length){sum.earmarked=0;sum.unassigned=sv?sv.value_point:null;}
  else if(unk.length)sum.earmark_needs='which account holds the goal money ('+unk.map(g=>g.name).join(', ')+')';
  else{const inSav=live.filter(g=>isSav(g.account));const miss=inSav.filter(g=>!num(g.saved));
    if(miss.length)sum.earmark_needs='amount saved so far ('+miss.map(g=>g.name).join(', ')+')';
    else if(!sv)sum.earmark_needs='the Savings balance';
    else{sum.earmarked=r2(inSav.reduce((s,g)=>s+g.saved,0));sum.unassigned=r2(sv.value_point-sum.earmarked);}}
  return [sum].concat(out);
 }}));
dash.calc('drift_calc',CR("drift_calc",{title:'Dollar drift',description:'For each pair of reported balance dates: opening reported, plus known inflows, minus known outflows, expected closing, reported closing, and the gap. Events with an unconfirmed account are only used in a total cash pair. A missing input gives a Needs message, never a guess.',inputs:['balance_log','cash_events','paystubs'],
 fn:(blAll,evAll,ps)=>{
  const bl=blAll.filter(b=>b.kind!=='Card');const ev=evAll.filter(e=>e.status!=='Pending'&&((e.in_balances==null||e.in_balances==='Y'||e.in_balances===true)||(e.in_expected_balances===true&&e.apply_to_expected_savings!==false)));
  const r2=x=>Math.round(x*100)/100;
  const MN=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const fd=s=>MN[+s.slice(5,7)-1]+' '+(+s.slice(8,10));
  const mo=v=>'$'+Math.abs(v).toLocaleString('en-US',{minimumFractionDigits:Math.abs(v%1)>1e-9?2:0,maximumFractionDigits:2});
  const lab=e=>e.kind==='pay_deposit'?'paycheck':mo(e.amount)+' '+evLabel(e).replace(/^One time /,'').toLowerCase();
  const lab2=e=>e.kind==='pay_deposit'?'paycheck of '+mo(e.amount):lab(e);
  const stubOf=e=>{if(e.kind!=='pay_deposit')return null;const s=ps.find(p=>p.pay_date===e.date);if(!s)return 'no pay stub on file for this date';return Math.abs(s.net_pay-e.amount)<0.005?'matches the '+fd(e.date)+' pay stub deposit':'differs from the '+fd(e.date)+' pay stub deposit of '+mo(s.net_pay);};
  const phrase=list=>'the '+list.map((e,i)=>(i===0||e.date!==list[i-1].date?fd(e.date)+' ':'')+lab(e)).join(' and the ');
  const sendFor=e=>e.amount>0?'Which account the '+fd(e.date)+' '+lab2(e)+' landed in':'Which account the '+fd(e.date)+' '+lab2(e)+' left from';
  const sorted=[...ev].sort((a,b)=>a.date<b.date?-1:1);
  const bal=(a,d)=>{const r=bl.filter(b=>b.account===a&&b.date===d);return r.length?r[r.length-1].reported_balance:null;};
  const datesOf=a=>[...new Set(bl.filter(b=>b.account===a).map(b=>b.date))].sort();
  const build=(scope,d0,d1,evs,opening,reported,missing,needUnk)=>{
    const needs=[],send=[];
    missing.forEach(m=>{needs.push(m);send.push(m.charAt(0).toUpperCase()+m.slice(1));});
    const unk=needUnk?evs.filter(e=>e.account==='Not confirmed'):[];
    if(unk.length){needs.push('which account '+phrase(unk)+' used');unk.forEach(e=>send.push(sendFor(e)));}
    const items=evs.map(e=>({event_id:e.event_id,date:e.date,label:lab(e),amount:e.amount,account:e.account,placed:!(needUnk&&e.account==='Not confirmed'),stub:stubOf(e)}));
    const ok=!needs.length;
    const inflows=ok?r2(evs.filter(e=>e.amount>0).reduce((s,e)=>s+e.amount,0)):null;
    const outflows=ok?r2(-evs.filter(e=>e.amount<0).reduce((s,e)=>s+e.amount,0)):null;
    const expected=ok?r2(opening+inflows-outflows):null;
    return {scope,from:d0,to:d1,status:ok?'ok':'needs',needs,send,opening,reported,inflows,outflows,expected,drift:ok?r2(reported-expected):null,items};
  };
  const out=[];
  [...new Set(bl.map(b=>b.account))].forEach(a=>{const ds=datesOf(a);for(let i=1;i<ds.length;i++){const d0=ds[i-1],d1=ds[i];
    out.push(build(a,d0,d1,sorted.filter(e=>(e.date>d0||(e.date===d0&&e.drift_explained==='Y'))&&e.date<=d1&&(e.account===a||e.account==='Not confirmed')),bal(a,d0),bal(a,d1),[],true));}});
  const cashA=[...new Set(bl.filter(b=>b.kind==='Cash').map(b=>b.account))];
  if(cashA.length>1){const ds=[...new Set(bl.filter(b=>b.kind==='Cash').map(b=>b.date))].sort();
    for(let i=1;i<ds.length;i++){const d0=ds[i-1],d1=ds[i];const miss=[];
      cashA.forEach(a=>[d0,d1].forEach(d=>{if(bal(a,d)==null)miss.push(a+' balance on '+fd(d));}));
      const ok=!miss.length;
      out.push(build('Total cash',d0,d1,sorted.filter(e=>(e.date>d0||(e.date===d0&&e.drift_explained==='Y'))&&e.date<=d1&&(cashA.includes(e.account)||e.account==='Not confirmed')),ok?r2(cashA.reduce((s,a)=>s+bal(a,d0),0)):null,ok?r2(cashA.reduce((s,a)=>s+bal(a,d1),0)):null,miss,false));}}
  return out;
 }}));

