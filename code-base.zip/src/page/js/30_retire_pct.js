/* ---------- 401(k) percent of salary ---------- */
const PCT_TRY=6,PCT_MAX=15;
dash.calc('pct_calc',CR("pct_calc",{title:'401(k) percent of salary',description:'The 401(k) as a percent of base salary: salary, paychecks, today\'s dollars and percent, the annual limit as a dollar amount and as a percent of pay, and the percent you chose for next year (empty until you choose). The take-home estimate uses the tax saving rate on pre-tax dollars from the assumptions (item tax_saving_pretax_pct); without it the take-home change says Needs. Employer money does not count against the employee deferral limit.',inputs:['retire_model','retirement_plan','income_pay','assumptions'],
 fn:(m,rp,inc,asm)=>{
  const mm=m[0];const base=inc.find(i=>i.kind==='Base');if(!mm||!base||!base.annual_gross)return [];const k=mm.accts.find(a=>a.key==='k401');if(!k)return [];
  const salary=base.annual_gross,n=base.paychecks_per_year;const cap=k.limit;const tx=(asm||[]).find(a=>a.item==='tax_saving_pretax_pct');
  const ch=rp.find(r=>r.item==='chosen_401k_pct');
  return [{salary:salary,paychecks:n,cap_annual:cap,cap_pct:cap/salary*100,cur_annual:k.emp_now,cur_pct:k.emp_now/salary*100,cur_pp:k.emp_now/n,employer:k.er,chosen_pct:ch&&typeof ch.value==='number'?ch.value:null,tax_save:tx&&typeof tx.value==='number'?tx.value/100:null}];
 }}));
const pctFacts=()=>{const r=rows('pct_calc');return r&&r[0];};
function pctEff(f,pct){return Math.min(Math.max(0,pct)/100*f.salary,f.cap_annual);}
function pctVals(m,c){const o={};m.accts.forEach(a=>{o[a.key]=a.key==='k401'?c:a.emp_now;});return o;}
function pctBal(m,f,pct,rate,y){return retBal(m,pctVals(m,pctEff(f,pct)),rate,y).total;}
const pctNum=v=>+(+v).toFixed(1);
function pctSel(){return state.pct.v;}
function pctBuild(m,f){
  const rg=$('pct-rg'),inp=$('pct-in');
  rg.addEventListener('input',()=>{state.pct.v=+rg.value;state.pct.touched=true;inp.value=String(pctNum(rg.value));retRefresh();});
  inp.addEventListener('input',()=>{let x=parseFloat(inp.value);if(Number.isNaN(x))return;x=Math.min(PCT_MAX,Math.max(0,x));state.pct.v=Math.round(x*2)/2===x?x:Math.round(x*2)/2;state.pct.touched=true;rg.value=String(state.pct.v);retRefresh();});
  inp.addEventListener('change',()=>{inp.value=String(pctNum(state.pct.v));});
}
function drawPct(m){
  const f=pctFacts();
  if(!f){['pct-read','pct-cap','pct-tax'].forEach(id=>$(id).replaceChildren());$('pct-limit').hidden=true;$('pct-limmark').hidden=true;$('pct-read').append(needsEl('Needs: base salary, 401(k) contribution and the retirement model'));return;}
  if(!state.pct){state.pct={v:f.chosen_pct!=null?f.chosen_pct:PCT_TRY};pctBuild(m,f);$('pct-rg').value=String(state.pct.v);$('pct-in').value=String(pctNum(state.pct.v));}
  const chosenSet=f.chosen_pct!=null;
  $('pct-lab').textContent=chosenSet?'Your chosen 401(k) % of salary':'Try a rate (401(k) % of salary)';
  $('pct-tag').textContent=(chosenSet?'Chosen for next year: '+pctf(f.chosen_pct)+'. ':'')+'Today: '+pctf(f.cur_pct)+' ('+money(f.cur_pp)+' per paycheck).';
  const v=pctSel();const eff=pctEff(f,v);const raw=v/100*f.salary;const capped=raw>f.cap_annual+0.005;const atLimit=raw>=f.cap_annual-0.005;
  /* the slider keeps moving past the limit, so the card says so: a chip beside the box and a mark on the slider at the limit */
  $('pct-limit').hidden=!atLimit;
  const lm=$('pct-limmark');lm.hidden=!(f.cap_pct>0&&f.cap_pct<PCT_MAX);lm.style.setProperty('--lim',(f.cap_pct/PCT_MAX*100)+'%');lm.querySelector('span').textContent='Limit '+pctf(f.cap_pct);
  const pp=eff/f.paychecks,curPP=f.cur_annual/f.paychecks;const ts=f.tax_save==null?null:1-f.tax_save;
  const dropVs=(pp-curPP)*ts,dropAll=pp*ts;
  const mk=(cls,lab,val,sub)=>{const d=el('div','mo-rd'+(cls?' '+cls:''));d.append(el('span','mo-tl',lab),el('b',null,val),el('span','mo-ts',sub));$('pct-read').append(d);};
  $('pct-read').replaceChildren();
  mk('','Per year',money(Math.round(eff)),capped?'Capped at the limit':pctf(v)+' of '+money(f.salary));
  mk('','Per paycheck',money(Math.round(pp*100)/100),f.paychecks+' paychecks a year');
  if(ts==null)mk('','Take-home change','Needs: tax saving rate','Tell Claude your combined federal and state tax rate on pre-tax dollars (item tax_saving_pretax_pct).');
  else mk('',dropVs>=0?'Take-home drop vs today':'Take-home gain vs today',money(Math.round(Math.abs(dropVs)*100)/100)+' per paycheck','Estimate, after tax savings');
  mk('','Balance at '+m.age1,money(Math.round(pctBal(m,f,v,RI(m),m.years))),'On the picked return path');
  const hit=f.cap_pct;
  $('pct-cap').textContent=capped?pctf(v)+' of pay would be '+money(Math.round(raw))+', over the limit of '+money(f.cap_annual)+', so only '+money(f.cap_annual)+' ('+pctf(hit)+' of pay) goes in. Anything over '+pctf(hit)+' adds nothing, so the numbers stop changing. The chart and numbers use the capped amount.':'Using this year\'s limit of '+money(f.cap_annual)+' ('+pctf(hit)+' of pay). Anything over '+pctf(hit)+' hits the cap. Room left under it at this rate: '+money(Math.round(f.cap_annual-eff))+' a year.';
  $('pct-tax').textContent=(f.tax_save==null?'Needs: the combined federal and state tax saving rate on pre-tax dollars, so the take-home change can be estimated. ':'Take-home change is an estimate: the pre-tax dollars times (1 minus '+(+(f.tax_save*100).toFixed(2))+' percent), your combined federal and state tax saving from the assumptions; your stubs will confirm. The whole 401(k) at this rate costs '+money(Math.round(dropAll*100)/100)+' of take-home. ')+'Percent is of base salary '+money(f.salary)+'. The employer match and next year\'s limit are separate: employer money does not count against your deferral limit, and next year\'s limit is announced in the autumn. The balance at '+m.age1+' uses the return path picked on the main chart (base unless changed), with other accounts held at today\'s rate. '+(chosenSet?'':'Nothing is chosen yet; the slider starts at '+PCT_TRY+'% for display only.');
}
function retVals(m,which){
  if(which==='you')return state.ret.v;
  const o={};m.accts.forEach(a=>{o[a.key]=which==='today'?a.emp_now:a.plan_emp;});return o;
}
function retBal(m,vEmp,rate,y){
  const rt=rate/100,q=Math.pow(1+rt,y);const p={grow:m.start*q};let tot=p.grow;
  m.accts.forEach(a=>{const c=vEmp[a.key]+a.er;p[a.key]=y?c*(q-1)/rt:0;tot+=p[a.key];});p.total=tot;return p;
}
const retFixedC=new WeakMap();
function retFixed(m,k,rate,y){let c=retFixedC.get(m);if(!c){c=new Map();retFixedC.set(m,c);}const key=k+'|'+rate+'|'+y;let r=c.get(key);if(!r){r=retBal(m,retVals(m,k),rate,y);c.set(key,r);}return r;}
function retDetect(m){
  const v=state.ret.v;const isT=m.accts.every(a=>near(v[a.key],a.emp_now)),isP=m.accts.every(a=>near(v[a.key],a.plan_emp));
  state.ret.mode=isT?'today':isP?'plan':'custom';
}
function retBuildControls(m){
  const box=$('ret-ctl');box.replaceChildren();
  m.accts.forEach(a=>{
    const cb=el('div','mo-cb');const top=el('div','mo-cb-top');const nm=el('label',null,a.key==='hsa'?'HSA, your part':a.key==='roth'?'Backdoor Roth IRAs, both':'401(k) pre-tax');nm.style.fontWeight='600';nm.htmlFor='rc-in-'+a.key;
    const inp=document.createElement('input');inp.type='number';inp.className='mo-in';inp.id='rc-in-'+a.key;inp.min='0';inp.inputMode='decimal';inp.setAttribute('aria-label',nm.textContent+' amount');
    const unit=el('span','mo-ts');unit.id='rc-un-'+a.key;
    const right=el('span');right.style.cssText='display:inline-flex;align-items:center;gap:.35rem';right.append(el('span','mo-ts','$'),inp,unit);top.append(nm,right);
    const rg=document.createElement('input');rg.type='range';rg.id='rc-rg-'+a.key;rg.min='0';rg.setAttribute('aria-label',nm.textContent+' slider');
    const sub=el('div','mo-kv');sub.id='rc-sub-'+a.key;
    cb.append(top,rg,sub);box.append(cb);
    rg.addEventListener('input',()=>{state.ret.v[a.key]=Math.min(a.max_emp,Math.max(0,+rg.value*unitDiv(m)));inp.value=+(+rg.value).toFixed(2);retDetect(m);retRefresh(a.key);});
    inp.addEventListener('input',()=>{let x=parseFloat(inp.value);if(Number.isNaN(x))x=0;x=Math.max(0,x)*unitDiv(m);state.ret.v[a.key]=Math.min(a.max_emp,x);rg.value=state.ret.v[a.key]/unitDiv(m);retDetect(m);retRefresh(a.key);});
    inp.addEventListener('change',()=>{inp.value=+(state.ret.v[a.key]/unitDiv(m)).toFixed(2);});
  });
}
function retSyncControls(m,skip){
  const div=unitDiv(m);const base=m.base_pay_pp*m.paychecks;
  m.accts.forEach(a=>{
    const inp=$('rc-in-'+a.key),rg=$('rc-rg-'+a.key),sub=$('rc-sub-'+a.key);if(!inp)return;
    const max=a.max_emp/div;rg.max=String(+max.toFixed(2));rg.step=a.key==='hsa'?'1':'5';inp.max=String(+max.toFixed(2));
    if(skip!==a.key){inp.value=+(state.ret.v[a.key]/div).toFixed(2);rg.value=state.ret.v[a.key]/div;}
    $('rc-un-'+a.key).textContent=state.ret.unit==='month'?'per month':'per paycheck';
    const emp=state.ret.v[a.key];const alt=state.ret.unit==='month'?emp/m.paychecks:emp/12;const altU=state.ret.unit==='month'?'per paycheck':'per month';
    const parts=[money(Math.round(alt*100)/100)+' '+altU,money(Math.round(emp))+' a year'];
    if(a.key!=='roth')parts.push(pctf(emp/base*100)+' of pay');
    parts.push('limit '+money(a.limit)+(a.er?' incl. employer':''));
    sub.replaceChildren(...parts.map(t=>el('span',null,t)).flatMap((n,i)=>i?[el('span',null,'·'),n]:[n]));
    if(a.er){sub.append(el('span',null,'Employer adds '+money(a.er/m.paychecks)+' per paycheck ('+money(a.er)+' a year), fixed'));}
  });
  $('ret-preset').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===state.ret.mode)));
  $('ret-unit').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===state.ret.unit)));
}
function retRefresh(skip){
  const m=retModel();if(!m)return;
  retSyncControls(m,skip);retHead(m);drawRetRead(m);drawRetChart(m);drawLimits();drawPct(m);
}
function retTotalYou(m){return m.accts.reduce((s,a)=>s+state.ret.v[a.key]+a.er,0);}
function drawRetRead(m){
  const box=$('ret-read');box.replaceChildren();
  const rt=RI(m);const b=retBal(m,state.ret.v,rt,m.years).total;
  const lo=retBal(m,state.ret.v,m.rates[0],m.years).total,hi=retBal(m,state.ret.v,m.rates[2],m.years).total;
  const gb=Math.pow(1+rt/100,m.years);const needTot=(m.goal_low-m.start*gb)*(rt/100)/(gb-1);
  const tot=retTotalYou(m);const extraYr=Math.max(0,needTot-tot);const room=m.accts.reduce((s,a)=>s+Math.max(0,a.limit-(state.ret.v[a.key]+a.er)),0);
  const gl=b-m.goal_low,gh=b-m.goal_high;
  const mk=(cls,lab,val,sub)=>{const d=el('div','mo-rd'+(cls?' '+cls:''));d.append(el('span','mo-tl',lab),el('b',null,val),el('span','mo-ts',sub));box.append(d);return d;};
  mk('','Balance now',money(m.start),'Your retirement accounts');
  mk('main','Balance at '+m.age1+', your setting',money(Math.round(b)),'Range '+compact(lo)+' to '+compact(hi)+' (cautious to optimistic). Putting in '+money(Math.round(tot/12))+' a month.');
  mk('',gl>=0?'Over the '+compact(m.goal_low)+' low goal':'Short of the '+compact(m.goal_low)+' low goal',money(Math.round(Math.abs(gl))),Math.round(b/m.goal_low*100)+'% of the low goal, every account');
  mk('',gh>=0?'Over the '+compact(m.goal_high)+' high goal':'Short of the '+compact(m.goal_high)+' high goal',money(Math.round(Math.abs(gh))),Math.round(b/m.goal_high*100)+'% of the high goal');
  const ex=Math.round(extraYr/12);
  mk('',ex>0?'More per month to reach the low goal':'To reach the low goal',ex>0?money(ex):'On track',ex>0?(extraYr>room?'More than the account limits allow ('+money(Math.round(room/12))+' a month of room); the rest would need a taxable account.':money(Math.round(extraYr/m.paychecks))+' per paycheck on top of your setting'):'Your setting reaches the low goal at the base return');
}
function drawRetChart(m){
  const box=$('ret-chart');box.replaceChildren();const W=box.clientWidth;if(!W)return;const tip=mkTip(box);
  const narrow=W<560;const H=narrow?340:400;const mg={l:narrow?46:54,r:narrow?62:132,t:16,b:34};
  const ages=d3.range(m.years+1).map(i=>m.age0+i);
  const rt=RI(m);
  const S={today:ages.map((a,i)=>retFixed(m,'today',rt,i).total),plan:ages.map((a,i)=>retFixed(m,'plan',rt,i).total),
    you:ages.map((a,i)=>retBal(m,state.ret.v,rt,i).total),lo:ages.map((a,i)=>retBal(m,state.ret.v,m.rates[0],i).total),hi:ages.map((a,i)=>retBal(m,state.ret.v,m.rates[2],i).total)};
  const x=d3.scaleLinear([m.age0,m.age1],[mg.l,W-mg.r]);
  const yMin=Math.floor(m.start*0.7/50000)*50000;const yMax=Math.max(m.goal_high*1.06,d3.max(S.hi)*1.04,d3.max(S.plan)*1.04);
  const y=d3.scaleLinear([yMin,yMax],[H-mg.b,mg.t]);
  const svg=mkSvg(box,W,H,'Projected retirement balance by age for today\'s pay stubs, every account at the limit and your setting, with a cautious to optimistic range and the goal range');
  const ticks=y.ticks(6);
  hgrid(svg,ticks,y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).tickValues(ticks).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickValues([m.age0,45,50,55,m.age1]).tickFormat(d=>d).tickSize(4).tickPadding(6));
  svg.append('text').attr('x',W-mg.r).attr('y',H-4).attr('text-anchor','end').attr('font-size',11).style('fill','var(--mo-muted)').text('Age');
  /* goal band */
  svg.append('rect').attr('x',mg.l).attr('y',y(m.goal_high)).attr('width',W-mg.l-mg.r).attr('height',y(m.goal_low)-y(m.goal_high)).attr('fill',C[2]).attr('opacity',.13);
  [[m.goal_high,'High goal '+compact(m.goal_high)],[m.goal_low,'Low goal '+compact(m.goal_low)]].forEach(([v,t])=>{
    svg.append('line').attr('x1',mg.l).attr('x2',W-mg.r).attr('y1',y(v)).attr('y2',y(v)).attr('stroke',C[2]).attr('stroke-width',1.2).attr('opacity',.8);
    if(!narrow)svg.append('text').attr('x',W-mg.r+6).attr('y',y(v)).attr('dy','0.32em').attr('font-size',11).style('fill','var(--mo-muted)').text(t);});
  /* uncertainty band */
  const area=d3.area().x((d,i)=>x(ages[i])).y0((d,i)=>y(S.lo[i])).y1((d,i)=>y(S.hi[i]));
  svg.append('path').attr('d',area(ages)).attr('fill',RC.you).attr('opacity',.2);
  const line=d3.line().x((d,i)=>x(ages[i])).y(d=>y(d)).curve(d3.curveMonotoneX);
  const defs=[['plan',RC.plan,2.4,null],['you',RC.you,3.2,null],['today',RC.today,2.4,'6 5']];
  defs.forEach(([k,c,w,da])=>svg.append('path').attr('d',line(S[k])).attr('fill','none').attr('stroke',c).attr('stroke-width',w).attr('stroke-dasharray',da).attr('stroke-linecap','round').attr('stroke-linejoin','round'));
  /* direct end labels */
  const names={today:'Today\'s stubs',plan:'At the limit',you:'Your setting'};const last=m.years;
  const ends=['today','plan','you'].map(k=>({k,v:S[k][last],ty:y(S[k][last])})).sort((a,b)=>a.ty-b.ty);
  for(let i=1;i<ends.length;i++)if(ends[i].ty-ends[i-1].ty<14)ends[i].ty=ends[i-1].ty+14;
  ends.forEach(e=>svg.append('text').attr('class','mo-halo').attr('x',x(m.age1)+6).attr('y',e.ty).attr('dy','0.32em').attr('font-size',11).style('fill','var(--mo-fg)').text(narrow?compact(e.v):compact(e.v)+' '+names[e.k]));
  /* start point */
  svg.append('circle').attr('cx',x(m.age0)).attr('cy',y(m.start)).attr('r',5).attr('fill',RC.you).attr('stroke','var(--mo-card)').attr('stroke-width',2);
  svg.append('text').attr('class','mo-halo').attr('x',x(m.age0)+9).attr('y',y(m.start)-28).attr('font-size',11).style('font-weight',600).style('fill','var(--mo-fg)').text('Now '+money(Math.round(m.start)));
  if(state.ret.age<m.age1){const xa=x(state.ret.age),ia=state.ret.age-m.age0;svg.append('line').attr('x1',xa).attr('x2',xa).attr('y1',mg.t).attr('y2',H-mg.b).attr('stroke','var(--mo-muted)').attr('stroke-dasharray','3 3');
    ['today','plan','you'].forEach(k=>svg.append('circle').attr('cx',xa).attr('cy',y(S[k][ia])).attr('r',4.5).attr('fill',RC[k]).attr('stroke','var(--mo-card)').attr('stroke-width',2));}
  /* hover */
  const cross=svg.append('line').attr('y1',mg.t).attr('y2',H-mg.b).attr('stroke','var(--mo-muted)').attr('stroke-width',1).style('display','none');
  const dots=['today','plan','you'].map(k=>svg.append('circle').attr('r',4.5).attr('fill',k==='you'?RC.you:k==='plan'?RC.plan:RC.today).attr('stroke','var(--mo-card)').attr('stroke-width',2).style('display','none'));
  let curAge=m.age1;
  const show=(age,ev)=>{
    const i=age-m.age0;cross.style('display',null).attr('x1',x(age)).attr('x2',x(age));
    ['today','plan','you'].forEach((k,j)=>dots[j].style('display',null).attr('cx',x(age)).attr('cy',y(S[k][i])));
    const bb=box.getBoundingClientRect();const e2=ev||{clientX:bb.left+x(age),clientY:bb.top+y(S.you[i])};
    tip.show(e2,['Age '+age+(i?' ('+i+' year'+(i>1?'s':'')+' from now)':' (now)'),{t:'Your setting: '+money(Math.round(S.you[i])),c:RC.you},'Range '+compact(S.lo[i])+' to '+compact(S.hi[i]),{t:'At the limit (maxed): '+money(Math.round(S.plan[i])),c:RC.plan},{t:'Today\'s pay stubs: '+money(Math.round(S.today[i])),c:RC.today}]);
  };
  const hide=()=>{cross.style('display','none');dots.forEach(d=>d.style('display','none'));tip.hide();};
  svg.attr('tabindex',0);
  svg.append('rect').attr('x',mg.l).attr('y',mg.t).attr('width',W-mg.l-mg.r).attr('height',H-mg.t-mg.b).attr('fill','transparent')
    .on('pointermove',ev=>{const [mx]=d3.pointer(ev,svg.node());curAge=Math.max(m.age0,Math.min(m.age1,Math.round(x.invert(mx))));show(curAge,ev);}).on('pointerleave',hide);
  svg.on('keydown',ev=>{if(ev.key==='ArrowLeft'){curAge=Math.max(m.age0,curAge-1);show(curAge);ev.preventDefault();}else if(ev.key==='ArrowRight'){curAge=Math.min(m.age1,curAge+1);show(curAge);ev.preventDefault();}else if(ev.key==='Escape')hide();}).on('blur',hide);
  /* legend */
  $('ret-legend').replaceChildren(...legendEl([{label:'Your setting',color:RC.you,line:'solid'},{label:'Cautious to optimistic range',color:RC.you,op:.25},{label:'At the limit (maxed)',color:RC.plan,line:'solid'},{label:'Today\'s pay stubs',color:RC.today,line:'dash'},{label:'Goal range',color:C[2],op:.3}]).children);
}
function drawLimits(){
  const box=$('ret-limits');const r=rows('contrib_calc'),m=retModel();if(!r||!m||!state.ret)return;
  const data=r.map(d=>{
    const a=m.accts.find(x=>x.key===contribRole(d));if(!a)return null;const mine=state.ret.v[a.key]+a.er;
    return {label:d.account,sub:d.tax_type+(d.employer_annual?' (you plus employer)':''),max:d.limit,
      bars:[[0,d.employee_annual,C[0],1],[d.employee_annual,d.total,C[0],.45]],ticks:[{v:d.plan_total}],marks:[{v:mine,color:'var(--mo-fg)'}],
      valueText:money(d.total)+' of '+money(d.limit)+' ('+pctf(d.pct_of_limit)+')',
      tip:[d.account+' ('+d.tax_type+')',
        'You now: '+money(d.per_paycheck_now)+' per paycheck, '+money(d.monthly_now)+' per month ('+pctf(d.pct_pay_now)+' of pay)',
        'Employer: '+money(d.employer_annual)+' per year',
        'To reach the limit: '+money(d.per_paycheck_max)+' per paycheck ('+pctf(d.pct_pay_max)+' of pay), '+money(d.plan_monthly)+' per month',
        'At the limit: '+money(d.plan_total)+' a year in total. Your setting: '+money(Math.round(mine))+'.',
        'Room left: '+money(d.gap)+' per year',
        'Adds by '+m.age1+': about '+money(d.fv_now)+' now, '+money(d.fv_plan)+' at the limit (base return)']};
  }).filter(Boolean);
  bullets(box,data);
  $('ret-limits-leg').replaceChildren(...legendEl([{label:'You now',color:C[0]},{label:'Employer',color:C[0],op:.45},{label:'Limit target (tick)',color:'var(--mo-fg)'},{label:'Your setting above (diamond)',color:'var(--mo-fg)'}]).children);
}
function drawRetire(){
  const m=retModel();if(!m)return;
  if(!state.ret){state.ret={mode:'today',unit:'month',rate:1,age:m.age1,v:{}};m.accts.forEach(a=>{state.ret.v[a.key]=a.emp_now;});retBuildControls(m);retBuildHead(m);
    $('ret-preset').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{const mm=retModel();const w=b.dataset.v;if(w==='today'||w==='plan'){mm.accts.forEach(a=>{state.ret.v[a.key]=w==='today'?a.emp_now:a.plan_emp;});}state.ret.mode=w;retRefresh();}));
    $('ret-unit').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{state.ret.unit=b.dataset.v;retRefresh();}));}
  $('ret-assume').textContent='Assumptions: '+m.rates[0]+'% cautious, '+m.rates[1]+'% base and '+m.rates[2]+'% optimistic a year, all after inflation and in today\'s dollars (about '+m.nominal.join('%, ')+'% before inflation at '+m.inflation+'% inflation). Contributions are made at the end of each year, before tax. The balance now is every 401(k) you hold; the HSA balance is not included because it is uninvested cash for medical expenses, and savings and checking cash are left out too. The mega backdoor Roth is not counted because it still needs HR to confirm. The shaded range is the cautious to optimistic path around your setting. Treat all of this as a range, not a forecast.';
  retRefresh();
}
