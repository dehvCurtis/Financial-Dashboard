/* ---------- facelift v2.0 to v2.6: new calcs (each fn is self-contained) ---------- */
dash.calc('scores_calc',CR("scores_calc",{title:'Financial and Risk scores',description:'Two 0 to 100 scores from scores_config. fraction = clamp((value - worst)/(best - worst)); Financial points = fraction x weight, Risk points = (1 - fraction) x weight; score = points / weight with data x 100. Components without data are left out and listed as Needs; the range shows the score if every Needs scored worst or best. Under the minimum weight coverage the card shows Not enough data. What-ifs rerun the same function on changed copies of the data.',inputs:['scores_config','liabilities','assets_other','bills','income_pay','contributions','networth_history','retirement_plan','assumptions','data_queue','paystubs'],
 fn:(cfgIn,liab,assets,bills,inc,ct,nwh,rp,ap,dq,ps)=>{
  const CFG=parseRow((Array.isArray(cfgIn)?cfgIn[0]:cfgIn)||{},['reweight','trend','inputs','financial','risk']);const I=CFG.inputs&&typeof CFG.inputs==='object'?CFG.inputs:{};
  const sum=(a,f)=>a.reduce((s,x)=>s+(f(x)||0),0);
  const item=(r,k)=>{const x=r.find(z=>z.item===k);return x?x.value:null;};
  const latest=a=>[...a].sort((p,q)=>p.date<q.date?-1:1).pop();
  const metrics=d=>{
    const m={},x={};
    const base=sum(d.inc.filter(i=>i.kind==='Base'),i=>i.annual_gross),gross=sum(d.inc,i=>i.annual_gross);
    const counted=d.liab.filter(l=>l.counts_in_dti==='Y');
    const pay=sum(counted,l=>l.monthly_payment);
    const est=sum(counted.filter(l=>l.monthly_payment==null&&openCard(l)&&l.balance),l=>l.balance*I.card_min_estimate_pct_of_balance/100);
    x.dti_listed=base?pay/(base/12)*100:null;x.card_est=est;x.debt_payments=pay;
    m.dti_back_end_est_pct=base?(pay+est)/(base/12)*100:null;
    const A={};d.assets.forEach(a=>{A[a.asset_id]=a;});
    const liquid=sum((I.liquid_asset_ids||[]).filter(i=>A[i]),i=>A[i].spendable_value!=null?A[i].spendable_value:A[i].value_point);x.liquid=liquid;
    const hi=d.liab.filter(l=>(l.rate_pct||0)>I.high_apr_threshold_pct&&l.balance);
    const hib=sum(hi,l=>l.balance);x.acct_b_bal=hib;x.acct_b_names=hi.map(l=>l.name);x.acct_b_interest_year=sum(hi,l=>l.balance*l.rate_pct/100);
    m.high_apr_balance_pct_of_gross=gross?hib/gross*100:null;
    const excl=I.runway_excluded_bill_ids||[];x.excluded_bill_ids=excl;
    const ess=sum(d.bills.filter(b=>b.essential==='Yes'&&!excl.includes(b.bill_id)),b=>b.monthly_amount);
    const allb=sum(d.bills.filter(b=>!excl.includes(b.bill_id)),b=>b.monthly_amount);
    const debtAll=pay+est;x.ess_bills=ess;x.all_bills=allb;x.debt_all=debtAll;
    x.mustpay=ess+debtAll;x.allfixed=allb+debtAll;
    m.emergency_months=x.mustpay?liquid/x.mustpay:null;m.runway_months_all_fixed=x.allfixed?liquid/x.allfixed:null;
    const sv=sum(d.ct,c=>c.employee_annual+c.employer_annual);x.payroll_saving=sv;m.payroll_savings_rate_pct=gross?sv/gross*100:null;
    const last=d.nwh.length?latest(d.nwh):null;const ret=last?last.retirement:null;x.ret=ret;
    const cur=item(d.rp,'current_age'),tgt=item(d.rp,'target_age'),gl=item(d.rp,'goal_low');
    const k=d.ct.find(c=>/401/.test(c.account))||d.ct[0];const C=k?k.employee_annual+k.employer_annual:null;x.k401_annual=C;
    const r=item(d.ap,I.retirement_return_case||'return_base_real_pct');
    if(ret!=null&&cur!=null&&tgt!=null&&gl&&C!=null&&r!=null){const n=tgt-cur,g=r/100;const fv=(cc)=>ret*Math.pow(1+g,n)+cc*(Math.pow(1+g,n)-1)/g;
      x.n=n;x.fv_base=fv(C);x.fv_cases={};['cautious','base','optimistic'].forEach(c=>{const rr=item(d.ap,'return_'+c+'_real_pct');if(rr!=null){const gg=rr/100;x.fv_cases[c]=ret*Math.pow(1+gg,n)+C*(Math.pow(1+gg,n)-1)/gg;}});
      const L=k?k.limit_annual:null;
      x.fv_max401k=L!=null?fv(L):null;x.goal_low=gl;m.retire_pace_pct=fv(C)/gl*100;}
    else m.retire_pace_pct=null;
    m.top_earner_share_pct=I.facts&&I.facts.household_earners===1?100:null;
    const b0=d.inc.find(i=>i.kind==='Base');const st=d.ps.length?[...d.ps].sort((a,b)=>a.pay_date<b.pay_date?-1:1).pop():null;
    const net=st&&b0&&b0.paychecks_per_year?st.take_home_core*b0.paychecks_per_year/12:null;x.net_m=net;
    const house=sum(d.assets.filter(a=>a.type==='Real estate'),a=>a.value_point);const liens=sum(d.liab.filter(l=>l.type==='Mortgage'||l.type==='HELOC'),l=>l.balance);
    m.cltv_pct=house?liens/house*100:null;
    m.debt_to_assets_pct=last&&last.assets?last.debts/last.assets*100:null;
    const tax=sum(d.liab.filter(l=>l.type==='Tax'),l=>l.balance);x.tax_bal=tax;m.irs_balance_pct_of_liquid=liquid?tax/liquid*100:null;
    const fb=I.foreign_bill_ids||[];const sp=sum(d.bills.filter(b=>fb.includes(b.bill_id)),b=>b.monthly_amount);x.foreign=sp;
    m.foreign_cost_pct_of_net=net?sp/net*100:null;
    const need=d.dq.filter(i=>i.status==='Needed'||i.status==='Statement requested').length,prov=d.dq.filter(i=>i.status==='Provided').length;x.q_need=need;x.q_prov=prov;
    m.queue_needed_pct=need+prov?need/(need+prov)*100:null;
    const cards=d.liab.filter(l=>openCard(l)&&l.balance);
    m.utilization_pct=cards.length&&cards.every(l=>l.credit_limit)?sum(cards,l=>l.balance)/sum(cards,l=>l.credit_limit)*100:null;
    return {m,x};
  };
  const score=(m,which)=>{
    const S=CFG[which]&&Array.isArray(CFG[which].components)?CFG[which]:{title:which==='financial'?'Financial Score':'Risk Score',scale:null,labels:[],components:[]};const rows=[];let avail=0,pts=0,tot=0;
    S.components.forEach(c=>{tot+=c.weight;const v=c.gated?null:m[c.metric];
      if(v==null||c.best==null||c.worst==null){rows.push({id:c.id,name:c.name,weight:c.weight,metric:c.metric,unit:c.unit,best:c.best,worst:c.worst,value:null,frac:null,points:null,needs:c.needs||('Needs: '+(c.requires||[]).join(', ')),formula:c.formula,source:c.source,requires:c.requires});return;}
      const fr=Math.max(0,Math.min(1,(v-c.worst)/(c.best-c.worst)));const p=(which==='financial'?fr:1-fr)*c.weight;
      rows.push({id:c.id,name:c.name,weight:c.weight,metric:c.metric,unit:c.unit,best:c.best,worst:c.worst,value:v,frac:fr,points:p,needs:null,formula:c.formula,source:c.source,requires:c.requires,optional_needs:c.optional_needs||null});avail+=c.weight;pts+=p;});
    const minCov=(CFG.reweight&&CFG.reweight.min_weight_coverage_pct)||60;const coverage=tot?avail/tot*100:0;
    const sc=avail?pts/avail*100:null;const enough=coverage>=minCov;
    const lab=sc==null?null:(S.labels.find(l=>sc>=l.min)||{}).label;
    return {title:S.title,scale:S.scale,score:enough?sc:null,raw:sc,label:enough?lab:'Not enough data',enough,n:rows.filter(r=>r.points!=null).length,M:rows.length,coverage,points:pts,weight_with_data:avail,weight_total:tot,range:[tot?pts/tot*100:null,tot?(pts+tot-avail)/tot*100:null],rows};
  };
  const base={liab,assets,bills,inc,ct,nwh,rp,ap,dq,ps};
  const run=d=>{const {m,x}=metrics(d);return {m,x,financial:score(m,'financial'),risk:score(m,'risk')};};
  const now=run(base);
  const clone=o=>JSON.parse(JSON.stringify(o));
  const wi=[];
  const addWi=(id,label,d,detail)=>{const r=run(d);wi.push({id,label,detail,financial:r.financial.score,risk:r.risk.score,d_fin:r.financial.score!=null&&now.financial.score!=null?r.financial.score-now.financial.score:null,d_risk:r.risk.score!=null&&now.risk.score!=null?r.risk.score-now.risk.score:null});};
  { const d=clone(base);const k=d.ct.find(c=>/401/.test(c.account));const L=k&&k.limit_annual;
    if(k&&L&&k.employee_annual<L){const before=k.employee_annual;k.employee_annual=L;addWi('k401_limit','Raise the 401(k) to the '+L.toLocaleString('en-US')+' limit',d,'401(k) you from '+before.toLocaleString('en-US')+' to '+L.toLocaleString('en-US')+' a year');}}
  { const x=now.x;const target=3*x.mustpay;const add=target-x.liquid;const id=(I.liquid_asset_ids||[])[0];
    if(add>0&&id){const d=clone(base);const a=d.assets.find(z=>z.asset_id===id);if(a){a.value_point+=add;if(a.spendable_value!=null)a.spendable_value+=add;addWi('cash3','Build cash to 3 months of essentials',d,'adds '+Math.round(add).toLocaleString('en-US')+' to '+a.name);}}}
  { const cards=base.liab.filter(l=>l.type===I.card_liability_type&&l.balance).sort((a,b)=>(b.rate_pct||0)-(a.rate_pct||0)||b.balance-a.balance);
    const t=cards[0];const id=(I.liquid_asset_ids||[])[0];if(t&&id){const d=clone(base);const l=d.liab.find(z=>z.liability_id===t.liability_id);const a=d.assets.find(z=>z.asset_id===id);if(a&&a.value_point>=l.balance){const bal=l.balance;a.value_point-=bal;if(a.spendable_value!=null)a.spendable_value-=bal;l.balance=0;l.monthly_payment=0;addWi('card0','Pay off '+t.name+' from '+a.name,d,'uses '+bal.toLocaleString('en-US',{minimumFractionDigits:2})+' of cash to clear a '+t.rate_pct+'% card');}}}
  const room=s=>s.rows.filter(r=>r.points!=null).map(r=>({id:r.id,name:r.name,room:s===now.financial?r.weight-r.points:r.points,weight:r.weight,value:r.value,best:r.best,unit:r.unit})).sort((a,b)=>b.room-a.room);
  return [{version:CFG.version,as_of:CFG.as_of,disclaimer:CFG.disclaimer,how:CFG.how_it_works,trend:CFG.trend,financial:now.financial,risk:now.risk,metrics:now.m,x:now.x,whatifs:wi,room_fin:room(now.financial),room_risk:room(now.risk)}];
 }}));

dash.calc('age_calc',CR("age_calc",{title:'Where you stand at your age',description:'Each metric in three percent forms: percent of guideline (value / guideline x 100, lower is better metrics use the limit), percent of typical (value / peer median x 100) and percentile rank (linear between the published p25, p50, p75, p90, p95 rows). A form without a sourced row says Needs data. Ratios are never shown as multiples. Every figure keeps its source, data year and dollar year.',inputs:['age_benchmarks','age_metrics_config','retirement_plan','networth_history','income_pay','contributions','liabilities','scores_calc','dti_calc','pace_calc'],
 fn:(bm,cfgIn,rp,nwh,inc,ct,liab,sc,dti,pace)=>{
  const CFG=parseRow(Array.isArray(cfgIn)?cfgIn[0]:cfgIn,['age_lookup','label_vocabulary','peer_group_notes','metrics','data_needs_to_check']);
  const B={};bm.forEach(r=>{B[r.id]=r;});
  const item=(r,k)=>{const x=r.find(z=>z.item===k);return x?x.value:null;};
  const sum=(a,f)=>a.reduce((s,x)=>s+(f(x)||0),0);
  const age=item(rp,'current_age'),tgtAge=item(rp,'target_age');
  if(age==null)return [{needs:['current_age in retirement_plan']}];
  const b=age<35?'under_35':age<45?'35_44':age<55?'45_54':age<65?'55_64':age<75?'65_74':'75plus';
  const bLabel={under_35:'under 35','35_44':'35 to 44','45_54':'45 to 54','55_64':'55 to 64','65_74':'65 to 74','75plus':'75 and over'}[b];
  const dollarYear=r=>{if(!r)return null;if(r.unit!=='USD')return null;const m=String(r.population_note||'').match(/(\d{4}) dollars/);return m?m[1]+' dollars':'nominal '+r.data_year+' dollars';};
  const src=r=>r?{id:r.id,source:r.source,url:r.url,data_year:r.data_year,dollar_year:dollarYear(r),population_note:r.population_note,confidence:r.confidence||null,value:r.value,unit:r.unit}:null;
  const used=new Set();const get=id=>{const r=B[id];if(r)used.add(id);return r||null;};
  const last=nwh.length?[...nwh].sort((p,q)=>p.date<q.date?-1:1).pop():null;
  const salary=sum(inc.filter(i=>i.kind==='Base'),i=>i.annual_gross);const gross=sum(inc,i=>i.annual_gross);
  const S=sc[0];
  /* guideline curve (salary multiple anchors from the benchmark rows; 25 = 0 is the publisher's start age, derived) */
  const anchors=[[25,0]];[30,40,50,60,67].forEach(a=>{const r=get('g_fidelity_'+a);if(r)anchors.push([a,r.value]);});
  const mult=a=>{if(anchors.length<2)return null;if(a<=anchors[0][0])return 0;for(let i=1;i<anchors.length;i++){const [a0,m0]=anchors[i-1],[a1,m1]=anchors[i];if(a<=a1)return m0+(a-a0)/(a1-a0)*(m1-m0);}return anchors[anchors.length-1][1];};
  const inv=m=>{if(anchors.length<2)return null;if(m<=0)return anchors[0][0];for(let i=1;i<anchors.length;i++){const [a0,m0]=anchors[i-1],[a1,m1]=anchors[i];if(m<=m1)return a0+(m-m0)/(m1-m0)*(a1-a0);}return null;};
  const trowe=(a,side)=>{const ages=[30,35,40,45,50,55,60,65];let lo=null,hi=null;ages.forEach(x=>{if(x<=a)lo=x;if(hi==null&&x>=a)hi=x;});if(lo==null||hi==null)return null;const rl=get('g_trowe_'+lo+'_'+side),rh=get('g_trowe_'+hi+'_'+side);if(!rl||!rh)return null;return lo===hi?rl.value:rl.value+(a-lo)/(hi-lo)*(rh.value-rl.value);};
  const pct=(v,d)=>v==null||d==null||!d?null:v/d*100;
  const ord=n=>{n=Math.round(n);const t=n%100;return n+((t>10&&t<14)?'th':({1:'st',2:'nd',3:'rd'}[n%10]||'th'));};
  const rank=(v,ids)=>{const pts=[[25,ids.p25],[50,ids.p50],[75,ids.p75],[90,ids.p90],[95,ids.p95]].map(([p,id])=>[p,get(id)]).filter(z=>z[1]);
    if(pts.length<2||v==null)return null;
    if(v<pts[0][1].value)return {percentile:null,below:pts[0][0],text:'below the '+ord(pts[0][0])+' percentile',rows:pts.map(z=>src(z[1]))};
    const top=pts[pts.length-1];if(v>top[1].value)return {percentile:null,above:top[0],text:'above the '+ord(top[0])+' percentile',top_pct:100-top[0],rows:pts.map(z=>src(z[1]))};
    for(let i=1;i<pts.length;i++){const [p0,r0]=pts[i-1],[p1,r1]=pts[i];if(v<=r1.value){const p=p0+(v-r0.value)/(r1.value-r0.value)*(p1-p0);return {percentile:p,top_pct:100-p,text:'about the '+ord(p)+' percentile',between:[p0,p1],rows:pts.map(z=>src(z[1]))};}}
    return null;};
  const metrics=[];
  const form=(o)=>Object.assign({pct:null,needs:null,rows:[],range:null},o);
  /* 1 net worth */
  if(last){const v=last.net_worth;const med=get('nw_median_'+b);
    const alt=[['nw_median_'+b,'families, survey of consumer finances'],['nw_median_'+b+'_sipp','households, Census'],['nw_median_married_35_54_sipp','married couples 35 to 54, Census'],['nw_median_40_44_b5','families 40 to 44, five year band']].map(([id,l])=>{const r=get(id);return r?{label:l,pct:pct(v,r.value),row:src(r)}:null;}).filter(Boolean);
    const rk=rank(v,{p25:'nw_p25_'+b,p50:'nw_p50_'+b,p75:'nw_p75_'+b,p90:'nw_p90_'+b,p95:'nw_p95_'+b});
    const ratio=med?v/med.value:null;
    metrics.push({id:'net_worth',title:'Net worth',value:v,unit:'USD',lower_better:false,
      guideline:form({needs:'Needs data: no published net worth target by age'}),
      typical:form({pct:med?pct(v,med.value):null,rows:med?[src(med)]:[],needs:med?null:'Needs data: no median row for your age group',range:alt.length>1?[Math.min(...alt.map(a=>a.pct)),Math.max(...alt.map(a=>a.pct))]:null,alts:alt}),
      rank:form({percentile:rk?rk.percentile:null,top_pct:rk?rk.top_pct:null,text:rk?rk.text:null,rows:rk?rk.rows:[],needs:rk?null:'Needs data: no percentile rows for your age group',approx:true}),
      label:ratio==null?'needs_data':ratio>=1.25?'ahead':ratio>=0.75?'on_track':'behind'});}
  /* 2 retirement balance against the salary guideline */
  const ret=last?last.retirement:null;let ladder=null;
  if(ret!=null&&salary){const gm=mult(age);const g=gm!=null?gm*salary:null;const tl=trowe(age,'low'),th=trowe(age,'high');
    const med=get('ret_median_'+b),vg=get('ret_vanguard_med_'+b);
    const alts=[med?{label:'families with an account, survey of consumer finances',pct:pct(ret,med.value),row:src(med)}:null,vg?{label:pubName(vg)+' plan participants',pct:pct(ret,vg.value),row:src(vg)}:null].filter(Boolean);
    const gRows=anchors.slice(1).map(a=>src(B['g_fidelity_'+a[0]])).filter(Boolean);
    metrics.push({id:'retirement',title:'Retirement balance',value:ret,unit:'USD',lower_better:false,
      guideline:form({pct:g?pct(ret,g):null,amount:g,rows:gRows,range:tl!=null&&th!=null?[pct(ret,th*salary),pct(ret,tl*salary)]:null,range_label:pubName(get('g_trowe_40_low'))+' range for your age',range_amounts:tl!=null?[tl*salary,th*salary]:null,derived:true}),
      typical:form({pct:med?pct(ret,med.value):null,rows:med?[src(med)]:[],range:alts.length>1?[Math.min(...alts.map(a=>a.pct)),Math.max(...alts.map(a=>a.pct))]:null,alts,note:'among families who have an account'}),
      rank:form({needs:'Needs data: no published percentile rows for retirement balances by age'}),
      label:g==null?'needs_data':ret/g>=1.10?'ahead':ret/g>=0.90?'on_track':'behind'});
    /* ladder */
    if(g){const k=ct.find(c=>/401/.test(c.account));const perYear=sum(ct,c=>c.employee_annual+c.employer_annual);const k401=k?k.employee_annual+k.employer_annual:0;
      const youPct=ret/g*100;const rungs=[25,50,75,100].map(p=>({pct:p,amount:g*p/100,age_at:inv(gm*p/100)}));
      const next=rungs.find(r=>r.pct>youPct)||null;
      const need=next?next.amount-ret:0;
      const t60=tgtAge||60;const g60m=mult(t60);const g60=g60m!=null?g60m*salary:null;
      const pc=pace&&pace[0]?pace[0]:null;
      ladder={age,salary,guideline:g,guideline_rows:gRows,you_pct:youPct,you_amount:ret,you_age_equiv:inv(ret/salary),rungs,next,need_next:need,
        per_year_saving:perYear,k401_per_year:k401,months_to_next_401k:k401>0?need/(k401/12):null,months_to_next_all:perYear>0?need/(perYear/12):null,k401_limit:k?k.limit_annual:null,months_to_next_limit:k&&k.limit_annual?need/((k.limit_annual+(k.employer_annual||0))/12):null,
        target_age:t60,guideline_at_target:g60,proj_target:pc?{lo:pc.end_lo,mid:pc.end_mid,hi:pc.end_hi}:null,
        target_pct:pc&&g60?{lo:pct(pc.end_lo,g60),mid:pct(pc.end_mid,g60),hi:pct(pc.end_hi,g60)}:null,
        trowe_target:(()=>{const l=trowe(t60,'low'),h=trowe(t60,'high');return l!=null?[l*salary,h*salary]:null;})()};}
  }
  /* 3 savings rate */
  if(gross){const v=sum(ct,c=>c.employee_annual+c.employer_annual)/gross*100;const g=get('g_savings_fidelity_15'),gl=get('g_savings_vanguard_12_15'),t=get('sav_vanguard_total_'+b);
    metrics.push({id:'savings_rate',title:'Savings rate',value:v,unit:'percent of pay',lower_better:false,
      guideline:form({pct:g?pct(v,g.value):null,rows:g?[src(g)]:[],range:g&&gl?[pct(v,g.value),pct(v,gl.value)]:null,range_label:'against the 15 percent and the 12 percent guidelines'}),
      typical:form({pct:t?pct(v,t.value):null,rows:t?[src(t)]:[],needs:t?null:'Needs data'}),
      rank:form({needs:'Needs data: no savings rate ranking by age'}),
      label:v>=15?'ahead':v>=12?'on_track':'behind',note:'Payroll saving only (401(k) and HSA, you plus employer). Saving outside payroll is not in the data, so this is a floor.'});}
  /* 4 credit card debt (lower is better) */
  {const allCards=liab.filter(l=>isCard(l)&&l.balance);const cards=allCards.filter(l=>!isClosed(l));const v=sum(allCards,l=>l.balance);const allLim=cards.length&&cards.every(l=>l.credit_limit);
    const g=get('g_util_30');const med=get('cc_median_'+b);const ex=get(age<=44?'cc_experian_avg_millennials_29_44':'cc_experian_avg_gen_x_45_60');const co1=get('cc_capone_avg_millennials_26_41'),co2=get('cc_capone_avg_gen_x_42_57');
    const util=allLim?sum(cards,l=>l.balance)/sum(cards,l=>l.credit_limit)*100:null;const missing=cards.filter(l=>!l.credit_limit).map(l=>l.name);
    const alts=[med?{label:'typical balance among families who carry one',pct:pct(v,med.value),row:src(med)}:null,ex?{label:'credit bureau average for your generation',pct:pct(v,ex.value),row:src(ex)}:null,co1&&age<=41?{label:'card issuer average, ages 26 to 41',pct:pct(v,co1.value),row:src(co1)}:null,co2&&age>=42&&age<=57?{label:'card issuer average, ages 42 to 57',pct:pct(v,co2.value),row:src(co2)}:null].filter(Boolean);
    metrics.push({id:'credit_card',title:'Credit card debt',value:v,unit:'USD',lower_better:true,
      guideline:form({pct:util!=null&&g?pct(util,g.value):null,rows:g?[src(g)]:[],needs:util==null?'Needs: credit limit for '+missing.join(', '):null,util}),
      typical:form({pct:med?pct(v,med.value):null,rows:med?[src(med)]:[],range:alts.length>1?[Math.min(...alts.map(a=>a.pct)),Math.max(...alts.map(a=>a.pct))]:null,alts,note:'among families who carry a balance'}),
      rank:form({needs:'Needs data: only a median and the share carrying a balance are published'}),
      label:!med?'needs_data':v<=med.value?'ahead':(ex&&v<=ex.value)?'on_track':'behind'});}
  /* 5 emergency fund */
  {const months=S.metrics.emergency_months;const liquid=S.x.liquid;const gl=get('g_ef_low'),gh=get('g_ef_high'),t=get('liquid_txn_median_'+b),sh=get('g_ef_bankrate_3mo_all');
    metrics.push({id:'emergency',title:'Emergency fund',value:months,unit:'months',lower_better:false,
      guideline:form({pct:months!=null&&gl?pct(months,gl.value):null,rows:[gl,gh].filter(Boolean).map(src),range:gl&&gh&&months!=null?[pct(months,gh.value),pct(months,gl.value)]:null,range_label:'against 6 months and 3 months'}),
      typical:form({pct:t?pct(liquid,t.value):null,rows:t?[src(t)]:[],note:'compares your liquid cash with the typical transaction account balance, not months'}),
      rank:form({needs:'Needs data: only the share of adults with 3 or more months is published'+(sh?' ('+sh.value+' percent)':'')}),
      label:months==null?'needs_data':months>=6?'ahead':months>=3?'on_track':'behind'});}
  /* 6 debt to income (lower is better) */
  if(dti&&dti[0]){const e=dti[0].back_end_est_pct,n=dti[0].back_end_pct;const g=get('g_dti_back'),g43=get('g_dti_43');
    metrics.push({id:'dti',title:'Debt to income',value:e,value_entered:n,unit:'percent',lower_better:true,
      guideline:form({pct:g?pct(e,g.value):null,pct_entered:g?pct(n,g.value):null,rows:[g,g43].filter(Boolean).map(src)}),
      typical:form({needs:'Needs data: no median debt to income by age'}),
      rank:form({needs:'Needs data: no ranking by age'}),
      label:e<=28?'ahead':e<=36?'on_track':'behind'});}
  /* 7 income, context only */
  if(gross){const cm=get('inc_median_'+b+'_census'),fm=get('inc_median_'+b);const rk=rank(gross,{p25:'inc_p25_'+b+'_census',p50:'inc_median_'+b+'_census',p75:'inc_p75_'+b+'_census',p90:'inc_p90_'+b+'_census',p95:'__none'});
    const alts=[fm?{label:'families, survey of consumer finances',pct:pct(gross,fm.value),row:src(fm)}:null,cm?{label:'households, Census',pct:pct(gross,cm.value),row:src(cm)}:null].filter(Boolean);
    metrics.push({id:'income',title:'Income (context only)',value:gross,unit:'USD',lower_better:false,info:true,
      guideline:form({needs:'No guideline: income is shown only to explain the other comparisons'}),
      typical:form({pct:fm?pct(gross,fm.value):null,rows:fm?[src(fm)]:[],range:alts.length>1?[Math.min(...alts.map(a=>a.pct)),Math.max(...alts.map(a=>a.pct))]:null,alts}),
      rank:form({percentile:rk?rk.percentile:null,top_pct:rk?rk.top_pct:null,text:rk?rk.text:null,rows:rk?rk.rows:[],needs:rk?null:'Needs data',approx:true}),label:'info'});}
  return [{age,bracket:b,bracket_label:bLabel,salary,disclaimer:CFG.disclaimer,vocabulary:CFG.label_vocabulary,metrics,ladder,rows_used:[...used].sort()}];
 }}));

/* payoff engine: monthly compounding, minimums first, then the pool in ranking order (shared with the slider). opt.hold is the one time cash
   shortfall (the cushion top-up to 1 month of must-pay): it is kept out of the pool in the first month only, and the rest in the next months if
   the first month's extra cannot cover it. After that every month gets the full extra. */
function PAYOFF_SIM(debts,extra,strategy,start,opt){
  opt=opt||{};const N=debts.length;const MAXM=720;
  const never=debts.map(d=>strategy==='minimums'&&(d.min<=0||d.min<=d.balance*(d.rate||0)/1200+1e-9));
  const bal=debts.map((d,i)=>never[i]?0:d.balance),paid=debts.map(()=>0),intr=debts.map(()=>0),payoffM=debts.map(()=>null);
  const months=[];let k=0;const minsTotal=debts.reduce((s,d)=>s+d.min,0);let holdLeft=Math.max(0,opt.hold||0);
  const rateAt=(d,k)=>{if(d.promo_end_index!=null&&k>=d.promo_end_index&&d.rate_after_promo_pct!=null)return d.rate_after_promo_pct;return d.rate||0;};
  const effAt=(d,k)=>{if(d.pays_in_full)return 0;if(d.promo_end_index!=null&&k<d.promo_end_index)return d.rate_after_promo_pct!=null?d.rate_after_promo_pct:(d.rate||0);return (d.rate==null?-1:rateAt(d,k))+(d.penalty_rate_pct||0);};
  const order=k=>{const idx=debts.map((d,i)=>i).filter(i=>bal[i]>0.004&&!debts[i].no_extra);
    const key=i=>{const d=debts[i];
      if(strategy==='smallest')return [bal[i],0,0];
      if(strategy==='highest')return [-(d.rate==null?-1:rateAt(d,k)),bal[i],0];
      const tier=(k===0&&d.days_past_due>0)?0:(d.late_recent?1:2);
      return [tier,tier===0?(d.secured?0:1):0,tier===0?-d.days_past_due:-effAt(d,k),bal[i]];};
    return idx.sort((a,b)=>{const A=key(a),B=key(b);for(let j=0;j<A.length;j++){if(A[j]!==B[j])return A[j]-B[j];}return debts[a].id<debts[b].id?-1:1;});};
  let firstOrder=null;
  while(k<MAXM&&bal.some(b=>b>0.004)){
    const row={k,pay:debts.map(()=>0),interest:debts.map(()=>0),bal:null};
    const held=debts.map(()=>0);
    debts.forEach((d,i)=>{if(bal[i]>0.004){const r=rateAt(d,k);const it=bal[i]*r/1200;if(k===0&&d.statement_balance!=null&&!(d.days_past_due>0)){held[i]=it;return;}bal[i]+=it;intr[i]+=it;row.interest[i]=it;}});
    let used=0;debts.forEach((d,i)=>{if(bal[i]>0.004){const p=Math.min(d.min,bal[i]);bal[i]-=p;paid[i]+=p;row.pay[i]+=p;used+=p;}});
    if(strategy!=='minimums'){const h=Math.min(holdLeft,Math.max(0,extra));holdLeft-=h;row.hold=h;let pool=extra-h+minsTotal-used;const ord=order(k);if(k===0)firstOrder=ord.slice();
      for(const i of ord){if(pool<=0.004)break;if(bal[i]<=0.004)continue;const p=Math.min(pool,bal[i]);bal[i]-=p;paid[i]+=p;row.pay[i]+=p;pool-=p;}}
    else if(k===0)firstOrder=order(0);
    /* grace: interest is waived only when this month's payment covers the statement balance; otherwise it is charged */
    debts.forEach((d,i)=>{if(held[i]>0){if(row.pay[i]+0.004<d.statement_balance){bal[i]+=held[i];intr[i]+=held[i];row.interest[i]=held[i];}else row.grace=(row.grace||[]).concat([i]);}});
    debts.forEach((d,i)=>{if(bal[i]<=0.004){if(payoffM[i]==null&&d.balance>0&&!never[i])payoffM[i]=k;bal[i]=0;}});
    row.bal=bal.slice();months.push(row);k++;
    if(opt.stopAt&&k>=opt.stopAt)break;}
  const sy=+start.slice(0,4),sm=+start.slice(5,7)-1;const lab=m=>{if(m==null)return null;const t=sy*12+sm+m;return Math.floor(t/12)+'-'+String(t%12+1).padStart(2,'0');};
  const done=bal.every(b=>b<=0.004);
  return {strategy,extra,months:months.length,done,end:done?lab(months.length-1):null,total_interest:intr.reduce((a,b)=>a+b,0),interest:intr,paid,payoff:payoffM.map(lab),payoff_index:payoffM,first_order:firstOrder||[],hold_months:months.filter(r=>r.hold>0).map(r=>[r.k,Math.round(r.hold*100)/100]),schedule:months,label:lab,stuck:debts.map((d,i)=>payoffM[i]==null),never:never.map((v,i)=>v?(debts[i].min<=0?'no minimum payment on file':'the minimum does not cover the monthly interest'):null)};
}
dash.calc('payoff_engine',CR("payoff_engine",{title:'Debt payoff plan',description:'Every non-mortgage debt with a balance. Surplus = monthly take-home (latest stub x paychecks per year / 12) minus every bill minus every debt payment you make (support withheld from pay is left out). Monthly compounding, minimums first, then the extra plus freed minimums in the chosen order. Smart order: past due first, then a late payment in the last 90 days, then the highest effective rate (a card paid in full each month costs no interest; a promo is ranked by the rate after it), ties by smaller balance. Missing rates, minimums or dates are listed as Needs. A saved strategy and extra amount (payoff_settings) are used when set; otherwise smart order and the cushion-safe extra.',inputs:['liabilities','bills','paystubs','income_pay','assets_other','payoff_settings'],
 fn:(liab,bills,ps,inc,assets,pset)=>{
  const sum=(a,f)=>a.reduce((s,x)=>s+(f(x)||0),0);
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const start=T0.slice(0,7);const today=T0;
  const days=(a,b)=>Math.round((Date.parse(b)-Date.parse(a))/864e5);
  const s0=realRows(pset||[])[0]||{};const set={};if(['smart','highest','smallest'].includes(s0.chosen_strategy))set.chosen_strategy=s0.chosen_strategy;if(typeof s0.extra_per_month==='number'&&s0.extra_per_month>=0)set.extra_per_month=s0.extra_per_month;
  const b0=inc.find(i=>i.kind==='Base');const st=ps.length?[...ps].sort((a,b)=>a.pay_date<b.pay_date?-1:1).pop():null;
  const needs=[];
  const take=st&&b0&&b0.paychecks_per_year?st.take_home_core*b0.paychecks_per_year/12:null;if(take==null)needs.push('take-home from a pay stub and paychecks per year');
  const billsM=sum(bills,b=>b.monthly_amount);
  const withheld=liab.filter(l=>l.type==='Support');
  const card=l=>openCard(l);
  const debts=[],mins=[];
  liab.forEach(l=>{
    if(l.type==='Support')return;
    let min=l.monthly_payment,minEst=false;
    if(min==null&&card(l)&&l.balance){min=Math.round(l.balance*4)/100;minEst=true;}
    if(min!=null)mins.push({id:l.liability_id,name:l.name,min,est:minEst,mortgage:l.type==='Mortgage',
      notes:l.type==='Mortgage'?[l.late_fee!=null?'Late fee '+l.late_fee.toFixed(2)+' when paid after the grace date.':null,(l.days_past_due==null||l.last_late_date==null)&&l.late_fee!=null?(l.late_needs||'Needs: which months were late'):null,l.days_past_due>0?l.days_past_due+' days past due.':null,l.next_due?'Next payment $'+(l.amount_due||l.monthly_payment).toLocaleString('en-US',{minimumFractionDigits:2})+' due '+['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][+l.next_due.slice(5,7)-1]+' '+(+l.next_due.slice(8,10))+(l.late_after?', late after '+['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][+l.late_after.slice(5,7)-1]+' '+(+l.late_after.slice(8,10)):'')+'.':null,/^(n|none|no)$/i.test(String(l.prepayment_penalty||''))?'No prepayment penalty.':null].filter(Boolean):[]});
    if(l.type==='Mortgage'||!l.balance)return;
    const n=[];const need=[];
    if(l.rate_pct==null)need.push('interest rate');
    if(l.monthly_payment==null)need.push(card(l)?'minimum payment (4 percent of the balance used as an estimate)':'minimum payment');
    const dueNext=(l.next_due_date&&l.next_due_date>=today?l.next_due_date:null)||l.due_date||nextDueDay(l.due_day,l.last_paid,today)||l.next_due_date||null;
    if(!dueNext&&!(l.days_past_due>0))need.push('due date');
    if(l.days_past_due==null)need.push('days past due, or confirm it is current');
    if(card(l)&&!l.credit_limit)need.push('credit limit');
    if(card(l)&&l.pays_in_full==null)need.push('whether you pay the full statement each month');
    let promoIdx=null;if(l.promo_end_date){const sy=+start.slice(0,4),sm=+start.slice(5,7),ey=+l.promo_end_date.slice(0,4),em=+l.promo_end_date.slice(5,7);promoIdx=(ey-sy)*12+(em-sm);if(l.rate_after_promo_pct==null)need.push('rate after the promo');}
    const lateRecent=l.last_late_date?days(l.last_late_date,today)<=90:false;
    if(l.secured==='Y')n.push({kind:'secured',text:'Secured by '+(l.secured_by||'collateral')+'. Falling behind puts it at risk, so keep this one on time.'});
    if(l.type==='HELOC'&&l.rate_type==null)n.push({kind:'variable',text:'Rate type not recorded. A home equity line is often variable, so its rate can change: confirm on the statement.'});
    if(l.rate_type==='variable')n.push({kind:'variable',text:"Variable rate: the rate can change. The plan holds today's rate."});
    if(l.type==='Tax')n.push({kind:'tax',text:'Tax debt: interest and penalties are not in the balance and the rate is not recorded, so it is ranked last until the notice gives the rate. Never skip a payment plan payment; confirm penalty and interest accrual on the notice.'});
    if(l.type==='Medical')n.push({kind:'medical',text:'Medical bills are usually interest free until they reach collections. Ask for a payment plan and the due date.'});
    if(promoIdx!=null)n.push({kind:'promo',text:'Promo ends '+l.promo_end_date+'. Ranked by the rate after the promo.'});
    if(/^(n|none|no)$/i.test(String(l.prepayment_penalty||'')))n.push({kind:'prepay',text:'No prepayment penalty: extra payments are free. Ask the lender to apply extra to principal.'});
    if(l.prepayment_penalty==='Y')n.push({kind:'prepay',text:'Prepayment penalty: gets its minimum only. Needs: penalty amount.'});
    const util=card(l)&&l.credit_limit?l.balance/l.credit_limit*100:null;
    if(util!=null&&util>30)n.push({kind:'util',text:Math.round(util)+' percent of the limit used. Getting under 30 percent ('+'$'+Math.round(l.credit_limit*0.3).toLocaleString('en-US')+') usually helps credit scores.'});
    if(isCard(l)&&isClosed(l))n.push({kind:'closed',text:'Closed to new charges'+(l.closed_date?' since '+l.closed_date:'')+': interest is charged on the balance until it is paid off, and it no longer counts toward credit utilization.'});
    if(card(l))n.push({kind:'card',text:l.pays_in_full==='Y'?'Paid in full each month, so it costs no interest: keep paying the statement balance.':'A card paid in full by the due date costs no interest'+(l.statement_balance!=null?' (statement balance $'+l.statement_balance.toLocaleString('en-US',{minimumFractionDigits:2})+')':'')+'.'});
    if(l.late_fee!=null&&!(l.days_past_due>0)&&(l.days_past_due==null||l.last_late_date==null))need.push((l.late_needs||'Needs: which months were late').replace(/^Needs:\s*/,''));
    if(l.days_past_due>0)n.push({kind:'late',text:l.days_past_due+' days past due'+(l.late_fee?', late fee $'+l.late_fee:'')+'. Late payments are commonly reported at 30 days, which is '+Math.max(0,30-l.days_past_due)+' days away.'});
    debts.push({id:l.liability_id,name:l.name,type:l.type,balance:l.balance,original:l.original_balance||null,rate:l.rate_pct,min:min==null?0:min,min_est:minEst,min_missing:min==null,
      days_past_due:l.days_past_due||0,late_fee:l.late_fee||null,late_recent:lateRecent,secured:l.secured==='Y',rate_type:l.rate_type||null,pays_in_full:l.pays_in_full==='Y'&&!isClosed(l),closed:isClosed(l),
      promo_end_index:promoIdx,promo_end_date:l.promo_end_date||null,rate_after_promo_pct:l.rate_after_promo_pct==null?null:l.rate_after_promo_pct,penalty_rate_pct:l.penalty_rate_pct||0,no_extra:l.prepayment_penalty==='Y',
      credit_limit:l.credit_limit||null,statement_balance:l.statement_balance==null||isClosed(l)?null:l.statement_balance,statement_date:l.statement_date||null,util,due:l.days_past_due>0?today:dueNext,interest_paid_to_date:l.interest_paid_to_date==null?null:l.interest_paid_to_date,notes:n,needs:need,as_of:l.as_of_date});
  });
  const minsPay=sum(mins,m=>m.min);
  const surplus=take==null?null:take-billsM-minsPay;
  /* cushion: essentials = essential bills + every debt payment incl. support withheld and the card estimate; cash = spendable value of the Cash assets (spendable_value when set, else the posted value_point) */
  const cash=sum(assets.filter(a=>a.type==='Cash'),a=>a.spendable_value!=null?a.spendable_value:a.value_point);
  const mustpay=sum(bills.filter(b=>b.essential==='Yes'),b=>b.monthly_amount)+minsPay+sum(withheld,w=>w.monthly_payment);
  const shortfall=Math.max(0,mustpay-cash);
  const safeE=surplus==null?0:Math.max(0,Math.round((surplus-shortfall)*100)/100);
  /* E is the steady extra a month (the saved amount, else the whole surplus). The cushion top-up is held back from the first month only (ARCH 11.3). */
  const E=set.extra_per_month!=null?set.extra_per_month:(surplus==null?0:Math.max(0,Math.round(surplus*100)/100));
  const strategy=set.chosen_strategy||'smart';
  const hold=Math.round(shortfall*100)/100;const sim=(s,e)=>PAYOFF_SIM(debts,e,s,start,{hold});
  const plans={smart:sim('smart',E),highest:sim('highest',E),smallest:sim('smallest',E),minimums:sim('minimums',0)};
  const strip=p=>{const o=Object.assign({},p);delete o.schedule;delete o.label;return o;};
  /* C17 checks on every plan */
  const c17=Object.keys(plans).map(k=>{const p=plans[k];const startBal=sum(debts.filter((d,i)=>!p.never[i]),d=>d.balance);const paid=p.paid.reduce((a,b)=>a+b,0);
    let over=0,below=0;p.schedule.forEach(r=>{const spend=r.pay.reduce((a,b)=>a+b,0);if(spend>minsPay-sum(mins.filter(m=>m.mortgage),m=>m.min)+(k==='minimums'?0:E)+0.01)over++;debts.forEach((d,i)=>{const owed=r.bal[i]+r.pay[i];if(owed>0.004&&r.pay[i]+0.004<Math.min(d.min,owed))below++;});});
    const nv=debts.filter((d,i)=>p.never[i]);return {plan:k,ends_at_zero:p.done&&!nv.length,flag:!p.done?'does not reach zero in 720 months':nv.length?'not paid off on minimums only: '+nv.map((d)=>d.name+' ('+p.never[debts.indexOf(d)]+')').join(', '):null,balance_identity:Math.abs(paid-(startBal+p.total_interest))<0.01||!p.done,over_budget_months:over,below_min:below};});
  return [{cash,mustpay,cash_months:mustpay?cash/mustpay:null,basis:{cash:basisOf(assets.filter(a=>a.type==='Cash')),debts:basisOf(liab),payments:basisOf(liab.filter(l=>l.monthly_payment!=null),'payment_basis'),bills:basisOf(bills)},cushion_shortfall:shortfall,cushion_hold:hold,safe_extra:safeE,extra_first:Math.max(0,Math.round((E-Math.min(hold,E))*100)/100),start,today,take_home:take,bills:billsM,mins:minsPay,mins_rows:mins,withheld:withheld.map(w=>({name:w.name,monthly:w.monthly_payment})),surplus,extra:E,extra_source:set.extra_per_month!=null?'saved setting':'computed surplus',strategy,
    debts,plans:{smart:strip(plans.smart),highest:strip(plans.highest),smallest:strip(plans.smallest),minimums:strip(plans.minimums)},c17,needs,settings:set}];
 }}));

dash.calc('drift_all',CR("drift_all",{title:'Dollar drift, every account',description:'Every account with two or more reported balances: bank accounts use expected = opening + known inflows - known outflows; cards use expected = opening + loaded charges - known payments, so a card balance above expected is unexplained spending. Weekly check points line up all accounts on the same date. ATM withdrawals count as a known outflow and are listed as cash spending not tracked. A trend shows only with 3 or more check points.',inputs:['balance_log','cash_events','card_transactions'],
 fn:(bl,ev,tx)=>{
  const r2=x=>Math.round(x*100)/100;
  const accts=[...new Set(bl.map(b=>b.account))];
  const kindOf=a=>{const r=bl.find(b=>b.account===a);return r?r.kind:null;};
  const bal=(a,d)=>{const r=bl.filter(b=>b.account===a&&b.date===d);return r.length?r[r.length-1].reported_balance:null;};
  const ev0=ev;const inB=e=>(e.in_balances==null||e.in_balances==='Y'||e.in_balances===true);const applied=e=>e.status!=='Pending'&&(inB(e)||(e.in_expected_balances===true&&e.apply_to_expected_savings!==false));ev=ev0.filter(applied);
  const isATM=e=>/\bATM\b|cash withdrawal/i.test(evLabel(e)+' '+(e.note||''));
  const out=[],atm=[];
  accts.forEach(a=>{const card=kindOf(a)==='Card';const ds=[...new Set(bl.filter(b=>b.account===a).map(b=>b.date))].sort();const pts=[];
    for(let i=1;i<ds.length;i++){const d0=ds[i-1],d1=ds[i];const open=bal(a,d0),rep=bal(a,d1);let inflow=0,outflow=0,trIn=0,trOut=0,needs=[];const items=[];
      if(card){tx.filter(t=>t.card===a&&t.date>d0&&t.date<=d1).forEach(t=>{inflow+=t.amount;items.push({date:t.date,label:t.merchant,amount:t.amount});});
        ev.filter(e=>e.pays_card===a&&e.date>d0&&e.date<=d1).forEach(e=>{outflow+=-e.amount;items.push({date:e.date,label:'payment',amount:e.amount});});}
      else{ev.filter(e=>(e.date>d0||(e.date===d0&&e.drift_explained==='Y'))&&e.date<=d1&&(e.account===a||(e.account==='Not confirmed'&&!e.pays_card))).forEach(e=>{
          if(e.account==='Not confirmed'){needs.push('which account the '+e.date+' '+evLabel(e).toLowerCase()+' used');return;}
          const lab=isATM(e)?'ATM':evLabel(e);if(isATM(e))atm.push({account:a,date:e.date,amount:-e.amount,note:'cash spending not tracked'});
          if(e.amount>0)inflow+=e.amount;else outflow+=-e.amount;if(e.kind==='transfer'){if(e.amount>0)trIn+=e.amount;else trOut+=-e.amount;}items.push({date:e.date,label:lab,amount:e.amount,atm:isATM(e),kind:e.kind});});}
      const ok=!needs.length;const exp=ok?r2(open+(card?inflow-outflow:inflow-outflow)):null;
      const drift=ok?r2(rep-exp):null;
      pts.push({account:a,card,from:d0,to:d1,opening:open,inflows:r2(inflow),outflows:r2(outflow),transfers_in:r2(trIn),transfers_out:r2(trOut),waiting_out:card?0:r2(ev0.filter(e=>e.account===a&&e.clearing==='waiting'&&e.kind!=='transfer'&&e.date>d0&&e.date<=d1).reduce((s,e)=>s-e.amount,0)),expected:exp,reported:rep,drift,needs,items,
        unexplained:drift==null?null:card?Math.max(0,drift):Math.max(0,-drift)});}
    out.push({account:a,kind:kindOf(a),card,dates:ds,points:pts,trend:pts.filter(p=>p.drift!=null).length>=3,single:ds.length<2});});
  const allDates=[...new Set(bl.map(b=>b.date))].sort();
  const grid=allDates.slice(-4).map(d=>({date:d,accounts:accts.map(a=>({account:a,reported:bal(a,d)}))}));
  /* what is left in a bank account once every payment waiting to clear has cleared: the latest posted reading plus the waiting rows (clearing waiting, not in that reading). Should be 0. */
  const left_over=accts.filter(a=>kindOf(a)!=='Card').map(a=>{const w=ev0.filter(e=>e.account===a&&e.clearing==='waiting');if(!w.length)return null;const ds=[...new Set(bl.filter(b=>b.account===a).map(b=>b.date))].sort();const d=ds[ds.length-1];const posted=bal(a,d);const tot=w.reduce((s,e)=>s+e.amount,0);
    return {account:a,posted,posted_date:d,waiting_total:r2(tot),rows:w.map(e=>e.event_id),left_over:posted==null?null:r2(posted+tot)};}).filter(Boolean);
  const lastD=allDates[allDates.length-1]||null;let next=null;if(lastD){const t=new Date(lastD+'T12:00:00Z');t.setUTCDate(t.getUTCDate()+7);next=t.toISOString().slice(0,10);}
  const unexpl=out.reduce((s,a)=>s+a.points.reduce((q,p)=>q+(p.unexplained||0),0),0);
  const known=out.reduce((s,a)=>s+a.points.reduce((q,p)=>q+(p.drift==null?0:(p.card?p.inflows:p.outflows-(p.transfers_out||0)+(p.waiting_out||0))),0),0);
  const npts=out.reduce((s,a)=>s+a.points.filter(p=>p.drift!=null).length,0);
  return [{expected_events:ev0.filter(e=>e.status!=='Pending'&&!inB(e)&&e.in_expected_balances===true).map(e=>({event_id:e.event_id,date:e.date,account:e.account,kind:evLabel(e),amount:e.amount,applied:e.apply_to_expected_savings!==false,linked:e.linked_event||null})),
    expected_now:bl.filter(b=>cellObj(b.expected_after_known_events)).map(b=>({account:b.account,reported:b.reported_balance,reported_date:b.date,expected:cellObj(b.expected_after_known_events).expected_balance,expected_date:cellObj(b.expected_after_known_events).expected_date,after_pending:cellObj(b.expected_after_known_events).expected_after_pending_deposit_E8==null?null:cellObj(b.expected_after_known_events).expected_after_pending_deposit_E8})),
    open_items:ev0.filter(e=>e.status!=='Pending'&&!inB(e)&&e.in_expected_balances!==true&&e.in_balances!=='N'&&e.in_balances!==false).map(e=>({event_id:e.event_id,date:e.date,account:e.account,kind:evLabel(e),amount:e.amount,question:'Is the '+Math.abs(e.amount).toLocaleString('en-US')+' already in the balance?'})),pending:ev0.filter(e=>e.status==='Pending').map(e=>({event_id:e.event_id,date:e.date,account:e.account,kind:evLabel(e),amount:e.amount,linked:e.linked_event||null,note:e.note})),accounts:out,left_over,grid,next_check:next,atm,unexplained_total:r2(unexpl),known_outflow:r2(known),check_points:npts,explained_pct:npts>=1&&known+unexpl>0?(known/(known+unexpl))*100:null}];
 }}));

dash.calc('plan_year_calc',CR("plan_year_calc",{title:'Plan-year 401(k) tile',description:'Year to date 401(k) from the stubs in the plan year against the limit for that year (prior year row labeled estimate when the year is not published). Remaining paychecks come from the pay calendar (first pay date and schedule), never from the number of stubs. Needed per paycheck = room left / remaining paychecks. Quarterly bars: even pace to the limit against what the stubs show.',inputs:['contribution_limits','contribution_plan','paystubs','income_pay','retirement_plan'],
 fn:(lim,plan,ps,inc,rp)=>{
  const item=(r,k)=>{const x=r.find(z=>z.item===k);return x?x.value:null;};
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const b0=inc.find(i=>i.kind==='Base')||{};const S=b0.annual_gross||null,p=b0.paychecks_per_year||null;
  const age=item(rp,'current_age');ps=ps.filter(s=>s.pay_date!=null);
  const years=[...new Set(plan.map(r=>r.plan_year).concat(ps.map(s=>+s.pay_date.slice(0,4))).concat([+T0.slice(0,4)]))].sort();
  const lastDay=(y,m)=>new Date(Date.UTC(y,m,0)).getUTCDate();
  const calendar=y=>{if(!b0.first_pay_date||!b0.pay_schedule)return null;const out=[];
    if(b0.pay_schedule==='semi-monthly'){for(let m=1;m<=12;m++){[15,lastDay(y,m)].forEach(d=>out.push(y+'-'+String(m).padStart(2,'0')+'-'+String(d).padStart(2,'0')));}}
    else if(b0.pay_schedule==='biweekly'){let t=Date.parse(b0.first_pay_date+'T12:00:00Z');while(new Date(t).getUTCFullYear()<y)t+=14*864e5;while(new Date(t).getUTCFullYear()===y){out.push(new Date(t).toISOString().slice(0,10));t+=14*864e5;}}
    else return null;
    /* nominal pay dates (a deposit moved to an earlier business day keeps its nominal date) */
    return out.filter(s=>s>=b0.first_pay_date);};
  const res=years.map(y=>{
    const exact=lim.find(r=>r.year===y);const prior=[...lim].filter(r=>r.year<y).sort((a,b)=>a.year-b.year).pop();const row=exact||prior||null;
    const est=!exact&&!!row;
    const ageEnd=age==null?null:age+(y-+T0.slice(0,4));
    const L=row?row.k401_deferral+(ageEnd!=null&&ageEnd>=50?(row.k401_catchup||0):0):null;
    const pr=plan.find(r=>r.plan_year===y)||null;const chosen=pr?pr.chosen_401k_pct:null;
    const stubs=ps.filter(s=>s.pay_date.slice(0,4)===String(y)).sort((a,b)=>a.pay_date<b.pay_date?-1:1);
    const Y=stubs.reduce((s,x)=>s+(x.k401_you||0),0);
    const ytdCol=stubs.length&&stubs[stubs.length-1].ytd_k401_you!=null?stubs[stubs.length-1].ytd_k401_you:null;
    const cal=calendar(y);const nowS=T0;
    const remaining=cal?cal.filter(d=>d>nowS).length:null;
    const latest=stubs.length?stubs[stubs.length-1]:null;
    const isPast=y<+T0.slice(0,4),isFuture=y>+T0.slice(0,4);
    const ratePct=chosen!=null?chosen:6;
    const pace=isFuture?(S&&p?ratePct/100*S/p:0):(latest?latest.k401_you:0);
    const rem=isPast?0:(isFuture?(cal?cal.length:p):remaining);
    const proj=Y+pace*(rem||0);
    const room=L==null?null:Math.max(0,L-Y);
    const needPP=room!=null&&rem?room/rem:null;
    const grossPP=b0.per_paycheck||(S&&p?S/p:null);
    const qs=[1,2,3,4].map(q=>{const m0=(q-1)*3+1,m1=q*3;const inQ=stubs.filter(s=>{const m=+s.pay_date.slice(5,7);return m>=m0&&m<=m1;});
      const qStart=y+'-'+String(m0).padStart(2,'0')+'-01';const qEnd=y+'-'+String(m1).padStart(2,'0')+'-'+lastDay(y,m1);
      const state=qEnd<nowS?'past':qStart>nowS?'future':'current';
      const grossQ=inQ.reduce((s,x)=>s+x.gross,0);const calQ=cal?cal.filter(d=>d>=qStart&&d<=qEnd).length:null;
      return {q,target:L==null?null:L/4,actual:inQ.reduce((s,x)=>s+(x.k401_you||0),0),stubs:inQ.length,state,chosen_marker:chosen==null?null:(state==='future'?(S?chosen/100*S/4:null):chosen/100*grossQ),paychecks_in_calendar:calQ};});
    const tryRate=chosen==null?6:null;
    const rate=chosen!=null?chosen:tryRate;
    const capPct=L&&S?L/S*100:null;
    const todayPct=latest&&latest.gross?latest.k401_you/latest.gross*100:null;
    return {year:y,limit:L,limit_row:row?{year:row.year,source:row.source,url:row.url,as_of_checked:row.as_of_checked,status:row.status}:null,estimate:est,catchup:ageEnd!=null&&ageEnd>=50,
      ytd:Y,ytd_column:ytdCol,ytd_tie:ytdCol==null?null:Math.abs(ytdCol-Y)<0.01,stubs:stubs.length,remaining_paychecks:rem,calendar_known:!!cal,pace_pp:pace,projected:proj,room,need_pp:needPP,need_pct_pp:needPP!=null&&grossPP?needPP/grossPP*100:null,
      status:L==null?'needs':rem===0?(Y>=L?'reached':'closed'):proj>=L?'on_track':'behind',short_by:L==null?null:Math.max(0,L-proj),quarters:qs,
      chosen_pct:chosen,try_rate:tryRate,rate_used:rate,rate_annual:rate!=null&&S?rate/100*S:null,rate_pp:rate!=null&&S&&p?rate/100*S/p:null,rate_vs_limit:rate!=null&&S&&L?rate/100*S/L*100:null,over_cap:rate!=null&&capPct!=null&&rate>capPct,
      cap_pct:capPct,today_pct:todayPct,plan_row:pr,past:isPast,future:isFuture};});
  return res;
 }}));

dash.calc('milestones_calc',CR("milestones_calc",{title:'Milestones',description:'Derived from facts already in the datasets: per debt 25, 50, 75 percent paid and paid off against its original balance; emergency fund 0.5, 1, 2, 3 and 6 months; net worth crossing each 50,000. A stored milestone keeps its first-seen date; one whose condition is no longer true is shown as retracted, never deleted.',inputs:['liabilities','networth_history','scores_calc'],
 fn:(liab,nwh,sc)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const out=[];
  liab.forEach(l=>{if(!l.original_balance||l.balance==null)return;const paid=1-l.balance/l.original_balance;
    [[0.25,'25 percent paid'],[0.5,'Half paid'],[0.75,'75 percent paid'],[1,'Paid off']].forEach(([f,t])=>{if(paid>=f-1e-9&&(f<1||l.balance===0))out.push({milestone_id:'debt_'+l.liability_id+'_'+Math.round(f*100),family:'debt_pct',subject:l.name,step:t,value_at:l.balance,evidence_dataset:'liabilities',evidence_id:l.liability_id,direction:'down',note:'Balance '+l.balance.toLocaleString('en-US',{minimumFractionDigits:2})+' of an original '+l.original_balance.toLocaleString('en-US',{minimumFractionDigits:2})});});});
  const em=sc&&sc[0]?sc[0].metrics.emergency_months:null;
  if(em!=null)[0.5,1,2,3,6].forEach(s=>{if(em>=s)out.push({milestone_id:'ef_'+s,family:'emergency_months',subject:'Emergency fund',step:s+(s===1?' month':' months'),value_at:Math.round(em*100)/100,evidence_dataset:'assets_other',evidence_id:'liquid cash',direction:'up',note:'Liquid cash covers '+(Math.round(em*100)/100)+' months of essentials'});});
  const last=nwh.length?[...nwh].sort((a,b)=>a.date<b.date?-1:1).pop():null;
  if(last&&last.net_worth>0){const top=Math.floor(last.net_worth/50000)*50000;if(top>0)out.push({milestone_id:'nw_'+top,family:'net_worth',subject:'Net worth',step:'Crossed '+top.toLocaleString('en-US'),value_at:last.net_worth,evidence_dataset:'networth_history',evidence_id:last.date,direction:'up',note:'Market moves and paychecks both count; noted, not celebrated'});}
  out.forEach(m=>{m.status='earned';});
  return out;
 }}));

dash.calc('coverage_calc',CR("coverage_calc",{title:'Coverage rings',description:'Picture: core datasets with a row fresher than 45 days (or undated rows present) over core datasets. Scores: weight of score components with data over total weight, averaged over both scores. Explained: known outflows over known outflows plus unexplained drift in the check windows; no check yet below one check point.',inputs:['scores_calc','drift_all','income_pay','paystubs','contributions','retirement_plan','assumptions','liabilities','assets_other','bills','balance_log','cash_events','networth_history','holding_snapshots'],
 fn:(sc,dr,inc,ps,ct,rp,ap,li,ao,bi,bl,ce,nwh,hs)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const core=[['income_pay',inc,null],['paystubs',ps,'pay_date'],['contributions',ct,null],['retirement_plan',rp,null],['assumptions',ap,null],['liabilities',li,'as_of_date'],['assets_other',ao,'as_of_date'],['bills',bi,null],['balance_log',bl,'date'],['cash_events',ce,'date'],['networth_history',nwh,'date'],['holding_snapshots',hs,'snapshot_date']];
  const age=d=>Math.round((Date.parse(T0)-Date.parse(d))/864e5);
  const pic=core.map(([id,rows,f])=>{const has=rows&&rows.length>0;const newest=has&&f?rows.map(r=>r[f]).filter(v=>/^\d{4}-\d\d-\d\d$/.test(v||'')).sort().pop():null;const fresh=has&&(!f||(newest&&age(newest)<=45));return {id,has,newest,fresh,age_days:newest?age(newest):null};});
  const have=pic.filter(p=>p.fresh).length;
  const S=sc[0];const sw=[S.financial,S.risk];const scHave=sw.reduce((s,x)=>s+x.weight_with_data,0),scTot=sw.reduce((s,x)=>s+x.weight_total,0);
  const D=dr[0];
  return [{date:T0,picture_pct:have/core.length*100,picture_have:have,picture_total:core.length,picture:pic,
    scores_pct:S.financial.weight_total&&S.risk.weight_total?(S.financial.weight_with_data/S.financial.weight_total*100+S.risk.weight_with_data/S.risk.weight_total*100)/2:null,scores_weight_have:scHave,scores_weight_total:scTot,
    explained_pct:D.check_points>=1?D.explained_pct:null,explained_checks:D.check_points,unexplained:D.unexplained_total,known_outflow:D.known_outflow,
    missing:pic.filter(p=>!p.fresh).map(p=>p.id).concat(sw.flatMap(s=>s.rows.filter(r=>r.points==null).map(r=>r.id)))}];
 }}));

dash.calc('checks_calc',CR("checks_calc",{title:'Correlation checks',description:'The checks the page can run on its own data, numbered as in the architecture register: C1 net worth identity, C2 holdings sum, C3 retirement start, C4 stub arithmetic, C5 stub to contributions, C6 stub to income, C7 stub to cash, C9 DTI inputs, C10 LTV inputs, C11 bills to cash, C12 drift identity, C13 goals, C14 dates, C15 dataset privacy and dashes, C16 reward rows, C17 payoff simulation, C18 benchmark rows, C19 score inputs, C21 plan-year tile, C22 mortgage to statement, C23 Form 1098 to statements, C24 statement requests in sync. C8 (card to liability) runs at ingestion, not on the page. Status is pass, needs (data missing, no number is guessed) or fail.',inputs:['nw_rows','networth_history','retire_model','paystubs','contributions','income_pay','liabilities','assets_other','data_queue','drift_calc','drift_all','goals_calc','home_calc','payoff_engine','age_calc','scores_calc','plan_year_calc','scores_config','cash_events','balance_log','bills','mortgage_statements','acct_a_holdings','holding_snapshots','acct_a_sources','milestones','statement_sync_calc'],
 fn:(nw,nwh,rm,ps,ct,inc,li,ao,dq,dc,da,gc,hc,pe,ag,sc,py,cfgIn,ce,bl,bi,ms,nbh,hs,nbs,mi,ss)=>{
  const out=[];const add=(id,name,status,detail,blocks)=>out.push({id,name,status,detail,blocks:!!blocks});
  const sum=(a,f)=>a.reduce((s,x)=>s+(f(x)||0),0);const near=(a,b,t)=>Math.abs(a-b)<=(t||0.01);
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const nwv=(nw.find(r=>r.item==='Net worth')||{}).amount;nwh=nwh.filter(r=>r.date!=null);const last=nwh.length?[...nwh].sort((a,b)=>a.date<b.date?-1:1).pop():null;
  const parts=sum(nw.filter(r=>r.item!=='Net worth'),r=>r.amount);
  add('C1','Net worth identity',near(parts,nwv)&&(!last||near(last.net_worth,nwv))?'pass':'fail','Items sum to '+parts.toFixed(2)+'; net worth '+(nwv!=null?nwv.toFixed(2):'n/a')+(last&&last.net_worth!=null?'; history '+last.net_worth.toFixed(2):''),true);
  {const a=sum(nbh,h=>h.value);const sd=hs.length?hs.reduce((m,h)=>h.snapshot_date>m?h.snapshot_date:m,''):null;const b=sum(hs.filter(h=>h.snapshot_date===sd),h=>h.value);const c=sum(nbs,x=>x.balance);
    add('C2','Holdings sum',nbh.length&&hs.length&&nbs.length?(near(a,b)&&near(a,c)?'pass':'fail'):'needs',nbh.length?'Holdings '+a.toFixed(2)+'; snapshots of '+sd+' '+b.toFixed(2)+'; sources '+c.toFixed(2):'Needs: a holdings export');}
  const retNW=(nw.find(r=>r.item==='Retirement accounts')||{}).amount;add('C3','Retirement start balance',rm[0]&&near(rm[0].start,retNW)?'pass':'fail','Model start '+(rm[0]?rm[0].start.toFixed(2):'n/a')+' vs net worth retirement '+(retNW!=null?retNW.toFixed(2):'n/a'),true);
  let bad4=0;ps.forEach(s=>{const t=(s.federal_tax||0)+(s.state_tax||0)+(s.fica||0);const n=s.gross-s.taxes-(s.k401_you||0)-(s.hsa_you||0)-(s.benefits||0)-(s.garnishment||0)-(s.other_deductions||0)+(s.other_additions||0);if(!near(t,s.taxes)||!near(n,s.net_pay))bad4++;});
  add('C4','Stub arithmetic',bad4?'fail':'pass',(ps.length-bad4)+' of '+ps.length+' stubs tie out (net pay and taxes)',true);
  const st=ps.length?[...ps].sort((a,b)=>a.pay_date<b.pay_date?-1:1).pop():null;const b0=inc.find(i=>i.kind==='Base');
  if(st&&b0){const k=ct.find(c=>/401/.test(c.account)),h=ct.find(c=>/HSA/.test(c.account));const r=[];let ok=true;
    if(k){const e=st.k401_you*b0.paychecks_per_year;r.push('401(k) '+e+' vs '+k.employee_annual);ok=ok&&near(e,k.employee_annual);}
    if(h){const e=st.hsa_you*b0.paychecks_per_year;r.push('HSA '+e+' vs '+h.employee_annual);ok=ok&&near(e,h.employee_annual);}
    add('C5','Stub to contributions',ok?'pass':'fail',r.join('; '));
    const e6=b0.per_paycheck*b0.paychecks_per_year;add('C6','Stub to income',Math.abs(e6-b0.annual_gross)/b0.annual_gross<=0.03?'pass':'fail',b0.per_paycheck+' x '+b0.paychecks_per_year+' = '+e6+' vs '+b0.annual_gross);}
  else add('C5','Stub to contributions','needs','Needs: pay stubs and income');
  const dep=ps.filter(s=>ce.some(e=>e.kind==='pay_deposit'&&e.date===s.pay_date&&near(e.amount,s.net_pay))).length;
  add('C7','Stub to cash',dep===ps.length?'pass':'needs',dep+' of '+ps.length+' stubs have a matching deposit; older deposits need bank statements');
  const miss=li.filter(l=>l.counts_in_dti==='Y'&&l.monthly_payment==null);const unq=miss.filter(l=>!dq.some(q=>(q.status==='Needed'||q.status==='Statement requested')&&q.item.toLowerCase().includes(l.name.split(' ')[0].toLowerCase())));
  add('C9','DTI inputs',unq.length?'fail':miss.length?'needs':'pass',miss.length?miss.map(l=>l.name).join(', ')+' has no minimum'+(unq.length?' and no data request':'; a data request exists'):'Every debt in the ratio has a payment',unq.length>0);
  {const m=li.find(l=>l.type==='Mortgage');const st=(ms||[]).filter(x=>x.kind!=='annual_form_1098'&&x.statement_date).sort((a,b)=>a.statement_date<b.statement_date?-1:1).pop();
    if(m&&st){const rep=m.value_basis==='expected'&&m.reported_balance!=null?m.reported_balance:m.balance;const ex=cellObj(st.expected_after_next_payment)||null;
      const ok=near(rep,st.principal_balance)&&(m.value_basis!=='expected'||(ex&&near(m.balance,ex.expected_principal_balance!=null?ex.expected_principal_balance:ex.expected_balance))||!ex);
      add('C22','Mortgage to statement',ok?'pass':'fail','Reported '+rep.toFixed(2)+' vs statement of '+st.statement_date+' '+st.principal_balance.toFixed(2)+(m.value_basis==='expected'?'; shown balance '+m.balance.toFixed(2)+' is expected after confirmed payments'+(ex?' and matches the statement schedule':''):''));}
    else add('C22','Mortgage to statement','needs','Needs: a mortgage statement');}
  {const f=(ms||[]).filter(x=>x.kind==='annual_form_1098').sort((a,b)=>a.tax_year-b.tax_year).pop();const pm=[];(ms||[]).forEach(x=>(cellObj(x.activity)||[]).forEach(a=>{if(/PMI/.test(a.type))pm.push(a.amount);}));
    if(!f)add('C23','Form 1098 to statements','needs','Needs: a Form 1098 row');
    else{const ok=near(f.pmi_monthly,f.pmi_paid/12)&&near(f.property_tax_monthly,f.property_taxes_paid/12)&&pm.every(v=>near(v,f.pmi_monthly));
      add('C23','Form 1098 to statements',ok?'pass':'fail','Form 1098 '+f.tax_year+': PMI '+f.pmi_paid.toFixed(2)+' a year = '+f.pmi_monthly.toFixed(2)+' a month; '+pm.length+' statement PMI disbursements '+(pm.every(v=>near(v,f.pmi_monthly))?'match':'differ')+'; property tax '+f.property_tax_monthly.toFixed(2)+' a month');}}
  add('C10','LTV inputs',hc[0]&&hc[0].value&&hc[0].ltv_pct!=null?'pass':'needs',hc[0]?'Home value '+hc[0].value+', liens '+hc[0].balance:'Needs: home value and liens',true);
  let bad12=0,n12=0;dc.forEach(p=>{if(p.status==='ok'){n12++;if(!near(p.expected,p.opening+p.inflows-p.outflows)||!near(p.drift,p.reported-p.expected))bad12++;}});
  da[0].accounts.forEach(a=>a.points.forEach(p=>{if(p.drift!=null){n12++;if(!near(p.drift,p.reported-p.expected))bad12++;}}));
  {const rb=ce.filter(e=>e.recurring==='Y'&&e.kind!=='pay_deposit'&&(e.counts_as_spend==='Y'||/bill/i.test(evLabel(e))));
    add('C11','Bills to cash',rb.length?'pass':'needs',rb.length?rb.length+' recurring bill payments found in cash events':'Needs: bill payments in the cash events (from bank statements)');}
  add('C12','Drift identity',bad12?'fail':'pass',n12+' check periods recomputed');
  add('C13','Goals',gc[0]&&gc[0].kind==='summary'&&!(gc[0].saved_needs||[]).length?'pass':'needs',gc[0]&&gc[0].count?gc[0].count+' goals':'No savings goals yet');
  const fut=[];li.forEach(l=>{if(l.as_of_date>T0)fut.push(l.name);});ao.forEach(a=>{if(a.as_of_date>T0)fut.push(a.name);});bl.forEach(b=>{if(b.date>T0)fut.push(b.log_id);});ps.forEach(s=>{if(s.pay_date>T0)fut.push(s.pay_date);});
  add('C14','Dates',fut.length?'fail':'pass',fut.length?'Future dates: '+fut.join(', '):'No as-of date after today');
  const blob=JSON.stringify([li,ao,bl,ce,ps,inc,ct,dq,bi]);const dash_=/[\u2013\u2014]/.test(blob);const acct=/\b\d{9,17}\b/.test(blob.replace(/\d{4}-\d{2}-\d{2}/g,''));
  add('C15','Dashes and privacy (datasets)',dash_||acct?'fail':'pass',(dash_?'dash characters found. ':'')+(acct?'a long digit run that looks like an account number. ':'')+(!dash_&&!acct?'No dash characters or account-number-like digits':''));
  {const badm=mi.filter(m=>/\d{8,}/.test(JSON.stringify(m))||!m.evidence_dataset);add('C16','Reward rows',badm.length?'fail':'pass',badm.length?badm.map(m=>m.milestone_id).join(', ')+' needs a dataset reference without long digit runs':mi.length+' milestone rows reference a dataset and hold no long digit runs');}
  const c17=pe[0].c17;const f17=c17.filter(c=>!c.balance_identity||c.over_budget_months||c.below_min);const flag=c17.filter(c=>!c.ends_at_zero);
  add('C17','Payoff simulation',f17.length?'fail':flag.length?'needs':'pass',f17.length?'Identity or budget broken in '+f17.map(c=>c.plan).join(', '):flag.length?flag.map(c=>c.plan+': '+c.flag).join('; '):'Every plan ends at zero, totals tie within a cent');
  const A=ag[0];const rowsOk=(A.metrics||[]).every(m=>['guideline','typical','rank'].every(f=>{const x=m[f];return x.pct!=null||x.percentile!=null||x.needs||x.text;}));
  add('C18','Benchmark rows',rowsOk?'pass':'fail',(A.rows_used||[]).length+' benchmark rows used, each with source and data year');
  const CFG=parseRow((Array.isArray(cfgIn)?cfgIn[0]:cfgIn)||{},['reweight','trend','inputs','financial','risk']);const w=['financial','risk'].map(k=>sum(CFG[k]&&CFG[k].components||[],c=>c.weight));
  add('C19','Score inputs',w.every(x=>x>0)&&w[0]===100?'pass':'fail','Weights '+w.join(' and ')+'; Financial '+sc[0].financial.n+' of '+sc[0].financial.M+', Risk '+sc[0].risk.n+' of '+sc[0].risk.M);
  const y=py.find(r=>r.year===+T0.slice(0,4));
  if(y){const st21=!y.limit_row?'fail':y.estimate?'needs':y.ytd_tie===false?'fail':!y.calendar_known?'needs':'pass';
    add('C21','Plan-year tile',st21,(y.limit_row?'Limit row '+y.limit_row.year+(y.estimate?' (estimate)':''):'No limit row')+'; '+(y.ytd_column==null?'no year to date column on the stubs to tie':'year to date ties')+'; '+(y.calendar_known?y.remaining_paychecks+' paychecks left from the pay calendar':'Needs: pay dates'));}
  {const x=ss[0];add('C24','Statement requests in sync',x.ok?'pass':'fail',x.ok?x.pairs+' statement request'+(x.pairs===1?'':'s')+', each with its open task':x.issues.join('; '));}
  return out;
 }}));

dash.calc('next_move',CR("next_move",{title:'Next best move',description:'One move, ranked: (a) a failed check that blocks a core number; (b) the open task that unlocks the most score weight per unit of effort (effort not set counts as 1); (c) the first debt in the payoff plan when the surplus is positive; (d) the oldest stale core dataset; (e) nothing urgent.',inputs:['checks_calc','tasks','scores_calc','payoff_engine','coverage_calc'],
 fn:(ck,tk,sc,pe,cv)=>{
  const f=ck.filter(c=>c.status==='fail'&&c.blocks);
  if(f.length)return [{kind:'check',label:'Fix a broken check',text:'Fix '+f[0].id+' '+f[0].name.toLowerCase()+'.',why:f[0].detail,effort:null,task_id:null}];
  const S=sc[0];const W={};[S.financial,S.risk].forEach(s=>s.rows.forEach(r=>{W[r.id]={weight:r.points==null?r.weight:0,name:r.name,score:s.title};}));
  const eff={Low:1,Medium:2,High:3};
  const cand=tk.filter(t=>t.status!=='Done'&&t.metric&&W[t.metric]&&W[t.metric].weight>0).map(t=>({t,w:W[t.metric].weight,e:eff[t.effort]||1})).sort((a,b)=>b.w/b.e-a.w/a.e);
  const others=cand.slice(1,4).map(c=>({id:c.t.id,task:c.t.task,area:c.t.area,unlocks:c.w,component:W[c.t.metric].name}));
  if(cand.length){const c=cand[0];return [{kind:'task',label:'Next best move',text:c.t.task,why:'Unlocks '+W[c.t.metric].name+' ('+c.w+' of 100 '+W[c.t.metric].score+' weight), so the score no longer leaves it out.',effort:c.t.effort||'not set',task_id:c.t.id,area:c.t.area,others}];}
  const P=pe[0];if(P.surplus>0&&P.plans.smart.first_order.length){const d=P.debts[P.plans.smart.first_order[0]];return [{kind:'debt',label:'Next best move',text:'Put the extra toward '+d.name+'.',why:'It is first in the payoff plan.',effort:null,task_id:null,others:[]}];}
  const stale=cv[0].picture.filter(p=>!p.fresh);if(stale.length)return [{kind:'stale',label:'Next best move',text:'Update '+stale[0].id.replace(/_/g,' ')+'.',why:'It is the oldest core data.',effort:null,task_id:null,others:[]}];
  return [{kind:'none',label:'Next best move',text:'Nothing urgent.',why:'Every check passes and no task unlocks a score part.',effort:null,task_id:null,others:[]}];
 }}));

