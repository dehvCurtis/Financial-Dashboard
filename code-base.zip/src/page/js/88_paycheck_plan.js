/* ---------- Paycheck plan (S6a) ----------
   What to pay from each upcoming paycheck. Every row comes from the user's own data: pay dates from income_pay (pay_schedule, first_pay_date,
   optional pay_days text), take-home from the latest stub, due items from each debt's next due date or due day and each bill's due day, the extra from
   payoff_engine. No vendor, debt or bill is named here. A dated item belongs to the latest paycheck on or before its due date, so it is assigned to
   exactly one paycheck; an item due before the first paycheck is paid from cash on hand and listed apart. Spending lines and items with no due day
   are set aside evenly per paycheck (monthly amount x 12 / paychecks per year) and the missing due days are a Needs line. */
const PP_COUNT=3;
const PP_WD=d=>['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][new Date(d+'T12:00:00Z').getUTCDay()];
const PP_LAST=(y,m)=>new Date(Date.UTC(y,m,0)).getUTCDate();
const PP_P2=n=>String(n).padStart(2,'0');
const PP_R2=x=>Math.round(x*100)/100;
/* a weekend pay date moves to the Friday before it */
function PP_BIZ(d){const w=new Date(d+'T12:00:00Z').getUTCDay();return w===6?V3_DAY(d,-1):w===0?V3_DAY(d,-2):d;}
/* the dates of one monthly rhythm (day numbers, 0 = last day) from a month before "from" for six months */
function PP_MONTHLY(days,from){const out=[];let y=+from.slice(0,4),m=+from.slice(5,7)-1;if(m<1){m=12;y--;}
  for(let n=0;n<8;n++){days.forEach(d=>{const last=PP_LAST(y,m);out.push(PP_BIZ(y+'-'+PP_P2(m)+'-'+PP_P2(d===0?last:Math.min(d,last))));});m++;if(m>12){m=1;y++;}}
  return out;}
/* the first "count" pay dates on or after "from"; null when the pay schedule is not enough to say */
function PP_PAYDATES(row,from,count){if(!row)return null;const s=String(row.pay_schedule||'').toLowerCase();const f=row.first_pay_date||null;
  const pd=row.pay_days?String(row.pay_days).split(/[,\s]+/).map(x=>/^last$/i.test(x)?0:parseInt(x,10)).filter(x=>x>=0&&x<=31):null;let all=null;
  if(/semi|twice/.test(s))all=PP_MONTHLY(pd&&pd.length?pd:[15,0],from);
  else if(/month/.test(s)){const d=pd&&pd.length?pd:(f?[+f.slice(8,10)]:null);if(d)all=PP_MONTHLY(d,from);}
  else if(/week|every/.test(s)&&f){const step=/bi|two|2|fortnight|other/.test(s)?14:7;let d=f;if(d<from)d=V3_DAY(d,Math.ceil((Date.parse(from)-Date.parse(d))/864e5/step)*step);all=[];for(let n=0;n<count+1;n++)all.push(V3_DAY(d,n*step));}
  if(!all)return null;const u=[...new Set(all)].filter(d=>d>=from).sort();return u.length>=count?u.slice(0,count):null;}
/* monthly repeats of a due date (same day each month, clamped to the month end) up to "end"; dd 0 = this date only */
function PP_OCC(first,dd,end){const out=[];let d=first,y=+first.slice(0,4),m=+first.slice(5,7);
  for(let n=0;n<24&&d&&d<=end;n++){out.push(d);if(!dd)break;m++;if(m>12){m=1;y++;}d=y+'-'+PP_P2(m)+'-'+PP_P2(Math.min(dd,PP_LAST(y,m)));}
  return out;}
dash.calc('paycheck_plan',CR("paycheck_plan",{title:'Paycheck plan',description:'What to pay from each of the next three paychecks. Pay dates come from the base income row (pay_schedule, first_pay_date, optional pay_days as text such as "10, last"; a weekend date moves to the Friday before), take-home from the latest stub. A bill or debt payment due on a date belongs to the latest paycheck on or before that date, so each is assigned to exactly one paycheck; one due before the first paycheck is listed apart as paid from cash on hand. Debt amounts are the minimums the payoff plan uses. Then the monthly extra of the payoff plan, divided by paychecks per year, goes to the debts the plan puts it on; an extra that does not fit this paycheck moves to the next one. Spending lines and items with no due day are set aside evenly. What is left is yours to keep. Missing pay dates or due days are Needs.',inputs:['payoff_engine','liabilities','bills','income_pay','paystubs'],
 fn:(pe,liab,bills,inc,ps)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);const P=pe[0];
  const b0=realRows(inc).find(i=>i.kind==='Base')||null;const st=realRows(ps).sort((a,b)=>a.pay_date<b.pay_date?-1:1).pop()||null;
  const take=st&&st.take_home_core!=null?st.take_home_core:null;const ppy=b0&&b0.paychecks_per_year>0?b0.paychecks_per_year:null;
  const dates=b0?PP_PAYDATES(b0,T0,PP_COUNT+1):null;
  const miss=[];if(take==null)miss.push('a pay stub');if(ppy==null)miss.push('paychecks per year');if(!dates)miss.push('how often you are paid and a first pay date');
  if(!P||miss.length)return [{needs:'Needs: '+(miss.length?miss.join(', '):'debts, bills and a pay stub'),needs_pay:dates?null:'how often you are paid and a first pay date'}];
  const edges=dates.slice(0,PP_COUNT+1),end=V3_DAY(edges[PP_COUNT],-1);
  const items=[],reserve=[];const mins=id=>P.mins_rows.find(m=>m.id===id);
  realRows(liab).forEach(l=>{if(l.type==='Support'||!l.balance)return;const m=mins(l.liability_id);if(!m||!(m.min>0))return;
    const late=l.days_past_due>0;let due=late?T0:(l.next_due_date||l.next_due||null);if((!due||due<T0)&&!late&&l.due_day)due=nextDueDay(l.due_day,l.last_paid,T0);
    if(!due||due<T0&&!late){reserve.push({id:l.liability_id,name:l.name,kind:'debt',monthly:m.min,undated:true});return;}
    const dd=l.due_day?+l.due_day:l.next_due_date?+l.next_due_date.slice(8,10):late?0:+due.slice(8,10);
    PP_OCC(due,dd,end).forEach(d=>items.push({id:l.liability_id,name:l.name,kind:'debt',date:d,amount:m.min,est:!!m.est,late:late&&d===due,paid_from:l.paid_from||null}));});
  realRows(bills).forEach(b=>{if(!(b.monthly_amount>0)||b.paid_by_liability_id!=null)return;
    if(b.kind==='spending'){reserve.push({id:b.bill_id,name:b.name,kind:'spending',monthly:b.monthly_amount,undated:false});return;}
    if(b.shutoff_amount>0&&b.shutoff_deadline>=T0&&b.shutoff_deadline<=end)items.push({id:b.bill_id,name:b.name+' (shut-off notice)',kind:'bill',date:b.shutoff_deadline,amount:b.shutoff_amount,est:false,late:true,shutoff:true,paid_from:b.paid_from||null});/* a utility shut-off notice: the past due part is its own item on its deadline; the next regular item is the new charges */
    const d=nextDueDay(b.due_day,b.last_paid,T0);if(!d){reserve.push({id:b.bill_id,name:b.name,kind:'bill',monthly:b.monthly_amount,undated:true});return;}
    PP_OCC(d,+b.due_day,end).forEach(x=>items.push({id:b.bill_id,name:b.name,kind:'bill',date:x,amount:(x===b.next_due&&b.new_charges>0?b.new_charges:b.monthly_amount),est:false,late:false,paid_from:b.paid_from||null}));});
  items.sort((a,b)=>a.date<b.date?-1:a.date>b.date?1:a.name<b.name?-1:a.name>b.name?1:0);
  const slot=d=>{let k=-1;for(let i=0;i<PP_COUNT;i++)if(edges[i]<=d)k=i;return k;};
  const sum=(a,f)=>PP_R2(a.reduce((s,x)=>s+f(x),0));
  const res=reserve.map(r=>({id:r.id,name:r.name,kind:r.kind,monthly:r.monthly,per_paycheck:PP_R2(r.monthly*12/ppy),undated:r.undated}));const resTotal=sum(res,r=>r.per_paycheck);
  /* the extra: the payoff plan's first month above each minimum gives the split between debts */
  const E=P.extra>0?P.extra:0;const Epp=PP_R2(E*12/ppy);let split=[];
  if(E>0&&P.debts.length){const s0=PAYOFF_SIM(P.debts,E,P.strategy,P.start,{stopAt:1}).schedule[0];
    const w=P.debts.map((d,i)=>({id:d.id,name:d.name,w:Math.max(0,s0.pay[i]-Math.min(d.min,s0.pay[i]))})).filter(x=>x.w>0.004);const wt=w.reduce((s,x)=>s+x.w,0);split=wt>0?w.map(x=>({id:x.id,name:x.name,share:x.w/wt})):[];}
  let carry=0;
  const paychecks=edges.slice(0,PP_COUNT).map((date,k)=>{const due=items.filter(x=>slot(x.date)===k);const dueTotal=sum(due,x=>x.amount);
    const room=Math.max(0,PP_R2(take-dueTotal-resTotal));const target=PP_R2(Epp+carry);const got=split.length?Math.min(target,room):0;carry=split.length?PP_R2(target-got):0;
    let left=got;const extra=split.map((s,i)=>{const a=i===split.length-1?PP_R2(left):PP_R2(got*s.share);left=PP_R2(left-a);return {id:s.id,name:s.name,amount:a};}).filter(x=>x.amount>0);
    const exTotal=sum(extra,x=>x.amount);const keep=PP_R2(take-dueTotal-resTotal-exTotal);
    return {n:k+1,date,next_date:edges[k+1],take_home:take,items:due,due_total:dueTotal,reserve_total:resTotal,extra,extra_total:exTotal,keep,short:keep<0?-keep:0};});
  const before=items.filter(x=>slot(x.date)<0);
  const names=res.filter(r=>r.undated).map(r=>r.name);
  return [{as_of:T0,take_home:take,per_year:ppy,schedule:b0.pay_schedule,strategy:P.strategy,extra_month:E,extra_per_paycheck:Epp,extra_unplaced:carry,edges,horizon_end:end,
    before:{items:before,total:sum(before,x=>x.amount)},paychecks,reserve:res,reserve_per_paycheck:resTotal,undated_names:names,needs:null,needs_pay:null,
    next:{date:paychecks[0].date,pay:PP_R2(paychecks[0].due_total+paychecks[0].extra_total),keep:paychecks[0].keep,short:paychecks[0].short}}];
 }}));
/* ---- draw: the Debt page section and the Home row ---- */
const ppLabel=d=>PP_WD(d)+' '+fd(d);
function drawPaycheckPlan(){const box=$('pp-plan');if(!box)return;aboutSync();box.replaceChildren(el('h2',null,'Paycheck plan'));const R=one('paycheck_plan');
  if(!R){box.append(needsEl(calcWhy(['paycheck_plan'],'Needs: a pay schedule and a pay stub')));return;}
  if(R.needs){box.append(needsEl(R.needs));if(R.needs_pay)box.append(el('p','mo-note','Ask in Claude: how often are you paid, and on which date was your first paycheck? It is listed under Data to send in Tasks.'));return;}
  const N=R.next,P0=R.paychecks[0];
  const tl=el('div','mo-tiles');tl.id='pp-tiles';box.append(tl);
  tiles(tl,[{label:'Pay from the '+ppLabel(N.date)+' paycheck',value:money2(N.pay),sub:'Due '+money2(P0.due_total)+(P0.extra_total?', extra '+money2(P0.extra_total):'')},
    {label:'Left to keep',value:money2(N.keep),sub:R.reserve_per_paycheck?'After '+money2(R.reserve_per_paycheck)+' set aside':''}]);
  srcTip(tl.querySelector('.mo-tv'),'Source: the paycheck plan, from the latest pay stub and each due date. Details in About this');
  /* warnings and decisions stay on the card */
  const ch=el('div','mx-chips');
  if(R.before.items.length){const bad=R.before.items.some(x=>x.late||x.shutoff);ch.append(aboutChip('Due before the next paycheck '+money2(R.before.total),bad?'bad':'warn'));}
  R.paychecks.forEach(c=>{if(c.short>0)ch.append(aboutChip('Short by '+money2(c.short)+' on '+ppLabel(c.date),'bad'));});
  if(R.paychecks.some(c=>c.items.some(x=>x.est)))ch.append(aboutChip('Minimum estimated','warn'));
  if(ch.children.length)box.append(ch);
  if(R.undated_names.length)box.append(el('p','mo-needs mo-note','Needs: the due day of '+R.undated_names.join(', ')+'. Each is listed under Data to send in Tasks.'));
  const ab=[];
  ab.push('Each paycheck pays what is due before the next one, then the extra from your payoff plan. Spending and bills with no due day are set aside; the rest is yours to keep. A planning tool, not advice.');
  if(R.before.items.length){const w=el('div');w.append(el('h3',null,'Due before the next paycheck'));
    w.append(v3kv(R.before.items.map(x=>({k:x.name,s:x.shutoff?'shut-off notice, pay by '+fd(x.date):x.late?'past due':fd(x.date)+' (pay from cash on hand)',v:money2(x.amount),cls:x.late?'bad':null})).concat([{k:'Total',v:money2(R.before.total),t:true}])));ab.push(w);}
  R.paychecks.forEach((c,i)=>{
    const kv=c.items.map(x=>({k:x.name,s:fd(x.date)+(x.est?', minimum estimated':'')+(x.paid_from?', last paid from '+x.paid_from:''),v:money2(x.amount)}));
    if(!c.items.length)kv.push({k:'Nothing with a due date',s:'before '+fd(c.next_date),v:money2(0)});
    c.extra.forEach(x=>kv.push({k:'Extra to '+x.name,s:'above its minimum, from the payoff plan',v:money2(x.amount)}));
    if(c.reserve_total)kv.push({k:'Set aside',s:'spending and bills with no due day',v:money2(c.reserve_total)});
    kv.push({k:c.short?'Short by':'Left to keep',s:c.short?'bills take more than this paycheck':'take-home '+money2(c.take_home),v:money2(c.short?c.short:c.keep),t:true,cls:c.short?'bad':null});
    const body=el('div');body.append(v3kv(kv));
    if(i===0){const w=el('div');w.append(el('h3',null,ppLabel(c.date)+' paycheck'),body);ab.push(w);}
    else{const f=fold(ppLabel(c.date)+': pay '+money2(c.due_total+c.extra_total)+', keep '+money2(c.keep),body,false);f.id='pp-c'+(i+1);ab.push(f);}});
  if(R.extra_unplaced>0.004)ab.push('About '+money2(R.extra_unplaced)+' of the extra does not fit these three paychecks; it moves on to the next one.');
  const rl=el('div');rl.append(v3kv(R.reserve.map(r=>({k:r.name,s:r.undated?'due day needed':r.kind==='spending'?'spending line':'bill',v:money2(r.per_paycheck)}))));
  if(R.reserve.length)ab.push(fold('What is set aside each paycheck',rl,false));
  ab.push(el('p','mx-src','Pay dates: '+R.schedule+', a weekend date moves to the Friday before. Due dates through '+fd(R.horizon_end)+'. The extra is '+money2(R.extra_month)+' a month, '+money2(R.extra_per_paycheck)+' a paycheck, from the payoff plan.'));
  box.append(aboutFold('pp',ab));}
