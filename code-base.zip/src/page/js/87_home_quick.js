/* ---------- Home quick look (S5a) ----------
   Collapsible sections: the weekly check-in and Needs attention are closed by default. The header is a button (aria-expanded,
   aria-controls) that always shows the title and the count or status, so nothing is hidden silently. Open or closed is remembered per
   viewer in localStorage when it works (a private window or blocked storage gives closed every time). A link, deep link, Back chip or
   goTo that targets something inside a closed section opens it first (collReveal). Opened by a link, a section stays open for the
   visit but the remembered choice is the viewer's own. */
const COLL_KEY='moc.coll.';const COLL={};
function collState(k){if(!(k in COLL)){let v=false;try{v=localStorage.getItem(COLL_KEY+k)==='1';}catch(e){v=false;}COLL[k]=v;}return COLL[k];}
function collSet(box,open,save){const b=box.querySelector(':scope > .mo-collh > .mo-collbtn'),body=box.querySelector(':scope > .mo-collbody');if(!b||!body)return;
  b.setAttribute('aria-expanded',String(open));body.hidden=!open;box.classList.toggle('open',open);const k=box.dataset.coll;if(!k)return;COLL[k]=open;
  if(save){try{localStorage.setItem(COLL_KEY+k,open?'1':'0');}catch(e){}}}
/* make box a collapsible section (once), then set its header: the title and a status chip (a count, a state or a Needs line) */
function collapsible(box,title,status,kind,tip){if(!box)return;let body=box.querySelector(':scope > .mo-collbody');
  if(!body){body=el('div','mo-collbody');body.id=box.id+'-body';[...box.childNodes].forEach(n=>body.append(n));
    const h=el('h2','mo-collh'),b=el('button','mo-collbtn');b.type='button';b.id=box.id+'-tog';b.setAttribute('aria-controls',body.id);h.append(b);
    box.replaceChildren(h,body);box.classList.add('mo-coll');
    b.addEventListener('click',()=>{const o=b.getAttribute('aria-expanded')!=='true';collSet(box,o,true);if(o)draw();});}
  const b=box.querySelector(':scope > .mo-collh > .mo-collbtn');const st=el('span','mx-chip mo-collst'+(kind?' '+kind:''),status||'');st.id=box.id+'-status';
  b.replaceChildren(el('span','mo-collt',title),st);if(tip)b.title=tip;collSet(box,collState(box.dataset.coll),false);}
/* open every closed section that holds t (t itself included); true when one opened, so the caller redraws before it measures */
function collReveal(t){let n=false;for(let c=t&&t.closest&&t.closest('.mo-coll');c;c=c.parentElement&&c.parentElement.closest('.mo-coll')){
  const b=c.querySelector(':scope > .mo-collh > .mo-collbtn');if(b&&b.getAttribute('aria-expanded')!=='true'){collSet(c,true,false);n=true;}}return n;}
/* Description text on Home: notes, subtitles, helper sentences, captions and flags are kept for screen readers as visually hidden text
   in place, and their words become the tooltip (title) of the element shown just before them; other pages keep their own text.
   Needs lines, chips, numbers, short value labels, links and the reply to a task action stay; a tile caption, value line or card subtitle
   longer than CAPTION_MAX is a caption (a short one, like the week of a season, is a value label).
   The closed detail folds on Home (How it adds up, How these are built) are the opt-in detail layer and keep their text: no other page
   holds it. Only Home is touched; a draw shared with another page is not. */
const QUIET_SEL='p.mo-note,p.mx-src,.mx-flag,#nw-ms small,#hm-season .mx-goal small',CAPTION_SEL='.mo-ts,.ex,p.mx-sub',CAPTION_MAX=60;
const isNeedsText=e=>e.classList.contains('mo-needs')||/^Needs\b/.test((e.textContent||'').trim());
function quietAnchor(e){let s=e.previousElementSibling;while(s&&(s.classList.contains('mo-sr')||s.hidden||s.classList.contains('mo-chart')))s=s.previousElementSibling;
  if(s)return s;const p=e.parentElement;return p&&p.id!=='page-home'?p:null;}
function homeQuick(root){root=root||document.getElementById('page-home');if(!root||root.id!=='page-home'&&!root.closest('#page-home'))return;
  const cap=[...root.querySelectorAll(CAPTION_SEL)].filter(e=>{const long=(e.textContent||'').trim().length>CAPTION_MAX;if(!long&&e.dataset.quiet){e.classList.remove('mo-sr');delete e.dataset.quiet;}return long;});const tips=new Map();
  [...root.querySelectorAll(QUIET_SEL)].concat(cap).forEach(e=>{if(isNeedsText(e)||e.closest('details,.mx-ask'))return;const t=(e.textContent||'').trim();if(!t)return;
    e.classList.add('mo-sr');e.dataset.quiet='1';const a=quietAnchor(e);if(a){if(!tips.has(a))tips.set(a,[]);tips.get(a).push(t);}});
  /* the tooltip is the anchor's own title (kept once in data-tbase) plus the hidden words, rebuilt on every pass so it never goes stale */
  tips.forEach((ts,a)=>{if(a.dataset.tbase==null)a.dataset.tbase=a.title||'';a.title=[a.dataset.tbase].concat(ts).filter(Boolean).join(' ').slice(0,600);});}
/* the weekly check-in header: weeks checked in and whether this week is in */
function checkinStatus(K){if(!K||!K.expected)return null;const w=K.weeks[K.weeks.length-1];return {text:K.count+' of '+K.total+' weeks, this week '+(w&&w.checked_in?'done':'not yet'),kind:w&&w.checked_in?'ok':'warn'};}
/* the Needs attention header: open tasks and data still to send, the same counts the Tasks page uses */
function needStatus(open,needed){const a=[];if(open!=null)a.push(open+(open===1?' task':' tasks'));if(needed!=null)a.push(needed+' data to send');return a.join(', ');}
