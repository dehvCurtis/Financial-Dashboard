/* ---------- v3: mock-up 6 gap fill and progress layer (each fn is self-contained; derived facts only) ---------- */
function TRY_MONTHS(b0,target,perMonth,ratePct){
  if(b0==null||target==null||perMonth==null||ratePct==null)return null;if(b0>=target)return 0;
  const i=ratePct/1200;let b=b0;for(let n=1;n<=1200;n++){b=b*(1+i)+perMonth;if(b>=target-1e-9)return n;}return null;}
function V3_DAY(s,n){const t=new Date(s+'T12:00:00Z');t.setUTCDate(t.getUTCDate()+n);return t.toISOString().slice(0,10);}
function V3_CHECKIN(bl,accts,d0,d1){
  /* best 3 day window that starts inside [d0,d1] and ends by d1: the most accounts with a reported balance */
  let best=0,date=null,win=null;for(let d=d0;d<=d1;d=V3_DAY(d,1)){const e=V3_DAY(d,2)>d1?d1:V3_DAY(d,2);const rs=bl.filter(b=>b.date>=d&&b.date<=e);const n=new Set(rs.map(b=>b.account)).size;
    if(n>best){best=n;date=rs.map(b=>b.date).sort().pop();win=[d,e];}}
  return {best,checked:accts.length>0&&best===accts.length,date:best===accts.length?date:null,window:win};}
dash.calc('runway_calc',CR("runway_calc",{title:'Cash runway',description:'Months = liquid cash / essentials a month (essential bills plus every debt payment, the same figures as the score). Steps at 0.5, 1, 2, 3 and 6 months; the gap to a step is step x essentials minus cash. This month comes from the payoff plan (take-home, bills, debt payments, left over). Coming up lists debt due dates in the next 45 days from the liabilities; a debt with no due date is listed as Needs.',inputs:['scores_calc','payoff_engine','liabilities','age_benchmarks','bills'],
 fn:(sc,pe,li,bm,bills)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const S=sc[0],P=pe[0];const months=S.metrics.emergency_months,liquid=S.x.liquid,mustpay=S.x.mustpay;
  if(months==null)return [{needs:'Needs: cash balances, essential bills and debt payments'}];
  const row=id=>bm.find(r=>r.id===id)||null;const lo=row('g_ef_low'),hi=row('g_ef_high');
  const steps=[0.5,1,2,3,6].map(s=>({months:s,target:s*mustpay,reached:months>=s-1e-9,gap:Math.max(0,s*mustpay-liquid)}));
  const next=steps.find(s=>!s.reached)||null;
  const end=V3_DAY(T0,45);const coming=[],nodate=[];
  li.forEach(l=>{if(l.type==='Support'||!l.balance)return;const late=l.days_past_due>0;let due=late?T0:(l.next_due_date||l.next_due||null);if((!due||due<T0)&&!late&&l.due_day)due=nextDueDay(l.due_day,l.last_paid,T0);
    if(!due){nodate.push(l.name);return;}if(due<T0||due>end)return;
    const card=openCard(l);coming.push({id:l.liability_id,name:l.name,kind:'debt',date:due,late,days_past_due:l.days_past_due||0,amount:card&&l.statement_balance!=null?l.statement_balance:(l.amount_due||l.monthly_payment),minimum:card?l.monthly_payment:null,statement:card&&l.statement_balance!=null,late_after:l.late_after||null,paid_for:l.last_paid||null,due_day:l.due_day||null,statement_due_day:l.statement_due_day||null});});
  /* bills with a due day: the next one on or after today, a month already paid skipped; a bill without a due day is a Needs line (spending lines, kind spending, have no due day) */
  realRows(bills).filter(b=>b.monthly_amount>0&&b.paid_by_liability_id==null&&b.kind!=='spending').forEach(b=>{if(b.shutoff_amount>0&&b.shutoff_deadline>=T0&&b.shutoff_deadline<=end)coming.push({id:b.bill_id,name:b.name,kind:'bill',date:b.shutoff_deadline,late:false,shutoff:true,days_past_due:0,amount:b.shutoff_amount,minimum:null,statement:false,late_after:null,paid_for:null,due_day:null});const d=nextDueDay(b.due_day,b.last_paid,T0);if(!d){nodate.push(b.name);return;}if(d>end)return;coming.push({id:b.bill_id,name:b.name,kind:'bill',date:d,late:false,days_past_due:0,amount:(d===b.next_due&&b.new_charges>0?b.new_charges:b.monthly_amount),minimum:null,statement:false,late_after:null,paid_for:b.last_paid||null,due_day:b.due_day});});
  coming.sort((a,b)=>a.date<b.date?-1:a.date>b.date?1:0);
  const wh=(P.withheld||[]).reduce((s,w)=>s+(w.monthly||0),0);
  return [{months,liquid,mustpay,ess_bills:S.x.ess_bills,debt_payments:S.x.debt_all,guideline:{low:lo?lo.value:null,high:hi?hi.value:null,rows:[lo,hi].filter(Boolean).map(r=>({id:r.id,source:r.source,data_year:r.data_year}))},
    steps,next,plan_keep:P.cushion_shortfall,plan_extra:P.extra,this_month:{take_home:P.take_home,bills:P.bills,debt:P.mins,withheld:wh,left:P.surplus},coming,coming_needs:nodate,window_end:end,as_of:T0}];
 }}));
dash.calc('checkins_calc',CR("checkins_calc",{title:'Weekly check-ins',description:'A week (Monday to Sunday) counts as checked in when every account in balance_log has a reported balance inside one 3 day window of that week. Rolling window of the last 12 weeks; no streaks and nothing resets. A clean check is a check-in whose drift checks ending in that window are all within 25 dollars per account.',inputs:['balance_log','drift_all'],
 fn:(bl,da)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const tol=25;const accts=[...new Set(bl.map(b=>b.account))].sort();
  const dow=new Date(T0+'T12:00:00Z').getUTCDay();const wk0=V3_DAY(T0,-((dow+6)%7));
  const pts=da&&da[0]?da[0].accounts.flatMap(a=>a.points):[];
  const weeks=[];for(let i=11;i>=0;i--){const ws=V3_DAY(wk0,-7*i),we=V3_DAY(ws,6);const r=V3_CHECKIN(bl,accts,ws,we>T0?T0:we);
    const inWin=r.checked?pts.filter(p=>p.to>=r.window[0]&&p.to<=r.window[1]&&p.drift!=null):[];
    const clean=r.checked&&inWin.length>0&&inWin.every(p=>Math.abs(p.drift)<=tol+1e-9);
    weeks.push({week_start:ws,week_end:we,checked_in:r.checked,accounts_reported:r.best,accounts_expected:accts.length,date:r.date,clean,drift_checks:inWin.length,future:ws>T0});}
  const first=bl.length?bl.map(b=>b.date).sort()[0]:null;
  return [{weeks,count:weeks.filter(w=>w.checked_in).length,total:12,accounts:accts,expected:accts.length,tolerance:tol,clean_checks:weeks.filter(w=>w.clean).map(w=>w.date),first_data:first,as_of:T0}];
 }}));
dash.calc('recap_calc',CR("recap_calc",{title:'Weekly recap',description:'One recap per check-in week: card and cash totals at the check-in compared with the previous check-in, unexplained drift in the check periods that end in that week, and the next best move. Shown on Home for 7 days after a check-in, then kept under Past weeks. A first check-in has nothing to compare with and says so.',inputs:['checkins_calc','balance_log','drift_all','next_move','data_queue'],
 fn:(ck,bl,da,nm,dq)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const K=ck[0];const r2=x=>Math.round(x*100)/100;const card=a=>{const r=bl.find(b=>b.account===a);return r&&r.kind==='Card';};
  const tot=(ws,date)=>{let cash=0,cards=0;K.accounts.forEach(a=>{const r=bl.filter(b=>b.account===a&&b.date>=ws&&b.date<=date).sort((x,y)=>x.date<y.date?-1:1).pop();if(!r)return;if(card(a))cards+=r.reported_balance;else cash+=r.reported_balance;});return {cash:r2(cash),cards:r2(cards)};};
  const pts=da&&da[0]?da[0].accounts.flatMap(a=>a.points):[];
  const done=K.weeks.filter(w=>w.checked_in);const out=[];
  done.forEach((w,i)=>{const prev=i>0?done[i-1]:null;const t=tot(w.week_start,w.date),tp=prev?tot(prev.week_start,prev.date):null;
    const drift=r2(pts.filter(p=>p.drift!=null&&p.to<=w.date&&(!prev||p.to>prev.date)).reduce((s,p)=>s+(p.unexplained||0),0));
    out.push({week_start:w.week_start,date:w.date,prev_date:prev?prev.date:null,cash:t.cash,cards:t.cards,cash_change:tp?r2(t.cash-tp.cash):null,cards_change:tp?r2(t.cards-tp.cards):null,unexplained_drift:drift,clean:w.clean});});
  out.reverse();const latest=out[0]||null;const days=latest?Math.round((Date.parse(T0)-Date.parse(latest.date))/864e5):null;
  const next=da&&da[0]?da[0].next_check:null;
  const prov=dq.filter(q=>q.status==='Provided').length,need=dq.filter(q=>q.status==='Needed'||q.status==='Statement requested').length;
  return [{recaps:out,latest,days_since:days,visible:latest!=null&&days<=7,next_check:next,days_to_next:next?Math.round((Date.parse(next)-Date.parse(T0))/864e5):null,next_move:nm&&nm[0]?nm[0].text:null,data_provided:prov,data_needed:need,as_of:T0}];
 }}));
dash.calc('quests_calc',CR("quests_calc",{title:'Quests',description:'A quest is a view over tasks and data requests grouped by what they unlock: one per score part in Needs (tasks whose metric names it), one per debt missing a rate or minimum (and the HELOC rate type), one per account with no balance in 60 days, and one to close the drift gap (events with an unconfirmed account and accounts over 25 dollars of drift). A task counts as done only when it is Done and verified.',inputs:['tasks','data_queue','scores_calc','liabilities','balance_log','cash_events','drift_all'],
 fn:(tk,dq,sc,li,bl,ce,da)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const S=sc[0];const out=[];const tdone=t=>t.status==='Done'&&!!t.verified_on;
  const mk=(id,title,unlocks,unlock_text,tasks,queue,extra)=>{const items=tasks.map(t=>({kind:'task',id:t.id,text:t.task,done:tdone(t),unverified:t.status==='Done'&&!t.verified_on})).concat(queue.map(q=>({kind:'data',id:'Q'+q.priority,text:q.item,done:q.status==='Provided'}))).concat(extra||[]);
    const d=items.filter(x=>x.done).length;out.push({quest_id:id,title,unlocks,unlock_text,items,task_ids:tasks.map(t=>t.id),done_count:d,total_count:items.length,status:items.length&&d===items.length?'Done':'Open'});};
  [S.financial,S.risk].forEach(s=>s.rows.filter(r=>r.points==null).forEach(r=>{mk('Q_'+r.id,'Unlock '+r.name,r.id,r.weight+' points of '+s.title+' weight',tk.filter(t=>t.metric===r.id),[]);}));
  li.forEach(l=>{if(l.type==='Support'||!l.balance)return;const miss=[];if(l.rate_pct==null)miss.push('rate');if(l.monthly_payment==null)miss.push('minimum payment');if(l.type==='HELOC'&&l.rate_type==null)miss.push('rate type (fixed or variable)');
    if(!miss.length)return;const kw=new RegExp('\\b'+l.name.split(' ')[0].replace(/[^A-Za-z0-9]/g,'')+'\\b','i');
    mk('Q_'+l.liability_id,'Complete '+l.name,'debt '+l.liability_id,'Needs: '+miss.join(', ')+'. Fills the payoff plan and the debt ratio without estimates',tk.filter(t=>t.status!=='Done'&&kw.test(t.task)),dq.filter(q=>(q.status==='Needed'||q.status==='Statement requested')&&kw.test(q.item)));});
  const accts=[...new Set(bl.map(b=>b.account))];accts.forEach(a=>{const last=bl.filter(b=>b.account===a).map(b=>b.date).sort().pop();if(last&&(Date.parse(T0)-Date.parse(last))/864e5>60)mk('Q_acct_'+a,'Bring '+a+' up to date','balances','A balance or statement newer than 60 days (last '+last+')',[],[]);});
  const MNs=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];const fdt=s=>MNs[+s.slice(5,7)-1]+' '+(+s.slice(8,10));
  const ex=[];ce.filter(e=>e.account==='Not confirmed').forEach(e=>ex.push({kind:'event',id:e.event_id,text:'Which account paid '+e.kind+', '+fdt(e.date),done:false}));
  if(da&&da[0])da[0].accounts.forEach(a=>{const p=[...a.points].reverse().find(z=>z.drift!=null);if(p&&Math.abs(p.drift)>25)ex.push({kind:'drift',id:a.account,text:a.account+': '+Math.abs(p.drift).toFixed(2)+' of drift to explain',done:false});});
  mk('Q_drift','Close the drift gap','drift','Every dollar that moved is explained, so the Explained ring can reach 100',tk.filter(t=>t.metric==='drift'),[],ex);
  return out;
 }}));
dash.calc('badges_calc',CR("badges_calc",{title:'Badges',description:'A badge is a rare, durable fact with a name. Earned when the fact is true in the data; a badge stored in milestones (family badge) keeps its first-seen date for good, and if the fact stops being true it says so instead of being taken away. On pace reads the same pace as the Age ladder (base path on today\'s pay stubs against the low goal). No points, levels or counts.',inputs:['coverage_calc','scores_calc','card_transactions','liabilities','paystubs','checkins_calc','milestones','pace_steps_calc'],
 fn:(cv,sc,tx,li,ps,ck,ms,pst)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const K=cv[0],S=sc[0],C=ck[0];const em=S.metrics.emergency_months;const r2=x=>Math.round(x*100)/100;const nf=v=>v.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  const stmts=new Set(tx.filter(t=>t.statement_close).map(t=>t.card+'|'+t.statement_close)).size;
  const debts=li.filter(l=>l.type!=='Support');const zero=debts.filter(l=>l.balance===0);
  const hiN=(S.x&&S.x.acct_b_names)||[],hiB=(S.x&&S.x.acct_b_bal)||0;
  const noMin=debts.filter(l=>l.balance>0&&l.monthly_payment==null);
  const best=debts.filter(l=>l.original_balance&&l.balance>0).map(l=>({n:l.name,p:Math.max(0,1-l.balance/l.original_balance)})).sort((a,b)=>b.p-a.p)[0];
  const clean=C.clean_checks.length;const pace=pst&&pst[0]&&pst[0].pct!=null?pst[0].pct:null;
  const cash=n=>({id:'B_cash_'+n,name:n===1?'One month of cash':n===3?'Three months of cash':'Six months of cash',ok:em!=null&&em>=n,fact:em==null?'Needs: cash and essentials':r2(em)+' months now'+(em>=n?'':', '+r2(n-em)+' to go'),goal:String(n)});
  const L=[
   {id:'B_first_statement',name:'First statement',ok:stmts>=1,fact:stmts?stmts+' statement'+(stmts>1?'s':'')+' read, '+tx.filter(t=>t.statement_close).length+' transactions saved':'Needs: a card or bank statement',goal:'1'},
   {id:'B_full_picture',name:'Full picture',ok:K.picture_pct>=100,fact:K.picture_have+' of '+K.picture_total+' core datasets current',goal:'100'},
   {id:'B_all_components',name:'All components',ok:K.scores_weight_have>=K.scores_weight_total,fact:K.scores_weight_have+' of '+K.scores_weight_total+' score weight has data',goal:'100'},
   {id:'B_explained',name:'Explained',ok:clean>=3,fact:clean+' of 3 clean checks (drift within '+C.tolerance+' dollars on every account)',goal:'3'},
   cash(1),cash(3),cash(6),
   {id:'B_debt_free',name:'Debt free (per debt)',ok:zero.length>0,fact:zero.length?zero.map(l=>l.name).join(', ')+' at 0':(best?'None at 0 yet; closest: '+best.n+', '+Math.round(best.p*100)+'% paid':'None at 0 yet'),goal:'0'},
   {id:'B_high_interest_free',name:'High interest free',ok:hiN.length===0,fact:hiN.length?hiN.length+' balances above the high rate line in the score settings, $'+nf(hiB)+' in all':'No balance above the high rate line in the score settings',goal:'0'},
   {id:'B_minimums_known',name:'Minimums known',ok:noMin.length===0,fact:noMin.length?'Missing: '+noMin.map(l=>l.name).join(', '):'Every debt has a minimum on file',goal:String(noMin.length)},
   {id:'B_twelve_stubs',name:'Twelve stubs',ok:ps.length>=12,fact:ps.length+' now'+(ps.length>=12?'':', '+(12-ps.length)+' to go'),goal:'12'},
   {id:'B_on_pace',name:'On pace',ok:pace!=null&&pace>=100,fact:pace==null?'Needs: retirement inputs':Math.round(pace)+'% of the low goal at the target age now',goal:'100'}];
  const stored=(ms||[]).filter(m=>m.family==='badge');
  return L.map(b=>{const s=stored.find(z=>z.milestone_id===b.id);const earned=b.ok||!!s;
    return {badge_id:b.id,name:b.name,earned,earned_on:s?s.earned_on:(b.ok?T0:null),first_seen:!s&&b.ok,still_true:b.ok,fact:b.fact,goal:b.goal};});
 }}));
dash.calc('seasons_calc',CR("seasons_calc",{title:'Seasons',description:'A season is a calendar quarter (winter, spring, summer, autumn), counted from the first dated row in the data, 13 weeks long. Three goals per season, all derived: reach the next cash step, pay off the first debt in the payoff plan from its first balance this season, and check in on 9 of the 13 weeks. Missing a week loses nothing; past seasons without balances are not scored.',inputs:['balance_log','paystubs','runway_calc','payoff_engine'],
 fn:(bl,ps,rw,pe)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);
  const NAMES=['winter','spring','summer','autumn'];const qOf=s=>({y:+s.slice(0,4),q:Math.floor((+s.slice(5,7)-1)/3)});
  const qStart=(y,q)=>y+'-'+String(q*3+1).padStart(2,'0')+'-01';const qEnd=(y,q)=>V3_DAY(q===3?(y+1)+'-01-01':y+'-'+String(q*3+4).padStart(2,'0')+'-01',-1);
  const dates=bl.map(b=>b.date).concat(ps.map(p=>p.pay_date)).filter(Boolean).sort();const now=qOf(T0);
  const first=dates.length?qOf(dates[0]):now;const num=(now.y*4+now.q)-(first.y*4+first.q)+1;
  const st=qStart(now.y,now.q),en=qEnd(now.y,now.q);const days=Math.round((Date.parse(T0)-Date.parse(st))/864e5);const week=Math.min(13,Math.floor(days/7)+1);
  const accts=[...new Set(bl.map(b=>b.account))];
  const strip=[];for(let i=1;i<=13;i++){const a=V3_DAY(st,7*(i-1));const b=i===13?en:V3_DAY(a,6);const state=i<week?'past':i===week?'current':'future';
    const r=state==='future'?{checked:false}:V3_CHECKIN(bl,accts,a,b>T0?T0:b);strip.push({i,start:a,end:b,state,checked:!!r.checked});}
  const R=rw[0],P=pe[0];const goals=[];
  if(R&&R.months!=null){const nx=R.next;goals.push(nx?{id:'cash',title:'Reach '+(nx.months===1?'1 month':nx.months+' months')+' of essentials cash',have:R.liquid,target:nx.target,progress:Math.min(1,R.liquid/nx.target),unit:'USD'}:{id:'cash',title:'Keep 6 months of essentials cash',have:R.liquid,target:6*R.mustpay,progress:1,unit:'USD'});}
  else goals.push({id:'cash',title:'Reach the next cash step',needs:'Needs: cash and essentials',progress:null});
  const fo=P&&P.plans&&P.plans.smart?P.plans.smart.first_order:[];
  if(fo.length){const d=P.debts[fo[0]];const key=d.name.toLowerCase();const rows=bl.filter(b=>b.date>=st&&b.date<=en&&(key.startsWith(b.account.toLowerCase())||b.account.toLowerCase().startsWith(key))).sort((a,b)=>a.date<b.date?-1:1);
    const s0=rows.length?rows[0]:null;
    goals.push(s0?{id:'debt',title:'Pay off '+d.name,have:Math.max(0,s0.reported_balance-d.balance),target:s0.reported_balance,progress:Math.max(0,Math.min(1,(s0.reported_balance-d.balance)/s0.reported_balance)),start:s0.reported_balance,start_date:s0.date,now:d.balance,unit:'USD'}
      :{id:'debt',title:'Pay off '+d.name,needs:'Needs: a balance for '+d.name+' recorded this season',progress:null,now:d.balance});}
  else goals.push({id:'debt',title:'Pay off the first debt in the plan',needs:'Needs: debts with balances',progress:null});
  const got=strip.filter(s=>s.checked).length;goals.push({id:'checkin',title:'Check in on 9 of 13 weeks',have:got,target:9,progress:Math.min(1,got/9),unit:'weeks'});
  const past=[];for(let k=num-1;k>=1;k--){const t=now.y*4+now.q-(num-k);const y=Math.floor(t/4),q=t%4;const n=bl.filter(b=>b.date>=qStart(y,q)&&b.date<=qEnd(y,q)).length;
    past.push({number:k,name:NAMES[q],year:y,start:qStart(y,q),end:qEnd(y,q),scored:false,balances:n,note:n?'Not scored: the goals need cash and debt balances from the start and the end of that season':'Not scored: no balances were recorded that season'});}
  return [{number:num,name:NAMES[now.q],year:now.y,start:st,end:en,week,weeks:13,strip,goals,met:goals.filter(g=>g.progress!=null&&g.progress>=1-1e-9).length,past,as_of:T0}];
 }}));
dash.calc('moves_calc',CR("moves_calc",{title:'What would move you up one rung',description:'Three moves computed from the same calcs as the rest of the page: the 401(k) at its limit (months to the next ladder rung at today\'s 401(k) pace against at the limit, before growth), the next payment in the payoff plan (interest avoided a year = extra to that debt x its rate), and cash to 3 months of essentials. Score effects come from the score what-ifs, which rerun the score on changed copies of the data.',inputs:['age_calc','scores_calc','payoff_engine'],
 fn:(ag,sc,pe)=>{
  const A=ag[0],S=sc[0],P=pe[0];const L=A&&A.ladder;const W=id=>(S.whatifs||[]).find(w=>w.id===id)||null;const out=[];
  if(L&&L.next&&L.k401_limit!=null&&L.months_to_next_401k!=null&&L.months_to_next_limit!=null){const w=W('k401_limit');
    out.push({id:'k401',title:'Raise the 401(k) to the limit',extra_month:(L.k401_limit-L.k401_per_year)/12,next_pct:L.next.pct,months_now:L.months_to_next_401k,months_limit:L.months_to_next_limit,sooner:L.months_to_next_401k-L.months_to_next_limit,d_fin:w?w.d_fin:null,d_risk:w?w.d_risk:null});}
  else out.push({id:'k401',title:'Raise the 401(k) to the limit',needs:L&&!L.next?'Every rung is reached':'Needs: 401(k) pace, the limit and the ladder'});
  if(P&&P.debts.length&&P.surplus!=null){const r=PAYOFF_SIM(P.debts,P.extra,'smart',P.start,{stopAt:1});const i=r.first_order[0];
    if(i!=null){const d=P.debts[i];const amt=r.schedule[0].pay[i];const ex=Math.max(0,amt-d.min);const w=W('card0');
      out.push({id:'pay',title:'Pay '+d.name+' first',debt:d.name,amount:amt,extra_to:ex,rate:d.rate,per_year:d.rate==null?null:ex*d.rate/100,whatif_label:w?w.label:null,d_fin:w?w.d_fin:null,d_risk:w?w.d_risk:null});}}
  else out.push({id:'pay',title:'Pay the first debt in the plan',needs:'Needs: debts, bills and a pay stub'});
  if(S.x&&S.x.mustpay){const add=3*S.x.mustpay-S.x.liquid;const w=W('cash3');out.push({id:'cash',title:add>0?'Build cash to 3 months of essentials':'Cash already covers 3 months',add:Math.max(0,add),months:S.metrics.emergency_months,d_fin:w?w.d_fin:null,d_risk:w?w.d_risk:null});}
  return out;
 }}));
dash.calc('stubcheck_calc',CR("stubcheck_calc",{title:'Pay stubs and the bank',description:'Every stub with take-home, taxes, 401(k) and health (HSA you plus benefits), and the deposit seen in cash_events on the pay date. Gap = deposit minus net pay; a stub with no deposit on file says Needs.',inputs:['paystubs','cash_events'],
 fn:(ps,ce)=>{const r2=x=>Math.round(x*100)/100;
  return [...ps].sort((a,b)=>a.pay_date<b.pay_date?1:-1).map(s=>{const e=ce.find(x=>x.kind==='Pay deposit'&&x.date===s.pay_date);
    return {pay_date:s.pay_date,gross:s.gross,take_home:s.take_home_core,net_pay:s.net_pay,taxes:s.taxes,k401:s.k401_you||0,health:r2((s.hsa_you||0)+(s.benefits||0)),withheld:s.garnishment||0,deposit:e?e.amount:null,gap:e?r2(e.amount-s.net_pay):null};});
 }}));
dash.calc('ltv_calc',CR("ltv_calc",{title:'Loan to value',description:'Mortgage only = mortgage / home value; combined = mortgage plus HELOC / home value (the house equity numbers). Reference lines come from ltv_benchmarks with their sources; the PMI lines are measured on the original value by the servicer, so they are references, not tests.',inputs:['home_calc','ltv_benchmarks','liabilities'],
 fn:(hc,lb,li)=>{const h=hc[0];if(!h)return [];const first=li.filter(l=>l.type==='Mortgage').reduce((s,l)=>s+l.balance,0);
  return [{value:h.value,first_lien_pct:h.first_lien_pct,combined_pct:h.ltv_pct,first_balance:first,combined_balance:h.balance,
    lines:lb.map(r=>({id:r.id,measure:r.measure,pct:r.pct,label:r.label,basis:r.basis,source:r.source,data_year:r.data_year,confidence:r.confidence}))}];
 }}));
dash.calc('debt_steps_calc',CR("debt_steps_calc",{title:'Per debt milestones',description:'For each debt with a balance: steps at under 75, 50 and 25 percent of its first recorded (original) balance and at 0. For a revolving card the first recorded balance is the balance on its first statement. Paid percent never goes below 0 (a balance above the first recorded one shows 0 percent paid and no steps done). A debt without an original balance on file says Needs.',inputs:['liabilities'],
 fn:(li)=>li.filter(l=>l.type!=='Support'&&l.balance!=null).map(l=>{const o=l.original_balance||null;const rem=o?l.balance/o:null;
  const steps=[['Under 75%','75%',0.75],['Under 50%','50%',0.5],['Under 25%','25%',0.25],['$0','$0',0]].map(([t,sh,f])=>({label:t,short:sh,done:rem!=null&&(f===0?l.balance===0:rem<f)}));
  return {id:l.liability_id,name:l.name,type:l.type,original:o,balance:l.balance,remaining_pct:rem==null?null:rem*100,paid_pct:rem==null?null:Math.max(0,(1-rem)*100),steps,needs:o?null:'Needs: original or first recorded balance'};})
 }));
dash.calc('bench_age_calc',CR("bench_age_calc",{title:'Benchmarks by age',description:'The retirement guideline in dollars at your salary: a published salary multiple by age (anchors at 30, 40, 50, 60 and 67, straight lines between them, derived) and a published range (every 5 years from 30 to 65), with the publisher read from each row source. Your row compares your retirement balance with both.',inputs:['age_benchmarks','income_pay','retirement_plan','networth_history'],
 fn:(bm,inc,rp,nwh)=>{const B={};bm.forEach(r=>{B[r.id]=r;});const item=k=>{const x=rp.find(z=>z.item===k);return x?x.value:null;};
  const age=item('current_age');const sal=inc.filter(i=>i.kind==='Base').reduce((s,i)=>s+(i.annual_gross||0),0);
  if(age==null||!sal)return [{needs:'Needs: age and salary'}];
  const an=[[25,0]];[30,40,50,60,67].forEach(a=>{if(B['g_fidelity_'+a])an.push([a,B['g_fidelity_'+a].value]);});
  const mult=a=>{for(let i=1;i<an.length;i++){const [a0,m0]=an[i-1],[a1,m1]=an[i];if(a<=a1)return m0+(a-a0)/(a1-a0)*(m1-m0);}return null;};
  const tr=(a,s)=>{const ages=[30,35,40,45,50,55,60,65];let lo=null,hi=null;ages.forEach(x=>{if(x<=a)lo=x;if(hi==null&&x>=a)hi=x;});if(lo==null||hi==null)return null;const rl=B['g_trowe_'+lo+'_'+s],rh=B['g_trowe_'+hi+'_'+s];if(!rl||!rh)return null;return lo===hi?rl.value:rl.value+(a-lo)/(hi-lo)*(rh.value-rl.value);};
  const ages=[...new Set([30,35,40,45,50,55,60,67,age])].sort((a,b)=>a-b);
  const last=nwh.length?[...nwh].sort((a,b)=>a.date<b.date?-1:1).pop():null;const ret=last?last.retirement:null;
  const rows=ages.map(a=>{const m=mult(a);const l=tr(a,'low'),h=tr(a,'high');return {age:a,you:a===age,fidelity:m==null?null:m*sal,fidelity_published:[30,40,50,60,67].includes(a)&&!!B['g_fidelity_'+a],trowe:l==null?null:[l*sal,h*sal],trowe_published:a%5===0&&a>=30&&a<=65};});
  const yr=rows.find(r=>r.you);
  return [{age,salary:sal,retirement:ret,rows,pct_fidelity:ret!=null&&yr.fidelity?ret/yr.fidelity*100:null,pct_trowe_low:ret!=null&&yr.trowe?ret/yr.trowe[0]*100:null,
    pub_guideline:pubName(B.g_fidelity_40),pub_range:pubName(B.g_trowe_40_low),sources:[B.g_fidelity_40,B.g_trowe_40_low].filter(Boolean).map(r=>({source:r.source,data_year:r.data_year}))}];
 }}));
dash.calc('score_since_calc',CR("score_since_calc",{title:'Since last month',description:'Uses the last scores_history row of each calendar month. With two month-end rows: the change in each score and the score parts that moved it most, largest first. With fewer, it says how many rows exist; no arrow, no trend word.',inputs:['scores_history'],
 fn:(h)=>{const by={};h=h.filter(r=>r.date!=null);[...h].sort((a,b)=>a.date<b.date?-1:1).forEach(r=>{by[r.date.slice(0,7)]=r;});const m=Object.keys(by).sort();
  if(m.length<2)return [{available:false,month_rows:m.length}];const a=by[m[m.length-2]],b=by[m[m.length-1]];
  const bcp=cellObj(b.component_points),acp=cellObj(a.component_points);  const parts=Object.keys(bcp||{}).map(k=>({id:k,delta:(bcp[k]||0)-((acp||{})[k]||0),from_new_data:(acp||{})[k]==null&&bcp[k]!=null})).filter(p=>Math.abs(p.delta)>0.005).sort((x,y)=>Math.abs(y.delta)-Math.abs(x.delta));
  return [{available:true,from:a.date,to:b.date,d_fin:b.financial-a.financial,d_risk:b.risk-a.risk,parts:parts.slice(0,3)}];}
 }));
dash.calc('pace_steps_calc',CR("pace_steps_calc",{title:'Pace to your low goal, every account',description:'Base path balance at the target age on today\'s pay stubs as a percent of your low goal (the existing pace table), with steps at 25, 50, 75 and 100 percent.',inputs:['pace_calc','retirement_plan'],
 fn:(pc,rp)=>{const t=pc.find(r=>/today/i.test(r.scenario))||pc[0];const g=(rp.find(z=>z.item==='goal_low')||{}).value;const age=(rp.find(z=>z.item==='target_age')||{}).value;
  if(!t||!g)return [{needs:'Needs: goal_low and the pace table'}];const p=t.end_mid/g*100;
  return [{pct:p,balance:t.end_mid,goal_low:g,target_age:age,steps:[25,50,75,100].map(s=>({step:s,done:p>=s}))}];}
 }));

/* ---------- v4 calcs: ranked task list, Form 1098 costs, statement requests in sync ---------- */
dash.calc('task_rank_calc',CR("task_rank_calc",{title:'Ranked tasks',description:'Open tasks (status not Done) in order: due date first (a task without one goes after every dated task), then priority (High, Medium, not set, Low), then the score weight the task unlocks (largest first), then file order. Also the data requests still needed (status Needed or Statement requested) by their order number.',inputs:['tasks','scores_calc','data_queue'],
 fn:(tasks,scores,queue)=>{
  tasks=realRows(tasks);queue=realRows(queue);const S=scores[0];const W={};[S.financial,S.risk].forEach(s=>s.rows.forEach(r=>{W[r.id]=r.points==null?r.weight:0;}));
  const P={High:0,Medium:1,Low:3};
  const open=tasks.map((t,i)=>({t,i})).filter(x=>x.t.status!=='Done').map(x=>({id:x.t.id,due_date:x.t.due_date||null,priority:x.t.priority||null,weight:x.t.metric&&W[x.t.metric]!=null?W[x.t.metric]:0,order:x.i,status:x.t.status,queue_id:x.t.queue_id||null}));
  open.sort((a,b)=>(a.due_date&&b.due_date?(a.due_date<b.due_date?-1:a.due_date>b.due_date?1:0):a.due_date?-1:b.due_date?1:0)||((a.priority in P?P[a.priority]:2)-(b.priority in P?P[b.priority]:2))||(b.weight-a.weight)||(a.order-b.order));
  open.forEach((x,k)=>{x.rank=k+1;});
  const need=queue.filter(q=>q.status==='Needed'||q.status==='Statement requested').sort((a,b)=>a.priority-b.priority);
  return [{tasks:open,open_count:open.length,to_do:open.filter(x=>x.status==='To do').length,open_status:open.filter(x=>x.status==='Open').length,done_count:tasks.length-open.length,
    data_needed:need.length,data_top:need.slice(0,2).map(q=>({queue_id:q.queue_id||('Q'+q.priority),item:q.item,area:q.area,status:q.status}))}];
 }}));
dash.calc('statement_sync_calc',CR("statement_sync_calc",{title:'Statement requests in sync',description:'A value that came from a screenshot keeps a data request with status Statement requested and an open task that asks for the downloaded statement; the two point at each other (task_id on the request, queue_id on the task). When the statement arrives the request becomes Provided and the task Done with a done date. Lists every pair that is out of step.',inputs:['data_queue','tasks'],
 fn:(queue,tasks)=>{
  queue=realRows(queue);tasks=realRows(tasks);const byId={};tasks.forEach(t=>{byId[t.id]=t;});const issues=[];let pairs=0;
  queue.forEach(q=>{const qid=q.queue_id||('Q'+q.priority);
    if(q.status==='Statement requested'){pairs++;const t=q.task_id?byId[q.task_id]:null;
      if(!t)issues.push(qid+' has no task');else if(t.queue_id!==qid)issues.push(t.id+' does not point back to '+qid);else if(t.status==='Done')issues.push(t.id+' is Done but '+qid+' still waits for the statement');}
    else if(q.task_id){const t=byId[q.task_id];if(q.status==='Provided'&&t&&t.status!=='Done')issues.push(qid+' is Provided but '+t.id+' is still '+t.status);}});
  tasks.forEach(t=>{if(t.queue_id&&!queue.some(q=>(q.queue_id||('Q'+q.priority))===t.queue_id&&q.task_id===t.id))issues.push(t.id+' points to '+t.queue_id+', which does not point back');});
  return [{pairs,issues,ok:!issues.length}];
 }}));

