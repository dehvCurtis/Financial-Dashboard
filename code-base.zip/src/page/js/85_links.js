/* ---------- tile links (tile_links/TILE_MAP.md): every tile with a larger chart or table opens it ----------
   One map, one helper. After a page draws, linkTiles(page) finds each mapped tile on that page (by its row and label, or by a
   selector) and writes data-goto-id, data-goto-name and data-tile-key, role="link" and tabindex 0; a tile showing a Needs value,
   or one that holds a button or link, is left as it is. A tap, Enter or Space calls jumpTo: show the target's page, open its
   folds and view, press the segment it needs, redraw, then scroll the target heading under the top bar with a Back chip above it,
   highlight the target for 1.6 s and move focus to it. The chip and the header Back share one stack (90_wiring). */
const TILE_LINKS=[
 ["hm-hero",{"sel":"#hm-hero","i":0},"nw-hist","Net worth over time"],
 ["hm-t-assets",{"row":"hm-tiles","label":"^Assets$"},"nw-assets","Assets by type"],
 ["hm-t-debts",{"row":"hm-tiles","label":"^Debts$"},"debt-donut","Debt balance by debt"],
 ["hm-t-dti",{"row":"hm-tiles","label":"^Debt to income$"},"debt-dti","Debt to income bars"],
 ["hm-t-cash",{"row":"hm-tiles","label":"^Cash$"},"cs-balhist","Cash balance over time"],
 ["hm-t2-runway",{"row":"hm-tiles2","label":"^Cash runway"},"cs-runway","Cash runway"],
 ["hm-t2-pace",{"row":"hm-tiles2","label":"^Retirement vs the age guideline"},"rt-ladder","Age ladder and age 60 pace"],
 ["hm-po-next",{"sel":"#hm-payoff .mx-big","i":0},"po-next","Next move",{"fb":"po-plan"}],
 ["hm-po-free",{"row":"hm-payoff","label":"^Debt free"},"po-planchart","Debt payoff timeline, your payoff plan",{"pre":"po-basis=plan"}],
 ["hm-po-int",{"row":"hm-payoff","label":"^Interest saved"},"po-compare","Compare plans table",{"fb":"po-res"}],
 ["hm-cover-picture",{"sel":"#hm-cover .mx-cring","i":0},"pg-body","Coverage",{"fb":"acc-progress"}],
 ["hm-cover-scores",{"sel":"#hm-cover .mx-cring","i":1},"pg-body","Coverage",{"fb":"acc-progress"}],
 ["hm-cover-explained",{"sel":"#hm-cover .mx-cring","i":2},"pg-body","Coverage",{"fb":"acc-progress"}],
 ["hm-recap",{"sel":"#hm-recap","i":0},"pg-weeks","Past weeks",{"fb":"acc-progress"}],
 ["hm-age-net_worth",{"sel":"#hm-age .mx-am","i":0},"nw-hist","Net worth over time"],
 ["hm-age-retirement",{"sel":"#hm-age .mx-am","i":1},"rt-ladder","Age ladder"],
 ["hm-age-savings",{"sel":"#hm-age .mx-am","i":2},"ret-limits","What you put in against the limits"],
 ["hm-age-credit_card",{"sel":"#hm-age .mx-am","i":3},"debt-donut","Debt balance by debt"],
 ["hm-age-emergency",{"sel":"#hm-age .mx-am","i":4},"cs-runway","Cash runway"],
 ["hm-age-dti",{"sel":"#hm-age .mx-am","i":5},"debt-dti","Debt to income bars"],
 ["hm-season-g1",{"sel":"#hm-season .mx-goal","i":0},"cs-runway","Cash runway"],
 ["hm-season-g2",{"sel":"#hm-season .mx-goal","i":1},"po-trail","Your payoff trail"],
 ["hm-season-g3",{"sel":"#hm-season .mx-goal","i":2},"cs-checkin","Weekly check-in"],
 ["hm-ret-today",{"sel":"#hm-ret .mo-rrow","i":0},"ret-chart","What you will have at 60"],
 ["hm-ret-max",{"sel":"#hm-ret .mo-rrow","i":1},"ret-chart","What you will have at 60"],
 ["nw-net",{"row":"nw-tiles","label":"^Net worth, known items"},"nw-hist","Net worth over time"],
 ["nw-assets",{"row":"nw-tiles","label":"^Total assets"},"nw-assets","Assets by type"],
 ["nw-debts",{"row":"nw-tiles","label":"^Total debts"},"debt-donut","Debt balance by debt"],
 ["nw-ret",{"row":"nw-tiles","label":"^Retirement accounts"},"ov-donut","Retirement balance by account"],
 ["nw-cash",{"row":"nw-tiles","label":"^Cash, savings and checking"},"cs-balhist","Cash balance over time"],
 ["nw-hsa",{"row":"nw-tiles","label":"^HSA, uninvested"},"nw-assets","Assets by type"],
 ["nw-missing",{"row":"nw-tiles","label":"^Debts missing a payment"},"t-liab","Debts table"],
 ["nw-equity",{"row":"nw-tiles","label":"^Home equity"},"nw-house","House value split"],
 ["nw-refunds",{"row":"nw-tiles","label":"^Tax refunds pending"},"t-assets","Assets table"],
 ["house-value",{"row":"house-tiles","label":"^Value"},"nw-house","House value split"],
 ["house-loans",{"row":"house-tiles","label":"^Mortgage plus HELOC"},"mn-ltv","Loan to value"],
 ["house-bought",{"row":"house-tiles","label":"^Bought for"},"t-assets","Assets table"],
 ["po-free",{"row":"po-tiles","label":"^Debt free"},"po-planchart","Debt payoff timeline, your payoff plan",{"pre":"po-basis=plan"}],
 ["ret-short",{"row":"ret-tiles","label":"^Short of the"},"ret-chart","What you will have at 60"],
 ["ret-extra",{"row":"ret-tiles","label":"^Extra per month"},"ret-limits","What you put in against the limits"],
 ["ret-k401now",{"row":"ret-tiles","label":"^401\\(k\\) per paycheck now"},"ret-limits","What you put in against the limits"],
 ["ret-k401max",{"row":"ret-tiles","label":"^Per paycheck to max"},"rt-plan","401(k) plan year"],
 ["ret-need",{"row":"ret-tiles","label":"^Total saving per year"},"rt-pace","Pace to your own goal"],
 ["rt-age-net_worth",{"sel":"#rt-age .mx-am","i":0},"nw-hist","Net worth over time"],
 ["rt-age-retirement",{"sel":"#rt-age .mx-am","i":1},"rt-ladder","Age ladder"],
 ["rt-age-savings",{"sel":"#rt-age .mx-am","i":2},"ret-limits","What you put in against the limits"],
 ["rt-age-credit_card",{"sel":"#rt-age .mx-am","i":3},"debt-donut","Debt balance by debt"],
 ["rt-age-emergency",{"sel":"#rt-age .mx-am","i":4},"cs-runway","Cash runway"],
 ["rt-age-dti",{"sel":"#rt-age .mx-am","i":5},"debt-dti","Debt to income bars"],
 ["rt-age-income",{"sel":"#rt-age .mx-am","i":6},"cf-sankey","Where your gross pay goes"],
 ["cash-total",{"row":"cash-bal","label":"^Cash, savings and checking"},"cs-balhist","Cash balance over time"],
 ["cash-sav",{"row":"cash-bal","label":"^Savings account"},"cs-balhist","Cash balance over time"],
 ["cash-chk",{"row":"cash-bal","label":"^Checking account"},"cs-balhist","Cash balance over time"],
 ["cf-take",{"row":"cf-tiles","label":"^Take-home pay per month"},"pc-chart","Each paycheck: take-home and deductions"],
 ["cf-debt",{"row":"cf-tiles","label":"^Debt payments"},"debt-pay","Monthly payment by debt"],
 ["cf-bills",{"row":"cf-tiles","label":"^Bills per month"},"cf-donut","Bills by category"],
 ["pc-net",{"row":"pc-tiles","label":"^Take-home per paycheck"},"pc-chart","Each paycheck split"],
 ["pc-month",{"row":"pc-tiles","label":"^Take-home per month"},"pc-chart","Each paycheck split"],
 ["pc-tax",{"row":"pc-tiles","label":"^Taxes withheld"},"pc-chart","Each paycheck split"],
 ["pc-saved",{"row":"pc-tiles","label":"^Saved from each check"},"pc-chart","Each paycheck split"],
 ["pc-count",{"row":"pc-tiles","label":"^Paychecks on file"},"pc-stubs","Pay stubs table",{"fb":"pc-tables"}],
 ["sg-saved",{"row":"sg-tiles","label":"^Total"},"sg-goals","Goal list with forecasts"],
 ["sg-monthly",{"row":"sg-tiles","label":"^Going"},"sg-goals","Goal list with forecasts"],
 ["sg-earmarked",{"row":"sg-tiles","label":"^Earmarked"},"sg-goals","Goal list with forecasts"],
 ["sg-unassigned",{"row":"sg-tiles","label":"^Unassigned"},"sg-goals","Goal list with forecasts"],
 ["dr-latest",{"row":"dr-tiles","label":"^Latest dollar drift"},"dr-bridge","Latest period, step by step"],
 ["dr-points",{"row":"dr-tiles","label":"^Drift points so far"},"dr-chart","Drift over time"],
 ["dr-waiting",{"row":"dr-tiles","label":"^Periods waiting on you"},"t-drift","Every period (table)"],
 ["inv-total",{"row":"inv-tiles","label":"^All holdings, total"},"inv-class","Allocation by asset class"],
 ["inv-gain",{"row":"inv-nb-tiles","label":"^Gain since current cost basis"},"inv-scatter","Cost basis against value"],
 ["inv-trad",{"row":"inv-nb-tiles","label":"^Traditional"},"inv-src","Balance by source"],
 ["inv-roth",{"row":"inv-nb-tiles","label":"^Roth"},"inv-src","Balance by source"],
 ["inv-growth",{"row":"inv-nb-tiles","label":"^Market growth since"},"inv-planwf","Where the balance came from"],
 ["inv-funds",{"row":"inv-tiles","label":"^Funds held"},"inv-tree","Holdings map"],
 ["inv-hi-bal",{"row":"inv-hi-tiles","label":"^Balance"},"inv-hi","Funds in the second 401(k)"],
 ["inv-hi-funds",{"row":"inv-hi-tiles","label":"^Funds held"},"inv-hi","Funds in the second 401(k)"],
 ["plan-return",{"row":"plan-tiles","label":"^Plan's own return"},"inv-planwf","Where the balance came from"],
 ["plan-yearly",{"row":"plan-tiles","label":"^Per year"},"inv-planwf","Where the balance came from"],
 ["plan-share",{"row":"plan-tiles","label":"^Share of balance"},"inv-planwf","Where the balance came from"],
 ["plan-bal",{"row":"plan-tiles","label":"^Balance on"},"inv-planwf","Where the balance came from"],
 ["bd-first-statement",{"sel":"#bd-body .mx-badge","text":"First statement"},"card-billhist","Bill statement history"],
 ["bd-full-picture",{"sel":"#bd-body .mx-badge","text":"Full picture"},"pg-body","Coverage",{"fb":"acc-progress"}],
 ["bd-all-components",{"sel":"#bd-body .mx-badge","text":"All components"},"hm-scores","Scores and their parts"],
 ["bd-explained",{"sel":"#bd-body .mx-badge","text":"Explained"},"card-drift-all","Every account, weekly check points"],
 ["bd-one-month-of-cash",{"sel":"#bd-body .mx-badge","text":"One month of cash"},"cs-runway","Cash runway"],
 ["bd-three-months-of-cash",{"sel":"#bd-body .mx-badge","text":"Three months of cash"},"cs-runway","Cash runway"],
 ["bd-six-months-of-cash",{"sel":"#bd-body .mx-badge","text":"Six months of cash"},"cs-runway","Cash runway"],
 ["bd-debt-free-per-debt",{"sel":"#bd-body .mx-badge","text":"Debt free (per debt)"},"po-trail","Your payoff trail"],
 ["bd-high-interest-free",{"sel":"#bd-body .mx-badge","text":"High interest free"},"debt-bubble","Rate against balance"],
 ["bd-minimums-known",{"sel":"#bd-body .mx-badge","text":"Minimums known"},"mn-fields","Payoff fields per debt (table)",{"open":"child"}],
 ["bd-twelve-stubs",{"sel":"#bd-body .mx-badge","text":"Twelve stubs"},"pc-stubs","Pay stubs table",{"fb":"pc-tables"}],
 ["bd-on-pace",{"sel":"#bd-body .mx-badge","text":"On pace"},"ret-chart","What you will have at 60"],
 ["season-now",{"sel":"#bd-body .mx-season","i":0},"hm-season","This season and its goals"]];
const TL={chip:null};
const tlReduced=()=>!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
const tlNeeds=t=>/^(Needs|Did not run|n\/a|Not known yet|Not calculated yet|date not set)/i.test((t||'').trim());
function tlFind(f){
  if(f.row){const r=document.getElementById(f.row);if(!r)return null;const re=new RegExp(f.label);return [...r.querySelectorAll(':scope > .mo-tile, .mo-tiles > .mo-tile')].find(t=>{const l=t.querySelector('.mo-tl');return l&&re.test(l.textContent.trim());})||null;}
  const a=[...document.querySelectorAll(f.sel)];if(f.text)return a.find(n=>n.textContent.includes(f.text))||null;return a[f.i||0]||null;}
function linkTile(node,g){
  if(!node||node.dataset.gotoId)return;
  if(node.querySelector('button,a,input,select,summary,[data-goto-id]'))return;
  const v=node.querySelector('.mo-tv,.mx-big,.v,b');if(v&&tlNeeds(v.textContent))return;if(tlNeeds(node.textContent))return;
  node.dataset.gotoId=g.id;node.dataset.gotoName=g.name;node.dataset.tileKey=g.key;if(g.pre)node.dataset.gotoPre=g.pre;if(g.fb)node.dataset.gotoFallback=g.fb;if(g.open)node.dataset.gotoOpen=g.open;
  node.setAttribute('role','link');node.tabIndex=0;node.classList.add('mo-golink');
  const lab=(node.querySelector('.mo-tl,.mx-eyebrow,h2,h3,b')||node).textContent.trim().replace(/\s+/g,' ');const val=v&&v!==node.querySelector('.mo-tl')?v.textContent.trim():'';
  const tp=pageOf(g.id)||pageOf(g.fb||'');const here=(node.closest('.mo-page')||{id:''}).id.slice(5);
  node.setAttribute('aria-label',(lab?lab+(val&&val!==lab?' '+val:'')+'. ':'')+'Open '+g.name+(tp&&tp!==here&&META[tp]?' on '+META[tp][0]:''));}
function linkTiles(page){TILE_LINKS.forEach(([key,f,id,name,o])=>{const n=tlFind(f);if(!n)return;const s=n.closest('.mo-page');if(!s||s.id!=='page-'+page)return;o=o||{};linkTile(n,{key,id,name,pre:o.pre,fb:o.fb,open:o.open});});}
function tlDropChip(){if(TL.chip){TL.chip.remove();TL.chip=null;}}
function tlHighlight(t){t.classList.remove('mo-hl');void t.offsetWidth;t.classList.add('mo-hl');clearTimeout(t._hl);t._hl=setTimeout(()=>t.classList.remove('mo-hl'),1600);}
function tlAnchor(t){if(t.matches('h2,h3')||t.querySelector(':scope > h2, :scope > h3, :scope > summary'))return t;let s=t.previousElementSibling;
  while(s&&(s.classList.contains('mo-seg')||s.classList.contains('mo-legend')||s.classList.contains('mo-ts')||s.classList.contains('mo-ctlbar')))s=s.previousElementSibling;
  return s&&/^H[23]$/.test(s.tagName)?s:t;}
function tlOpen(t,mode){for(let d=t.closest('details');d;d=d.parentElement&&d.parentElement.closest('details'))d.open=true;if(t.tagName==='DETAILS')t.open=true;if(mode==='child'){const c=t.querySelector('details');if(c)c.open=true;}
  revealView(t);collReveal(t);}
function tlPre(pre){if(!pre)return;const [g,v]=pre.split('=');const b=document.querySelector('#'+g+' button[data-v="'+v+'"]');if(b&&b.getAttribute('aria-pressed')!=='true')b.click();}
/* the jump: draw on demand, open folds, press the segment, then scroll, highlight and focus */
function jumpTo(id,o){o=o||{};let pg=pageOf(id)||pageOf(o.fallback||'');if(!pg){console.warn('tile link: no target '+id);return false;}
  const from=o.from;const label=from?(from.querySelector('.mo-tl,.mx-eyebrow,h2,h3,b')||from).textContent.trim().replace(/\s+/g,' ').slice(0,40):'';
  tlDropChip();const cur=(document.querySelector('.mo-page:not([hidden])')||{id:'page-home'}).id.slice(5);navPush(from);if(pg!==cur)show(pg);else setBack();
  let t=$(id);if(!t&&o.fallback)t=$(o.fallback);if(!t){console.warn('tile link: no target '+id);return false;}
  tlOpen(t,o.open);tlPre(o.pre);draw();
  t=$(id)||(o.fallback&&$(o.fallback));if(!t)return false;
  if(t.hidden||!t.getClientRects().length){const f=o.fallback&&$(o.fallback);if(f&&!f.hidden)t=f;else{console.warn('tile link: target hidden '+id);return false;}}
  const a=tlAnchor(t);let top=a;
  if(from){const b=el('button','mo-back','Back to '+label);b.type='button';b.setAttribute('aria-label','Back to '+label+(NAV.stack.length&&NAV.stack[NAV.stack.length-1].page!==pg&&META[NAV.stack[NAV.stack.length-1].page]?' on '+META[NAV.stack[NAV.stack.length-1].page][0]:''));
    b.addEventListener('click',()=>{tlDropChip();back();});a.before(b);TL.chip=b;top=b;}
  const go=()=>top.scrollIntoView({block:'start',behavior:tlReduced()?'auto':'smooth'});
  requestAnimationFrame(()=>setTimeout(()=>{go();tlHighlight(t);if(!t.hasAttribute('tabindex'))t.tabIndex=-1;t.focus({preventScroll:true});
    const fix=()=>{const r=top.getBoundingClientRect(),tb=document.querySelector('.mo-top').getBoundingClientRect().bottom;if(Math.abs(r.top-tb)>12)top.scrollIntoView({block:'start'});};
    if(tlReduced()||!('onscrollend' in window))setTimeout(fix,120);else{const sc=scroller()||window;sc.addEventListener('scrollend',fix,{once:true});}},60));
  return true;}
function tlFire(n){jumpTo(n.dataset.gotoId,{pre:n.dataset.gotoPre,fallback:n.dataset.gotoFallback,open:n.dataset.gotoOpen,from:n});}
document.addEventListener('click',ev=>{const n=ev.target.closest&&ev.target.closest('[data-goto-id]');if(!n)return;const inner=ev.target.closest('button,a,input,select,summary');if(inner&&inner!==n&&n.contains(inner))return;ev.preventDefault();tlFire(n);});
document.addEventListener('keydown',ev=>{if(ev.key!=='Enter'&&ev.key!==' ')return;const n=ev.target;if(!n||!n.dataset||!n.dataset.gotoId||n.tagName==='BUTTON')return;ev.preventDefault();tlFire(n);});
