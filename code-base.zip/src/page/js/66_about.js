/* ---------- shared "About this" fold and source on tap (user rule, all pages) ----------
   Every card shows one key number or chart, short labels and chips. The explanation (formulas, sources, as-of dates, long notes)
   sits in ONE closed fold per card with the same label in the same place, the last thing on the card. The fold is a native details
   element, so the keyboard and screen readers work. Its open state is kept in ABOUT_OPEN by key, so a switch change or a redraw
   that rebuilds the card brings it back as it was. Warnings and decision items are not put here: they stay on the card as chips
   (aboutChip) or one line alerts (mx-alert lines). A number can point at its fold (srcNum) or carry a tooltip with source and as-of. */
const ABOUT_OPEN={};
const ABOUT_LABEL='About this';
function aboutSync(){document.querySelectorAll('details.mx-about').forEach(d=>{if(d.dataset.key)ABOUT_OPEN[d.dataset.key]=d.open;});}
function aboutFold(key,nodes){
  const d=document.createElement('details');d.className='mo-fold mx-about';d.id='about-'+key;d.dataset.key=key;if(ABOUT_OPEN[key])d.open=true;
  const s=document.createElement('summary');s.textContent=ABOUT_LABEL;d.append(s);
  const b=el('div','mx-aboutbody');[].concat(nodes==null?[]:nodes).forEach(n=>{if(n==null||n===false)return;b.append(typeof n==='string'?el('p','mo-note',n):n);});d.append(b);
  d.addEventListener('toggle',()=>{ABOUT_OPEN[key]=d.open;});return d;}
/* a static card in the markup holds its fold as plain details with class mx-about; this restores its state after a re-mount */
function aboutOpen(key){const d=document.getElementById('about-'+key);if(!d)return false;d.open=true;ABOUT_OPEN[key]=true;return true;}
/* a number that points at its fold: a real button, so a tap or Enter opens About this and moves focus to it; hover shows source and as-of */
function srcNum(text,key,tip,cls){const b=el('button','mx-srcnum'+(cls?' '+cls:''),text);b.type='button';b.title=tip||'Source and as-of in About this';
  b.setAttribute('aria-label',text+'. Source and as-of are in About this.');
  b.addEventListener('click',()=>{aboutOpen(key);const d=document.getElementById('about-'+key);if(d){d.scrollIntoView({block:'nearest'});const s=d.querySelector('summary');if(s)s.focus({preventScroll:true});}});return b;}
/* a plain number (inside a tile that is already a link): hover tooltip with its source and as-of */
function srcTip(node,tip){if(node&&tip){node.title=tip;}return node;}
const aboutChip=(text,kind)=>{const c=chip(text,kind);c.style.marginLeft='0';return c;};
