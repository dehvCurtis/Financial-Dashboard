/* ---------- calculations ---------- */
dash.calc('nw_rows',CR("nw_rows",{title:'Net worth, known items',description:'Retirement balances plus house, truck, cash (savings and checking) and uninvested HSA cash, minus debts. Receivables such as pending refunds are excluded.',inputs:['acct_a_sources','acct_b_holdings','assets_other','liabilities'],
 fn:(acct_a_sources,acct_b_holdings,assets_other,liabilities)=>{
  const sum=(a,f)=>a.reduce((s,x)=>s+(f(x)||0),0);
  const retire=Math.round((sum(acct_a_sources,x=>x.balance)+sum(acct_b_holdings,x=>x.value))*100)/100;
  const house=sum(assets_other.filter(a=>a.type==='Real estate'),a=>a.value_point);
  const truck=sum(assets_other.filter(a=>a.type==='Vehicle'),a=>a.value_point);
  const cash=sum(assets_other.filter(a=>a.type==='Cash'),a=>a.value_point);
  const hsa=sum(assets_other.filter(a=>a.type==='HSA'),a=>a.value_point);
  const other=sum(assets_other.filter(a=>!['Real estate','Vehicle','Cash','HSA','Receivable'].includes(a.type)),a=>a.value_point);
  const debt=sum(liabilities,l=>l.balance);
  const out=[{item:'Retirement accounts',amount:retire},{item:'House',amount:house},{item:'Truck',amount:truck},{item:'Cash, savings and checking',amount:cash}];
  if(hsa)out.push({item:'HSA, uninvested',amount:hsa});
  if(other)out.push({item:'Other assets',amount:other});
  out.push({item:'Mortgage, HELOC and debts',amount:-debt},{item:'Net worth',amount:Math.round((retire+house+truck+cash+hsa+other-debt)*100)/100});
  return out;
 }}));
dash.calc('nw_steps',CR("nw_steps",{title:'Net worth waterfall steps',description:'Assets stepping up, each debt stepping down, ending at net worth.',inputs:['acct_a_sources','acct_b_holdings','assets_other','liabilities'],
 fn:(acct_a_sources,acct_b_holdings,assets_other,liabilities)=>{
  const sum=(a,f)=>a.reduce((s,x)=>s+(f(x)||0),0);
  const r2=x=>Math.round(x*100)/100;
  const retire=r2(sum(acct_a_sources,x=>x.balance)+sum(acct_b_holdings,x=>x.value));
  const out=[{label:'Retirement accounts',value:retire,kind:'delta',type:'Retirement'}];
  assets_other.filter(a=>a.type!=='Receivable'&&a.value_point>0).sort((a,b)=>b.value_point-a.value_point).forEach(a=>out.push({label:a.type==='HSA'?'HSA, uninvested':a.name,value:a.value_point,kind:'delta',type:a.type}));
  const assets=sum(out,x=>x.value);
  out.push({label:'Total assets',value:r2(assets),kind:'total'});
  liabilities.filter(l=>l.balance>0).sort((a,b)=>b.balance-a.balance).forEach(l=>out.push({label:l.name,value:-l.balance,kind:'delta',type:l.type,liability_id:l.liability_id}));
  const debt=sum(liabilities,l=>l.balance);
  out.push({label:'Net worth',value:r2(assets-debt),kind:'total'});
  return out;
 }}));
dash.calc('acct_a_hist',CR("acct_a_hist",{title:'First account balance by export date',description:'Total of the first account funds at each holdings export date, used for sparklines and the change since the first export.',inputs:['holding_snapshots'],
 fn:(snaps)=>{const m=new Map();snaps.forEach(s=>m.set(s.snapshot_date,(m.get(s.snapshot_date)||0)+s.value));return [...m].sort((a,b)=>a[0]<b[0]?-1:1).map(([date,value])=>({date,value:Math.round(value*100)/100}));}}));
dash.calc('home_calc',CR("home_calc",{title:'House equity and proceeds',description:'Value minus mortgage and HELOC, loan to value, and a net-if-sold range using the selling-cost percentages on the house row.',inputs:['assets_other','liabilities'],
 fn:(assets_other,liabilities)=>{
  const h=assets_other.find(a=>a.type==='Real estate');const ms=liabilities.filter(l=>l.type==='Mortgage'||l.type==='HELOC');
  if(!h||!ms.length)return [];const m={balance:ms.reduce((s,l)=>s+l.balance,0)};
  const first=liabilities.filter(l=>l.type==='Mortgage').reduce((s,l)=>s+l.balance,0);
  return [{value:h.value_point,balance:m.balance,equity:h.value_point-m.balance,ltv_pct:Math.round(m.balance/h.value_point*1000)/10,first_lien_pct:Math.round(first/h.value_point*1000)/10,purchase_price:h.purchase_price,gain_since_purchase:h.value_point-h.purchase_price,net_proceeds_low:Math.round(h.value_point-m.balance-h.value_point*h.sell_cost_high_pct/100),net_proceeds_high:Math.round(h.value_point-m.balance-h.value_point*h.sell_cost_low_pct/100)}];
 }}));
dash.calc('house_split',CR("house_split",{title:'House value split',description:'House value divided into the mortgage, the HELOC and your equity.',inputs:['assets_other','liabilities'],
 fn:(a,l)=>{const h=a.find(x=>x.type==='Real estate');if(!h)return [];const m=l.filter(x=>x.type==='Mortgage').reduce((s,x)=>s+x.balance,0);const he=l.filter(x=>x.type==='HELOC').reduce((s,x)=>s+x.balance,0);return [{part:'Mortgage',amount:Math.round(m)},{part:'HELOC',amount:Math.round(he)},{part:'Your equity',amount:Math.round(h.value_point-m-he)}];}}));
dash.calc('holdings_calc',CR("holdings_calc",{title:'Holdings totals',description:'Sum of fund values, cost basis and gain or loss across the first account, plus the second 401(k) value.',inputs:['acct_a_holdings','acct_b_holdings'],
 fn:(nb,hi)=>{const r2=x=>Math.round(x*100)/100;const nbv=nb.reduce((s,x)=>s+x.value,0),hiv=hi.reduce((s,x)=>s+x.value,0);const cost=nb.reduce((s,x)=>s+x.quantity*x.cost_basis_per_share,0);const gain=nb.reduce((s,x)=>s+x.gain_loss,0);
  return [{total_all:r2(nbv+hiv),total_est:r2(nbv),total_hi:r2(hiv),cost_basis:r2(cost),gain_total:r2(gain),gain_pct:cost?Math.round(gain/cost*1000)/10:null,funds:nb.length+hi.length}];}}));
dash.calc('all_holdings',CR("all_holdings",{title:'All holdings, one list',description:'Every fund held, with its account, its share of that account, cost basis, gain or loss, return on cost where reported, and a small return history.',inputs:['acct_a_holdings','acct_b_holdings','holding_snapshots','acct_a_sources'],
 fn:(nb,hi,snaps,src)=>{
  const AN=acctNames(src,hi);nb=nb.filter(x=>typeof x.value==='number');hi=hi.filter(x=>typeof x.value==='number');snaps=snaps.filter(s=>s.snapshot_date&&s.price>0&&s.cost_basis_per_share>0);
  const totNb=nb.reduce((s,x)=>s+x.value,0),totHi=hi.reduce((s,x)=>s+x.value,0);
  const dates=[...new Set(snaps.map(s=>s.snapshot_date))].sort();
  const a=nb.map(x=>{
    const hist=dates.map(d=>snaps.find(s=>s.snapshot_date===d&&s.fund===x.fund));
    const spark=[0].concat(hist.filter(Boolean).map(s=>Math.round((s.price/s.cost_basis_per_share-1)*1000)/10));
    return {holding:x.fund,ticker:x.ticker||'',account:AN.nb,asset_class:x.asset_class||'Not yet classified',value:x.value,share_pct:Math.round(x.value/totNb*1000)/10,cost_basis:Math.round(x.quantity*x.cost_basis_per_share*100)/100,gain_loss:x.gain_loss,return_pct:x.cost_basis_per_share?Math.round((x.last_price/x.cost_basis_per_share-1)*1000)/10:null,spark:spark};});
  const b=hi.map(x=>({holding:x.fund,ticker:x.ticker,account:AN.hi,asset_class:x.asset_class,value:x.value,share_pct:Math.round(x.value/totHi*1000)/10,cost_basis:null,gain_loss:null,return_pct:null,spark:null}));
  return a.concat(b).sort((p,q)=>q.value-p.value);}}));
dash.calc('by_class',CR("by_class",{title:'Holdings by asset type',description:'Total value of all holdings by asset type.',inputs:['all_holdings'],
 fn:(ah)=>{const m=new Map();ah.forEach(h=>{const k=h.asset_class||'Not yet classified';m.set(k,(m.get(k)||0)+h.value);});const tot=[...m.values()].reduce((s,x)=>s+x,0);return [...m].map(([cls,value])=>({cls,value:Math.round(value*100)/100,share_pct:Math.round(value/tot*1000)/10})).sort((a,b)=>b.value-a.value);}}));
dash.calc('perf_series',CR("perf_series",{title:'Holding growth over time',description:'Return on cost for each holding at average cost and at each snapshot date.',inputs:['holding_snapshots'],
 fn:(snaps)=>{snaps=snaps.filter(s=>s.snapshot_date&&s.price>0&&s.cost_basis_per_share>0);const out=[];const keys=[...new Set(snaps.map(s=>s.account+'|'+s.fund))];const dates=[...new Set(snaps.map(s=>s.snapshot_date))].sort();
  keys.forEach(k=>{const rs=snaps.filter(s=>s.account+'|'+s.fund===k);out.push({fund:rs[0].fund,account:rs[0].account,point:'Avg cost',order:0,return_pct:0});
   dates.forEach((d,i)=>{const s=rs.find(x=>x.snapshot_date===d);if(s)out.push({fund:s.fund,account:s.account,point:d,order:i+1,return_pct:Math.round((s.price/s.cost_basis_per_share-1)*1000)/10});});});
  return out;}}));
dash.calc('plan_calc',CR("plan_calc",{title:'First account lifetime summary',description:'Plan statement totals with the yearly equivalent of the time-weighted return and the share of the ending balance that is market growth.',inputs:['plan_stats','plan_summary'],
 fn:(plan_stats,plan_summary)=>{const s=plan_stats.find(x=>x&&x.period_start&&x.period_end&&x.ending_balance);const gr=plan_summary.find(x=>x.item==='Market growth');if(!s||!gr)return [];const yrs=(new Date(s.period_end)-new Date(s.period_start))/(365.25*86400000);const g=gr.amount;
  return [{personal_return_pct:s.personal_return_pct,years:Math.round(yrs*100)/100,annualized_pct:Math.round((Math.pow(1+s.personal_return_pct/100,1/yrs)-1)*1000)/10,growth_share_pct:Math.round(g/s.ending_balance*1000)/10,ending_balance:s.ending_balance}];}}));
dash.calc('price_growth',CR("price_growth",{title:'Fund price growth',description:'Price change and yearly equivalent from the start date to the end date for each fund with a start price.',inputs:['price_history'],
 fn:(ph)=>ph.filter(x=>x.start_price>0&&x.end_price>0&&x.start_date&&x.end_date).map(x=>{const yrs=(new Date(x.end_date)-new Date(x.start_date))/(365.25*86400000);const g=(x.end_price/x.start_price-1)*100;return {fund:x.fund,start_price:x.start_price,end_price:x.end_price,start_date:x.start_date,end_date:x.end_date,growth_pct:Math.round(g*10)/10,annualized_pct:Math.round((Math.pow(x.end_price/x.start_price,1/yrs)-1)*1000)/10,note:x.note};}).sort((a,b)=>b.growth_pct-a.growth_pct)}));
dash.calc('account_calc',CR("account_calc",{title:'Balances by account',description:'Each held account today: the first account split into its Traditional (pre-tax) and Roth source balances, and the second 401(k). The HSA is uninvested cash and is not included here.',inputs:['acct_a_sources','acct_b_holdings'],
 fn:(acct_a_sources,acct_b_holdings)=>{const AN=acctNames(acct_a_sources,acct_b_holdings);
  const r2=x=>Math.round(x*100)/100;
  const pre=acct_a_sources.filter(s=>s.tax_type==='Pre-tax').reduce((s,x)=>s+x.balance,0);
  const roth=acct_a_sources.filter(s=>s.tax_type==='Roth').reduce((s,x)=>s+x.balance,0);
  const hi=acct_b_holdings.reduce((s,x)=>s+x.value,0);
  return [{account:AN.aPre,bucket:'Pre-tax',now_usd:r2(pre)},{account:AN.aRoth,bucket:'Roth',now_usd:r2(roth)},{account:AN.hi,bucket:'401(k)',now_usd:r2(hi)},{account:'HSA',bucket:'HSA',now_usd:null}];
 }}));
dash.calc('pending_calc',CR("pending_calc",{title:'Pending tax refunds',description:'Refunds still owed to you, the tax balance owed that could be applied first, and what is left if it is fully applied.',inputs:['assets_other','liabilities'],
 fn:(assets_other,liabilities)=>{const pend=assets_other.filter(a=>a.type==='Receivable').reduce((s,a)=>s+a.value_point,0);const irs=liabilities.filter(l=>l.type==='Tax').reduce((s,l)=>s+(l.balance||0),0);return [{pending_refunds:pend,irs_balance:irs,after_offset:Math.round((pend-Math.min(pend,irs))*100)/100}];}}));
dash.calc('paycheck_calc',CR("paycheck_calc",{title:'Latest paycheck',description:'Take-home, taxes and deductions on the latest pay stub, and the monthly take-home.',inputs:['paystubs'],
 fn:(s)=>{const a=[...s].sort((x,y)=>x.pay_date<y.pay_date?-1:1);const l=a[a.length-1];const f=a[0];return [{pay_date:l.pay_date,gross:l.gross,take_home:l.take_home_core,take_home_month:Math.round(l.take_home_core*2),tax_rate_pct:Math.round(l.taxes/l.gross*1000)/10,saved_per_check:l.k401_you+l.hsa_you,first_take_home:f.take_home_core,stub_count:a.length}];}}));
dash.calc('paystub_baseline',CR("paystub_baseline",{title:'Pay stub year to date',description:'Year-to-date totals printed on each pay stub: the tax rate, the share kept as take-home, and what was saved (401(k) plus HSA, both parts), per pay date. The last row is the latest.',inputs:['paystubs'],
 fn:(s)=>{const a=s.filter(x=>typeof x.ytd_gross==='number'&&x.ytd_gross>0).sort((x,y)=>x.pay_date<y.pay_date?-1:1);const r1=v=>Math.round(v*10)/10;
  return a.map((x,i)=>{const sv=(x.ytd_401k_you||0)+(x.ytd_hsa_you||0)+(x.ytd_hsa_employer||0);return {pay_date:x.pay_date,ytd_gross:x.ytd_gross,tax_rate_pct:r1((x.ytd_taxes||0)/x.ytd_gross*100),take_home_pct:r1((x.ytd_net||0)/x.ytd_gross*100),saved_ytd:Math.round(sv*100)/100,saved_pct:r1(sv/x.ytd_gross*100),latest:i===a.length-1};});}}));
dash.calc('bills_calc',CR("bills_calc",{title:'Monthly bills total',description:'Sum of monthly bills, the yearly equivalent, and the share of gross monthly pay.',inputs:['bills','income_pay'],
 fn:(bills,income_pay)=>{const t=bills.reduce((s,x)=>s+x.monthly_amount,0);const g=income_pay.reduce((s,i)=>s+i.annual_gross,0)/12;const ess=bills.filter(b=>b.essential==='Yes').reduce((s,x)=>s+x.monthly_amount,0);return [{total_monthly:t,total_annual:t*12,pct_of_gross:Math.round(t/g*1000)/10,essential_monthly:ess,optional_monthly:t-ess}];}}));
dash.calc('bills_takehome',CR("bills_takehome",{title:'Bills against take-home',description:'Monthly take-home pay (latest stub take-home times paychecks per year, divided by 12, an estimate) and the monthly bills as a share of it. Gross figures stay in the bills and debt ratio calcs.',inputs:['bills','income_pay','paystubs'],
 fn:(bills,income_pay,paystubs)=>{const t=bills.reduce((s,x)=>s+x.monthly_amount,0);const b0=income_pay.find(i=>i.kind==='Base');const st=paystubs&&paystubs.length?[...paystubs].sort((a,b)=>a.pay_date<b.pay_date?-1:1).pop():null;
  const th=st&&b0&&b0.paychecks_per_year>0&&typeof st.take_home_core==='number'?st.take_home_core*b0.paychecks_per_year/12:null;
  return [{take_home_month:th,take_home_per_paycheck:th==null?null:st.take_home_core,paychecks_per_year:th==null?null:b0.paychecks_per_year,bills_monthly:t,pct_of_take_home:th?Math.round(t/th*1000)/10:null,gross_monthly:income_pay.reduce((s,i)=>s+i.annual_gross,0)/12}];}}));
dash.calc('bills_cat',CR("bills_cat",{title:'Bills by category',description:'Monthly bill totals grouped by category with each category share of the total.',inputs:['bills'],
 fn:(bills)=>{const m=new Map();bills.forEach(b=>m.set(b.category,(m.get(b.category)||0)+b.monthly_amount));const t=[...m.values()].reduce((s,x)=>s+x,0);return [...m.entries()].map(([category,total])=>({category,total,share_pct:Math.round(total/t*1000)/10})).sort((a,b)=>b.total-a.total);}}));
dash.calc('contrib_calc',CR("contrib_calc",{title:'Contributions against limits',description:'Yearly, monthly and per-paycheck contributions from the pay stubs next to each account limit, with the room left and what each adds by the target age.',inputs:['contributions','income_pay','retirement_plan','assumptions'],
 fn:(contributions,income_pay,retirement_plan,asm)=>{
  const b0=income_pay.find(i=>i.kind==='Base');const base=b0?b0.per_paycheck:null;contributions=realRows(contributions);
  const gp=k=>{const r=retirement_plan.find(x=>x.item===k);return r?r.value:null;};const ra=asm.find(a=>a.item==='return_base_real_pct');const rate=ra&&typeof ra.value==='number'?ra.value/100:null;
  if(!base||!contributions.length)return [];const yrs=gp('target_age')!=null&&gp('current_age')!=null?gp('target_age')-gp('current_age'):null;const gg=rate!=null&&yrs!=null?Math.pow(1+rate,yrs):null;const fv=c=>gg==null?null:rate===0?Math.round(c*yrs):Math.round(c*(gg-1)/rate);
  const plan=c=>gp(CONTRIB_ROLE[contribRole(c)].plan_item);
  return contributions.map(c=>{const n=c.paychecks_per_year;const total=c.employee_annual+c.employer_annual;const shared=/HSA/i.test(c.account||'');const room=shared?c.limit_annual-c.employer_annual:c.limit_annual;const nowpp=Math.round(c.employee_annual/n*100)/100;const maxpp=Math.round(room/n*100)/100;
   return {account_id:c.account_id,account:c.account,tax_type:c.tax_type,employee_annual:c.employee_annual,employer_annual:c.employer_annual,total:total,limit:c.limit_annual,plan_total:plan(c),gap:c.limit_annual-total,pct_of_limit:Math.round(total/c.limit_annual*1000)/10,per_paycheck_now:nowpp,per_paycheck_max:maxpp,pct_pay_now:Math.round(nowpp/base*1000)/10,pct_pay_max:Math.round(maxpp/base*1000)/10,fv_now:fv(total),fv_plan:fv(c.limit_annual),monthly_now:Math.round(c.employee_annual/12),plan_monthly:Math.round(room/12)};});
 }}));
dash.calc('retire_model',CR("retire_model",{title:'Retirement model',description:'Everything the retirement chart needs: starting balance now, ages, goals, return paths from the assumptions file, each account contribution today and with every account at its limit (maxed), and the balance at the target age for both on all three paths. Contributions at year end, before tax, in today\'s dollars.',inputs:['assumptions','retirement_plan','contributions','income_pay','acct_a_holdings','acct_b_holdings'],
 fn:(asm,rp,contrib,inc,nb,hi)=>{
  const g=k=>{const x=rp.find(r=>r.item===k);return x?x.value:null;};const a=k=>{const x=asm.find(r=>r.item===k);return x?x.value:null;};
  {const need=['current_age','target_age','goal_low'].filter(k=>typeof g(k)!=='number').concat(['return_cautious_real_pct','return_base_real_pct','return_optimistic_real_pct','inflation_pct'].filter(k=>typeof a(k)!=='number'));
   const b=inc.find(i=>i.kind==='Base');contrib=realRows(contrib);if(need.length||!b||!contrib.length)return [];}
  const nbv=nb.reduce((s,x)=>s+x.value,0),hiv=hi.reduce((s,x)=>s+x.value,0);const start=nbv+hiv;
  const age0=g('current_age'),age1=g('target_age'),n=age1-age0;
  const rates=[a('return_cautious_real_pct'),a('return_base_real_pct'),a('return_optimistic_real_pct')];const infl=a('inflation_pct');
  const nominal=rates.map(r=>Math.round(((1+r/100)*(1+infl/100)-1)*1000)/10);
  /* one account per contribution row that exists (no account is assumed): its role (401(k), HSA, IRA) picks the plan item */
  const seen=new Set();const accts=['k401','hsa','roth'].map(role=>contrib.find(c=>contribRole(c)===role&&!seen.has(c))).filter(Boolean).map(c=>{seen.add(c);const role=contribRole(c);const R0=CONTRIB_ROLE[role];
    return {key:role,name:c.account||R0.short,short:R0.short,tax:c.tax_type,emp_now:c.employee_annual||0,er:c.employer_annual||0,limit:c.limit_annual,plan_total:g(R0.plan_item)!=null?g(R0.plan_item):c.limit_annual};});
  const k=accts.find(x=>x.key==='k401')||accts[0];
  /* 401(k): employer money counts against the total additions limit, not the employee deferral limit; HSA: the limit covers both */
  accts.forEach(x=>{const shared=x.key==='hsa';x.plan_emp=shared?x.plan_total-x.er:x.plan_total;x.max_emp=shared?x.limit-x.er:x.limit;});
  const fv=(c,rt)=>{const q=Math.pow(1+rt/100,n);return c*(q-1)/(rt/100);};
  const grow=(rt)=>start*Math.pow(1+rt/100,n);
  const now_total=accts.reduce((s,x)=>s+x.emp_now+x.er,0),plan_total=accts.reduce((s,x)=>s+x.plan_total,0);
  const sc=(name,tot)=>({scenario:name,annual:tot,end_lo:Math.round(grow(rates[0])+fv(tot,rates[0])),end_mid:Math.round(grow(rates[1])+fv(tot,rates[1])),end_hi:Math.round(grow(rates[2])+fv(tot,rates[2]))});
  const scenarios=[sc('Today\'s pay stubs',now_total),sc('At the limit (maxed)',plan_total)];
  const lo=g('goal_low'),hi2=g('goal_high');
  const gb=Math.pow(1+rates[1]/100,n);
  const need=Math.round((lo-start*gb)*(rates[1]/100)/(gb-1));
  const cur=accts.map(x=>x.emp_now+x.er);const bal=c=>Math.round(grow(rates[1])+fv(c,rates[1]));
  const ladder=[{step:'Today\'s pay stubs',annual:cur.reduce((s,x)=>s+x,0),balance:bal(cur.reduce((s,x)=>s+x,0))}];
  accts.forEach((x,i)=>{cur[i]=x.plan_total;const t=cur.reduce((s,y)=>s+y,0);ladder.push({step:x.short+' to limit',annual:t,balance:bal(t)});});
  return [{start:Math.round(start*100)/100,start_nb:Math.round(nbv*100)/100,start_hi:Math.round(hiv*100)/100,age0:age0,age1:age1,years:n,goal_low:lo,goal_high:hi2,rates:rates,nominal:nominal,inflation:infl,paychecks:(contrib.find(c=>c.paychecks_per_year)||{}).paychecks_per_year||b0pay(inc),base_pay_pp:inc.find(i=>i.kind==='Base').per_paycheck,accts:accts,now_total:now_total,plan_total:plan_total,scenarios:scenarios,ladder:ladder,need_annual:need}];
 }}));
dash.calc('pace_calc',CR("pace_calc",{title:'Balance at target age',description:'Balance at the target age for today and with every account at its limit (maxed) on each return path, and whether the base path reaches the low goal.',inputs:['retire_model'],
 fn:(m)=>{if(!m.length)return [];const lo=m[0].goal_low;return m[0].scenarios.map(s=>({scenario:s.scenario,annual:s.annual,end_lo:s.end_lo,end_mid:s.end_mid,end_hi:s.end_hi,pct_low_goal:Math.round(s.end_mid/lo*1000)/10,on_pace:s.end_mid>=lo?'Yes':'No'}));}}));
dash.calc('age60_calc',CR("age60_calc",{title:'Balance at 60 headline',description:'Balance at the target age at the base return for today\'s contribution rate and with every account at its limit (maxed), with the gap to the low goal.',inputs:['retire_model'],
 fn:(m)=>{if(!m.length)return [];const x=m[0],a=x.scenarios[0],b=x.scenarios[1];
  return [{age:x.age1,now_end:a.end_mid,plan_end:b.end_mid,now_annual:a.annual,plan_annual:b.annual,extra_year:b.annual-a.annual,extra_month:Math.round((b.annual-a.annual)/12),goal_low:x.goal_low,gap_now:x.goal_low-a.end_mid,over_plan:b.end_mid-x.goal_low,now_lo:a.end_lo,now_hi:a.end_hi,plan_lo:b.end_lo,plan_hi:b.end_hi}];}}));
dash.calc('need_calc',CR("need_calc",{title:'Saving needed for the low goal',description:'Yearly saving that reaches the low goal at the base return from today\'s balances, contributions at year end.',inputs:['retire_model'],
 fn:(m)=>m.length?[{need_7_annual:m[0].need_annual}]:[]}));
dash.calc('dti_calc',CR("dti_calc",{title:'Debt to income',description:'Housing and total debt payments over gross monthly income, using the payments entered so far. The missing count shows debts still without a payment. The estimate fields add 4 percent of the balance of credit cards with no payment entered. Rent (Housing bills) joins the standard ratio only when no mortgage is on file; otherwise it is a second ratio. Total monthly obligations (one definition for the whole page) = every monthly bill (rent included, once) plus every debt payment entered; a debt still missing its payment is named, never guessed.',inputs:['income_pay','liabilities','bills'],
 fn:(income_pay,liabilities,bills)=>{
  const sum=(a,f)=>a.reduce((s,x)=>s+(f(x)||0),0);
  const base=sum(income_pay.filter(i=>i.kind==='Base'),i=>i.annual_gross)/12;
  const all=sum(income_pay,i=>i.annual_gross)/12;
  const counted=liabilities.filter(l=>l.counts_in_dti==='Y');
  const missing=counted.filter(l=>l.monthly_payment==null).length;
  const total0=sum(counted,l=>l.monthly_payment);
  const housing0=sum(liabilities.filter(l=>l.type==='Mortgage'||l.type==='HELOC'),l=>l.monthly_payment);
  const billsT=sum(realRows(bills),b=>b.monthly_amount);const rentRows=(bills||[]).filter(b=>b.category==='Housing'&&b.monthly_amount>0);const rent=sum(rentRows,b=>b.monthly_amount);
  const rentIn=rent>0&&!liabilities.some(l=>l.type==='Mortgage'&&l.balance>0);const total=total0+(rentIn?rent:0),housing=housing0+(rentIn?rent:0);
  const pct=x=>Math.round(x*1000)/10;
  const noPay=counted.filter(l=>l.monthly_payment==null);
  const cardsNoPay=noPay.filter(l=>openCard(l)&&l.balance>0);
  const cardBal=sum(cardsNoPay,l=>l.balance);const est=Math.round(cardBal*0.04*100)/100;
  return [{rent_monthly:Math.round(rent*100)/100,rent_names:rentRows.map(b=>b.name),rent_in_standard:rentIn,back_end_with_rent_pct:pct((total0+rent)/base),obligations_monthly:Math.round((total0+billsT)*100)/100,obligations_annual:Math.round((total0+billsT)*12*100)/100,obligations_bills:Math.round(billsT*100)/100,obligations_debts:Math.round(total0*100)/100,missing_names:noPay.map(l=>l.name),est_card_balance:Math.round(cardBal*100)/100,est_card_payment:est,debt_payments_est:Math.round((total+est)*100)/100,back_end_est_pct:pct((total+est)/base),base_monthly:Math.round(base),total_monthly:Math.round(all),debt_payments:Math.round(total*100)/100,housing_payments:Math.round(housing*100)/100,missing_payments:missing,front_end_pct:pct(housing/base),back_end_pct:pct(total/base),back_end_with_variable_pct:pct(total/all),total_balance:Math.round(sum(liabilities,l=>l.balance)*100)/100}];
 }}));
dash.calc('payoff_calc',CR("payoff_calc",{title:'Debt payoff schedule',description:'Month by month balance of each debt with a balance if today\'s payment continues. The first payment is in the current month, the same start as the payoff plan (payoff_engine), so both give the same payoff month on minimums. The mortgage uses its principal and interest part, a tax balance without a rate carries no interest, and a credit line uses its payment with no new draws.',inputs:['liabilities'],
 fn:(liab)=>{
  const T0=(typeof window!=='undefined'&&window.__TODAY)||new Date().toISOString().slice(0,10);const asof=T0.slice(0,7)+'-01';const out=[];
  liab.filter(l=>l.balance>0).forEach(l=>{
   const pay=l.principal_interest||l.monthly_payment||0;const r=(l.rate_pct||0)/1200;let b=l.balance;const bal=[b];let interest=0,m=0,ok=true;
   if(!(pay>0)){out.push({name:l.name,type:l.type,liability_id:l.liability_id,rate_pct:l.rate_pct,balance:l.balance,payment:null,months:null,payoff:'payment not added',interest_total:null,balances:bal,start_date:asof});return;}
   while(b>0.005&&m<720){const i=b*r;if(pay<=i+1e-9){ok=false;break;}interest+=i;b=Math.max(0,b+i-pay);m++;bal.push(Math.round(b*100)/100);}
   const d=new Date(asof+'T00:00:00Z');d.setUTCMonth(d.getUTCMonth()+m-1);
   out.push({name:l.name,type:l.type,liability_id:l.liability_id,rate_pct:l.rate_pct,balance:l.balance,payment:pay,months:ok?m:null,payoff:ok?d.toISOString().slice(0,7):'never at this payment',interest_total:Math.round(interest),balances:bal,start_date:asof});});
  return out;}}));
dash.calc('pay_flow',CR("pay_flow",{title:'Where gross monthly pay goes',description:'Links for the pay flow: gross monthly pay into debt payments, bills, your saving from pay and everything else, then into each debt, bill category and saving account.',inputs:['income_pay','liabilities','bills','contributions'],
 fn:(inc,liab,bills,contrib)=>{
  const base=inc.filter(i=>i.kind==='Base').reduce((s,i)=>s+i.annual_gross,0)/12;const r0=x=>Math.round(x);
  const debts=liab.filter(l=>l.counts_in_dti==='Y'&&l.monthly_payment>0);const debtT=debts.reduce((s,l)=>s+l.monthly_payment,0);
  const bt=bills.reduce((s,b)=>s+b.monthly_amount,0);
  const save=contrib.filter(c=>c.employee_annual>0);const saveT=save.reduce((s,c)=>s+c.employee_annual/12,0);
  const rest=base-debtT-bt-saveT;
  const out=[{source:'Gross pay',target:'Debt payments',value:r0(debtT),cls:'debt'},{source:'Gross pay',target:'Bills',value:r0(bt),cls:'bills'},{source:'Gross pay',target:'Saving from pay',value:r0(saveT),cls:'save'},{source:'Gross pay',target:'Taxes and everything else',value:r0(rest),cls:'rest'}];
  debts.sort((a,b)=>b.monthly_payment-a.monthly_payment).forEach(l=>out.push({source:'Debt payments',target:l.name,value:r0(l.monthly_payment),cls:'debt'}));
  const m=new Map();bills.forEach(b=>m.set(b.category,(m.get(b.category)||0)+b.monthly_amount));[...m].sort((a,b)=>b[1]-a[1]).forEach(([c,v])=>out.push({source:'Bills',target:c,value:r0(v),cls:'bills'}));
  save.forEach(c=>out.push({source:'Saving from pay',target:c.account.replace(' pre-tax','')+' (you)',value:r0(c.employee_annual/12),cls:'save'}));
  return out;}}));
dash.calc('pay_split',CR("pay_split",{title:'Gross pay split',description:'Monthly base pay divided into debt payments, bills, saving from the paycheck and everything else.',inputs:['dti_calc','bills_calc','contrib_calc'],
 fn:(d,b,c)=>{const base=d[0].base_monthly;const debt=d[0].debt_payments;const bills=b[0].total_monthly;const save=Math.round(c.reduce((s,x)=>s+x.employee_annual,0)/12);return [{part:'Debt payments',amount:Math.round(debt),base:base},{part:'Monthly bills',amount:Math.round(bills),base:base},{part:'Saving from pay',amount:save,base:base},{part:'Taxes and everything else',amount:Math.round(base-debt-bills-save),base:base}];}}));
