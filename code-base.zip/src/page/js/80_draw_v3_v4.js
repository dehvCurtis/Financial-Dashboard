/* ---------- v3: shared bits ---------- */
function v3steps(items,label){const ul=el('ul','mo-steps mx-steps');ul.setAttribute('aria-label',label);
  items.forEach(s=>{const li=el('li','mo-step'+(s.done?' done':s.now?' now':''),(s.done?'✓ ':'')+s.label);li.setAttribute('aria-label',(s.aria||s.label)+(s.done?', done':s.now?', next':', not yet'));ul.append(li);});return ul;}
function v3tick(pct,max,ticks,label,color){const w=el('div','mx-tb');w.setAttribute('role','img');w.setAttribute('aria-label',label);const t=el('div','mx-track');
  const f=el('i','mx-fill');f.style.width=(Math.max(0,Math.min(max,pct||0))/max*100)+'%';if(color)f.style.background=color;t.append(f);
  (ticks||[]).forEach(k=>{const b=el('b','mx-tick');b.style.left='calc('+(Math.min(max,k)/max*100)+'% - 1px)';t.append(b);});w.append(t);return w;}
function v3table(heads,rowsL,label){const tb=el('table','mx-tbl');if(label)tb.setAttribute('aria-label',label);const th=el('thead');const tr=el('tr');
  heads.forEach(h=>{const c=el('th',h.num?'num':null,h.t);c.scope='col';tr.append(c);});th.append(tr);tb.append(th);const bd=el('tbody');
  rowsL.forEach(r=>{const x=el('tr',r.cls||null);r.cells.forEach((v,i)=>{const c=el('td',heads[i].num?'num':null);if(v instanceof Node)c.append(v);else c.textContent=v==null?'n/a':String(v);x.append(c);});bd.append(x);});
  tb.append(bd);const w=el('div','mx-tblw');w.append(tb);return w;}
function v3kv(list){const d=el('div','mx-kvl');list.forEach(r=>{const x=el('div','mx-kvr'+(r.t?' t':''));const a=el('span','k');a.append(document.createTextNode(r.k));if(r.s)a.append(el('small',null,r.s));const b=el('span','v'+(r.cls?' '+r.cls:''),r.v);x.append(a,b);d.append(x);});return d;}
function v3head(box,title,sub){box.replaceChildren();const h=el('div','mx-chd');h.append(el('h2',null,title));if(sub)h.append(el('p','mx-sub',sub));box.append(h);}
const v3m=v=>Math.round(v*100)/100;
/* ---------- Home: weekly recap, moves, goals, season, since last month ---------- */
function drawRecap(){const box=$('hm-recap');if(!box)return;const R=one('recap_calc'),K=one('checkins_calc');
  if(!R||!K){box.hidden=false;v3head(box,'Weekly recap');box.append(needsEl(calcWhy(["recap_calc","checkins_calc"],'Needs: reported balances for every account')));return;}
  if(!R.visible){box.hidden=true;box.replaceChildren();return;}
  box.hidden=false;const L=R.latest;v3head(box,'Weekly recap','Check-in '+fdy(L.date)+(R.days_since?', '+R.days_since+(R.days_since===1?' day':' days')+' ago':', today'));
  const money_=L.prev_date?'Cards '+(L.cards_change<=0?'down ':'up ')+money2(Math.abs(L.cards_change))+', cash '+(L.cash_change>=0?'up ':'down ')+money2(Math.abs(L.cash_change))+' since '+fd(L.prev_date)+'.':'First check-in: cards '+money2(L.cards)+', cash '+money2(L.cash)+'. Changes show from the next check-in.';
  const lines=[['Money',money_],['Data',R.data_provided+' data items provided, '+R.data_needed+' still needed. The queue has no dates, so there is no weekly change yet.'],['Explained',L.unexplained_drift>0.005?money2(L.unexplained_drift)+' of drift unexplained in the check periods up to '+fd(L.date)+'.':'No unexplained drift in the check periods up to '+fd(L.date)+'.'],['Next',R.next_move||'Nothing urgent.']];
  const dl=el('div','mx-recap');lines.forEach(([k,t])=>{const r=el('div');r.append(el('b',null,k),el('span',null,t));dl.append(r);});box.append(dl);
  box.append(el('p','mo-note',K.count+' of the last '+K.total+' weeks checked in. '+(R.next_check?'Next check-in '+fd(R.next_check)+(R.days_to_next!=null?' (in '+R.days_to_next+(R.days_to_next===1?' day).':' days).'):'.'):'')));}
function drawMoves(){const box=$('hm-moves');if(!box)return;v3head(box,'What would move you up one rung','Estimates from your own numbers; score effects rerun the score on changed copies of your data');const M=rows('moves_calc');
  if(!M||!M.length){box.append(needsEl(calcWhy(["moves_calc"],'Needs: the age ladder, scores and payoff plan')));return;}
  const sd=(v,n)=>v==null?'':Math.abs(v)<0.05?n+' unchanged':n+' '+(v>0?'up ':'down ')+(Math.round(Math.abs(v)*10)/10);
  const ul=el('ul','mx-moves');M.forEach(m=>{const li=el('li');
    if(m.needs){li.append(el('span',null,m.title),el('span','eff mixed','Needs data'),el('span','w',m.needs));ul.append(li);return;}
    if(m.id==='k401')li.append(el('span',null,'Add '+money2(m.extra_month)+' a month to your 401(k) (to the limit)'),el('span','eff',m.next_pct+'% rung about '+Math.round(m.sooner)+' months sooner'),el('span','w','About '+Math.round(m.months_now)+' months at today\'s 401(k) pace, about '+Math.round(m.months_limit)+' at the limit, before growth. '+[sd(m.d_fin,'Financial Score'),sd(m.d_risk,'Risk Score')].filter(Boolean).join(', ')+' (estimate).'));
    if(m.id==='pay')li.append(el('span',null,m.title),el('span','eff',m.per_year==null?'Rate not on file':'Saves about '+money(Math.round(m.per_year))+' a year'),el('span','w','Pay '+money2(m.amount)+' this month'+(m.rate!=null?'; each extra dollar avoids about '+m.rate+' cents of interest a year':'')+'.'+(m.whatif_label?' Paying it from savings instead: '+[sd(m.d_fin,'Financial Score'),sd(m.d_risk,'Risk Score')].join(', ')+' (estimate).':'')));
    if(m.id==='cash')li.append(el('span',null,m.add>0?'Add '+money(Math.round(m.add))+' to the emergency fund':m.title),el('span','eff',m.add>0?'Reaches 3 months':'Done'),el('span','w','Cash covers '+v3m(m.months)+' months of essentials now. '+[sd(m.d_fin,'Financial Score'),sd(m.d_risk,'Risk Score')].filter(Boolean).join(', ')+(m.d_fin!=null?' (estimate).':'')));
    if(m.d_fin!=null&&(m.d_fin<-0.05||m.d_risk>0.05))li.querySelector('.eff').classList.add('mixed');ul.append(li);});
  box.append(ul);const b=el('button','mo-link','See the age ladder');b.type='button';b.addEventListener('click',()=>goTo('progress','hm-ladder'));box.append(b);}
function drawHomeGoals(){const box=$('hm-goals');if(!box)return;v3head(box,'Savings goals','How far along each goal is');const G=rows('goals_calc');
  const gs=G?G.filter(g=>g.kind==='goal'):[];
  if(!G)box.append(needsEl(calcWhy(["goals_calc"],'Needs: the savings goals dataset')));
  else if(!gs.length)box.append(el('p','mo-note mo-nogoal','No goals set yet. Tell Claude what you are saving for.'));
  gs.forEach(g=>{const r=el('div','mx-goal');const h=el('div','h');h.append(el('span',null,g.name),el('span','v',g.needs.length?(g.saved!=null?money(g.saved)+' saved':'Needs data'):money(g.saved)+' of '+money(g.target)));r.append(h);
    if(!g.needs.length){const t=pbar(g.pct*100,{max:100,tick:false});t.setAttribute('role','img');t.setAttribute('aria-label',g.name+' '+Math.round(g.pct*100)+' percent of the target');t.removeAttribute('aria-hidden');r.append(t);}
    else r.append(el('small','mo-needs','Needs: '+g.needs.join(', ')+'.'));box.append(r);});
  const b=el('button','mx-btn ghost','See goal plans');b.type='button';b.dataset.gotoId='card-goals';b.dataset.gotoName='Savings goals';b.dataset.tileKey='hm-goals';box.append(b);/* the tile link helper opens it */}
function seasonStrip(Z){const s=el('div','mx-sstrip');s.setAttribute('role','img');const got=Z.strip.filter(x=>x.checked).length;
  s.setAttribute('aria-label','Week '+Z.week+' of '+Z.weeks+'; '+got+(got===1?' week':' weeks')+' with a check-in so far');
  Z.strip.forEach(x=>{const i=el('i',x.state+(x.checked?' ok':''));i.title='Week '+x.i+', from '+fd(x.start)+(x.checked?', checked in':'');s.append(i);});return s;}
function drawSeason(){const box=$('hm-season');if(!box)return;const Z=one('seasons_calc');
  if(!Z){v3head(box,'Season');box.append(needsEl(calcWhy(["seasons_calc"],'Needs: dated balances or pay stubs')));return;}
  v3head(box,'Season '+Z.number+', '+Z.name,'Week '+Z.week+' of '+Z.weeks);box.append(el('p','mo-note','Three goals from your own numbers, no streaks to protect. Miss a week and the season just keeps going.'));
  box.append(seasonStrip(Z));box.append(el('p','mx-src','Filled: a week with a check-in. Outlined: this week.'));
  Z.goals.forEach(g=>{const r=el('div','mx-goal');const h=el('div','h');
    const v=g.needs?'Needs data':g.unit==='USD'?money(Math.round(g.have))+' of '+money(Math.round(g.target)):g.have+' of '+g.target+' weeks';h.append(el('span',null,g.title),el('span','v',v));r.append(h);
    if(g.progress!=null){const t=pbar(g.progress*100,{max:100,tick:false});t.setAttribute('role','img');t.removeAttribute('aria-hidden');t.setAttribute('aria-label',g.title+': '+Math.round(g.progress*100)+' percent');r.append(t);}
    if(g.needs)r.append(el('small','mo-needs',g.needs));
    else if(g.id==='debt')r.append(el('small',null,g.now>g.start?'Balance '+money2(g.now)+', '+money2(g.now-g.start)+' above the '+fd(g.start_date)+' start of '+money2(g.start)+'; charges after the statement count until it is paid.':'From '+money2(g.start)+' on '+fd(g.start_date)+' to '+money2(g.now)+' now.'));
    box.append(r);});
  const p=Z.past[0];box.append(el('p','mx-src',p?'Season '+p.number+', '+p.name+': '+p.note.charAt(0).toLowerCase()+p.note.slice(1)+'.':'This is the first season with data.'));}
function drawSince(){const box=$('hm-scores');if(!box||!box.firstChild)return;const Q=one('score_since_calc');const old=$('hm-since');if(old)old.remove();
  const p=el('p','mo-note');p.id='hm-since';
  if(!Q)p.textContent='Since last month: needs the scores history.';
  else if(!Q.available)p.textContent='Since last month: needs two month-end snapshots ('+Q.month_rows+' so far).';
  else p.textContent='Since '+fd(Q.from)+': Financial '+(Q.d_fin>=0?'▲ up ':'▼ down ')+(Math.round(Math.abs(Q.d_fin)*10)/10)+', Risk '+(Q.d_risk>=0?'▲ up ':'▼ down ')+(Math.round(Math.abs(Q.d_risk)*10)/10)+(Q.parts.length?'; mostly from '+Q.parts.map(x=>x.id+(x.from_new_data?' (new data)':'')).join(', '):'')+'.';
  const f=box.querySelector('details');if(f)box.insertBefore(p,f);else box.append(p);}
function drawCheckCount(){const cv=$('hm-cover');const K=one('checkins_calc');if(!cv||!K)return;const old=$('hm-ckc');if(old)old.remove();
  const p=el('p','mo-note',K.count+' of the last '+K.total+' weeks checked in. No streaks: a missed week is only an empty square in the weekly check-in on Home.');p.id='hm-ckc';const s=cv.querySelector('.mx-src');if(s)cv.insertBefore(p,s);else cv.append(p);}
/* ---------- Money: net worth milestones, loan to value, payoff fields ---------- */
function drawNwMilestones(){const box=$('nw-ms');if(!box)return;box.replaceChildren(el('h3',null,'Net worth milestones'));
  const ms=msMerged().filter(m=>m.family==='net_worth').slice(-3).reverse();
  if(!ms.length){box.append(el('p','mo-note','None yet. Each 50,000 crossing is recorded with its date, in both directions.'));return;}
  const ul=el('ul','mx-tasks');ms.forEach(m=>{const li=el('li');const t=el('div','tt');t.append(el('b',null,m.step),chip(m.status==='earned'?'Earned':'Retracted',m.status==='earned'?'ok':'warn'));li.append(t,el('small',null,(m.first_seen?'First seen ':'Since ')+fdy(m.earned_on)+'. '+m.note));ul.append(li);});box.append(ul);}
function drawLtv(){const box=$('mn-ltv');if(!box)return;v3head(box,'Loan to value','Mortgage only and with the HELOC, against lender reference lines');const T=one('ltv_calc');
  if(!T){box.append(needsEl(calcWhy(["ltv_calc"],'Needs: the house value and its loans')));return;}
  const lines=T.lines||[];const first=lines.filter(l=>/first lien/i.test(l.measure)),comb=lines.filter(l=>/combined/i.test(l.measure));
  [['Mortgage only (LTV)',T.first_lien_pct,first,T.first_balance],['Mortgage plus HELOC (combined)',T.combined_pct,comb,T.combined_balance]].forEach(([lab,p,ls,bal])=>{
    const r=el('div','mx-ltvr');const h=el('div','h');h.append(el('span',null,lab),el('b',null,p+'%'));r.append(h);
    r.append(v3tick(p,100,ls.map(l=>l.pct),lab+' '+p+' percent of the home value'+(ls.length?'; reference lines at '+ls.map(l=>l.pct+' percent').join(' and '):'')));
    r.append(el('small',null,ls.length?ls.map(l=>l.label).join('. ')+'.':'No reference line on file for this measure.'));box.append(r);});
  box.append(el('p','mo-note','LTV = mortgage / home value ('+money(Math.round(T.first_balance))+' / '+money(T.value)+'). Combined adds the HELOC ('+money(Math.round(T.combined_balance))+'). The home value is your own estimate; the PMI lines are measured on the original value, so they are references, not a test.'));
  const seen=new Set();const src=lines.filter(l=>{if(seen.has(l.source))return false;seen.add(l.source);return true;}).map(l=>l.source+', '+l.data_year+(l.confidence?', '+l.confidence+' confidence':''));
  if(src.length)box.append(el('p','mx-src','Sources: '+src.join('; ')+'. Lender rules vary.'));}
function drawPoFields(){const box=$('mn-fields');if(!box)return;box.replaceChildren();const L=rows('liabilities');if(!L)return;
  const v=x=>x==null||x===''?'not entered':String(x);
  const rowsL=L.filter(l=>l.type!=='Support').map(l=>({cells:[l.name,v(l.days_past_due),l.late_fee!=null?money2(l.late_fee):'not entered',l.credit_limit!=null?money(l.credit_limit):'not entered',v(l.rate_type),v(l.secured),v(l.promo_end_date),v(l.prepayment_penalty),l.next_due_date||l.next_due||'not entered']}));
  box.append(fold('Show table: Payoff fields per debt',mkTable([{t:'Debt'},{t:'Days past due'},{t:'Late fee',num:true},{t:'Credit limit',num:true},{t:'Rate type'},{t:'Secured'},{t:'Promo ends'},{t:'Prepayment penalty'},{t:'Next due'}],rowsL)));}
/* ---------- Retire: try a monthly amount, pace steps, benchmarks by age ---------- */
const TRY={c:null};
function drawTry(){const box=$('rt-ladder');const A=one('age_calc');if(!box||!box.firstChild)return;const old=$('rt-try');if(old)old.remove();const old2=$('rt-head2');if(old2)old2.remove();
  const w=el('div','mx-try');w.id='rt-try';
  if(!A||!A.ladder){w.append(el('h3',null,'Try a monthly amount'),needsEl(calcWhy(["age_calc"],'Needs: the age ladder (age, salary, retirement balance)')));box.append(w);return;}
  const L=A.ladder;const h3=box.querySelector('h3');if(h3){const p=el('p','mo-take','Retirement balance today: '+pc0(L.you_pct)+' of the guideline for your age. '+(L.next?'Next rung is '+L.next.pct+'% at '+money(Math.round(L.next.amount))+'.':'Every rung is reached.'));p.id='rt-head2';h3.after(p);}
  const ap=rows('assumptions')||[];const r=(ap.find(x=>x.item==='return_base_real_pct')||{}).value;const ct=rows('contributions')||[];
  const now=L.k401_per_year/12;const mx=Math.max(100,Math.ceil(ct.filter(c=>!/HSA/.test(c.account)).reduce((s,c)=>s+(c.limit_annual||0),0)/12/50)*50);
  if(TRY.c==null)TRY.c=Math.round(now);
  w.append(el('h3',null,'Try a monthly amount'));const lab=el('label','mx-tlab');lab.htmlFor='rt-try-rg';w.append(lab);
  const rg=el('input');rg.type='range';rg.id='rt-try-rg';rg.min='0';rg.max=String(mx);rg.step='10';rg.value=String(TRY.c);rg.setAttribute('aria-label','Monthly retirement contribution slider');w.append(rg);
  const out=el('div','mx-box');out.setAttribute('role','status');w.append(out);
  const note=el('p','mo-note',(r==null?'Needs: a base return in assumptions. ':r+'% a year after inflation, monthly. ')+'The guideline itself rises with age; this holds the guideline for '+L.age+' fixed. Display only, not a forecast.');w.append(note);
  const upd=()=>{const c=+rg.value;TRY.c=c;lab.textContent='Contribution: '+money(c)+' a month (401(k) and Roth IRA)';out.replaceChildren();
    if(r==null){out.append(needsEl(calcWhy(["age_calc"],'Needs: return_base_real_pct')));return;}
    const full=L.rungs.find(z=>z.pct===100);const nN=L.next?TRY_MONTHS(L.you_amount,L.next.amount,c,r):0;const nF=full?TRY_MONTHS(L.you_amount,full.amount,c,r):null;const nF0=full?TRY_MONTHS(L.you_amount,full.amount,now,r):null;
    const t=(n)=>n==null?'not within 100 years':'about '+n+(n===1?' month':' months');
    if(L.next)out.append(document.createTextNode('Next rung ('+L.next.pct+'%, '+money(Math.round(L.next.amount))+'): '+t(nN)+'. '));
    out.append(document.createTextNode('Full guideline for '+L.age+' ('+money(Math.round(full.amount))+'): '));out.append(el('b',null,t(nF)));
    out.append(document.createTextNode(nF!=null&&nF0!=null?(nF===nF0?', same as now.':nF<nF0?', '+(nF0-nF)+' months sooner than at today\'s '+money(Math.round(now))+'.':', '+(nF-nF0)+' months later than at today\'s '+money(Math.round(now))+'.'):'.'));};
  rg.addEventListener('input',upd);upd();box.append(w);}
function drawPaceSteps(){const box=$('rt-pace');if(!box)return;box.replaceChildren();const P=one('pace_steps_calc');
  box.append(el('h3',null,'Pace to your low goal, every account'));
  if(!P||P.needs){box.append(needsEl(calcWhy(["pace_steps_calc"],P&&P.needs||'Needs: the pace table')));return;}
  const nx=P.steps.find(s=>!s.done);box.append(v3steps(P.steps.map(s=>({label:s.step+'%',done:s.done,now:nx&&s.step===nx.step})),'Pace to your low goal, every account: '+Math.round(P.pct)+' percent'));
  box.append(el('p','mo-note','At today\'s saving, the base path reaches '+money(P.balance)+' at '+P.target_age+', '+(Math.round(P.pct*10)/10)+'% of your '+compact(P.goal_low)+' low goal.'));}
function drawBenchAge(){const box=$('rt-bench');if(!box)return;v3head(box,'Benchmarks and sources','By age, in dollars at your salary, with named sources');const B=one('bench_age_calc'),A=one('age_calc');
  if(!B||B.needs){box.append(needsEl(calcWhy(["bench_age_calc","age_calc"],B&&B.needs||'Needs: age, salary and the benchmarks dataset')));return;}
  const rg=x=>x?compact(x[0])+' to '+compact(x[1]):'none';
  box.append(v3table([{t:'Age'},{t:B.pub_guideline,num:true},{t:B.pub_range+' range',num:true}],B.rows.map(r=>({cls:r.you?'sel':null,cells:[r.age+(r.you?' (you)':''),r.fidelity==null?'n/a':money(Math.round(r.fidelity))+(r.fidelity_published?'':' *'),r.trowe?rg(r.trowe)+(r.trowe_published?'':' *'):'none']})),'Retirement guideline by age in dollars'));
  box.append(el('p','mo-note','Guideline in dollars at salary '+money(B.salary)+'. * between published ages the guideline is a straight line (derived). You at '+B.age+': '+(B.retirement!=null?money2(B.retirement)+', '+pc0(B.pct_fidelity)+' of the '+B.pub_guideline+' guideline and '+pc0(B.pct_trowe_low)+' of the low end of the '+B.pub_range+' range.':'Needs: retirement balance.')+' Each publisher states its own assumptions (saving rate, retirement age); see Sources below. Both are aspirational.'));
  box.append(el('p','mx-src','Sources: '+B.sources.map(s=>s.source.replace(/\s*\(.*?\)\s*$/,'')+', data year '+s.data_year).join('; ')+'.'));
  const bm=rows('age_benchmarks')||[];const used=A&&A.rows_used?A.rows_used.map(id=>bm.find(r=>r.id===id)).filter(Boolean):[];
  if(used.length){const fv=r=>{const u=r.unit||'';if(u==='USD')return money(r.value);if(/^x /.test(u))return Math.round(r.value*100)+'% of '+u.slice(2);if(/^percent/.test(u))return r.value+'%';if(/^months/.test(u))return r.value+' months';return r.value+' '+u;};
    const ul=el('ul','mx-srcl');used.forEach(r=>{const li=el('li');const h=el('div','h');h.append(el('b',null,r.metric.replace(/_/g,' ')+', '+r.statistic+' ('+r.age_group.replace(/_/g,' ')+')'),el('span','v',fv(r)));li.append(h,el('small',null,r.source.replace(/\s*\(.*?\)\s*$/,'')+', data year '+r.data_year+(r.confidence?', '+r.confidence+' confidence':'')));ul.append(li);});
    box.append(fold('Sources for the age stats ('+used.length+' rows)',ul));}}
/* ---------- Cash: runway, pay stub tables, gap per account, check-ins ---------- */
function drawRunway(){const box=$('cs-runway');if(!box)return;aboutSync();box.replaceChildren(el('h2',null,'Cash runway'));const R=one('runway_calc');
  if(!R||R.needs){box.append(needsEl(calcWhy(["runway_calc"],R&&R.needs||'Needs: cash balances, bills and debt payments')));return;}
  const m=isFinite(R.months)&&R.months>0?R.months:0,tgt=R.guideline.low||3,mx=Math.max(6,tgt*2,Math.ceil(m));
  /* half circle gauge: the arc fills with the months of cash, a tick marks the 3 month target */
  const ns='http://www.w3.org/2000/svg',cx=130,cy=124,rr=100,len=Math.PI*rr;const g=el('div','mx-gauge');
  const svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 -18 260 168');svg.setAttribute('role','img');svg.setAttribute('aria-label','Cash runway gauge: '+v3m(m)+' months of cash; target '+tgt+' months; the scale ends at '+mx+' months');
  const arc='M'+(cx-rr)+' '+cy+' A'+rr+' '+rr+' 0 0 1 '+(cx+rr)+' '+cy;
  const bg=document.createElementNS(ns,'path');bg.setAttribute('d',arc);bg.setAttribute('class','gbg');
  const fg=document.createElementNS(ns,'path');fg.setAttribute('d',arc);fg.setAttribute('class','gfg'+(m<1?' low':''));fg.setAttribute('stroke-dasharray',(Math.max(0,Math.min(1,m/mx))*len).toFixed(2)+' '+len.toFixed(2));
  const t=Math.min(1,tgt/mx),tx=cx-rr*Math.cos(Math.PI*t),ty=cy-rr*Math.sin(Math.PI*t),ux=-Math.cos(Math.PI*t),uy=-Math.sin(Math.PI*t);
  const tk=document.createElementNS(ns,'line');tk.setAttribute('x1',(tx-ux*14).toFixed(1));tk.setAttribute('y1',(ty-uy*14).toFixed(1));tk.setAttribute('x2',(tx+ux*14).toFixed(1));tk.setAttribute('y2',(ty+uy*14).toFixed(1));tk.setAttribute('class','gtick');
  const tt=document.createElementNS(ns,'text');tt.setAttribute('x',(tx+ux*26).toFixed(1));tt.setAttribute('y',(ty+uy*26+4).toFixed(1));tt.setAttribute('text-anchor','middle');tt.setAttribute('class','gtx');tt.textContent=tgt+' mo target';
  const z=document.createElementNS(ns,'text');z.setAttribute('x',cx-rr);z.setAttribute('y',cy+18);z.setAttribute('text-anchor','middle');z.setAttribute('class','gtx');z.textContent='0';
  svg.append(bg,fg,tk,tt,z);g.append(svg);
  const big=el('p','big');big.append(srcNum(v3m(m)+' months of cash','runway','Source: cash balances over essentials. Formula and sources in About this'));g.append(big);box.append(g);
  box.append(el('p','mo-note mx-nextstep',R.next?'Add '+money2(R.next.gap)+' to reach '+(R.next.months===1?'1 month':R.next.months+' months'):'Every emergency step is reached.'));
  const ch=el('div','mx-chips');ch.append(aboutChip('Essentials '+money2(R.mustpay)+' a month',''));if(m<1)ch.append(aboutChip('Under 1 month of cash','warn'));box.append(ch);
  const ab=[];
  ab.push(el('p','mo-note','Months of cash = cash '+money2(R.liquid)+' (savings plus checking) divided by essentials '+money2(R.mustpay)+' a month: essential bills '+money2(R.ess_bills)+' plus debt payments '+money2(R.debt_payments)+'. Essentials are the bills and debt payments you cannot skip. This is the Emergency fund score part.'));
  if(R.guideline.low!=null)ab.push(el('p','mo-note','Guideline: '+R.guideline.low+' months, or '+R.guideline.high+' with a mortgage and one income. The gauge scale ends at '+mx+' months.'));
  const w=el('div');w.append(el('p','mx-src','Emergency fund steps, in months'));w.append(v3steps(R.steps.map(s=>({label:String(s.months),aria:s.months+(s.months===1?' month':' months'),done:s.reached,now:R.next&&s.months===R.next.months})),'Emergency fund steps: 0.5, 1, 2, 3 and 6 months'));ab.push(w);
  if(R.next){ab.push(el('p','mo-note','Next step: '+money2(R.next.gap)+' more reaches '+(R.next.months===1?'1 month':R.next.months+' months')+' ('+money2(R.next.target)+'). '+(R.plan_keep>0.005?'The payoff plan keeps '+money2(R.plan_keep)+' of this month\'s surplus for that and puts '+money2(R.plan_extra)+' toward debt.':'')+(R.steps[3]&&!R.steps[3].reached?' 3 months needs '+money2(R.steps[3].gap)+' more.':'')));}
  ab.push(el('p','mx-src','Bills and the coming due dates are on the Bills page. This card keeps only the essentials total.'));
  box.append(aboutFold('runway',ab));}
/* Bills page: Coming up (moved here from the Cash runway card; one list of the debt and bill due dates in the next 45 days) */
function drawComing(){const box=$('bl-coming');if(!box)return;aboutSync();box.replaceChildren(el('h2',null,'Coming up'));const R=one('runway_calc');
  if(!R||R.needs){box.append(needsEl(calcWhy(["runway_calc"],R&&R.needs||'Needs: bills, debts and due dates')));return;}
  if(!R.coming.length)box.append(el('p','mo-note','No due dates in the next 45 days on file.'));
  else box.append(v3kv(R.coming.map(c=>({k:c.name,s:(c.shutoff?'Shut-off notice: pay the past due part by '+fd(c.date):c.late?c.days_past_due+' days past due':(c.paid_for?'Paid for '+MN[+c.paid_for.slice(5,7)-1]+' '+c.paid_for.slice(0,4)+', next '+fd(c.date):fd(c.date)))+(c.late_after?', late after '+fd(c.late_after):''),v:(c.late||c.shutoff?'\u26a0 ':'')+(c.statement?'Statement '+money2(c.amount)+(c.minimum!=null?', minimum '+money2(c.minimum):''):money2(c.amount)),cls:c.late||c.shutoff?'bad':null}))));
  if(R.coming_needs.length)box.append(el('p','mo-needs mo-note','Needs: a due date for '+R.coming_needs.join(', ')+'.'));
  box.append(aboutFold('coming',['Debt and bill due dates through '+fd(R.window_end)+', from each debt\'s next due date or due day and each bill\'s due day. A month already paid is skipped; spending lines have no due day.'].concat(R.coming.filter(c=>c.statement_due_day&&c.due_day&&c.statement_due_day!==c.due_day).map(c=>c.name+': you pay by the '+ordn(c.due_day)+'; the statement says due the '+ordn(c.statement_due_day)+'.'))));}
function drawStubTables(){const box=$('pc-tables');if(!box)return;box.replaceChildren();const R=rows('stubcheck_calc');
  if(!R||!R.length){box.append(needsEl(calcWhy(["stubcheck_calc"],'Needs: pay stubs')));return;}
  const stf=fold('Show table: pay stubs',v3table([{t:'Pay date'},{t:'Take-home',num:true},{t:'Taxes',num:true},{t:'401(k)',num:true},{t:'Health',num:true}],R.map(s=>({cells:[fd(s.pay_date),money2(s.take_home),money2(s.taxes),money2(s.k401),money2(s.health)]})),'Pay stubs, newest first'));stf.id='pc-stubs';box.append(stf);
  const m=R.filter(s=>s.deposit!=null).length;
  const f=fold('Show table: stub check against the bank',v3table([{t:'Stub'},{t:'Net pay',num:true},{t:'Deposit seen',num:true},{t:'Gap',num:true}],R.map(s=>({cells:[fd(s.pay_date),money2(s.net_pay),s.deposit==null?'Needs: bank statement':money2(s.deposit),s.gap==null?'n/a':money2(s.gap)]})),'Stub deposits checked against the bank'));
  f.append(el('p','mo-note',m+' of '+R.length+' stubs have a matching deposit in the cash events. Health is the HSA you put in plus benefits.'));box.append(f);}
function drawGap(){const box=$('cs-gap');if(!box)return;v3head(box,'Gap per account','Reported minus expected at the latest check, every account');const D=one('drift_all');
  if(!D){box.append(needsEl(calcWhy(["drift_all"],'Needs: reported balances')));return;}
  const rowsG=[],needs=[];D.accounts.forEach(a=>{const p=[...a.points].reverse().find(z=>z.drift!=null);if(p)rowsG.push({a:a.account,card:a.card,p});else needs.push(a.account);});
  if(!rowsG.length){box.append(needsEl(calcWhy(["drift_all"],'Needs: two reported balances on one account')));}
  else{const W=(box.clientWidth||340)-2,rh=34,H=rowsG.length*rh+28,ml=96,mr=8;const svg=mkSvg(box,W,H,'Dollar drift per account at the latest check: '+rowsG.map(r=>r.a+' '+money2(r.p.drift)).join('; ')+(needs.length?'; needs a second balance: '+needs.join(', '):''));
    const mx=Math.max(25,d3.max(rowsG,r=>Math.abs(r.p.drift)));const lw=70;const x=d3.scaleLinear([-mx,mx],[ml+lw,W-mr-lw]);const tip=mkTip(box);{const lg=legendEl([{label:'Gap of $25 or less: accent bar',color:'var(--mo-accent)'},{label:'Gap over $25: warning bar, worth a look',color:'var(--mo-warn-f)'}]);lg.classList.add('mx-chartleg');box.append(lg);}
    svg.append('line').attr('x1',x(0)).attr('x2',x(0)).attr('y1',4).attr('y2',H-22).attr('stroke','var(--mo-muted)').attr('stroke-width',1);
    rowsG.forEach((r,i)=>{const y=8+i*rh;const v=r.p.drift;const big=Math.abs(v)>25;
      svg.append('text').attr('x',0).attr('y',y+13).attr('font-size',12.5).attr('fill','var(--mo-fg)').text(r.a+(r.card?' (card)':''));
      const x0=x(Math.min(0,v)),w=Math.max(2,Math.abs(x(v)-x(0)));
      svg.append('rect').attr('x',x0).attr('y',y+2).attr('width',w).attr('height',16).attr('rx',3).attr('fill',big?'var(--mo-warn-f)':'var(--mo-accent)')
        .on('pointermove',ev=>tip.show(ev,[r.a,fd(r.p.from)+' to '+fd(r.p.to),'Expected '+money2(r.p.expected),'Reported '+money2(r.p.reported),'Gap '+money2(v)])).on('pointerleave',()=>tip.hide());
      const lab=(v>0?'+':'')+money2(v);const right=v>=0;
      svg.append('text').attr('x',right?Math.max(x(v),x(0))+4:x(v)-4).attr('y',y+14).attr('font-size',12).attr('text-anchor',right?'start':'end').attr('fill','var(--mo-fg)').attr('font-weight',650).text(lab);});
    svg.append('text').attr('x',x(0)).attr('y',H-6).attr('text-anchor','middle').attr('font-size',11).attr('fill','var(--mo-muted)').text('0 = every movement explained');
    box.append(v3table([{t:'Account'},{t:'Expected',num:true},{t:'Reported',num:true},{t:'Gap',num:true}],rowsG.map(r=>({cells:[r.a,money2(r.p.expected),money2(r.p.reported),(r.p.drift>0?'+':'')+money2(r.p.drift)]})),'Expected, reported and gap per account'));}
  if(needs.length)box.append(el('p','mo-needs mo-note','Needs a second balance: '+needs.join(', ')+'.'));
  box.append(el('p','mo-note','On a card a positive gap is spending not loaded yet; on a bank account a negative gap is money that left without a known movement. Bars over 25 dollars use the warning color.'));}
/* a collapsible section on Home (87_home_quick.js): the header keeps the weeks count and this week's state, the body holds the rest */
function drawCheckins(){const box=$('cs-checkin');if(!box)return;const body=box.querySelector(':scope > .mo-collbody');const tg=body||box;tg.replaceChildren();
  drawCheckinBody(tg);const s=checkinStatus(one('checkins_calc'));const nd=tg.querySelector('.mo-needs');
  collapsible(box,'Weekly check-in',s?s.text:(nd?nd.textContent:''),s?s.kind:'warn','Every account on the same few days, once a week');homeQuick(box);}
function drawCheckinBody(box){const K=one('checkins_calc');
  if(!K||!K.expected){box.append(needsEl(calcWhy(["checkins_calc"],'Needs: reported balances for every account')));return;}
  const sent=K.count+' of the last '+K.total+' weeks checked in.';box.append(el('p','mo-take',sent));
  const s=el('div','mx-wstrip');s.setAttribute('role','img');s.setAttribute('aria-label',sent+' Weeks from '+fd(K.weeks[0].week_start)+' to '+fd(K.weeks[K.weeks.length-1].week_start)+'.');
  K.weeks.forEach(w=>{const i=el('i',w.checked_in?'ok':'',w.checked_in?'✓':'');i.setAttribute('aria-hidden','true');i.title='Week of '+fd(w.week_start)+(w.checked_in?': checked in '+fd(w.date):': '+w.accounts_reported+' of '+w.accounts_expected+' accounts');s.append(i);});box.append(s);
  const v=el('div','mx-vals');v.append(el('span',null,fd(K.weeks[0].week_start)),el('span',null,'this week'));box.append(v);
  box.append(el('p','mo-note','A week counts when all '+K.expected+' accounts ('+K.accounts.join(', ')+') have a balance within 3 days. Nothing resets; a missed week is just an empty square.'+(K.first_data?' Balances start '+fdy(K.first_data)+'.':'')));
  box.append(el('h3',null,'Drift ladder'));const n=K.clean_checks.length;
  box.append(v3steps([{label:'First clean check',done:n>=1,now:n<1},{label:'3 clean checks',done:n>=3,now:n>=1&&n<3}],'Drift ladder: '+n+' clean checks'));
  box.append(el('p','mo-note','A clean check is a check-in where every account\'s drift is within '+K.tolerance+' dollars. Clean checks so far: '+n+'.'));}
/* ---------- More: what the cards are waiting for, what you have ---------- */
function drawNeedsList(){const box=$('nd-list'),pb=$('pf-list');
  if(box){box.replaceChildren();const N=rows('needs_calc');
    if(!N)box.append(needsEl(calcWhy(['needs_calc','profile_calc'],'Needs: the profile answers dataset (profile_answers)')));
    else{const miss=N.filter(n=>!n.queue_id&&!n.ready),cov=N.filter(n=>n.queue_id&&!n.ready),rd=N.filter(n=>n.ready);
      box.append(el('p','mo-take',N.filter(n=>!n.ready).length+' Needs lines: '+cov.length+' with a data request, '+miss.length+' still without one'+(rd.length?', '+rd.length+' request'+(rd.length===1?'':'s')+' ready to mark Provided':'')+'.'));
      const list=(arr,head)=>{if(!arr.length)return;const d=el('details');d.append(el('summary',null,head+' ('+arr.length+')'));const ul=el('ul','mo-list st-list');
        arr.forEach(n=>{const li=el('li');li.append(el('b',null,(n.subject?n.subject+': ':'')),document.createTextNode(n.text+(n.queue_id?' ('+n.queue_id+(n.task_id?', task '+n.task_id:'')+', '+n.request_status+')':'')));ul.append(li);});d.append(ul);box.append(d);};
      list(miss,'Without a data request yet');list(cov,'Covered by a data request');list(rd,'Ready to mark Provided');}}
  if(pb){pb.replaceChildren();const P=rows('profile_calc');if(!P){pb.append(needsEl(calcWhy(['profile_calc'],'Needs: the profile answers dataset (profile_answers)')));return;}
    const g=[['have','On file'],['needs_entries','Yes, details still to enter'],['ask','Not asked yet'],['no','Answered no (left out)'],['conflict','Answered no, but rows are on file']];
    g.forEach(([s,h])=>{const a=P.filter(p=>p.status===s);if(!a.length)return;const p=el('p','mo-note');p.append(el('b',null,h+': '),document.createTextNode(a.map(x=>x.category+(s==='have'?' ('+x.rows+')':'')).join(', ')));pb.append(p);});}}
/* ---------- More: badges and seasons, quests, past weeks ---------- */
function drawBadges(){const box=$('bd-body');if(!box)return;box.replaceChildren();const B=rows('badges_calc'),Z=one('seasons_calc');
  const c=el('div','mo-card');c.append(el('h2',null,'Badges'));
  if(!B)c.append(needsEl(calcWhy(["badges_calc","seasons_calc"],'Needs: coverage, scores and the datasets')));
  else{c.append(el('p','mo-note','Each badge is a fact in your data. Earned badges keep their date for good; if the fact stops being true the card says so. No points, levels or counts.'));
    const g=el('div','mx-badges');B.forEach(b=>{const d=el('div','mx-badge'+(b.earned?' on':''));const ic=el('span','ic',b.earned?'✓':b.goal);ic.setAttribute('aria-hidden','true');
      d.append(ic,el('b',null,b.name),el('span','f','Fact: '+b.fact));
      d.append(el('span','st '+(b.earned?'ok':'warn'),b.earned?(b.still_true?'Earned':'Earned, not true now'):'Room to grow'));
      if(b.earned)d.append(el('span','f',(b.first_seen?'First seen ':'Since ')+fdy(b.earned_on)+(b.still_true?'':'; the badge keeps its date')));
      d.setAttribute('aria-label',b.name+': '+(b.earned?'earned':'not yet')+'. '+b.fact);d.setAttribute('role','group');g.append(d);});c.append(g);}
  box.append(c);
  const s=el('div','mo-card');s.append(el('h2',null,'Seasons'));
  if(!Z)s.append(needsEl(calcWhy(["badges_calc","seasons_calc"],'Needs: dated balances or pay stubs')));
  else{const r=el('div','mx-season');const t=el('div','tt');t.append(el('b',null,'Season '+Z.number+', '+Z.name),chip('in progress'));r.append(t,el('small',null,'Week '+Z.week+' of '+Z.weeks+'. '+Z.met+' of '+Z.goals.length+' goals met so far.'));s.append(r);
    Z.past.forEach(p=>{const r2=el('div','mx-season');const t2=el('div','tt');t2.append(el('b',null,'Season '+p.number+', '+p.name),chip('not scored'));r2.append(t2,el('small',null,p.note+'.'));s.append(r2);});
    s.append(el('p','mx-src','A season is a calendar quarter. Goals roll forward with no penalty.'));}
  box.append(s);}
function drawQuests(){const box=$('pg-body');if(!box)return;
  /* tasks are listed only on the Tasks page: a quest shows its progress and a count that links there, never the task rows */
  const Q=rows('quests_calc'),TR=one('task_rank_calc');const c=el('div','mo-card');c.id='pg-quests';c.append(el('h2',null,'Quests'));
  if(!Q)c.append(needsEl(calcWhy(["quests_calc","recap_calc"],'Needs: tasks, the data queue and scores')));
  else{
    if(TR){const lk=el('button','mo-link',plural(TR.open_count,'open task')+' on the Tasks page');lk.type='button';lk.addEventListener('click',()=>go('tasks','acc-tasks',{from:lk}));c.append(lk);}
    const ul=el('ul','mx-tasks');Q.forEach(q=>{const li=el('li');const t=el('div','tt');t.append(el('b',null,q.title),chip(q.total_count?q.done_count+' of '+q.total_count+' done':'Needs data',q.status==='Done'?'ok':q.total_count?'':'warn'));li.append(t,el('small',null,q.unlock_text+'.'));ul.append(li);});c.append(ul);
    c.append(aboutFold('quests',[Q.length+' quests, each a group of tasks and requests that unlocks one thing. A task counts as done only when it is Done and verified. The tasks themselves are on the Tasks page.','Everything on this page is computed from your data. Nothing is earned by typing a number; a statement or stub has to back it.']));}
  const old=$('pg-quests');if(old)old.remove();const old2=$('pg-weeks');if(old2)old2.remove();
  const anchor=box.querySelector('.mo-card');if(anchor)box.insertBefore(c,anchor.nextElementSibling);else box.append(c);
  const R=one('recap_calc');const w=el('div','mo-card');w.id='pg-weeks';w.append(el('h2',null,'Past weeks'));
  if(!R||!R.recaps.length)w.append(el('p','mo-note','No check-in weeks yet.'));
  else{const ul=el('ul','mx-tasks');R.recaps.forEach(x=>{const li=el('li');const t=el('div','tt');t.append(el('b',null,'Week of '+fd(x.week_start)),chip(x.clean?'Clean check':'Checked in',x.clean?'ok':''));
      li.append(t,el('small',null,(x.prev_date?'Cards '+(x.cards_change<=0?'down ':'up ')+money2(Math.abs(x.cards_change))+', cash '+(x.cash_change>=0?'up ':'down ')+money2(Math.abs(x.cash_change))+'. ':'First check-in '+fd(x.date)+': cards '+money2(x.cards)+', cash '+money2(x.cash)+'. ')+'Unexplained drift '+money2(x.unexplained_drift)+'.'));ul.append(li);});w.append(ul);}
  box.append(w);}

/* ---------- v4: task system (Home ranked list, task queue, quick actions), Form 1098 line ---------- */
/* Write path: the dashboard declares db (each viewer writes data/users/<own id>/) and user. Task actions are written to the
   viewer's own collection data/users/<id>/tasks/edits, one small document per task (or per added task), and overlaid on tasks.json
   when the page draws. Claude reads that collection and folds the edits into tasks.json at the next update. When this view has no
   db (signed out, view only, or outside claude.ai) every action instead shows a ready one line message for Claude, in a text box,
   and tries to copy it. */
const TK={db:null,uid:null,edits:{},ready:false,writable:true,msg:null};
const TODAY_=()=>window.__TODAY||new Date().toISOString().slice(0,10);
const addDays=(s,n)=>{const d=new Date(s+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};
function tkUse(name){try{return window.claude&&typeof window.claude.use==='function'?Promise.resolve(window.claude.use(name)).catch(()=>null):Promise.resolve(null);}catch(e){return Promise.resolve(null);}}
/* redraw only the tab on screen; a hidden tab draws itself when it opens */
const tabOn=id=>{const pg=$('page-'+id);return !!pg&&!pg.hidden;};
function tkRedraw(){try{if(tabOn('home'))drawHomeTasks();}catch(e){console.error('draw home tasks: '+e.message);}try{if(tabOn('tasks')&&$('tq-card'))drawTaskQueue();}catch(e){console.error('draw task queue: '+e.message);}}
(async()=>{const db=await tkUse('db');const u=await tkUse('user');let uid=null;try{uid=u&&typeof u.id==='function'?await u.id():null;}catch(e){uid=null;}
  if(db&&uid){TK.db=db;TK.uid=uid;try{const col=db.collection('data/users/'+uid+'/tasks/edits');
    if(typeof col.onSnapshot==='function')col.onSnapshot(s=>{const o={};s.docs.forEach(d=>{o[d.id]=d.data();});TK.edits=o;TK.ready=true;tkRedraw();},()=>{TK.db=null;tkRedraw();});
    else{const s=await col.get();s.docs.forEach(d=>{TK.edits[d.id]=d.data();});TK.ready=true;}}catch(e){TK.db=null;}}
  TK.ready=true;if(TK.db)tkRedraw();})();/* without db nothing changed since the first draw */
/* tasks.json with the page edits laid over it; added tasks get the id of their edit document */
function tasksView(){const tk=rows('tasks');if(!tk)return null;const E=TK.edits||{};
  const out=tk.map(t=>{const e=E[t.id];if(!e)return Object.assign({},t,{_edit:null});const x=Object.assign({},t,{_edit:e});
    if(e.status)x.status=e.status;if(e.done_date!==undefined)x.done_date=e.done_date;if(e.snooze_until)x.snooze_until=e.snooze_until;return x;});
  Object.keys(E).filter(k=>E[k]&&E[k].new).sort().forEach(k=>{const e=E[k];out.push({id:k,task:e.task,area:e.area||'Other',status:e.status||'To do',note:e.note||null,verified_on:null,checks_run:null,metric:null,metric_before:null,metric_after:null,effort:null,done_date:e.done_date||null,due_date:e.due_date||null,priority:e.priority||null,created:e.created||null,queue_id:null,_edit:e,_new:true});});
  return out;}
const PRI_={High:0,Medium:1,Low:3};
function rankTasks(list){const R=one('task_rank_calc');const W={},ord={};if(R)R.tasks.forEach(x=>{W[x.id]=x.weight;ord[x.id]=x.order;});
  return list.map((t,i)=>({t,w:W[t.id]||0,o:t.id in ord?ord[t.id]:1000+i})).sort((a,b)=>{const ad=a.t.due_date,bd=b.t.due_date;
    return (ad&&bd?(ad<bd?-1:ad>bd?1:0):ad?-1:bd?1:0)||((a.t.priority in PRI_?PRI_[a.t.priority]:2)-(b.t.priority in PRI_?PRI_[b.t.priority]:2))||(b.w-a.w)||(a.o-b.o);}).map(x=>x.t);}
const snoozed=t=>t.snooze_until&&t.snooze_until>TODAY_();
function tkMessage(kind,t,extra){const T=TODAY_();
  if(kind==='done')return 'Task update for Claude: mark '+t.id+' ('+t.task+') Done on '+T+', not yet verified.';
  if(kind==='snooze')return 'Task update for Claude: snooze '+t.id+' ('+t.task+') until '+extra+'.';
  if(kind==='undo')return 'Task update for Claude: reopen '+t.id+' ('+t.task+').';
  if(kind==='add')return 'Task update for Claude: add a task "'+extra.task+'", area '+extra.area+', priority '+(extra.priority||'not set')+', due '+(extra.due_date||'not set')+'.';
  return '';}
function tkShow(box,text,saved){let w=box.querySelector('.mx-ask');if(!w){w=el('div','mx-ask');box.append(w);}w.replaceChildren();
  w.append(el('p','mo-note',saved?'Saved in your private dashboard data. Claude folds it into the task list at the next update. The same change as a message:':'This view cannot save task changes. Copy this message and send it to Claude in the chat:'));
  const ta=document.createElement('textarea');ta.className='mx-askbox';ta.readOnly=true;ta.rows=3;ta.value=text;ta.setAttribute('aria-label','Message for Claude');w.append(ta);
  try{if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(text).then(()=>{const n=w.querySelector('.mx-copied');if(!n)w.append(el('p','mo-note mx-copied','Copied.'));},()=>{});}catch(e){}
  TK.msg=text;}
async function tkWrite(docId,body,del){if(!TK.db||!TK.uid)return false;try{const ref=TK.db.doc('data/users/'+TK.uid+'/tasks/edits/'+docId);if(del)await ref.delete();else await ref.set(body);
  if(del)delete TK.edits[docId];else TK.edits[docId]=body;return true;}catch(e){TK.writable=false;return false;}}
async function tkAct(box,kind,t,extra){const T=TODAY_();let ok=false;const prev=TK.edits[t.id]||{};
  if(kind==='done')ok=await tkWrite(t.id,Object.assign({},prev,{task_id:t.id,status:'Done',done_date:T,verified_on:null,snooze_until:null,at:new Date().toISOString(),by:'page'}));
  else if(kind==='snooze')ok=await tkWrite(t.id,Object.assign({},prev,{task_id:t.id,snooze_until:extra,at:new Date().toISOString(),by:'page'}));
  else if(kind==='undo')ok=await tkWrite(t.id,null,true);
  else if(kind==='add'){const id='new-'+T.replace(/-/g,'')+'-'+String(Date.now()).slice(-6);ok=await tkWrite(id,{new:true,task:extra.task,area:extra.area,priority:extra.priority||null,due_date:extra.due_date||null,status:'To do',created:T,at:new Date().toISOString(),by:'page'});}
  const msg=tkMessage(kind,t,extra);tkRedraw();const b2=$(box.id)||box;tkShow(b2,msg,ok);}
function taskActs(box,t){const w=el('div','mx-acts');
  if(t.status!=='Done'){const d=el('button','mx-act','Done');d.type='button';d.setAttribute('aria-label','Mark '+t.id+' done');d.addEventListener('click',()=>tkAct(box,'done',t));
    const s=el('button','mx-act','Snooze 7 days');s.type='button';s.setAttribute('aria-label','Snooze '+t.id+' for 7 days');s.addEventListener('click',()=>tkAct(box,'snooze',t,addDays(TODAY_(),7)));w.append(d,s);}
  if(t._edit){const u=el('button','mx-act','Undo page change');u.type='button';u.addEventListener('click',()=>tkAct(box,'undo',t));w.append(u);}
  return w;}
function addTaskForm(box){const f=el('div','mx-add');const inp=document.createElement('input');inp.type='text';inp.className='mo-in';inp.placeholder='New task';inp.setAttribute('aria-label','New task');
  const pr=document.createElement('select');pr.className='mo-in';pr.setAttribute('aria-label','Priority');['Medium','High','Low'].forEach(v=>pr.append(new Option(v+' priority',v)));
  const du=document.createElement('input');du.type='date';du.className='mo-in';du.min='2000-01-01';du.max='2099-12-31';du.setAttribute('aria-label','Due date');
  const b=el('button','mx-act','Add task');b.type='button';b.addEventListener('click',()=>{const v=inp.value.trim();if(!v){inp.focus();return;}const due=du.value&&du.validity.valid?du.value:null;
    tkAct(box,'add',{id:'new',task:v},{task:v,area:'Other',priority:pr.value,due_date:due});inp.value='';});
  f.append(inp,pr,du,b);return f;}
const RULE_TEXT='Done here marks a task Done (unverified). It counts as verified only after its data is entered, the checks are rerun and the named number moved; Claude then fills the verified date.';
function taskMeta(t){const m=[t.id,t.area];if(t.due_date)m.push('due '+fdy(t.due_date));else if(t.status!=='Done')m.push('no due date');if(t.priority)m.push(t.priority+' priority');
  if(t.queue_id)m.push('statement for '+t.queue_id);if(t.done_date)m.push('done '+fdy(t.done_date));if(t.snooze_until&&t.status!=='Done')m.push('snoozed until '+fdy(t.snooze_until));if(t._new)m.push('added on this page');else if(t._edit)m.push('changed on this page');return m;}
function drawHomeTasks(){const box=$('hm-tasks');if(!box)return;box.replaceChildren();const tv=tasksView();const q=rows('data_queue');
  if(!tv){box.append(needsEl('Needs: the task list'));collapsible($('hm-need'),'Needs attention','Needs: the task list','warn');return;}
  const open=rankTasks(tv.filter(t=>t.status!=='Done'&&!snoozed(t)));const top=open.slice(0,5);
  const ul=el('ul','mx-tasks mx-home');ul.id='hm-tasklist';
  top.forEach((t,i)=>{const li=el('li');li.id='hm-t-'+t.id;const tt=el('div','tt');const b=el('b',null,(i+1)+'. '+t.task);tt.append(b,chip(t.status,''));li.append(tt);
    li.append(el('small',null,taskMeta(t).join(', ')));li.append(taskActs(box,t));ul.append(li);});
  box.append(el('p','mx-eyebrow','Tasks, most urgent first'),ul);
  const sn=tv.filter(t=>t.status!=='Done'&&snoozed(t)).length;
  box.append(el('p','mo-note',open.length+' open tasks ('+open.filter(t=>t.status==='To do').length+' To do, '+open.filter(t=>t.status==='Open').length+' Open)'+(sn?', '+sn+' snoozed':'')+'. Ranked by due date, then priority, then the score weight a task unlocks.'));
  box.append(el('p','mo-note mx-rule',RULE_TEXT));
  if(q){const qc=dqCounts(q);const need=q.filter(x=>x.status==='Needed'||x.status==='Statement requested').sort((a,b)=>a.priority-b.priority);
    const h=el('p','mx-eyebrow','Data to send: '+qc.needed+' still needed');h.id='hm-dcount';box.append(h);const dl=el('ul','mx-tasks mx-home');dl.id='hm-datalist';
    need.slice(0,2).forEach(x=>{const li=el('li');const tt=el('div','tt');tt.append(el('b',null,'Send: '+x.item));li.append(tt,el('small',null,(x.queue_id||('Q'+x.priority))+', '+x.area+(x.status==='Statement requested'?', statement to confirm a screenshot':', data needed')));dl.append(li);});box.append(dl);}
  else box.append(needsEl('Needs: the data queue'));
  box.append(addTaskForm(box));
  collapsible($('hm-need'),'Needs attention',needStatus(open.length,q?dqCounts(q).needed:null),open.length?'warn':'ok');homeQuick(box);
}

let HOME_SUB='';
/* Home: one row per subject (IA.md 2.2). Each row shows the number its page shows, from the same calc and the same format (data-same
   names the element that shows it; the browser suite checks the two agree), and opens that page at its main card. A subject with no rows on file says so; a calc that did not run says which. The open data
   requests per subject come from needs_calc (each is tied to a data request and a task). */
const GLANCE_AREA={debt:'Debt',bills:'Bills',cash:'Cash'};
function drawGlance(){const box=$('hm-glance');if(!box)return;box.replaceChildren(el('h2',null,'Each subject, one number'));
  const D=one('dti_calc'),B=one('bills_calc'),S=one('scores_calc'),R=one('runway_calc'),G=one('goals_calc'),H=one('holdings_calc'),A6=one('age60_calc'),PC=one('paycheck_calc'),PK=one('paycheck_plan'),A=one('age_calc'),bm=rows('dti_benchmarks'),N=rows('needs_calc')||[];
  const cl=bm&&bm.find(b=>b.standard==='Classic guideline');const L=A&&A.ladder;const em=S&&S.metrics?S.metrics.emergency_months:null;const lo=R&&R.guideline?R.guideline.low:null;
  const lb=rows('liabilities');
  const R_=[
   {page:'debt',to:'debt-donut',same:'hm-tiles',name:'Debt',val:D?money(D.total_balance):calcWhy(['dti_calc'],lb?'Needs: debts':'No debts on file'),ex:D?'Debt to income '+pctf(D.back_end_pct)+(D.rent_monthly?', '+pctf(D.back_end_with_rent_pct)+' with rent':''):'',
    chip:D&&cl?(D.back_end_pct<=cl.back_end_pct?['ok','Under '+cl.back_end_pct+'%']:['warn','Over '+cl.back_end_pct+'%']):null},
   {page:'debt',to:'pp-plan',same:'pp-tiles',name:'Next paycheck'+(PK&&!PK.needs?', '+fd(PK.next.date):''),val:PK?(PK.needs?PK.needs:'Pay '+money2(PK.next.pay)):calcWhy(['paycheck_plan'],'Needs: a pay schedule and a pay stub'),ex:PK&&!PK.needs?'Keep '+money2(PK.next.keep):'',chip:PK&&!PK.needs&&PK.next.short>0?['warn','Short']:null},
   {page:'bills',to:'cf-tiles',same:'cf-tiles',name:'Bills and spending',val:B?money(B.total_monthly)+' a month':calcWhy(['bills_calc'],'Needs: your bills'),ex:D&&D.obligations_monthly!=null?'Total monthly obligations '+money(D.obligations_monthly)+' ('+money(D.obligations_annual)+' a year)':''},
   {page:'cash',to:'cs-runway',same:'hm-tiles2',name:'Cash runway',val:em==null?calcWhy(['scores_calc'],'Needs: bills and cash'):(Math.round(em*100)/100)+' months',ex:lo!=null?'Guideline '+lo+' to '+R.guideline.high+' months':'',
    chip:em!=null&&lo!=null?(em<lo?['warn','Low']:['ok','In range']):null},
   {page:'cash',to:'card-goals',same:'sg-tiles',name:'Savings goals',val:G?(G.count?money(G.total_saved)+' saved':'No goals yet'):calcWhy(['goals_calc'],'Needs: savings goals'),ex:G?(G.count?G.count+(G.count===1?' goal':' goals')+', '+money(G.total_monthly)+' a month':'Add one in Claude; it lives with the runway'):'',chip:G&&!G.count?['plan','Planned']:null},
   {page:'investments',to:'inv-tiles',same:'inv-tiles',name:'Investments',val:H?money(H.total_all):calcWhy(['holdings_calc'],'Needs: holdings'),ex:H?'All holdings, '+H.funds+(H.funds===1?' fund':' funds'):''},
   {page:'retirement',to:'ret-head',same:'rh-read',name:'Retirement at '+(A6?A6.age:60),val:A6?money(A6.now_end):calcWhy(['age60_calc'],'Needs: retirement plan and balances'),ex:A6?"On today's pay stubs; low goal "+compact(A6.goal_low):'',
    chip:A6?(A6.gap_now>0?['warn','Short']:['ok','On goal']):null},
   {page:'pay',to:'pc-tiles',same:'pc-tiles',name:'Pay',val:PC?money(PC.take_home_month)+' a month':calcWhy(['paycheck_calc'],'Needs: a pay stub'),ex:PC?'Take-home, '+money(PC.take_home)+' a paycheck':''},
   {page:'progress',to:'rt-ladder',same:'rt-ladder',name:'Age ladder',val:L&&L.you_pct!=null?pc0(L.you_pct)+' of the guideline':calcWhy(['age_calc'],'Needs: age, salary and retirement balance'),ex:L?'Age '+L.age:''}];
  const ul=el('ul','mo-glance');
  R_.forEach(g=>{const li=el('li');const b=el('button');b.type='button';b.id='gl-'+(g.to==='card-goals'?'goals':g.to==='pp-plan'?'paycheck':g.page==='progress'?'age':g.page);b.dataset.glance=g.page+':'+g.to;b.dataset.same=g.same;
    const tx=el('span');tx.append(el('span','nm',g.name),el('span',/^Needs|^Did not run|^No /.test(g.val)?'need':'val',g.val));if(g.ex)tx.append(el('span','ex',g.ex));
    const area=GLANCE_AREA[g.page];const n=area&&g.to!=='card-goals'&&g.to!=='pp-plan'?N.filter(x=>x.area===area).length:0;if(n)tx.append(el('span','ex',n+(n===1?' data request open':' data requests open')+' (Tasks)'));
    const ch=g.chip?el('span','mo-chip '+g.chip[0],g.chip[1]):el('span');const cv=el('span','chev');cv.setAttribute('aria-hidden','true');
    b.append(tx,ch,cv);b.setAttribute('aria-label',g.name+' '+g.val+(g.ex?'. '+g.ex:'')+(g.chip?'. '+g.chip[1]:'')+'. Open '+META[g.page][0]);
    b.addEventListener('click',()=>goTo(g.page,g.to,null,{from:b}));li.append(b);ul.append(li);});
  box.append(ul);}
function drawHome(){
  const nw=rows('nw_rows'),st=rows('nw_steps'),dti=rows('dti_calc'),bm=rows('dti_benchmarks'),m=retModel(),nwh=rows('networth_history');
  if(nwh&&nwh.length){HOME_SUB='As of '+fdy([...nwh].sort((a,b)=>a.date<b.date?-1:1).pop().date);}else HOME_SUB='Needs: a net worth history row for the as-of date';
  if(current==='home')$('stl').textContent=HOME_SUB;
  const hero=$('hm-hero');hero.replaceChildren(el('h2',null,'Net worth, known items'));
  if(nw){hero.append(el('div','mo-hero-n',money(nwItem(nw,'Net worth'))));const t=nwTrend().delta;if(t){const d=el('p','mo-ts',t.text);d.classList.add(t.dir==='up'?'mo-pos':t.dir==='down'?'mo-neg':'x');d.style.margin='0';d.style.fontWeight='600';hero.append(d);}
    hero.append(el('p','mo-note','Retirement, house, truck, savings, checking and uninvested HSA, minus every debt. Pending tax refunds are not counted.'));}
  else hero.append(needsEl(calcWhy(["nw_rows","nw_steps","dti_calc","age60_calc"],'Needs: retirement balances, assets and debts')));
  const tl=[];
  const asset=st&&st.find(s=>s.label==='Total assets');
  tl.push(asset?{label:'Assets',value:money(asset.value),sub:'House, retirement, cash, truck and HSA'}:{label:'Assets',value:'Needs: asset values',sub:''});
  tl.push(dti?{label:'Debts',value:money(dti[0].total_balance),sub:money(dti[0].debt_payments)+' a month in payments'}:{label:'Debts',value:'Needs: debts',sub:''});
  const cl=bm&&bm.find(b=>b.standard==='Classic guideline');
  tl.push(dti?{label:'Debt to income',value:pctf(dti[0].back_end_pct),sub:cl?(dti[0].back_end_pct<=cl.back_end_pct?'Under the '+cl.back_end_pct+'% guideline':'Over the '+cl.back_end_pct+'% guideline'):'Guideline needed'}:{label:'Debt to income',value:'Needs: debts and income',sub:''});
  tl.push(nw?{label:'Cash',value:money(nwItem(nw,'Cash, savings and checking')),sub:'Savings and checking'}:{label:'Cash',value:'Needs: cash balances',sub:''});
  tiles($('hm-tiles'),tl);
  const tv=$('hm-tiles').children[2]&&$('hm-tiles').children[2].querySelector('.mo-tv');if(tv&&dti&&cl)tv.classList.add(dti[0].back_end_pct<=cl.back_end_pct?'mo-pos':'mo-wrn');
  const rc=$('hm-ret');rc.replaceChildren(el('h2',null,'Retirement at '+(m?m.age1:60)));
  if(m){
    m.scenarios.forEach((s,i)=>{const r=el('div','mo-rrow');const t=el('div','t');t.append(el('span',null,s.scenario==="Today's pay stubs"?"On today's pay stubs":'At the limit (maxed)'),el('b',null,money(s.end_mid)));const bar=el('div','mo-bar2');const f=document.createElement('i');f.style.width=Math.min(100,s.end_mid/m.goal_high*100)+'%';f.style.background=i?RC.plan:RC.today;bar.append(f);r.append(t,bar);rc.append(r);});
    rc.append(aboutFold('ret-at60',['Bar full means the '+compact(m.goal_high)+' high goal; the goal range is '+compact(m.goal_low)+' to '+compact(m.goal_high)+'. Base case, '+m.rates[1]+'% a year after inflation, in today\'s dollars.']));
  }else rc.append(needsEl(calcWhy(["nw_rows","nw_steps","dti_calc","age60_calc"],'Needs: retirement plan, assumptions and balances')));
}
function drawAsof(){
  const box=$('asof-list');box.replaceChildren();
  const add=(l,v,s)=>{const r=el('div','mo-task');const a=el('div');a.append(el('div',null,l));if(s)a.append(el('div','mo-note',s));r.append(a,el('span','mo-chip',v));box.append(r);};
  const ao=rows('assets_other');if(ao)ao.forEach(a=>add(a.name,fdy(a.as_of_date),a.source));else box.append(needsEl('Needs: assets file'));
  const mx=(r,f)=>r&&r.length?r.map(x=>x[f]).sort().pop():null;
  [['Pay stubs, latest','paystubs','pay_date'],['Holdings export, latest','holding_snapshots','snapshot_date'],['Net worth history, latest','networth_history','date'],['Reported balances, latest','balance_log','date']].forEach(([l,id,f])=>{const d=mx(rows(id),f);if(d)add(l,fdy(d));else add(l,'Needs: '+id.replace(/_/g,' '));});
}
/* Cash balance over time (IA.md, user approved): one line per cash account from balance_log, filled dots for reported balances,
   hollow dots for an expected balance after known money movements (not a bank reading), and one month of essentials from
   runway_calc as a dashed line. Dots only, no line, until an account has three points. */
function drawBalHist(){const card=$('cs-balhist');if(!card)return;const box=$('cs-balchart'),note=$('cs-balnote');box.replaceChildren();card.querySelectorAll('.mo-legend,.mo-needs').forEach(x=>x.remove());
  const lg=(rows('balance_log')||[]).filter(r=>r.kind==='Cash'&&r.account&&r.date&&isFinite(r.reported_balance));const R=one('runway_calc');
  if(!lg.length){box.after(needsEl(calcWhy(['balance_log'],'Needs: cash balances with their dates')));note.textContent='';return;}
  const accts=[...new Set(lg.map(r=>r.account))].sort();const T=s=>new Date(s+'T00:00:00');
  const S=accts.map((a,i)=>{const pts=lg.filter(r=>r.account===a).map(r=>({date:r.date,v:r.reported_balance,exp:false,src:r.source||''}));
    lg.filter(r=>r.account===a).forEach(r=>{const e=cellObj(r.expected_after_known_events);if(e&&typeof e==='object'&&e.is_reported===false&&isFinite(e.expected_balance)&&e.expected_date)pts.push({date:e.expected_date,v:e.expected_balance,exp:true,src:'Expected after known money movements, not a bank reading'});});
    pts.sort((x,y)=>x.date<y.date?-1:x.date>y.date?1:(x.exp?1:-1));return {a,col:C[i%C.length],pts};});
  const all=[].concat(...S.map(s=>s.pts));const W=box.clientWidth;const must=R&&isFinite(R.mustpay)?R.mustpay:null;
  if(W){const tip=mkTip(box);const H=230,mg={l:56,r:16,t:16,b:30};let t0=d3.min(all,d=>T(d.date)),t1=d3.max(all,d=>T(d.date));if(+t0===+t1){t0=new Date(+t0-3*86400000);t1=new Date(+t1+3*86400000);}
    const x=d3.scaleTime([t0,t1],[mg.l+12,W-mg.r-12]);const vals=all.map(d=>d.v).concat(must!=null?[must]:[]);const lo=Math.min(0,d3.min(vals)),hi=d3.max(vals);
    const y=d3.scaleLinear([lo,hi*1.1||1],[H-mg.b,mg.t]).nice();const svg=mkSvg(box,W,H,'Cash balance over time by account'+(must!=null?', with one month of essentials':''));
    hgrid(svg,y.ticks(4),y,mg.l,W-mg.r);
    svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(4).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
    svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call((()=>{const ud=[...new Set(all.map(d=>d.date))].sort().map(T);const ax=d3.axisBottom(x);return ud.length<=5?ax.tickValues(ud):ax.ticks(4);})().tickFormat(d3.timeFormat('%b %-d')).tickSize(4).tickPadding(6));
    if(must!=null){svg.append('line').attr('x1',mg.l).attr('x2',W-mg.r).attr('y1',y(must)).attr('y2',y(must)).attr('stroke','var(--mo-warn)').attr('stroke-width',1.5).attr('stroke-dasharray','5 4');}
    const hp=[];S.forEach(s=>{const rep=s.pts.filter(p=>!p.exp);
      if(rep.length>=3)svg.append('path').attr('d',d3.line().x(p=>x(T(p.date))).y(p=>y(p.v))(rep)).attr('fill','none').attr('stroke',s.col).attr('stroke-width',2.2);
      s.pts.forEach(p=>{const cx=x(T(p.date)),cy=y(p.v);svg.append('circle').attr('cx',cx).attr('cy',cy).attr('r',5).attr('fill',p.exp?'var(--mo-card)':s.col).attr('stroke',s.col).attr('stroke-width',2);
        hp.push({px:cx,py:cy,lines:[s.a+', '+fdy(p.date),money(p.v)+(p.exp?' expected':' reported'),p.src].filter(Boolean)});});});
    hoverLayer(svg,hp,mg.l,mg.t,W-mg.l-mg.r,H-mg.t-mg.b,(p,ev)=>tip.show(ev,p.lines),()=>tip.hide(),40);}
  const items=S.map(s=>({label:s.a,color:s.col}));if(all.some(p=>p.exp))items.push({label:'Expected, not a bank reading',color:'var(--mo-muted)',ring:true});if(must!=null)items.push({label:'One month of essentials, '+money(must),color:'var(--mo-warn)',line:'dash'});
  box.after(legendEl(items));
  const few=S.some(s=>s.pts.filter(p=>!p.exp).length<3);note.textContent='Each dot is a balance you reported, by date; a hollow dot is the balance expected after the money movements you confirmed.'+(must!=null?' Above the dashed line, the account alone covers one month of essentials.':'')+(few?' Dots only until an account has three points.':'');}
function drawCashTop(){
  const nw=rows('nw_rows'),ao=rows('assets_other'),box=$('cash-bal');aboutSync();
  if(!nw||!ao){box.replaceChildren(needsEl(calcWhy(["nw_rows"],'Needs: cash balances')));return;}
  box.replaceChildren();const T0=window.__TODAY||new Date().toISOString().slice(0,10);const Q=rows('data_queue')||[];
  const day=d=>Math.round((Date.parse(T0+'T00:00:00Z')-Date.parse(d+'T00:00:00Z'))/86400000);
  const card=(key,label,value,tip,about,chips,hero)=>{const w=el('div','mx-bal'+(hero?' hero':''));const tl=el('div','mo-tiles');tiles(tl,[{hero:!!hero,label,value}]);const t=tl.querySelector('.mo-tile');srcTip(t.querySelector('.mo-tv'),tip);
    chips.forEach(c=>t.append(c));w.append(tl,aboutFold('bal-'+key,about));box.append(w);};
  card('total','Cash, savings and checking',money(nwItem(nw,'Cash, savings and checking')),'Source: the balances below. As-of dates in About this',[cashSub()],[],true);
  ao.filter(a=>a.type==='Cash').forEach(a=>{const kw=new RegExp('\\b'+a.name.split(' ')[0].replace(/[^A-Za-z0-9]/g,'')+'\\b','i');
    const chips=[];if(Q.some(q=>q.status==='Statement requested'&&(q.area==='Cash')&&kw.test(q.item)))chips.push(aboutChip('Needs statement','warn'));
    const age=a.as_of_date?day(a.as_of_date):null;if(age!=null&&age>14)chips.push(aboutChip('Stale, '+age+' days','warn'));
    if(a.expected_is_reported===false||(a.reported_value==null&&a.expected_value!=null))chips.push(aboutChip('Estimate','warn'));
    const about=['As of '+fdy(a.as_of_date)+'.','Source: '+a.source+(a.value_basis?' Basis: '+a.value_basis:'')];
    card(a.asset_id||a.name,a.name,money(a.value_point),'Source: '+a.source+' As of '+fdy(a.as_of_date)+'.',about,chips,false);});
}
/* ---------- hotfix v4.1 user requests: payoff periods, missing payment review ---------- */
/* The period behind every "interest saved" figure: the plan and minimums only both start at payoff_engine's start month, and the
   saving counts each debt's interest until it is paid off, on the debts that clear on minimums. Dates only, from the same runs. */
function poPeriod(P,pl,mn){const ok=P.debts.map((d,i)=>!(mn.never&&mn.never[i]));const last=a=>a.filter((x,i)=>ok[i]&&x).sort().pop()||null;
  return {start:P.start,plan_end:last(pl.payoff),min_end:last(mn.payoff)};}
function poSavedLabel(P,pl,mn){const p=poPeriod(P,pl,mn);return 'Interest saved from '+monthLab(p.start)+' to payoff, versus minimums only';}
function poSavedWhen(P,pl,mn){const p=poPeriod(P,pl,mn);return 'Paid off by '+(p.plan_end?monthLab(p.plan_end):'n/a')+' on the plan, '+(p.min_end?monthLab(p.min_end):'n/a')+' on minimums only';}
/* "Debts missing a payment": the same dti_calc rows give the count and the list. */
function missingReview(dti){const box=$('nw-missing');const tl=[...document.querySelectorAll('#nw-tiles .mo-tile')].find(t=>{const l=t.querySelector('.mo-tl');return l&&l.textContent==='Debts missing a payment';});
  if(!box)return;box.replaceChildren();box.hidden=true;if(!tl||!dti||!dti[0])return;const D=dti[0];const names=D.missing_names||[];if(!D.missing_payments)return;
  const b=el('button','mx-btn mx-misbtn','Review '+D.missing_payments+(D.missing_payments===1?' debt':' debts'));b.type='button';b.id='nw-missing-btn';b.setAttribute('aria-expanded','false');b.setAttribute('aria-controls','nw-missing');
  b.addEventListener('click',()=>{const open=box.hidden;box.hidden=!open;b.setAttribute('aria-expanded',String(open));if(open)box.scrollIntoView({block:'nearest'});});tl.append(b);
  const L=rows('liabilities')||[],PE=one('payoff_engine'),Q=rows('data_queue')||[],T=rows('tasks')||[];
  box.append(el('h3',null,'Debts missing a payment ('+D.missing_payments+')'));
  box.append(el('p','mo-note','Each debt below has no monthly payment on file, so the main debt ratio leaves it out. Send the latest statement for it as a downloaded PDF or CSV and the missing values go into place.'));
  const ul=el('ul','mx-mislist');
  names.forEach(n=>{const l=L.find(x=>x.name===n)||{};const d=PE&&PE.debts.find(x=>x.name===n);const li=el('li','mx-misrow');li.dataset.debt=n;
    li.append(el('h4',null,n));
    li.append(el('p','mo-note',[l.type||'Type not on file','balance '+(l.balance!=null?money2(l.balance):'not on file'),l.rate_pct!=null?'rate '+l.rate_pct+'%':'rate not on file'].join(', ')));
    const miss=[];if(l.monthly_payment==null)miss.push(isCard(l)?'minimum payment (the monthly payment, from the statement)':'monthly payment');
    if(l.rate_pct==null)miss.push('rate');if(d&&d.statement_balance==null&&openCard(l))miss.push('statement balance');
    if(!(l.next_due_date||l.due_date))miss.push('due date');
    li.append(el('p','mo-needs mx-misneed','Missing: '+miss.join(', ')+'.'));
    li.append(el('p','mo-note',d&&d.min_est?'Estimate in use: minimum '+money2(d.min)+' a month, 4 percent of the balance. The payoff plan uses it, and so does the estimated debt ratio ('+money2(D.est_card_payment)+' for cards with no payment). The main debt ratio leaves it out.':'No estimate in use: the main debt ratio leaves this debt out'+(d&&d.min_missing?' and the payoff plan gives it no payment.':'.')));
    const kw=new RegExp('\\b'+n.split(' ')[0].replace(/[^A-Za-z0-9]/g,'')+'\\b','i');
    const qs=Q.filter(q=>(q.status==='Needed'||q.status==='Statement requested')&&kw.test(q.item)),ts=T.filter(t=>t.status!=='Done'&&kw.test(t.task));
    const lk=el('div','mx-mislinks');
    qs.forEach(q=>{const a=el('button','mx-mislink',(q.queue_id||'Q'+q.priority)+', '+q.status+': '+q.item);a.type='button';
      a.addEventListener('click',()=>{go('tasks','acc-queue');const r=document.querySelector('#t-queue tr[data-key="'+q.priority+'"]');if(r)r.scrollIntoView({block:'center'});});lk.append(a);});
    ts.forEach(t=>{const a=el('button','mx-mislink',t.id+', '+t.status+': '+t.task);a.type='button';
      a.addEventListener('click',()=>{go('tasks','acc-tasks');const r=$('tq-'+t.id);if(r)r.scrollIntoView({block:'center'});});lk.append(a);});
    if(!qs.length&&!ts.length)lk.append(el('p','mo-note','No open data request or task names this debt yet.'));
    li.append(el('p','mx-eyebrow','Linked requests'),lk);
    li.append(el('p','mo-note','What to send: the latest '+n+' statement as a downloaded PDF or CSV. It shows the minimum payment, the statement balance and the due date.'));
    ul.append(li);});
  box.append(ul);}

