/* ---------- facelift v2.0: shared bits ---------- */
const one=id=>{const r=rows(id);return r&&r[0];};
function msMerged(){const live=rows('milestones_calc')||[],S=(rows('milestones')||[]).filter(m=>m.family!=='badge');const T0=window.__TODAY||new Date().toISOString().slice(0,10);
  const out=live.map(m=>{const s=S.find(z=>z.milestone_id===m.milestone_id);return Object.assign({},m,{earned_on:s&&s.earned_on?s.earned_on:T0,first_seen:!s});});
  S.forEach(s=>{if(!out.find(m=>m.milestone_id===s.milestone_id))out.push(Object.assign({},s,{status:'retracted',retracted_on:s.retracted_on||T0}));});return out;}
function poSaved(){const s=rows('payoff_settings');return s&&s[0]?s[0]:null;}
const isDark=()=>{const t=document.documentElement.getAttribute('data-theme');if(t)return t==='dark';return !!(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches);};
function applyTheme(){const g=isDark()?'#c8a415':'#8a6d00';C[4]=g;}
if(window.matchMedia){try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(typeof draw==='function')draw();});}catch(e){}}
const pc0=v=>v==null||!isFinite(v)?'n/a':Math.round(v)+'%';
const monthLab=s=>s?MN[+s.slice(5,7)-1]+' '+s.slice(0,4):'n/a';
const ordn=n=>{n=Math.round(n);const t=n%100;return n+((t>10&&t<14)?'th':({1:'st',2:'nd',3:'rd'}[n%10]||'th'));};
const uv=(v,u)=>{u=u||'';return /^%/.test(u)?v+u:v+(u?' '+u:'');};
const LABEL_WORD={ahead:'Ahead',on_track:'On track',behind:'Behind',needs_data:'Needs data',info:'Context'};
function chip(text,kind){return el('span','mx-chip'+(kind?' '+kind:''),text);}
function ringSvg(pct,cls,size){const s=size||96,r=s/2-7,c=2*Math.PI*r;const ns='http://www.w3.org/2000/svg';
  const svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox',`0 0 ${s} ${s}`);svg.setAttribute('width',s);svg.setAttribute('height',s);svg.setAttribute('aria-hidden','true');svg.setAttribute('class','mx-ringsvg'+(cls?' '+cls:''));
  const a=document.createElementNS(ns,'circle');a.setAttribute('cx',s/2);a.setAttribute('cy',s/2);a.setAttribute('r',r);a.setAttribute('class','bg');
  const b=document.createElementNS(ns,'circle');b.setAttribute('cx',s/2);b.setAttribute('cy',s/2);b.setAttribute('r',r);b.setAttribute('class','fg');
  const f=Math.max(0,Math.min(100,pct||0))/100;b.setAttribute('stroke-dasharray',(f*c).toFixed(2)+' '+c.toFixed(2));b.setAttribute('transform',`rotate(-90 ${s/2} ${s/2})`);
  svg.append(a,b);return svg;}
function pbar(pct,opt){opt=opt||{};const max=opt.max||200;const t=el('div','mx-track');t.setAttribute('aria-hidden','true');
  const f=el('i','mx-fill');f.style.width=(Math.max(0,Math.min(max,pct||0))/max*100)+'%';if(opt.color)f.style.background=opt.color;t.append(f);
  if(opt.tick!==false){const k=el('b','mx-tick');k.style.left=(100/max*100)+'%';t.append(k);}return t;}
function srcLine(rowsL,extra){if(!rowsL||!rowsL.length)return null;const seen=new Set();const parts=[];
  rowsL.forEach(r=>{if(!r)return;const k=r.source+'|'+r.data_year;if(seen.has(k))return;seen.add(k);parts.push(r.source.replace(/\s*\(.*?\)\s*$/,'')+', data year '+r.data_year+(r.dollar_year?', '+r.dollar_year:'')+(r.confidence?', '+r.confidence+' confidence':''));});
  return el('p','mx-src','Source: '+parts.slice(0,3).join('; ')+(parts.length>3?'; and '+(parts.length-3)+' more':'')+(extra?'. '+extra:''));}
function goTo(tab,elId,openId,o){go(resolvePage(tab,elId),openId,o);let t=$(elId);if(t){revealView(t);if(collReveal(t)){draw();t=$(elId)||t;}t.scrollIntoView({block:'start'});focusTarget(t);}}
function fold(title,body,open){const d=document.createElement('details');d.className='mo-fold';if(open)d.open=true;const s=document.createElement('summary');s.textContent=title;d.append(s);if(body)d.append(body);return d;}
function mkTable(heads,rowsL,opt){opt=opt||{};const tb=document.createElement('table');tb.className='mo-table';const th=document.createElement('thead');const tr=document.createElement('tr');
  heads.forEach(h=>{const c=document.createElement('th');c.textContent=h.t;if(h.num)c.className='num';tr.append(c);});th.append(tr);tb.append(th);const bd=document.createElement('tbody');
  rowsL.forEach(r=>{const x=document.createElement('tr');if(r.cls)x.className=r.cls;r.cells.forEach((v,i)=>{const c=document.createElement('td');c.dataset.label=heads[i].t;if(heads[i].num)c.className='num';if(i===0)c.classList.add('key');if(v instanceof Node)c.append(v);else c.textContent=v==null?'n/a':String(v);x.append(c);});bd.append(x);});
  tb.append(bd);const sc=el('div','mo-scroll');sc.append(tb);return sc;}

function miniGrid(heads,rowsL,tpl,label){const g=el('div','mx-wk');g.setAttribute('role','table');if(label)g.setAttribute('aria-label',label);g.style.gridTemplateColumns=tpl;
  heads.forEach(h=>g.append(el('span','h'+(h.num?' num':''),h.t)));rowsL.forEach(r=>r.forEach((v,i)=>g.append(el('span',(i===0?'a':'')+(heads[i].num?' num':'')+(v&&v.miss?' miss':''),v&&v.t!=null?v.t:String(v)))));return g;}
/* ---------- Home: scores ---------- */
function scoreBlock(s,risk){const b=el('div','mx-score');const r=el('div','mx-ring'+(risk?' risk':''));
  r.append(ringSvg(s.score==null?0:s.score,risk?'risk':''));const v=el('div','v');v.append(el('b',null,s.score==null?'n/a':String(Math.round(s.score))),el('small',null,'of 100'));r.append(v);
  b.append(r,el('b',null,s.title+':'),chip(s.label,risk?(s.score>=75?'bad':s.score>=50?'warn':'ok'):(s.score>=60?'ok':s.score>=40?'':'warn')));
  b.append(el('span',null,(risk?'Higher is riskier. ':'Higher is healthier. ')+'Based on '+s.n+' of '+s.M+' components'));
  return b;}
function compRow(r,risk){const d=el('div','mx-comp'+(r.points==null?' na':''));
  const name=el('span',null,r.name+' ('+r.weight+')');
  const val=r.points==null?'Needs':(Math.round(r.points*10)/10)+' '+(risk?'risk ':'')+'of '+r.weight;
  d.append(name,el('span','num',val));
  if(r.points!=null){const m=el('div','m');const i=el('i');i.style.width=(r.points/r.weight*100)+'%';if(risk)i.style.background='var(--mo-warn-f)';m.append(i);d.append(m);
    const u=r.unit||'';const vv=uv(u.indexOf('%')===0?Math.round(r.value*10)/10:Math.round(r.value*100)/100,u);d.append(el('small',null,'Now '+vv+'. Full '+(risk?'safety':'marks')+' at '+uv(r.best,u)+', zero at '+uv(r.worst,u)+'.'));}
  else d.append(el('small',null,r.needs));
  return d;}
function drawScores(){
  const box=$('hm-scores');if(!box)return;box.replaceChildren();const S=one('scores_calc');
  if(!S){box.append(el('h2',null,'Scores'),needsEl(calcWhy(["scores_calc"],'Needs: scores_config and the core datasets')));return;}
  const g=el('div','mx-scores');g.append(scoreBlock(S.financial,false),scoreBlock(S.risk,true));box.append(g);
  const rg=s=>s.range[0]==null?'':'Could land '+Math.round(s.range[0])+' to '+Math.round(s.range[1])+' once the Needs are filled.';
  box.append(el('p','mo-note','Financial: '+rg(S.financial)+' Risk: '+rg(S.risk)));
  const hist=rows('scores_history')||[];const tr=S.trend||{min_snapshots:6,min_days_span:60};
  const span=hist.length>1?Math.round((Date.parse(hist[hist.length-1].date)-Date.parse(hist[0].date))/864e5):0;
  box.append(el('p','mo-note',hist.length>=tr.min_snapshots&&span>=tr.min_days_span?'Trend available from '+hist.length+' snapshots.':'No trend yet: '+hist.length+' of '+tr.min_snapshots+' monthly snapshots over '+tr.min_days_span+' days. Scores move with your data, not with time.'));
  const body=el('div','mx-in');
  [[S.financial,false,'Financial Score parts'],[S.risk,true,'Risk Score parts']].forEach(([s,risk,t])=>{body.append(el('h3',null,t));
    const rs=[...s.rows].sort((a,b)=>risk?((b.points==null?-1:b.points)-(a.points==null?-1:a.points)):0);rs.forEach(r=>body.append(compRow(r,risk)));});
  body.append(el('h3',null,'What would raise the Financial Score'));
  const ul=el('ul','mx-moves');
  const dl=(v,n)=>Math.abs(v)<0.05?n+' unchanged':(v>0?'+':'')+(Math.round(v*10)/10)+' '+n;
  (S.whatifs||[]).forEach(w=>{const li=el('li');const ef=el('span','eff'+(w.d_fin<0||w.d_risk>0.05?' mixed':''),dl(w.d_fin,'Financial')+', '+dl(w.d_risk,'Risk'));li.append(el('span',null,w.label),ef,el('span','w',w.detail+'. Reruns the same score on changed copies of your data.'));ul.append(li);});
  S.room_fin.slice(0,3).forEach(r=>{const li=el('li');li.append(el('span',null,r.name),el('span','eff',(Math.round(r.room*10)/10)+' points of room'),el('span','w','Full marks at '+uv(r.best,r.unit)));ul.append(li);});
  body.append(ul);
  body.append(el('h3',null,'What would lower the Risk Score'));
  const ul2=el('ul','mx-moves');S.room_risk.slice(0,3).forEach(r=>{const li=el('li');li.append(el('span',null,r.name),el('span','eff',(Math.round(r.room*10)/10)+' risk points could come off'),el('span','w','Lowest risk at '+uv(r.best,r.unit)));ul2.append(li);});body.append(ul2);
  const nd=[...S.financial.rows,...S.risk.rows].filter(r=>r.points==null);
  body.append(el('h3',null,'Needs ('+nd.length+')'));
  const ul3=el('ul','mo-needlist');nd.forEach(r=>{const li=el('li');const d=el('div',null,r.name+' ('+r.weight+' weight)');d.append(el('small',null,r.needs));li.append(d);ul3.append(li);});body.append(ul3);
  const math=el('div','mx-in');[...S.financial.rows,...S.risk.rows].forEach(r=>{const p=el('p','mo-note');p.append(el('b',null,r.id+' '+r.name+': '),document.createTextNode(r.formula.replace(/\.?\s*$/,'. ')+'Best '+r.best+', worst '+r.worst+'. '+(r.source||'')));math.append(p);});
  math.append(el('p','mo-note',S.how));
  body.append(fold('Show the math',math));
  box.append(fold('How these are built',body));
  box.append(el('p','mx-src',S.disclaimer+' Config version '+S.version+', '+fdy(S.as_of)+'.'));
}
/* ---------- Home: extra tiles, next move, payoff summary, coverage, age summary, plan-year line ---------- */
function drawHomeExtra(){
  const S=one('scores_calc'),A=one('age_calc'),P=one('payoff_engine');
  const t2=$('hm-tiles2');if(t2){const tl=[];
    if(S){const em=S.metrics.emergency_months;tl.push({label:'Cash runway',value:em==null?'n/a':(Math.round(em*100)/100)+' months',sub:'Essentials '+money2(S.x.mustpay)+' a month'});}
    else tl.push({label:'Cash runway',value:calcWhy(['scores_calc'],'Needs: bills and cash'),sub:''});
    if(A&&A.ladder&&A.ladder.target_pct){const L=A.ladder;tl.push({label:'Retirement vs the age guideline at '+L.target_age,value:pc0(L.target_pct.mid),sub:'of the guideline, base path ('+pc0(L.target_pct.lo)+' to '+pc0(L.target_pct.hi)+')'});}
    else tl.push({label:'Retirement vs the age guideline',value:calcWhy(['age_calc'],'Needs data'),sub:''});
    tiles(t2,tl);}
  const mv=$('hm-move');if(mv){mv.replaceChildren();const n=one('next_move');
    if(n){const c=el('div','mx-move');c.append(el('p','mx-eyebrow',n.label),el('h3',null,n.text),el('p','mo-note','Why: '+n.why+(n.effort?' Effort: '+n.effort+'.':'')));mv.append(c);}}
  const hp=$('hm-payoff');if(hp){hp.replaceChildren(el('h2',null,'Debt payoff plan'));
    if(!P||!P.debts.length){hp.append(needsEl(calcWhy(['payoff_engine'],'Needs: debts with balances')));}
    else{const R0=poRun(P);const pl=R0.plan,mn=R0.mins;const np=payNext(P,pl);
      hp.append(el('p','mx-big',np.text));hp.append(el('p','mo-note',np.why+(np.then?' '+np.then:'')));
      const cmp=planCompare(P,pl,mn);
      tiles(hp.appendChild(el('div','mo-tiles')),[{label:'Debt free, no mortgage',value:pl.end?monthLab(pl.end):'n/a',sub:STRAT[R0.s]+' with '+money(Math.round(R0.e))+' extra a month'},{label:poSavedLabel(P,pl,mn),value:cmp.saved==null?'n/a':money(Math.round(cmp.saved)),sub:poSavedWhen(P,pl,mn)+(cmp.excluded.length?' ('+cmp.excluded.length+' debts never clear on minimums and are left out)':'')}]);
      const b=el('button','mx-btn','Open payoff plan');b.type='button';b.addEventListener('click',()=>goTo('debt','sec-payoff'));hp.append(b);}}
  const cv=$('hm-cover');if(cv){cv.replaceChildren(el('h2',null,'How complete the picture is'));const K=one('coverage_calc');
    if(K){const g=el('div','mx-rings');
      [['Picture',K.picture_pct,K.picture_have+' of '+K.picture_total+' datasets current'],['Scores',K.scores_pct,K.scores_weight_have+' of '+K.scores_weight_total+' weight'],['Explained',K.explained_pct,K.explained_pct==null?'no check yet':K.explained_checks+' check periods']].forEach(([t,p,s])=>{
        const b=el('button','mx-cring');b.type='button';const r=el('div','mx-ring sm');r.append(ringSvg(p==null?0:p,'',72));const v=el('div','v');v.append(el('b',null,p==null?'n/a':Math.round(p)+'%'));r.append(v);b.append(r,el('b',null,t),el('span',null,s));g.append(b);});
      cv.append(g);const ms=msMerged().filter(m=>m.status==='earned');
      cv.append(el('p','mo-note',ms.length?'Latest milestone: '+ms[ms.length-1].subject+', '+ms[ms.length-1].step.toLowerCase()+'. '+ms.length+' in all, on Progress.':'No milestones yet.'));
      cv.append(el('p','mx-src','Three separate measures on purpose; there is no combined score. Tap a ring for the list.'));}
    else cv.append(needsEl(calcWhy(['coverage_calc'],'Needs: scores and drift')));}
  drawAgeStats('hm-age',HAGE,true);
}
/* ---------- Money: payoff plan ---------- */
const PO={strategy:null,extra:null};
const STRAT={smart:'Smart order',highest:'Highest rate first',smallest:'Smallest balance first',minimums:'Minimums only'};
function poRun(P){const sv=poSaved();const s=PO.strategy||(sv&&sv.chosen_strategy)||P.strategy||'smart';const e=PO.extra!=null?PO.extra:(sv&&sv.extra_per_month!=null?sv.extra_per_month:P.extra);
  const plan=PAYOFF_SIM(P.debts,e,s,P.start,{hold:P.cushion_hold});const mins=PAYOFF_SIM(P.debts,0,'minimums',P.start);return {s,e,plan,mins};}
const paidText=(pl,i)=>pl.payoff_index[i]===0?'Paid off with this payment':pl.payoff[i]?'Paid off '+monthLab(pl.payoff[i]):'Not paid off within 60 years';
const minText=(mn,i)=>mn.never[i]?'On minimums only: not paid off ('+(mn.never[i]==='no minimum payment on file'?'there is no minimum payment on file':'the minimum is below the monthly interest')+')':'On minimums only: paid off '+monthLab(mn.payoff[i]);
function planCompare(P,pl,mn){const ex=[];let a=0,b=0;P.debts.forEach((d,i)=>{if(mn.never&&mn.never[i]){ex.push(d.name);return;}a+=mn.interest[i];b+=pl.interest[i];});return {saved:a-b,excluded:ex,minInt:a,planInt:b};}
function payNext(P,pl){const fo=pl.first_order;if(!fo||!fo.length)return {text:'Nothing to pay beyond minimums',why:''};
  const i=fo[0],d=P.debts[i];const pay0=pl.schedule?pl.schedule[0].pay[i]:null;const amt=pay0!=null?pay0:d.min+P.extra_first;
  const when=d.days_past_due>0?'today':d.due?'by '+fd(d.due):null;
  const reason=d.days_past_due>0?'Past due first: '+d.days_past_due+' days late.':d.late_recent?'A late payment in the last 90 days.':d.rate==null?'Ranked by balance because no rate is recorded.':'Highest effective rate: '+d.rate+'%.';
  const more=pl.schedule?fo.slice(1).map(j=>({j,x:pl.schedule[0].pay[j]-Math.min(P.debts[j].min,pl.schedule[0].pay[j])})).filter(z=>z.x>0.005):[];
  const then=more.length?'The rest of this month\'s extra goes to '+more.map(z=>P.debts[z.j].name+' ('+money2(z.x)+' above its minimum)').join(', ')+'.':'';
  return {i,d,amount:amt,text:'Pay '+money2(amt)+' to '+d.name+(when?' '+when:''),why:reason+(when?'':' Needs: due date.'),when,then};}
function drawPayoffPlan(){
  const box=$('po-plan');if(!box)return;aboutSync();box.replaceChildren();const P=one('payoff_engine');
  box.append(el('h2',null,'Debt payoff plan'));
  if(!P){box.append(needsEl(calcWhy(["payoff_engine"],'Needs: debts, bills and a pay stub')));return;}
  if(P.surplus==null){box.append(needsEl(calcWhy(["payoff_engine"],'Needs: '+P.needs.join(', '))));return;}
  /* 1. the next move, 2. the debt free date with the extra control, 3. the order, 4. alerts, 5. one About this fold */
  const nx=el('div','mx-nm');nx.id='po-next';box.append(nx);
  const res=el('div');res.id='po-res';box.append(res);
  const max=Math.max(100,Math.ceil(2*Math.max(P.extra,P.surplus,1)/100)*100);const cur=poRun(P).e;
  const cb=el('div','mo-cb');const top=el('div','mo-cb-top');const lab=el('label',null,'Extra toward debt each month');lab.setAttribute('for','po-in');lab.style.fontWeight='600';
  const inp=el('input','mo-in');inp.id='po-in';inp.type='number';inp.min='0';inp.max=String(max);inp.step='1';inp.inputMode='decimal';inp.value=String(Math.round(cur*100)/100);
  top.append(lab,inp);const rg=el('input');rg.type='range';rg.id='po-rg';rg.min='0';rg.max=String(max);rg.step='1';rg.value=String(cur);rg.setAttribute('aria-label','Extra toward debt each month slider');
  const tag=el('div','mx-alert');tag.id='po-tag';const rs=el('button','mx-btn ghost');rs.type='button';rs.id='po-reset';const dflt=poSaved()&&poSaved().extra_per_month!=null?poSaved().extra_per_month:P.extra;rs.textContent='Reset to the default, '+money2(dflt);
  cb.append(top,rg,tag,rs);box.append(cb);
  const ctl=el('div','mo-ctlbar');const seg=el('div','mo-seg mx-strat');seg.setAttribute('role','group');seg.setAttribute('aria-label','Payoff order');seg.id='po-strat';
  [['smart','Smart'],['highest','Highest rate'],['smallest','Smallest']].forEach(([k,t])=>{const b=el('button',null,t);b.type='button';b.dataset.v=k;b.setAttribute('aria-label',STRAT[k]);b.setAttribute('aria-pressed',String(poRun(P).s===k));b.addEventListener('click',()=>{PO.strategy=k;drawPayoffPlan();drawTrail();drawPayoffBasis();});seg.append(b);});
  ctl.append(seg);box.append(ctl);
  const al=el('div','mx-chips');al.id='po-alerts';box.append(al);
  /* About this: take-home arithmetic, notes, cushion note, the three plan table, the order, check C17, ranking rules and math */
  const ab=[];
  ab.push('Every debt gets its minimum first. The extra each month, plus the minimum of every debt already cleared, goes to the debt at the top of the order. The mortgage keeps its own schedule. A planning tool, not advice.');
  const sp=el('div','mx-surplus');const eq=(a,b,c)=>{const r=el('div','eq'+(c?' t':''));r.append(el('span',null,a),el('span',null,b));sp.append(r);};
  eq('Take-home a month (latest stub times paychecks per year, divided by 12; an estimate)',money2(P.take_home));eq('Minus every bill',money2(-P.bills));eq('Minus every debt payment you make'+(P.mins_rows.some(m=>m.est)?' ('+P.mins_rows.filter(m=>m.est).map(m=>m.name).join(', ')+' at the 4 percent estimate)':''),money2(-P.mins));eq('Surplus',money2(P.surplus),true);
  ab.push(sp);
  const cf=parseRow(Array.isArray(rows('scores_config'))?rows('scores_config')[0]:rows('scores_config'),['reweight','trend','inputs','financial','risk']);
  const fb=cf&&cf.inputs&&cf.inputs.foreign_bill_ids?(rows('bills')||[]).filter(b=>cf.inputs.foreign_bill_ids.includes(b.bill_id)):[];
  if(fb.length){const amt=fb.reduce((s,b)=>s+b.monthly_amount,0);ab.push('Secondary, labeled: without '+fb.map(b=>b.name).join(', ')+' the surplus would be '+money2(P.surplus+amt)+'. The plan uses the full bills list.');}
  if(P.withheld.length)ab.push(P.withheld.map(w=>w.name+' ('+money2(w.monthly)+' a month)').join(', ')+' is taken from pay before take-home, so it is not counted again.');
  const cm=P.cash_months;
  ab.push(P.safe_extra<=0?'Build a cushion first, cash covers '+(Math.round(cm*100)/100)+' months.':cm!=null&&cm<1?'Emergency cushion: cash '+money2(P.cash)+' covers '+(Math.round(cm*100)/100)+' months of essentials ('+money2(P.mustpay)+' a month). The plan holds back '+money2(P.cushion_shortfall)+' to reach 1 month, in the first month only, so month 1 puts '+money2(P.extra_first)+' toward debt and every later month puts '+money2(P.extra)+'.':'Emergency cushion: cash covers '+(Math.round(cm*100)/100)+' months of essentials, so nothing is held back and every month puts the full extra toward debt.');
  const ptag=el('p','mo-note');ptag.id='po-tag-about';ab.push(ptag);
  const dyn=el('div','mx-aboutbody');dyn.id='po-about-dyn';ab.push(dyn);
  const rules=el('div','mx-aboutbody');
  rules.append(el('h3',null,'Ranking rules and math'));
  rules.append(el('p','mo-note','Smart order: (1) anything past due, more days first, secured debt first; (2) a late payment in the last 90 days; (3) the highest effective rate, where a card you pay in full each month costs no interest and a promo is ranked by the rate after it; (4) ties by the smaller balance. Notes explain and do not re-rank: secured, variable rate, tax debt, promo end dates, prepayment penalty, more than 30 percent of a card limit used.'));
  rules.append(el('p','mo-note','Math: each month the balance grows by balance x rate / 12, then the payment is subtracted. Total interest is the sum of those monthly charges. Minimums only means each debt pays its own minimum and nothing rolls over; a debt whose minimum does not cover its interest, or that has no minimum, is not paid off on that path and is left out of the interest saved. A debt with no rate on file is simulated without interest and says so. Your choice on the slider stays on this screen; tell Claude the amount to save it in payoff_settings.'));
  ab.push(rules);
  box.append(aboutFold('po',ab));
  const upd=(v,src)=>{v=Math.max(0,Math.min(max,+v||0));PO.extra=v;if(src!=='in')inp.value=String(Math.round(v*100)/100);if(src!=='rg')rg.value=String(v);
    tag.textContent=v>P.surplus+0.005?'More than your surplus of '+money2(P.surplus)+'.':Math.abs(v-P.surplus)<0.005?(P.cushion_hold>0.005?'The full surplus. Month 1 holds back '+money2(Math.min(P.cushion_hold,v))+' for the cushion.':'The full surplus: nothing is held back.'):'';
    ptag.textContent='Default '+money2(P.extra)+' a month; month 1 holds back '+money2(Math.min(P.cushion_hold,P.extra))+' to reach a 1 month cushion; surplus '+money2(P.surplus)+'. Saved choice: '+(poSaved()&&poSaved().extra_per_month!=null?money2(poSaved().extra_per_month):'none yet')+'.';
    drawPayoffResult(P);drawTrail();drawPayoffBasis();};
  rg.addEventListener('input',()=>upd(rg.value,'rg'));inp.addEventListener('input',()=>upd(inp.value,'in'));rs.addEventListener('click',()=>upd(dflt,'reset'));
  upd(cur,'init');
}
function drawPayoffResult(P){
  const box=$('po-res'),nx=$('po-next');if(!box||!nx)return;box.replaceChildren();nx.replaceChildren();const R=poRun(P);const pl=R.plan,mn=R.mins;
  const np=payNext(P,pl);const c0=planCompare(P,pl,mn);
  /* the next move: one action, one short why, the other reasons behind Why */
  nx.className='mx-nm mx-nextpay'+(np.d&&np.d.days_past_due>0?' late':'');
  nx.append(el('p','mx-eyebrow','Next move'));
  const amt=el('p','amt');amt.append(srcNum(np.text,'po','Source: the payoff plan on today\'s balances. Ranking and math are in About this'));nx.append(amt);
  if(np.why)nx.append(el('p','mo-note',np.why));
  const why=el('ul','mx-why');why.id='po-why';
  if(np.d){const d=np.d;const extraTo=Math.max(0,np.amount-d.min);
    if(d.statement_balance!=null&&!(d.days_past_due>0))why.append(el('li',null,'Paying the statement balance '+money2(d.statement_balance)+(d.due?' by '+fd(d.due):'')+' avoids interest on it. The plan pays the whole balance, '+money2(np.amount)+', so no interest is charged this month.'));
    if(np.then)why.append(el('li',null,np.then));
    if(d.rate!=null)why.append(el('li',null,'Each extra dollar here avoids about '+d.rate+' cents of interest a year: '+money2(extraTo*d.rate/100)+' a year on '+money2(extraTo)+' of extra (before compounding).'));
    why.append(el('li',null,paidText(pl,np.i)+'. '+minText(mn,np.i)+'.'));
    d.notes.filter(n=>n.kind==='late').forEach(n=>why.append(el('li',null,n.text)));}
  if(why.children.length){const wb=el('button','why','Why');wb.type='button';wb.setAttribute('aria-controls','po-why');const op=!!ABOUT_OPEN['po-why'];wb.setAttribute('aria-expanded',String(op));why.hidden=!op;
    wb.addEventListener('click',()=>{const o=why.hidden;why.hidden=!o;wb.setAttribute('aria-expanded',String(o));ABOUT_OPEN['po-why']=o;});nx.append(wb,why);}
  const ch=el('div','mx-chips');
  if(np.d&&np.d.days_past_due>0)ch.append(chip(np.d.days_past_due+' days past due','bad'));
  if(np.d&&np.d.min_est)ch.append(chip('Minimum is an estimate','warn'));
  if(ch.children.length)nx.append(ch);
  /* the debt free date */
  const tl=el('div','mo-tiles');tl.id='po-tiles';box.append(tl);
  const base=mn.never.some(Boolean)?Math.max(0,...mn.payoff_index.filter((m,i)=>m!=null&&!mn.never[i])):mn.months;
  const fill=pl.end&&base>0?Math.min(1,pl.months/base):(pl.end?1:0);
  const tile=el('div','mo-tile');tile.append(el('span','mo-tl','Debt free, no mortgage'));
  const dial=el('div','mx-dial');const ring=el('div','ring');ring.append(ringSvg(fill*100,'',104));const v=el('div','v');
  const tv=el('span','mo-tv',pl.end?monthLab(pl.end):'n/a');srcTip(tv,'Source: the payoff plan with '+money(Math.round(R.e))+' extra a month, '+STRAT[R.s]+'. Details in About this');v.append(tv,el('small',null,pl.end?pl.months+' months':'not in 60 years'));ring.append(v);
  const side=el('div','side');const sc=el('div','mx-chips');
  sc.append(chip('Interest '+money(Math.round(pl.total_interest)),''),chip('Saves '+money(Math.round(c0.saved)),'ok'));
  if(pl.end&&!mn.never.some(Boolean)&&mn.months>pl.months)sc.append(chip((mn.months-pl.months)+' months sooner','ok'));
  side.append(sc);dial.append(ring,side);tile.append(dial);tl.append(tile);
  /* alerts that stay on the card */
  const al=$('po-alerts');if(al){al.replaceChildren();
    if(P.safe_extra<=0)al.append(chip('Build a cushion first','warn'));else if(P.cash_months!=null&&P.cash_months<1)al.append(chip('Cash covers '+(Math.round(P.cash_months*100)/100)+' months of essentials','warn'));
    if(P.mins_rows.some(m=>m.est))al.append(chip('Estimate in use: '+P.mins_rows.filter(m=>m.est).map(m=>m.name).join(', '),'warn'));
    if(P.debts.some(d=>d.min_missing))al.append(chip('Needs: a minimum payment','warn'));}
  /* About this, the changing part */
  const dyn=$('po-about-dyn');if(!dyn)return;dyn.replaceChildren();
  {const keep=el('div','mx-keep');keep.append(el('b',null,'Keep the others on their minimums'));
    P.debts.forEach((d,i)=>{if(np.d&&i===np.i)return;const r=el('div');r.append(el('span',null,d.name),el('span',null,d.min_missing?'Needs: minimum':money2(d.min)+(d.min_est?' (estimate)':'')));keep.append(r);});
    P.mins_rows.filter(m=>m.mortgage).forEach(m=>{const r=el('div');r.append(el('span',null,m.name+' (own schedule)'),el('span',null,money2(m.min)));keep.append(r);});dyn.append(keep);}
  dyn.append(el('p','mo-note',poSavedLabel(P,pl,mn)+': '+money(Math.round(c0.saved))+'. '+poSavedWhen(P,pl,mn)+'. Total interest '+money(Math.round(c0.planInt))+' vs '+money(Math.round(c0.minInt))+' on the debts that clear on minimums.'));
  {const h=el('h3',null,'Compare plans with the same '+money(Math.round(R.e))+' extra');h.id='po-compare';dyn.append(h);}
  const order=['smart','highest','smallest'];const runs={};const firsts=[];order.forEach(k=>{runs[k]=k===R.s?pl:PAYOFF_SIM(P.debts,R.e,k,P.start,{hold:P.cushion_hold});});
  const rowsC=order.map(k=>{const p=runs[k];const c=planCompare(P,p,mn);const fi=p.payoff_index.map((m,i)=>[m,i]).filter(z=>z[0]!=null).sort((a,b)=>a[0]-b[0])[0];
    const df=el('span');df.append(document.createTextNode(p.end?monthLab(p.end):'not in 60 years'),el('small',null,p.end?p.months+' months':''));firsts.push(STRAT[k]+': '+(fi?P.debts[fi[1]].name:'n/a'));
    const pn=el('span');pn.append(document.createTextNode(STRAT[k].replace(' first','')),el('small',null,k===R.s?'shown':''));
    return {cls:k===R.s?'sel':'',cells:[pn,df,money(Math.round(p.total_interest)),money(Math.round(c.saved))]};});
  const mnC=planCompare(P,mn,mn);const nv=P.debts.filter((d,i)=>mn.never[i]).map(d=>d.name);const mdf=el('span');mdf.append(document.createTextNode(nv.length?'not paid off':(mn.end?monthLab(mn.end):'n/a')),el('small',null,nv.length?nv.join(', '):mn.months+' months'));
  const mi=el('span');mi.append(document.createTextNode(money(Math.round(mnC.minInt))),el('small',null,'debts that pay off'));rowsC.push({cells:['Minimums only',mdf,mi,'0']});
  dyn.append(v3table([{t:'Plan'},{t:'Debt free'},{t:'Total interest from '+monthLab(P.start)+' to payoff',num:true},{t:'Saved versus minimums only',num:true}],rowsC,'Compare payoff plans'));
  dyn.append(el('p','mx-src','First cleared: '+firsts.join('; ')+'.'));
  const best=order.reduce((a,k)=>runs[k].total_interest<runs[a].total_interest-0.005?k:a,'smart');
  dyn.append(el('p','mo-note',best==='smart'||Math.abs(runs.smart.total_interest-runs[best].total_interest)<0.005?'Smart order costs the least interest here (or ties).':STRAT[best]+' costs '+money(Math.round(runs.smart.total_interest-runs[best].total_interest))+' less interest; Smart order is kept first only for a safety reason (past due, promo or collateral).'));
  dyn.append(el('h3',null,'Payoff order and dates'));
  const ol=el('ol','mx-order');pl.first_order.forEach(i=>{const d=P.debts[i];const li=el('li');li.append(el('b',null,d.name),document.createTextNode(d.rate==null?', rate not on file':', '+d.rate+'%'));
    const why2=d.days_past_due>0?'Past due first.':R.s==='smallest'?'Smaller balance first.':d.rate==null?'No rate on file, so it sits at the end until the rate is known.':'By rate: '+d.rate+'%.';
    li.append(el('small',null,why2+' '+paidText(pl,i)+'. '+minText(mn,i)+'.'));ol.append(li);});
  P.mins_rows.filter(m=>m.mortgage).forEach(m=>{const li=el('li');li.append(el('b',null,m.name),el('small',null,'Not in the order. Keeps its schedule; extra goes to higher rate debts first.'+((m.notes||[]).length?' '+m.notes.join(' '):'')));ol.append(li);});
  dyn.append(ol);
  const c17=(one('checks_calc')?rows('checks_calc'):[]).find(c=>c.id==='C17');if(c17)dyn.append(el('p','mx-src','Check C17: '+c17.detail+'.'));
}
function drawTrail(){
  const box=$('po-trail');if(!box)return;box.replaceChildren(el('h2',null,'Your payoff trail'));const P=one('payoff_engine');
  if(!P||!P.debts.length){box.append(needsEl(calcWhy(["payoff_engine","debt_steps_calc","payoff_calc"],'Needs: debts with balances')));return;}
  const R=poRun(P);const pl=R.plan,mn=R.mins;
  box.append(el('p','mo-note','One stop per debt, in payoff order. The line fills with the share already paid when the original balance is on file.'));
  const tr=el('div','mx-trail');
  pl.first_order.forEach((i,n)=>{const d=P.debts[i];const st=el('div','mx-stop');const late=d.days_past_due>0;
    const node=el('div','mx-node'+(late?' late':''),late?'!':String(n+1));const rail=el('div','rail');const fr=el('i');const share=d.original?Math.max(0,Math.min(1,1-d.balance/d.original)):0;fr.style.height=(share*100)+'%';rail.append(fr);
    const c=el('div','mx-sc'+(late?' late':n===0?' first':''));const hd=el('div','hd');hd.append(el('b',null,'Stop '+(n+1)+': '+d.name),el('span',null,d.rate==null?'rate not on file':d.rate+'%'));c.append(hd);
    const chips=el('div','mx-chips');
    if(late)chips.append(chip(d.days_past_due+' days past due','bad'));
    if(d.util!=null)chips.append(chip(Math.round(d.util)+'% of limit used'+(d.util>30?' (over 30%)':''),d.util>30?'warn':''));
    if(d.secured)chips.append(chip('Secured'));if(d.min_est)chips.append(chip('Minimum is an estimate','warn'));
    chips.append(chip(late?'Past due':'On plan',late?'bad':'ok'));c.append(chips);
    const ds=(rows('debt_steps_calc')||[]).find(z=>z.id===d.id);if(ds&&!ds.needs){const nx=ds.steps.find(z=>!z.done);c.append(v3steps(ds.steps.map(z=>({label:z.short,aria:z.label+' of the first balance',done:z.done,now:nx===z})),d.name+' milestones: '+Math.round(ds.paid_pct)+' percent paid'));}
    if(d.original){c.append(pbar(share*100,{max:100,tick:false}));const v=el('div','mx-vals');v.append(el('span',null,'Original '+money2(d.original)),el('span',null,'Now '+money2(d.balance)+' ('+Math.round(share*100)+'% paid)'));c.append(v);}
    else{const v=el('div','mx-vals');v.append(el('span',null,'Now '+money2(d.balance)),el('span',null,'Needs: original or first recorded balance'));c.append(v);}
    const g=el('div','mx-grid2');const kv=(a,b)=>{const x=el('div');x.append(document.createTextNode(a),el('b',null,b));g.append(x);};
    kv('Interest paid so far',d.interest_paid_to_date!=null?money2(d.interest_paid_to_date):'Needs: statements');
    kv('Interest saved by plan, '+monthLab(P.start)+' to payoff, versus minimums only',mn.never[i]?'not comparable':money2(mn.interest[i]-pl.interest[i]));
    kv('Plan payoff',pl.payoff_index[i]===0?'With this payment':monthLab(pl.payoff[i]));kv('Minimums only',mn.never[i]?(mn.never[i]==='no minimum payment on file'?'Not paid off (no minimum on file)':'Not paid off (minimum below the monthly interest)'):monthLab(mn.payoff[i]));
    c.append(g);
    d.notes.forEach(x=>c.append(el('div','mx-flag'+(x.kind==='late'?'':' w'),x.text)));
    if(d.needs.length)c.append(el('p','mo-needs mo-note','Needs: '+d.needs.join(', ')+'.'));
    st.append(node,rail,c);tr.append(st);});
  if(pl.end){const st=el('div','mx-stop');const node=el('div','mx-node fin');node.append(v3flag());const c=el('div','mx-sc');const hd=el('div','hd');hd.append(el('b',null,'Debt free except the mortgage'),el('span',null,monthLab(pl.end)));c.append(hd);
    const freed=P.debts.reduce((s,d)=>s+d.min,0)+R.e;c.append(el('p','mo-note','All '+P.debts.length+' debts above cleared. The freed '+money2(freed)+' a month (their minimums plus the extra) can go to savings and retirement.'));const rl=el('div','rail');st.append(node,rl,c);tr.append(st);}
  const MG=(rows('payoff_calc')||[]).find(z=>z.type==='Mortgage');const ml=(rows('liabilities')||[]).find(l=>l.type==='Mortgage');
  if(ml){const st=el('div','mx-stop');const node=el('div','mx-node home','\u2302');node.setAttribute('aria-hidden','true');const c=el('div','mx-sc');const hd=el('div','hd');hd.append(el('b',null,'Mortgage, on its schedule'),el('span',null,ml.rate_pct+'%'+(ml.rate_type?' '+ml.rate_type:'')));c.append(hd);
    const ch=el('div','mx-chips');if(ml.secured==='Y')ch.append(chip('Secured by '+(ml.secured_by||'collateral')));c.append(ch);
    if(ml.original_balance){const sh=Math.max(0,Math.min(1,1-ml.balance/ml.original_balance));c.append(pbar(sh*100,{max:100,tick:false}));const v=el('div','mx-vals');v.append(el('span',null,'Original '+money2(ml.original_balance)),el('span',null,'Now '+money2(ml.balance)));c.append(v);}
    else{const v=el('div','mx-vals');v.append(el('span',null,'Now '+money2(ml.balance)),el('span',null,'Needs: original balance'));c.append(v);}
    const g=el('div','mx-grid2');const kv=(a,b)=>{const x=el('div');x.append(document.createTextNode(a),el('b',null,b));g.append(x);};
    kv('Interest paid so far',ml.interest_paid_to_date!=null?money2(ml.interest_paid_to_date):'Needs: statements');kv('Interest saved by plan, '+monthLab(P.start)+' to payoff, versus its schedule',money2(0));
    kv('Payoff on schedule',MG&&MG.payoff?monthLab(MG.payoff):'n/a');kv('Payment (with escrow)',money2(ml.amount_due||ml.monthly_payment));c.append(g);
    c.append(el('p','mo-note','Paying only the scheduled payment is the plan: it is the lowest rate here. Principal and interest '+(MG?money2(MG.payment):'n/a')+' a month; the rest is escrow.'));st.append(node,el('div','rail'),c);tr.append(st);}
  box.append(tr);
  box.append(el('p','mo-note','Interest avoided so far, compared with paying only the minimum: Needs statements that show the interest charged each month. The plan figures above are forward looking.'));
}
function v3flag(){const ns='http://www.w3.org/2000/svg';const s=document.createElementNS(ns,'svg');s.setAttribute('viewBox','0 0 16 16');s.setAttribute('width','16');s.setAttribute('height','16');s.setAttribute('aria-hidden','true');
  const p=document.createElementNS(ns,'path');p.setAttribute('d','M3 1v14M3 2h9l-2 3 2 3H3');p.setAttribute('fill','none');p.setAttribute('stroke','currentColor');p.setAttribute('stroke-width','1.6');s.append(p);return s;}
function drawPayoffBasis(){
  const sg=$('po-basis');const P=one('payoff_engine');const box=$('po-planchart');const old=$('debt-payoff');if(!sg||!box)return;
  const plan=state.poBasis==='plan';const wasHidden=old.hidden;old.hidden=plan;box.hidden=!plan;$('po-view').parentNode.style.display=plan?'none':'';if(!plan&&(wasHidden||!old.querySelector('svg'))){try{drawPayoff();}catch(e){}}if(!plan||!P){box.replaceChildren();return;}
  box.replaceChildren();const R=poRun(P);const pl=R.plan;const W=box.clientWidth||340;const tip=mkTip(box);
  const M=pl.months;const sched=pl.schedule;const keys=P.debts.map((d,i)=>i);
  const H=260,mg={l:52,r:12,t:12,b:28};const x=d3.scaleLinear([0,Math.max(1,M)],[mg.l,W-mg.r]);
  const rowsM=[{m:0,v:P.debts.map(d=>d.balance)}].concat(sched.map((r,k)=>({m:k+1,v:r.bal})));
  const st=d3.stack().keys(keys).value((r,k)=>r.v[k])(rowsM);const ymax=d3.max(st[st.length-1],d=>d[1])||1;
  const y=d3.scaleLinear([0,ymax*1.05],[H-mg.b,mg.t]).nice();const svg=mkSvg(box,W,H,'Stacked balances under your payoff plan, month by month');
  hgrid(svg,y.ticks(4),y,mg.l,W-mg.r);svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(4).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).ticks(Math.min(6,M)).tickFormat(m=>{const l=pl.label?null:null;const t=+P.start.slice(0,4)*12+(+P.start.slice(5,7)-1)+m;return MN[t%12]+' '+String(Math.floor(t/12)).slice(2);}).tickSize(4).tickPadding(6));
  const col=i=>(typeof DEBT_COL==='function'?DEBT_COL({name:P.debts[i].name,type:P.debts[i].type,liability_id:P.debts[i].id}):C[i%C.length]);
  const ar=d3.area().x(d=>x(d.data.m)).y0(d=>y(d[0])).y1(d=>y(d[1]));
  st.forEach(s=>svg.append('path').attr('d',ar(s)).attr('fill',col(s.key)).attr('opacity',.85).attr('stroke','var(--mo-card)').attr('stroke-width',1));
  svg.append('rect').attr('x',mg.l).attr('y',mg.t).attr('width',W-mg.l-mg.r).attr('height',H-mg.t-mg.b).attr('fill','transparent').on('pointermove',ev=>{const [mx]=d3.pointer(ev,svg.node());const m=Math.max(0,Math.min(M,Math.round(x.invert(mx))));const t=+P.start.slice(0,4)*12+(+P.start.slice(5,7)-1)+m;
    const lines=['Start of '+MN[t%12]+' '+Math.floor(t/12)];let tot=0;P.debts.forEach((d,i)=>{const v=rowsM[m].v[i];tot+=v;if(v>0.5)lines.push({t:d.name+': '+money(Math.round(v)),c:col(i)});});lines.push('Total '+money(Math.round(tot)));tip.show(ev,lines);}).on('pointerleave',()=>tip.hide());
  box.append(legendEl(P.debts.map((d,i)=>({label:d.name,color:col(i)}))));
  box.append(el('p','mo-note',STRAT[R.s]+' with '+money(Math.round(R.e))+' extra a month: debt free (no mortgage) '+(pl.end?monthLab(pl.end):'not in 60 years')+'. The mortgage is not in this view.'));
}
/* ---------- Retire: age ladder, plan-year tile, percent forms ---------- */
function drawLadder(id){
  const box=$(id||'rt-ladder');if(!box)return;box.replaceChildren();const A=one('age_calc');
  box.append(el('p','mx-eyebrow','Age ladder'));
  if(!A||!A.ladder){box.append(el('h3',null,'Where you stand'),needsEl(calcWhy(["age_calc"],'Needs: age, salary, retirement balance and the guideline rows')));return;}
  const L=A.ladder;box.append(el('h3',null,'Where you stand at '+L.age));
  box.append(el('p','mo-note','Retirement savings as a share of the published guideline for your age: '+money(Math.round(L.guideline))+' (salary '+money(L.salary)+').'));
  const ul=el('ul','mx-ladder');const items=L.rungs.map(r=>({k:'rung',r})).concat([{k:'you'}]).sort((a,b)=>(b.k==='you'?L.you_pct:b.r.pct)-(a.k==='you'?L.you_pct:a.r.pct));
  items.forEach(it=>{const li=el('li','mx-rung');const dot=el('span','dot');const tx=el('div');
    if(it.k==='you'){li.classList.add('you');dot.textContent='';const t=el('div','t','You are here: '+pc0(L.you_pct)+' of guideline');t.append(chip('NOW','you'));tx.append(t,el('div','d',money2(L.you_amount)+' at age '+L.age+'. The guideline curve reaches this balance at about age '+Math.round(L.you_age_equiv)+'.'));}
    else{const r=it.r;const nxt=L.next&&L.next.pct===r.pct;if(nxt){li.classList.add('next');dot.textContent='\u2191';}else if(r.pct<=L.you_pct)li.classList.add('done');
      const t=el('div','t',r.pct+'% of guideline, '+money(Math.round(r.amount)));if(nxt)t.append(chip('NEXT','next'));tx.append(t,el('div','d','The guideline curve reaches this balance at about age '+Math.round(r.age_at)+'.'));}
    li.append(dot,tx);ul.append(li);});
  box.append(ul);
  if(L.next){const w=el('div','mx-box');w.append(el('b',null,'What it takes: '),document.createTextNode(money(Math.round(L.need_next))+' more reaches the next rung. At your 401(k) pace ('+money(Math.round(L.k401_per_year/12))+' a month) that is about '+Math.round(L.months_to_next_401k)+' months before growth'+(L.months_to_next_limit?'; at the 401(k) limit about '+Math.round(L.months_to_next_limit)+' months':'')+'.'));box.append(w);}
  if(L.target_pct){box.append(el('h3',null,'Age '+L.target_age+' pace'));box.append(pbar(L.target_pct.mid,{max:100,tick:false}));
    const v=el('div','mx-vals');v.append(el('span',null,'Base path '+money(L.proj_target.mid)),el('span',null,'Guideline '+money(L.guideline_at_target)));box.append(v);
    box.append(el('p','mo-note','Base path '+pc0(L.target_pct.mid)+' of the guideline at '+L.target_age+'; range '+pc0(L.target_pct.lo)+' (cautious, '+money(L.proj_target.lo)+') to '+pc0(L.target_pct.hi)+' (optimistic, '+money(L.proj_target.hi)+'). '+(L.trowe_target?'A second publisher puts the target at '+money(L.trowe_target[0])+' to '+money(L.trowe_target[1])+'. ':'')+'On today\'s pay stubs, returns after inflation. An estimate, not a forecast.'));}
  const s=srcLine(L.guideline_rows,'Guideline at '+L.age+' interpolated between the published ages, derived');if(s)box.append(s);
}
const PY={year:null,view:'annual'};
function drawPlanYear(){
  const box=$('rt-plan');if(!box)return;box.replaceChildren(el('h2',null,'401(k) plan year'));const Y=rows('plan_year_calc');
  if(!Y||!Y.length){box.append(needsEl(calcWhy(["plan_year_calc","pct_calc"],'Needs: contribution_limits and contribution_plan')));return;}
  const T=Y.find(r=>!r.past&&!r.future)||Y[Y.length-1];if(PY.year==null)PY.year=T.year;const y=Y.find(r=>r.year===PY.year)||T;
  const bar=el('div','mo-ctlbar');const s1=el('div','mo-seg');s1.setAttribute('role','group');s1.setAttribute('aria-label','Plan year');
  Y.filter(r=>!r.past||r.stubs).forEach(r=>{const b=el('button',null,String(r.year));b.type='button';b.setAttribute('aria-pressed',String(r.year===y.year));b.addEventListener('click',()=>{PY.year=r.year;drawPlanYear();});s1.append(b);});
  const s2=el('div','mo-seg');s2.setAttribute('role','group');s2.setAttribute('aria-label','View');[['annual','Annual'],['quarterly','Quarterly']].forEach(([k,t])=>{const b=el('button',null,t);b.type='button';b.setAttribute('aria-pressed',String(PY.view===k));b.addEventListener('click',()=>{PY.view=k;drawPlanYear();});s2.append(b);});
  bar.append(s1,s2);box.append(bar);
  const est=y.estimate?' (estimate: '+y.limit_row.year+' limit, '+y.year+' not published yet)':'';
  if(y.future){box.append(el('p','mx-big',y.year+' has not started'));
    box.append(el('p','mo-take',(y.chosen_pct==null?'No percent chosen for '+y.year+' yet. Showing a '+y.try_rate+' percent try-a-rate for display only: ':'Chosen '+y.chosen_pct+' percent: ')+money(Math.round(y.rate_annual))+' a year, '+money2(y.rate_pp)+' a paycheck, '+pc0(y.rate_vs_limit)+' of the '+money(y.limit)+' limit'+est+'.'));
    box.append(el('p','mo-note','Reaching the limit takes '+money2(y.need_pp)+' a paycheck ('+(Math.round(y.need_pct_pp*10)/10)+'% of gross) over '+y.remaining_paychecks+' paychecks on the pay calendar.'));}
  else{box.append(el('p','mx-big',money(y.ytd)+' of '+money(y.limit)+' in for '+y.year+est));box.append(el('p','mo-note',money(y.room)+' of room left, from '+y.stubs+' pay stubs on file this year.'));
    box.append(pbar(y.limit?y.ytd/y.limit*100:0,{max:100,tick:false}));
    const stx=y.status==='on_track'?'On track':y.status==='behind'?'Behind':y.status==='reached'?'Limit reached':y.status==='closed'?'Year closed':'Needs data';
    const r=el('div','mx-chips');r.append(chip(stx,y.status==='on_track'||y.status==='reached'?'ok':'warn'));box.append(r);
    if(y.status==='behind'||y.status==='on_track')box.append(el('p','mo-take','At today\'s '+money2(y.pace_pp)+' a paycheck the year ends near '+money(Math.round(y.projected))+(y.status==='behind'?', '+money(Math.round(y.short_by))+' short of the limit':'')+'. Reaching the limit needs '+money2(y.need_pp)+' a paycheck ('+(Math.round(y.need_pct_pp*10)/10)+'% of gross) for the '+y.remaining_paychecks+' paychecks left on the pay calendar.'));}
  if(PY.view==='quarterly'){const q=el('div','mx-qbars');const mx=Math.max(...y.quarters.map(z=>Math.max(z.target||0,z.actual,z.chosen_marker||0)),1);
    y.quarters.forEach(z=>{const c=el('div','mx-q');const t=el('div','bar');const tg=el('i','tg');tg.style.height=((z.target||0)/mx*100)+'%';const ac=el('i','ac');ac.style.height=(z.actual/mx*100)+'%';t.append(tg,ac);
      if(z.chosen_marker!=null){const m=el('b','mk');m.style.bottom=(z.chosen_marker/mx*100)+'%';t.append(m);}
      c.append(t,el('span','ql','Q'+z.q),el('span','qv',z.state==='future'?'not yet':money(z.actual)),el('span','qs',z.stubs?z.stubs+' stubs':'no stubs on file'));q.append(c);});
    box.append(q);box.append(legendEl([{label:'Even pace to the limit ('+money(Math.round(y.limit/4))+' a quarter)',color:'var(--mo-track)'},{label:'From your stubs',color:'var(--mo-accent)'},{label:'Chosen percent marker',color:'var(--mo-fg)'}]));
    box.append(fold('Show table: quarters',mkTable([{t:'Quarter'},{t:'Even pace',num:true},{t:'From stubs',num:true},{t:'Chosen percent',num:true},{t:'Paychecks on calendar',num:true}],y.quarters.map(z=>({cells:['Q'+z.q+(z.state==='current'?' (now)':''),money(Math.round(z.target)),z.state==='future'?'not yet':money(z.actual),z.chosen_marker==null?'n/a':money(Math.round(z.chosen_marker)),z.paychecks_in_calendar==null?'n/a':z.paychecks_in_calendar]})))));}
  /* comparison on one percent of salary scale */
  const cmp=el('div','mx-cmp');const mxp=Math.max(y.cap_pct||0,y.rate_used||0,y.today_pct||0,1)*1.1;
  [['Today',y.today_pct],[y.chosen_pct!=null?'Chosen':'Try-a-rate (display only)',y.rate_used],['Limit',y.cap_pct]].forEach(([l,v])=>{if(v==null)return;const r=el('div','mx-hb');const t=el('div','trk');const i=el('i');i.style.width=(v/mxp*100)+'%';if(l==='Limit')i.style.background='var(--mo-fg)';t.append(i);
    const S=one('pct_calc');const sal=S?S.salary:null;r.append(el('span',null,l),t,el('span','v',(Math.round(v*10)/10)+'%'+(sal?' = '+money(Math.round(v/100*sal))+' a year':'')));cmp.append(r);});
  box.append(el('h3',null,'Percent of salary'),cmp);
  if(y.over_cap)box.append(el('p','mo-needs mo-note','The chosen percent is above the limit percent; payroll stops at the limit.'));
  const nd=[];if(y.ytd_column==null)nd.push('a year to date 401(k) column from the stubs to tie this total');if(!y.calendar_known)nd.push('pay dates');
  {const ps=(rows('paystubs')||[]).filter(s=>s.pay_date&&s.pay_date.slice(0,4)===String(y.year)).map(s=>s.pay_date).sort();if(ps.length&&ps[0]>y.year+'-02-01'&&!y.future)nd.push('any 401(k) deferrals this year before the first stub on file ('+fdy(ps[0])+'); the limit is per person');}
  if(nd.length)box.append(el('p','mo-needs mo-note','Needs: '+nd.join('; ')+'.'));
  if(y.limit_row)box.append(el('p','mx-src','Limits for '+y.limit_row.year+': '+y.limit_row.source+', checked '+fdy(y.limit_row.as_of_checked)+(y.catchup?'. Catch-up included (age 50 or more).':'. No catch-up before age 50.')));
}
const AGEF={view:'all'};
const HAGE={view:'all'};
function drawAgeStats(id,ST,home){
  ST=ST||AGEF;const box=$(id||'rt-age');if(!box)return;const A=one('age_calc');
  if(home){box.replaceChildren(el('p','mx-eyebrow','You and people your age'));if(!A||!A.metrics){box.append(el('h2',null,'Where you stand at your age'),needsEl(calcWhy(["age_calc"],'Needs: your age and the benchmarks dataset')));return;}box.append(el('h3',null,'Percent of guideline, typical, and rank'));}
  else{box.replaceChildren(el('h2',null,'You and people your age'));
  if(!A||!A.metrics){box.append(needsEl(calcWhy(["age_calc"],'Needs: age and the benchmarks dataset')));return;}
  box.append(el('h3',null,'Percent of guideline, typical, and rank'));}
  box.append(el('p','mo-note','Three views for each number, all as percentages, for people '+A.bracket_label+'. Bars run 0 to 200 percent; the dark tick is 100 percent. Needs data means the sources have no figure, not that you scored zero.'));
  const sg=el('div','mo-seg');sg.setAttribute('role','group');sg.setAttribute('aria-label','Which view');[['all','All three'],['guideline','Guideline'],['typical','Typical'],['rank','Rank']].forEach(([k,t])=>{const b=el('button',null,t);b.type='button';b.setAttribute('aria-pressed',String(ST.view===k));b.addEventListener('click',()=>{ST.view=k;drawAgeStats(id,ST,home);});sg.append(b);});box.append(sg);
  const fv=m=>m.unit==='USD'?money(Math.round(m.value)):m.unit==='months'?(Math.round(m.value*100)/100)+' months':m.unit==='percent of pay'?(Math.round(m.value*10)/10)+'% of pay':(Math.round(m.value*10)/10)+'%';
  A.metrics.filter(m=>!(home&&m.info)).forEach(m=>{const s=el('div','mx-am');const h=el('div','h');h.append(el('b',null,m.title+(m.lower_better?' (lower is better)':'')),el('span','v',fv(m)));s.append(h);
    const g=el('div','mx-am3'+(ST.view!=='all'?' one':''));
    const box3=(k,lab)=>{if(ST.view!=='all'&&ST.view!==k)return;const f=m[k];const c=el('div','mx-fm');c.append(el('span','l',lab));
      if(k==='rank'){if(f.percentile!=null){c.append(el('span','p','Top '+Math.round(f.top_pct)+'%'),pbar(f.percentile,{max:100,tick:false}),el('span','x',f.text+(f.approx?', approximate':'')));}
        else if(f.text){c.append(el('span','p',f.text.replace(/^(above|below) the /,(x,a)=>a==='above'?'Above ':'Below ')),el('span','x','percentile'));}
        else c.append(el('span','p nd','Needs data'),el('span','x',f.needs.replace(/^Needs data: /,'')));}
      else if(f.pct!=null){c.append(el('span','p',pc0(f.pct)),pbar(f.pct),el('span','x','of '+(k==='guideline'?(m.lower_better?'the limit':'guideline'):'typical')+(f.range?'; range '+pc0(f.range[0])+' to '+pc0(f.range[1]):'')));}
      else c.append(el('span','p nd',/^No guideline/.test(f.needs||'')?'Not used':/^Needs:/.test(f.needs||'')?'Needs':'Needs data'),el('span','x',(f.needs||'').replace(/^Needs( data)?: /,'')));
      g.append(c);};
    box3('guideline','Of guideline');box3('typical','Of typical');box3('rank','Rank for your age');s.append(g);
    const rd=[];if(m.id==='net_worth'&&m.typical.alts&&m.typical.alts.length>1)rd.push('Sources disagree, so the range is shown: '+m.typical.alts.map(a=>pc0(a.pct)+' of '+a.label).join('; ')+'.');
    if(m.id==='retirement'&&m.guideline.range_amounts)rd.push('A second publisher puts the guideline at '+money(Math.round(m.guideline.range_amounts[0]))+' to '+money(Math.round(m.guideline.range_amounts[1]))+', so you are at '+pc0(m.guideline.range[0])+' to '+pc0(m.guideline.range[1])+' of that range. Typical is '+(m.typical.note||'')+'.');
    if(m.id==='credit_card'&&m.typical.alts)rd.push(m.typical.alts.map(a=>pc0(a.pct)+' of the '+a.label).join('; ')+'.');
    if(m.id==='emergency')rd.push('Your cash covers '+(Math.round(m.value*100)/100)+' months of essentials. With one earner and a mortgage, 6 months is the fuller target. Of typical '+(m.typical.note||'')+'.');
    if(m.id==='dti'&&m.guideline.pct_entered!=null)rd.push(pc0(m.guideline.pct)+' of the 36 percent limit with the card estimate, '+pc0(m.guideline.pct_entered)+' on entered payments only.');
    if(m.note)rd.push(m.note);
    s.append(el('p','rd',(m.label!=='info'?(LABEL_WORD[m.label]||'')+'. ':'')+rd.join(' ')));
    const allRows=[].concat(m.guideline.rows||[],m.typical.rows||[],m.rank.rows||[]);const sl=srcLine(allRows);if(sl)s.append(sl);
    box.append(s);});
  if(home){box.append(el('p','mx-src','Typical and rank compare you with people '+A.bracket_label+' (Federal Reserve Survey of Consumer Finances and other named sources, each on Progress, Age ladder). A planning tool, not advice.'));
    const b=el('button','mo-link','See every comparison and source');b.type='button';b.addEventListener('click',()=>goTo('progress','rt-age'));box.append(b);return;}
  box.append(el('p','mx-src',A.disclaimer));
  const b=el('button','mo-link','Every benchmark row with its source');b.type='button';b.addEventListener('click',()=>go('progress','acc-bench'));box.append(b);
}
/* ---------- Cash: drift on every account, bill statements ---------- */
function drawDriftAll(){
  const box=$('card-drift-all');if(!box)return;box.replaceChildren(el('h2',null,'Every account, weekly check points'));const D=one('drift_all');
  if(!D){box.append(needsEl(calcWhy(["drift_all"],'Needs: reported balances')));return;}
  box.append(el('p','mo-take','The same check for every account and card: reported balance minus expected balance. On a card, a balance above expected is spending not loaded yet. Nothing here guesses a cause.'));
  const accts=D.accounts.map(a=>a.account);const gr=el('div','mx-wk');gr.setAttribute('role','table');gr.setAttribute('aria-label','Reported balances by check point date');
  gr.style.gridTemplateColumns='minmax(0,.9fr) repeat('+D.grid.length+',minmax(0,1fr))';
  gr.append(el('span','h','Check point'));D.grid.forEach(g=>gr.append(el('span','h num',fd(g.date))));
  accts.forEach(a=>{gr.append(el('span','a',a));D.grid.forEach(g=>{const r=g.accounts.find(z=>z.account===a);gr.append(el('span','num'+(r&&r.reported!=null?'':' miss'),r&&r.reported!=null?money2(r.reported):'not sent'));});});
  box.append(gr);
  box.append(el('p','mo-note','Next weekly check point: '+(D.next_check?fdy(D.next_check):'n/a')+'. Report all '+accts.length+' balances on the same day so every account can be checked.'));
  D.accounts.forEach(a=>{const r=el('div','mx-hist');const last=[...a.points].reverse().find(p=>p.drift!=null);
    const h=el('div','mx-hh');h.append(el('b',null,a.account+(a.card?' (card)':'')));
    if(last){const amt=last.unexplained;h.append(el('span',null,amt<0.005?'no drift':money2(amt)+(a.card?' unexplained card spending':' less than expected')));}
    else h.append(el('span','mo-needs',a.single?'needs a second balance':'needs data'));r.append(h);
    if(last){r.append(el('span','mo-note',fd(last.from)+' to '+fd(last.to)+': opening '+money2(last.opening)+(a.card?' plus loaded charges '+money2(last.inflows)+' minus payments '+money2(last.outflows):' plus inflows '+money2(last.inflows)+' minus outflows '+money2(last.outflows))+' = expected '+money2(last.expected)+'; reported '+money2(last.reported)+'.'));
      const h=(rows('drift_history')||[]).find(z=>z.account===a.account&&z.date===last.to);if(h&&h.first_drift!=null&&Math.abs(h.first_drift-last.drift)>0.005)r.append(el('span','mo-note','Drift on '+fd(last.to)+' was '+money2(h.first_drift)+' when first checked; after new data it is '+money2(last.drift)+'.'));
      if(a.card&&last.unexplained>0.005)r.append(el('span','mo-note','Charges after the last statement are not in the data yet; the next downloaded statement (PDF or CSV) closes this.'));}
    const n=a.points.filter(p=>p.drift!=null).length;
    if(a.single){r.append(el('span','mx-src','One balance so far; send it again on the next check point.'));box.append(r);return;}
    if(a.trend){const vals=a.points.filter(p=>p.drift!=null).map(p=>p.drift);r.append(spark(vals,C[0]));}else r.append(el('span','mx-src',n+' check '+(n===1?'period':'periods')+'; a trend needs 3.'));
    box.append(r);});
  if(D.expected_now&&D.expected_now.length){box.append(el('h3',null,'Expected now (not a reading)'));D.expected_now.forEach(x=>box.append(el('p','mo-note',x.account+': expected '+money2(x.expected)+' on '+fd(x.expected_date)+' from user confirmed events, not a bank reading. Last reported '+money2(x.reported)+' on '+fd(x.reported_date)+'.'+(x.after_pending!=null?' After the pending deposit: '+money2(x.after_pending)+'.':'')+' Drift will be the next reported balance minus '+money2(x.expected)+'.')));}
  if(D.expected_events&&D.expected_events.length){box.append(el('h3',null,'User confirmed, not yet in a reported balance'));D.expected_events.forEach(x=>{const r=el('div','mx-hist');const h=el('div','mx-hh');h.append(el('b',null,x.kind),el('span',null,money2(x.amount)));r.append(h,el('span','mo-note',fd(x.date)+', '+(x.account==='Not confirmed'?'paying account not confirmed':x.account)+'. '+(x.applied?'Counted as an expected outflow.':'Same money as '+(x.linked||'another event')+', not applied twice.')));box.append(r);});}
  if(D.open_items&&D.open_items.length){box.append(el('h3',null,'Open questions'));D.open_items.forEach(x=>{const r=el('div','mx-hist');const h=el('div','mx-hh');h.append(el('b',null,x.question),el('span',null,money2(x.amount)));r.append(h,el('span','mo-note',x.kind+', '+x.account+', '+x.date+'. Not applied to any expected balance until you say whether it is already in the balance.'));box.append(r);});}
  if(D.pending&&D.pending.length){box.append(el('h3',null,'Pending'));D.pending.forEach(x=>{const r=el('div','mx-hist');const h=el('div','mx-hh');h.append(el('b',null,x.kind),el('span',null,money2(x.amount)));r.append(h,el('span','mo-note',fd(x.date)+', '+x.account+(x.linked?', same money as '+x.linked+' (applied once)':'')+'. Pending: not in any balance or drift check until it is confirmed.'));box.append(r);});}
  if(D.atm.length){box.append(el('h3',null,'ATM and cash'));D.atm.forEach(x=>box.append(el('p','mo-note','ATM '+fd(x.date)+' from '+x.account+': '+money2(x.amount)+', cash spending not tracked.')));}
  else box.append(el('p','mo-note','ATM withdrawals and cash transfers carry an ATM label, count as known outflows and are listed as cash spending not tracked. None so far.'));
  const hs=rows('drift_history')||[];box.append(el('p','mx-src','Check points saved in drift_history: '+hs.length+'. Unexplained total '+money2(D.unexplained_total)+' against '+money2(D.known_outflow)+' of known outflows.'));
}
function drawBillHist(){
  const box=$('card-billhist');if(!box)return;box.replaceChildren(el('h2',null,'Bill statement history'));const bs=(rows('bill_statements')||[]).filter(b=>b.bill&&b.statement_date&&typeof b.amount==='number');
  if(!bs.length){box.append(needsEl('Needs: bill statements'));return;}
  const by=d3.group(bs,b=>b.bill);
  by.forEach((list,name)=>{const L=[...list].sort((a,b)=>a.statement_date<b.statement_date?-1:1);const wrap=el('div','mx-bh');wrap.append(el('h3',null,name+' ('+L.length+' statements)'));
    const W=(box.clientWidth||340)-4,H=150,mg={l:44,r:8,t:10,b:24};const svg=mkSvg(wrap,W,H,name+' amount by statement date');
    const x=d3.scaleBand(L.map(z=>z.statement_date),[mg.l,W-mg.r]).padding(.25);const y=d3.scaleLinear([0,d3.max(L,z=>z.amount)*1.1],[H-mg.b,mg.t]).nice();
    hgrid(svg,y.ticks(3),y,mg.l,W-mg.r);svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(3).tickFormat(v=>'$'+v).tickSize(0).tickPadding(4));
    const step=Math.ceil(L.length/5);svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickValues(L.filter((z,i)=>i%step===0).map(z=>z.statement_date)).tickFormat(s=>MN[+s.slice(5,7)-1]+' '+s.slice(2,4)).tickSize(0).tickPadding(6));
    const tip=mkTip(wrap);svg.selectAll('rect.b').data(L).join('rect').attr('class','b').attr('x',z=>x(z.statement_date)).attr('width',x.bandwidth()).attr('y',z=>y(z.amount)).attr('height',z=>y(0)-y(z.amount)).attr('rx',2).attr('fill',C[0])
      .on('pointermove',(ev,z)=>tip.show(ev,[fdy(z.statement_date),money2(z.amount),z.note||''].filter(Boolean))).on('pointerleave',()=>tip.hide());
    const bl=(rows('bills')||[]).find(b=>b.name===name);wrap.append(el('p','mo-note','Latest '+money2(L[L.length-1].amount)+' ('+fdy(L[L.length-1].statement_date)+'), average '+money2(d3.mean(L,z=>z.amount))+(bl?'. The bills list uses '+money2(bl.monthly_amount)+' a month.':'.')));
    wrap.append(fold('Show table: '+name,mkTable([{t:'Statement'},{t:'Amount',num:true},{t:'Due'},{t:'Note'}],L.map(z=>({cells:[fdy(z.statement_date),money2(z.amount),z.due_date?fdy(z.due_date):'n/a',z.note||'']})))));
    box.append(wrap);});
  box.append(el('p','mx-src','Amounts only, from the billing screens and eBills; no account numbers are stored.'));
}
/* ---------- More: task queue, progress, benchmarks ---------- */
const TQ={area:'All'};
function drawTaskQueue(){
  const box=$('tq-card');if(!box)return;const keep=box.querySelector('.mx-ask');box.replaceChildren(el('h2',null,'Task queue'));const tk=tasksView();
  if(!tk){box.append(needsEl(calcWhy(["next_move"],'Needs: the task list')));return;}
  const open=tk.filter(t=>t.status!=='Done');const done=tk.filter(t=>t.status==='Done');const ver=done.filter(t=>t.verified_on);
  box.append(el('p','mo-take',open.length+' open ('+open.filter(t=>t.status==='To do').length+' To do, '+open.filter(t=>t.status==='Open').length+' Open), '+done.length+' done ('+ver.length+' verified, '+(done.length-ver.length)+' unverified).'));
  box.append(el('p','mo-note mx-rule',RULE_TEXT));
  const n=one('next_move');if(n)box.append(el('p','mo-note','Next: '+n.text));
  const areas=['All'].concat([...new Set(tk.map(t=>t.area))].sort());
  const chips=el('div','mx-filter');chips.setAttribute('role','group');chips.setAttribute('aria-label','Filter by area');
  areas.forEach(a=>{const b=el('button',null,a+(a==='All'?'':' ('+tk.filter(t=>t.area===a&&t.status!=='Done').length+')'));b.type='button';b.setAttribute('aria-pressed',String(TQ.area===a));b.addEventListener('click',()=>{TQ.area=a;drawTaskQueue();});chips.append(b);});box.append(chips);
  const list=el('ul','mx-tasks'),dlist=el('ul','mx-tasks');const sel=tk.filter(t=>TQ.area==='All'||t.area===TQ.area);
  const ord=rankTasks(sel.filter(t=>t.status!=='Done')).concat(sel.filter(t=>t.status==='Done').sort((a,b)=>(b.done_date||'')<(a.done_date||'')?-1:(b.done_date||'')>(a.done_date||'')?1:0));
  ord.forEach(t=>{const li=el('li');li.id='tq-'+t.id;const top=el('div','tt');top.append(el('b',null,t.task));
    const st=t.status==='Done'?(t.verified_on?'Done, verified '+fd(t.verified_on):'Done (unverified)'):t.status;top.append(chip(st,t.status==='Done'?(t.verified_on?'ok':'warn'):''));li.append(top);
    const meta=taskMeta(t);if(t.status==='Done'&&!t.done_date)meta.push('done date not recorded');
    if(t.metric)meta.push('moves '+t.metric+(t.metric_before!=null?' from '+t.metric_before+' to '+t.metric_after:''));{const cr=cellObj(t.checks_run);if(Array.isArray(cr)&&cr.length)meta.push('checks '+cr.join(', '));}if(t.effort)meta.push('effort '+t.effort);
    li.append(el('small',null,meta.join(', ')));if(t.note)li.append(el('small','nt',t.note));li.append(taskActs(box,t));(t.status==='Done'?dlist:list).append(li);});
  box.append(list);if(dlist.children.length)box.append(fold('Done tasks ('+dlist.children.length+')',dlist));
  box.append(addTaskForm(box));if(keep)box.append(keep);
}
function drawProgress(){
  const box=$('pg-body');if(!box)return;box.replaceChildren();const K=one('coverage_calc'),ms=msMerged(),ck=(rows('checks_calc')||[]).concat(rows('checks_more_calc')||[]);
  const c1=el('div','mo-card');c1.append(el('h2',null,'Coverage'));
  if(K){c1.append(el('p','mo-note','Picture: '+K.picture_have+' of '+K.picture_total+' core datasets have current rows ('+pc0(K.picture_pct)+'). Scores: '+K.scores_weight_have+' of '+K.scores_weight_total+' weight has data ('+pc0(K.scores_pct)+'). Explained: '+(K.explained_pct==null?'no check yet':pc0(K.explained_pct)+' of money that left is explained ('+money2(K.unexplained)+' unexplained)')+'.'));
    c1.append(miniGrid([{t:'Dataset'},{t:'Newest'},{t:'Current'}],K.picture.map(p=>[p.id.replace(/_/g,' '),p.newest?fd(p.newest):(p.has?'undated':'empty'),p.fresh?'Yes':{t:'No',miss:true}]),'minmax(0,1.6fr) minmax(0,1fr) minmax(0,.8fr)','Datasets and how current they are'));
    c1.append(el('p','mo-note','Missing for the scores: '+K.missing.join(', ')+'.'));}
  box.append(c1);
  const c2=el('div','mo-card');c2.append(el('h2',null,'Milestones'));
  if(ms.length){const ul=el('ul','mx-tasks');ms.forEach(m=>{const li=el('li');const t=el('div','tt');t.append(el('b',null,m.subject+': '+m.step),chip(m.status==='earned'?'Earned':'Retracted',m.status==='earned'?'ok':'warn'));li.append(t,el('small',null,(m.first_seen?'First seen ':'Since ')+fdy(m.earned_on)+'. Evidence: '+m.evidence_dataset+' '+m.evidence_id+'. '+m.note));ul.append(li);});c2.append(ul);}
  else c2.append(el('p','mo-note','None yet.'));
  c2.append(el('p','mx-src','Derived from your data, no points, levels or streaks. A corrected row retracts a milestone instead of deleting it.'));box.append(c2);
  const c3=el('div','mo-card');c3.append(el('h2',null,'Checks run on this page'));const cnt=s=>ck.filter(c=>c.status===s).length;
  c3.append(el('p','mo-note',cnt('pass')+' pass, '+cnt('needs')+' need data, '+cnt('fail')+' fail.'));
  const ul=el('ul','mx-tasks');ck.forEach(c=>{const li=el('li');const t=el('div','tt');t.append(el('b',null,c.id+' '+c.name),chip(c.status==='pass'?'Pass':c.status==='needs'?'Needs data':'Fail',c.status==='pass'?'ok':c.status==='needs'?'warn':'bad'));li.append(t,el('small',null,c.detail));ul.append(li);});c3.append(ul);box.append(c3);
}
function drawBench(){
  const box=$('bench-body');if(!box)return;box.replaceChildren();const bm=rows('age_benchmarks'),A=one('age_calc');
  if(!bm){box.append(needsEl(calcWhy(["age_calc"],'Needs: age_benchmarks')));return;}
  const b=A?A.bracket:'35_44';const mine=bm.filter(r=>r.id.indexOf('_'+b)>=0||r.id.startsWith('g_'));
  const fmtv=r=>{const u=r.unit||'';if(u==='USD')return money(r.value);if(/^x /.test(u))return Math.round(r.value*100)+'% of '+u.slice(2);if(/^percent/.test(u))return r.value+'% '+u.replace(/^percent\s*/,'').replace(/^of /,'of ');return r.value+' '+u;};
  const c=el('div','mo-card');c.append(el('h2',null,'Benchmarks for '+(A?A.bracket_label:'your age')+' and guidelines'));
  c.append(el('p','mo-note',mine.length+' of '+bm.length+' rows. Multiples of salary are shown as a percent of salary. Each row keeps its source, data year and dollar year.'));
  c.append(fold('Show table: '+mine.length+' rows',mkTable([{t:'Row'},{t:'Statistic'},{t:'Value',num:true},{t:'Year'},{t:'Source'}],mine.map(r=>({cells:[r.metric.replace(/_/g,' ')+' ('+r.age_group+')',(r.id.match(/_p(\d\d)_/)?ordn(+r.id.match(/_p(\d\d)_/)[1])+' ':'')+r.statistic,fmtv(r),r.data_year+(r.unit==='USD'?', '+((String(r.population_note||'').match(/(\d{4}) dollars/)||[])[1]||'nominal')+' dollars':''),r.source+(r.confidence?' ('+r.confidence+' confidence)':'')]})))));
  box.append(c);
}
/* one definition of the data queue counts (F6): still needed = Needed plus Statement requested; observations and dashboard to do are separate */
function dqCounts(q){const c={total:q.length,provided:0,needed:0,requested:0,observations:0,todo:0};q.forEach(x=>{if(x.status==='Provided')c.provided++;else if(x.status==='Needed')c.needed++;else if(x.status==='Statement requested'){c.needed++;c.requested++;}else if(x.status==='Observation')c.observations++;else if(x.status==='Dashboard to do')c.todo++;});return c;}
function drawBackupExtra(){
  const box=$('bk-kit');if(!box)return;box.replaceChildren();if(typeof window.__bkShowStatus==='function')window.__bkShowStatus();
  const info=typeof window.__bkInfo==='function'?window.__bkInfo():{last:null};const T=window.__TODAY||new Date().toISOString().slice(0,10);
  const D=typeof window.__bkDue==='function'?window.__bkDue(info.last,T,null):null;
  const p=el('p','mo-note','Monthly backup: save the rebuild kit on the 1st of each month and copy it to your own cloud folder. '+(D?(D.overdue?'Overdue: '+(info.last?'the last confirmed backup ('+fdy(info.last)+') is before the 1st of this month.':'no confirmed backup yet; the first was due '+fdy(D.due)+'.'):'Next one due '+fdy(D.due)+'.'):''));
  p.id='bk-due';if(D&&D.overdue)p.classList.add('mo-wrn');box.append(p);
  box.append(el('p','mo-note','Rebuild kit (zip): every dataset as its own JSON file ready to upload, a CSV of each (a view only), the dataset titles, descriptions and sources, the dashboard title, a schema with each field\'s types, a manifest with the sha256 of every file, the page source when this view can read it, and RESTORE.md with the steps. The JSON backup holds the same in one file. The architecture document, style guide and change log come from Claude on request.'));
  box.append(el('p','mo-note','Send downloaded statements (PDF or CSV) when you can and keep the originals in your own folder. A screenshot still works: its values are used right away and the statement is requested to confirm them. Only the extracted values are kept, never account numbers, addresses or loan IDs.'));
}
window.__bkRedraw=()=>{const pg=document.getElementById('page-data');if(!pg||pg.hidden)return;try{drawBackupExtra();}catch(e){console.error('draw backup: '+e.message);}};
function drawHouseStatus(){const t=$('house-tiles');if(!t)return;const old=$('house-status');if(old)old.remove();const h=(rows('assets_other')||[]).find(a=>a.type==='Real estate');if(!h)return;
  const p=el('p','mo-note',h.status?'Status: '+h.status+'.'+(h.sale_assumed==='No'?' No sale is assumed; Net if sold is a what-if only.':''):'Sale status: not recorded. Net if sold is a what-if only.');p.id='house-status';t.after(p);}
function expectedNotes(){const out=[];(rows('assets_other')||[]).forEach(a=>{if(a.value_basis==='expected')out.push(a.name+' '+money2(a.value_point)+' is '+(a.value_basis_note||'expected, not a reading').replace(/^Expected/,'expected')+' (reported '+money2(a.reported_value)+' on '+fd(a.reported_date)+').');});
  (rows('liabilities')||[]).forEach(l=>{if(l.value_basis==='expected')out.push(l.name+' '+money2(l.balance)+' is '+(l.balance_basis||'expected, not a reading').replace(/^Expected/,'expected')+' (reported '+money2(l.reported_balance)+' on '+fd(l.reported_date)+').');});
  const h=rows('networth_history');const last=h&&h.length?[...h].sort((a,b)=>a.date<b.date?-1:1).pop():null;
  if(last&&last.basis==='expected'&&cellObj(last.reported_snapshot))out.push('Net worth uses these expected values; the last reported snapshot was '+money2(cellObj(last.reported_snapshot).net_worth)+' on '+fd(cellObj(last.reported_snapshot).date)+'.');
  return out;}
function drawExpected(tab){if(tab==='cash'){const old=document.getElementById('exp-cash');if(old)old.remove();const n=expectedNotes();const body=document.querySelector('#about-bal-total .mx-aboutbody'),hero=document.querySelector('#cash-bal .mx-bal.hero .mo-tile');if(!n.length||!body)return;
    const p=el('p','mo-note mx-expnote',n.join(' ')+' Confirm with the next balance and the next statement.');p.id='exp-cash';body.append(p);if(hero&&!hero.querySelector('.mx-chip'))hero.append(aboutChip('Expected values in use','warn'));return;}
  const map={home:'hm-hero',money:'nw-tiles',cash:'cash-bal'};const id=map[tab];if(!id)return;const host=$(id);if(!host)return;const old=$('exp-'+tab);if(old)old.remove();const n=expectedNotes();if(!n.length)return;
  const p=el('p','mo-note mx-expnote',n.join(' ')+' Confirm with the next balance and the next statement.');p.id='exp-'+tab;if(tab==='home')host.append(p);else host.after(p);}

