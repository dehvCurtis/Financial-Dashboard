'use strict';
/* ---------- shared helpers ---------- */
const state={sort:{key:'value',dir:-1},tmGroup:'account',poView:'all',poBasis:'today',ret:null};
/* an empty calc result means no data for that card: the card shows its Needs line, the same as a calc that has not loaded */
/* a row with every field empty is a file's no-rows placeholder; cards skip it (a named placeholder such as a goal_id none row stays) */
const rows=id=>{const d=dash.data(id);if(!d||d.status!=='ok'||!Array.isArray(d.data))return d&&d.status==='ok'?d.data:null;const r=d.data.filter(x=>!(x&&typeof x==='object'&&Object.keys(x).every(k=>x[k]==null)));return r.length?r:null;};
const needsEl=t=>el('span','mo-needs',t);
/* A file with no real rows yet keeps one placeholder row (every field null, or its id none) so the store can load it; calcs skip it. */
function isPlaceholder(r){if(!r||typeof r!=='object')return true;const v=Object.keys(r).map(k=>r[k]);if(v.every(x=>x==null))return true;const id=['goal_id','question_id','id','queue_id','setting_id','liability_id','bill_id','asset_id'].find(k=>k in r&&r[k]!=null);return id?String(r[id]).toLowerCase()==='none':false;}
const realRows=a=>(a||[]).filter(r=>!isPlaceholder(r));
/* ---------- live store cell shape (hotfix v4.1) ----------
   The live store hands a file row's nested object or array cell over as its JSON text (Dashboard type: "a nested object as its JSON").
   Each reader of such a cell parses it where it reads it: cellObj(v) gives the object or array for JSON text and the value as it came
   for anything else (an object already parsed, a number, text that is not JSON, null). parseRow(r, keys) does that for named cells. */
function cellObj(v){if(typeof v!=='string')return v;try{const o=JSON.parse(v);return o&&typeof o==='object'?o:v;}catch(e){return v;}}
function parseRow(r,keys){if(!r||typeof r!=='object')return r;const o=Object.assign({},r);keys.forEach(k=>{o[k]=cellObj(r[k]);});return o;}
/* CR records each calc's inputs (for the cards' messages) and hands the options to dash.calc unchanged. */
const CALC_IN={};
function CR(id,o){CALC_IN[id]=(o&&o.inputs||[]).slice();return o;}
/* A calc that threw has status error with its own message; a calc downstream of it has status error with "<calc> didn't run."
   calcWhy(ids, text) names the calc that threw, else gives the card's own Needs text. */
const DIDNT_RUN=/^(.+?) didn[’']t run\.?$/;
function calcErr(id){let d=null;try{d=dash.data(id);}catch(e){d=null;}return d&&d.status==='error'?String(d.message||''):null;}
function calcRoot(id,seen){seen=seen||new Set();if(seen.has(id))return null;seen.add(id);const m=calcErr(id);if(m==null)return null;
  const w=m.match(DIDNT_RUN);if(w){for(const n of w[1].split(/,\s*/)){const r=calcRoot(n.trim(),seen);if(r)return r;}}
  else if(/didn[’']t load|isn[’']t in this dashboard/.test(m))return null;
  for(const i of CALC_IN[id]||[]){if(!CALC_IN[i])continue;const r=calcRoot(i,seen);if(r)return r;}
  return w?null:{id,msg:m};}
function calcWhy(ids,text){for(const id of [].concat(ids)){const r=calcRoot(id);if(!r)continue;
    const t='Did not run: '+r.id+' ('+(r.msg.length>80?r.msg.slice(0,80):r.msg)+')';return r.id===id?t:t+'. Waiting on '+r.id+', which did not run.';}
  return text;}
/* Triple tap readout: which cells arrived as JSON text, and which calcs did not run. */
const NESTED_CELLS={age_metrics_config:['age_lookup','label_vocabulary','peer_group_notes','metrics','data_needs_to_check'],assets_other:['expected_events'],balance_log:['expected_after_known_events'],mortgage_statements:['last_month_paid','activity','expected_after_oct_payment'],networth_history:['reported_snapshot'],scores_config:['reweight','trend','inputs','financial','risk'],scores_history:['component_points'],tasks:['checks_run']};
function liveShapeReport(){const t=[],o=[];Object.keys(NESTED_CELLS).forEach(id=>{const r=rows(id);if(!r)return;let s=0,b=0;r.forEach(x=>NESTED_CELLS[id].forEach(k=>{if(typeof x[k]==='string')s++;else if(x[k]&&typeof x[k]==='object')b++;}));if(s)t.push(id+' '+s);if(b)o.push(id+' '+b);});
  const f=Object.keys(CALC_IN).sort().map(i=>[i,calcErr(i)]).filter(x=>x[1]!=null);
  return 'cells as JSON text: '+(t.length?t.join(', '):'none')+(o.length?'  (as objects: '+o.join(', ')+')':'')+'\ncalcs that did not run: '+(f.length?f.map(x=>x[0]+' ('+x[1].slice(0,60)+')').join(', '):'none');}
const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=text;return e;};
/* Pages mount on first open (90_wiring). While a page draws (window.__drawPage), an element that sits on another page, or on a page
   not mounted yet, is handed over as a detached copy of its markup, so a draw function shared by two pages only changes the page on
   screen; the other page draws itself when it opens. Outside a draw, $ is plain getElementById. */
const moSinks=new Map();
function moSink(id,e){let s=moSinks.get(id);if(s)return s;const t=window.__tplNode?window.__tplNode(id):null;s=t?t.cloneNode(true):(e?e.cloneNode(false):document.createElement('div'));moSinks.set(id,s);return s;}
const $=id=>{const e=document.getElementById(id);const pg=window.__drawPage;if(!pg)return e;
  if(e){const s=e.closest('.mo-page');return !s||s.id==='page-'+pg?e:moSink(id,e);}
  const k=window.__idPage&&window.__idPage[id];return k&&k!==pg?moSink(id,null):null;};
const nf=d3.format(',');
const money=v=>{if(v==null||!isFinite(v))return 'n/a';const a=Math.abs(v);const s='$'+d3.format(Math.abs(a%1)>1e-9?',.2f':',.0f')(a);return v<0?'-'+s:s;};
const compact=v=>{if(v==null||!isFinite(v))return 'n/a';const a=Math.abs(v);const s=a>=1e6?'$'+(+(a/1e6).toFixed(2))+'M':a>=1e5?'$'+Math.round(a/1e3)+'k':a>=1e3?'$'+(+(a/1e3).toFixed(1))+'k':'$'+Math.round(a);return v<0?'-'+s:s;};
const pctf=v=>v==null||!isFinite(v)?'n/a':(+Number(v).toFixed(1))+'%';
const F={text:v=>v==null||v===''?'n/a':String(v),money,pct:v=>v==null||!isFinite(v)?'n/a':(+Number(v).toFixed(2))+'%',int:v=>v==null?'n/a':nf(v),signed:v=>v==null?'n/a':(v>0?'+':v<0?'-':'')+money(Math.abs(v))};
const C=dash.colors.slice();
/* Account names come from the data: the first account from the account on its source rows (acct_a_sources.account), the second from the account on its
   fund rows (acct_b_holdings.account). Generic names stand in when the data has none. Colors follow the role, never a name. */
function acctNames(src,hi){const f=r=>((r||[]).find(s=>s&&s.account)||{}).account;const a=f(src)||'First account',b=f(hi)||'Second account';
  return {nb:a,hi:b,aPre:a+', Traditional',aRoth:a+', Roth'};}
/* contribution rows by role, read from the account name (no account id is assumed) */
const CONTRIB_ROLE={k401:{short:'401(k)',plan_item:'payroll_401k_annual'},hsa:{short:'HSA',plan_item:'hsa_annual'},roth:{short:'Roth IRA',plan_item:'backdoor_roth_annual'}};
function contribRole(c){const a=String(c&&c.account||'');return /401|403|457/.test(a)?'k401':/HSA/i.test(a)?'hsa':'roth';}
/* the publisher of a benchmark row, read from its source text (the words before the first comma) */
function pubName(r){return r&&r.source?String(r.source).split(',')[0].trim():'the published guideline';}
/* a debt's category is its type; an account closed to new charges carries account_status Closed (and closed_date). A closed card still
   counts in the debt ratio, high rate debt, essentials and the payoff order, but not in utilization, available credit, the card minimum
   estimate or the statement grace logic. */
const isCard=l=>/credit card/i.test(String(l&&l.type||''));
const isClosed=l=>/^closed$/i.test(String(l&&l.account_status||''))||/^closed /i.test(String(l&&l.type||''));
const openCard=l=>isCard(l)&&!isClosed(l);
/* next due date from a day of the month (1 to 31, clamped to the month's length), on or after today; a month already paid
   (last_paid YYYY-MM) is skipped */
function nextDueDay(day,lastPaid,today){day=+day;if(!(day>=1&&day<=31)||!today)return null;const p2=n=>String(n).padStart(2,'0');let y=+today.slice(0,4),m=+today.slice(5,7);
  const at=(y,m)=>y+'-'+p2(m)+'-'+p2(Math.min(day,new Date(Date.UTC(y,m,0)).getUTCDate()));let d=at(y,m);let n=0;
  while((d<today||(lastPaid&&String(lastPaid)>=y+'-'+p2(m)))&&n<24){m++;if(m>12){m=1;y++;}d=at(y,m);n++;}return d;}
function b0pay(inc){const b=(inc||[]).find(i=>i.kind==='Base');return b?b.paychecks_per_year:null;}
const acctColor=a=>{const n=acctNames(rows('acct_a_sources'),rows('acct_b_holdings'));const i=[n.nb,n.hi,'HSA',n.aPre,n.aRoth].indexOf(a);return C[(i<0?7:i)%C.length];};
const CLASS_ORDER=['US equity','International equity','Target-date fund','Sector equity','Taxable bond','Crypto','Other'];
const classColor=c=>{const i=CLASS_ORDER.indexOf(c);return C[(i<0?CLASS_ORDER.length-1:i)%C.length];};
const MN=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const fd=s=>typeof s==='string'&&s.length>=10?MN[+s.slice(5,7)-1]+' '+(+s.slice(8,10)):'date not set';
const cashSub=()=>{const a=rows('assets_other');if(!a)return 'Savings plus checking, counted in net worth';return a.filter(x=>x.type==='Cash').map(x=>x.name.replace(/ account$/,'')+' as of '+fd(x.as_of_date)).join(', ')+'. Counted in net worth';};

function mkTip(box){
  const t=el('div','mo-tip');t.style.display='none';box.append(t);
  return {
    show(ev,lines){
      t.replaceChildren();
      lines.forEach((l,i)=>{const d=el('div',i===0?'tt':null);if(typeof l==='string')d.textContent=l;else{if(l.c){const s=el('i','sw');s.style.background=l.c;d.append(s);}d.append(document.createTextNode(l.t));}t.append(d);});
      t.style.display='block';const bb=box.getBoundingClientRect();
      let x=ev.clientX-bb.left+14,y=ev.clientY-bb.top+14;const w=t.offsetWidth,h=t.offsetHeight;
      if(x+w>bb.width)x=ev.clientX-bb.left-w-14;if(x<0)x=0;
      if(y+h>bb.height+30)y=ev.clientY-bb.top-h-12;if(y<0)y=0;
      t.style.left=x+'px';t.style.top=y+'px';
    },
    hide(){if(t._st)return;t.style.display='none';}
  };
}
function mkSvg(box,W,H,label){return d3.select(box).append('svg').attr('class','mo-svg').attr('width','100%').attr('height',H).attr('viewBox',`0 0 ${W} ${H}`).attr('role','img').attr('aria-label',label);}
function hgrid(svg,data,y,x1,x2){svg.append('g').attr('class','mo-grid').selectAll('line').data(data).join('line').attr('x1',x1).attr('x2',x2).attr('y1',d=>y(d)).attr('y2',d=>y(d));}
function legendEl(items){
  const lg=el('div','mo-legend');
  items.forEach(it=>{const s=el('span');
    if(it.line){const l=el('i','ln');l.style.borderTopColor=it.color;l.style.borderTopStyle=it.line==='dash'?'dashed':it.line==='dot'?'dotted':'solid';s.append(l);}
    else{const i=el('i','mo-sw');i.style.background=it.color;if(it.ring){i.style.background='transparent';i.style.border='2px solid '+it.color;}if(it.op)i.style.opacity=it.op;s.append(i);}
    s.append(document.createTextNode(it.label));lg.append(s);});
  return lg;
}
function spark(vals,color){
  const w=100,h=28;const x=d3.scaleLinear([0,vals.length-1],[2,w-2]);const lo=d3.min(vals),hi=d3.max(vals);const y=d3.scaleLinear([lo,hi===lo?lo+1:hi],[h-3,3]);
  const line=d3.line().x((d,i)=>x(i)).y(d=>y(d));
  const svg=d3.create('svg').attr('class','mo-spark').attr('viewBox',`0 0 ${w} ${h}`).attr('preserveAspectRatio','none').attr('aria-hidden','true');
  svg.append('path').attr('d',d3.area().x((d,i)=>x(i)).y0(h).y1(d=>y(d))(vals)).attr('fill',color||C[0]).attr('opacity',.14);
  svg.append('path').attr('d',line(vals)).attr('fill','none').attr('stroke',color||C[0]).attr('stroke-width',2).attr('vector-effect','non-scaling-stroke').attr('stroke-linejoin','round');
  return svg.node();
}
function tiles(box,specs){
  box.replaceChildren();
  specs.forEach(s=>{
    const t=el('div','mo-tile'+(s.hero?' hero':''));t.append(el('span','mo-tl',s.label),el('span','mo-tv',s.value));
    if(s.delta){const d=el('span','mo-delta '+(s.delta.dir||''),(s.delta.dir==='up'?'▲ ':s.delta.dir==='down'?'▼ ':'')+s.delta.text);t.append(d);}
    if(s.sub)t.append(el('span','mo-ts',s.sub));
    if(s.spark&&s.spark.length>1)t.append(spark(s.spark,s.color));
    box.append(t);
  });
}
const deltaOf=(a,b,fmt)=>{const d=a-b;return {dir:d>0.005?'up':d<-0.005?'down':'flat',text:(d>=0?'+':'-')+(fmt||money)(Math.abs(d))};};

/* ---------- donut with center total ---------- */
function donut(box,items,o){
  o=o||{};box.replaceChildren();items=items.filter(d=>d.value>0);const total=d3.sum(items,d=>d.value);
  if(!total){box.append(el('p','mo-note','Nothing to show yet.'));return;}
  const wrap=el('div','mo-donut');box.append(wrap);const tip=mkTip(wrap);
  const S=o.size||(box.clientWidth<420?180:210),R=S/2;
  const svg=d3.select(wrap).append('svg').attr('class','mo-svg').attr('width',S).attr('height',S).attr('viewBox',`0 0 ${S} ${S}`).attr('role','img').attr('aria-label',o.label||'Donut chart');
  const g=svg.append('g').attr('transform',`translate(${R},${R})`);
  const pad=items.length>1?0.02:0;
  const arc=d3.arc().innerRadius(R*0.64).outerRadius(R-5).padAngle(pad).cornerRadius(2);
  const arcH=d3.arc().innerRadius(R*0.64).outerRadius(R-1).padAngle(pad).cornerRadius(2);
  const pie=d3.pie().sort(null).value(d=>d.value)(items);
  const big=svg.append('text').attr('x',R).attr('y',R-2).attr('text-anchor','middle').style('font-family','var(--mo-font)').style('font-size',o.bigSize||'22px').style('fill','var(--mo-fg)');
  const sm=svg.append('text').attr('x',R).attr('y',R+16).attr('text-anchor','middle').style('font-size','11px').style('fill','var(--mo-muted)');
  const c0=o.center||[compact(total),'Total'];
  const setC=(a,b)=>{big.text(a);sm.text(b);};setC(c0[0],c0[1]);
  const legend=el('div','mo-dl');wrap.append(legend);
  const lis=[];
  const pctOf=v=>Math.round(v/total*1000)/10;
  const focus=(i,ev)=>{
    const d=items[i];
    g.selectAll('path').attr('d',(p,j)=>j===i?arcH(p):arc(p)).attr('opacity',(p,j)=>j===i?1:.55);
    lis.forEach((li,j)=>li.classList.toggle('dim',j!==i));
    setC(compact(d.value),d.label.length>22?d.label.slice(0,21)+'...':d.label);
    if(ev)tip.show(ev,o.tip?o.tip(d,total):[d.label,money(d.value)+' ('+pctOf(d.value)+'%)']);
  };
  const blur=()=>{g.selectAll('path').attr('d',arc).attr('opacity',1);lis.forEach(li=>li.classList.remove('dim'));setC(c0[0],c0[1]);tip.hide();};
  g.selectAll('path').data(pie).join('path').attr('d',arc).attr('fill',(p,i)=>items[i].color).attr('tabindex',0).attr('aria-label',(p,i)=>items[i].label+' '+money(items[i].value))
    .on('pointermove',(ev,p)=>focus(pie.indexOf(p),ev)).on('pointerleave',blur).on('focus',(ev,p)=>focus(pie.indexOf(p))).on('blur',blur);
  items.forEach((d,i)=>{
    const li=el('div','mo-dli');const sw=el('i','mo-sw');sw.style.background=d.color;li.append(sw,el('span',null,d.label),el('span','v',(o.legendVal?o.legendVal(d):money(d.value))+'  '+pctOf(d.value)+'%'));
    li.addEventListener('pointerenter',()=>focus(i));li.addEventListener('pointerleave',blur);legend.append(li);lis.push(li);
  });
}

/* ---------- bullet rows (HTML tracks) ---------- */
function bullets(box,data,o){
  o=o||{};box.replaceChildren();const tip=mkTip(box);
  data.forEach(r=>{
    const row=el('div','mo-bl');const lab=el('div','mo-bl-l',r.label);if(r.sub)lab.append(el('small',null,r.sub));
    const tr=el('div','mo-bl-t');const pos=v=>(Math.max(0,Math.min(v,r.max))/r.max*100)+'%';
    const add=(a,b,col,op,inset)=>{const i=document.createElement('i');i.style.left=pos(a);i.style.width=(Math.max(0,Math.min(b,r.max)-Math.min(a,r.max))/r.max*100)+'%';i.style.background=col;if(op!=null)i.style.opacity=op;if(inset){i.style.top=inset+'px';i.style.bottom=inset+'px';i.style.borderRadius='2px';}tr.append(i);return i;};
    (r.zones||[]).forEach(z=>add(z[0],z[1],z[2],z[3]==null?.25:z[3]));
    (r.bars||[]).forEach(b=>add(b[0],b[1],b[2],b[3],6));
    if(r.whisk){const lo=r.whisk[0],hi=r.whisk[1];const w=add(lo,hi,'var(--mo-fg)',.9);w.style.top='10px';w.style.bottom='10px';w.style.height='2px';w.style.opacity=.75;
      [lo,hi].forEach(v=>{const c=add(v,v,'var(--mo-fg)',.75);c.style.width='2px';c.style.top='5px';c.style.bottom='5px';c.style.marginLeft='-1px';});}
    (r.ticks||[]).forEach(t=>{const i=add(t.v,t.v,'var(--mo-fg)',1);i.style.width='3px';i.style.marginLeft='-1.5px';i.style.top='-3px';i.style.bottom='-3px';i.style.borderRadius='1px';i.style.boxShadow='0 0 0 1px var(--mo-card)';});
    (r.marks||[]).forEach(t=>{const i=document.createElement('i');i.style.left=pos(t.v);i.style.top='50%';i.style.width='12px';i.style.height='12px';i.style.marginLeft='-6px';i.style.marginTop='-6px';i.style.background=t.color||'var(--mo-fg)';i.style.transform='rotate(45deg)';i.style.boxShadow='0 0 0 2px var(--mo-card)';i.style.top='50%';i.style.bottom='auto';tr.append(i);});
    const val=el('div','mo-bl-v',r.valueText||'');
    row.append(lab,tr,val);box.append(row);
    row.addEventListener('pointermove',ev=>tip.show(ev,r.tip||[r.label]));row.addEventListener('pointerleave',()=>tip.hide());
  });
}

/* ---------- waterfall ---------- */
function waterfall(box,steps,o){
  o=o||{};box.replaceChildren();const W=box.clientWidth;if(!W||!steps.length)return;const tip=mkTip(box);
  const narrow=W<560;const m={t:narrow?40:22,r:8,b:narrow?100:70,l:narrow?44:54};const H=o.H||(narrow?380:350);const placed=[];
  let cum=0;const S=steps.map(s=>{const d={...s};if(s.kind==='total'){d.y0=0;d.y1=s.value;cum=s.value;}else{d.y0=cum;d.y1=cum+s.value;cum=d.y1;}return d;});
  const ymax=d3.max(S,d=>Math.max(d.y0,d.y1))*1.1;
  const x=d3.scaleBand(d3.range(S.length),[m.l,W-m.r]).paddingInner(.22).paddingOuter(.1);
  const y=d3.scaleLinear([0,ymax],[H-m.b,m.t]).nice();
  const svg=mkSvg(box,W,H,o.label||'Waterfall chart');
  hgrid(svg,y.ticks(5),y,m.l,W-m.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  const col=d=>d.kind==='total'?(o.total||'var(--mo-fg)'):d.value>=0?(o.up||C[0]):(o.down||C[1]);
  S.forEach((d,i)=>{
    const top=Math.min(y(d.y0),y(d.y1)),h=Math.max(2,Math.abs(y(d.y0)-y(d.y1)));
    if(i<S.length-1){svg.append('line').attr('x1',x(i)+x.bandwidth()).attr('x2',x(i+1)).attr('y1',y(d.y1)).attr('y2',y(d.y1)).attr('stroke','var(--mo-muted)').attr('stroke-width',1).attr('opacity',.5);}
    svg.append('rect').attr('x',x(i)).attr('y',top).attr('width',x.bandwidth()).attr('height',h).attr('rx',2).attr('fill',col(d)).attr('opacity',d.kind==='total'?.85:1);
    const lbl=(d.kind==='delta'&&d.value<0?'-':'')+compact(Math.abs(d.value));
    /* value labels never overlap: each tries just above its bar, then one and two lines higher; if all collide it stands upright above the bar */
    {const fs=narrow?10:11,cx=x(i)+x.bandwidth()/2,w=lbl.length*fs*0.6,hit=(yy)=>placed.some(p=>Math.abs(p.y-yy)<fs+1&&p.x0<cx+w/2+2&&cx-w/2-2<p.x1);
     const ys=[top-5,top-5-(fs+2),top-5-2*(fs+2)].filter(v=>v>=fs);const yy=ys.find(v=>!hit(v));const t0=svg.append('text').attr('class','mo-halo').attr('font-size',fs).style('fill','var(--mo-fg)').text(lbl);
     if(yy!=null){t0.attr('x',cx).attr('y',yy).attr('text-anchor','middle');placed.push({x0:cx-w/2,x1:cx+w/2,y:yy});}
     else{t0.attr('text-anchor','start').attr('transform','translate('+(cx+fs/3)+','+(top-4)+') rotate(-90)');placed.push({x0:cx-fs/2,x1:cx+fs/2,y:top-4-w/2});}}
    const t=svg.append('text').attr('x',x(i)+x.bandwidth()/2).attr('y',H-m.b+14).attr('font-size',narrow?10:11).style('fill','var(--mo-muted)');
    if(narrow){t.attr('text-anchor','end').attr('transform',`rotate(-40 ${x(i)+x.bandwidth()/2+4} ${H-m.b+12})`).attr('x',x(i)+x.bandwidth()/2+4).text(d.label.length>22?d.label.slice(0,21)+'...':d.label);}
    else{t.attr('text-anchor','middle');const maxc=Math.max(7,Math.floor(x.step()/6.4));const words=d.label.split(' ');const lines=[];let cur='';words.forEach(w=>{if((cur+' '+w).trim().length>maxc&&cur){lines.push(cur);cur=w;}else cur=(cur+' '+w).trim();});lines.push(cur);
      lines.slice(0,3).forEach((ln,k)=>t.append('tspan').attr('x',x(i)+x.bandwidth()/2).attr('dy',k?'1.15em':0).text(ln));}
    svg.append('rect').attr('x',x(i)-3).attr('y',m.t).attr('width',x.bandwidth()+6).attr('height',H-m.t-m.b+30).attr('fill','transparent')
      .on('pointermove',ev=>tip.show(ev,[d.label,(d.kind==='total'?'Total ':d.value>=0?'Adds ':'Takes off ')+money(Math.abs(d.value)),d.kind==='total'?'':'Running total '+money(d.y1)].filter(Boolean))).on('pointerleave',()=>tip.hide());
  });
  const lgi=[];if(S.some(d=>d.kind==='total'))lgi.push({label:'Total: full bar from zero',color:o.total||'var(--mo-fg)',op:.85});if(S.some(d=>d.kind!=='total'&&d.value>=0))lgi.push({label:o.upLabel||'Adds: step up from the running total',color:o.up||C[0]});if(S.some(d=>d.kind!=='total'&&d.value<0))lgi.push({label:o.downLabel||'Takes off: step down from the running total',color:o.down||C[1]});
  if(lgi.length>1){const lg=legendEl(lgi);lg.classList.add('mx-chartleg');box.append(lg);}
}

/* ---------- sankey (layers found automatically) ---------- */
function sankey(box,linksIn,o){
  o=o||{};box.replaceChildren();if(!box.clientWidth)return;const tip=mkTip(box);
  const W=box.clientWidth,narrow=W<560,H=narrow?(o.Hn||600):(o.H||520),pad=14,nodeW=14,minH=17,gap=9,fs=narrow?11:12;
  const links=linksIn.filter(l=>l.value>0).map(l=>({...l}));const nodes=new Map();
  const node=n=>{if(!nodes.has(n))nodes.set(n,{name:n,in:0,out:0,layer:0,ins:[],outs:[],cls:null});return nodes.get(n);};
  links.forEach(l=>{const s=node(l.source),t=node(l.target);s.out+=l.value;t.in+=l.value;s.outs.push(l);t.ins.push(l);s.cls=s.cls||l.cls;t.cls=t.cls||l.cls;});
  const all=[...nodes.values()];let ch=true,gd=0;while(ch&&gd++<30){ch=false;links.forEach(l=>{const s=nodes.get(l.source),t=nodes.get(l.target);if(t.layer<s.layer+1){t.layer=s.layer+1;ch=true;}});}
  const L=d3.max(all,n=>n.layer)||1;all.forEach(n=>{n.value=Math.max(n.in,n.out);});
  const ml=W*(narrow?.27:.19),mr=W*(narrow?.30:.28);all.forEach(n=>{n.x=ml+(W-ml-mr-nodeW)*n.layer/L;});
  const avail=H-2*pad;
  d3.group(all,n=>n.layer).forEach(list=>{
    const tot=d3.sum(list,n=>n.value);const k=Math.max(0,(avail-list.length*minH-(list.length-1)*gap)/tot);
    list.forEach(n=>{n.h=minH+n.value*k;});const used=d3.sum(list,n=>n.h)+(list.length-1)*gap;let yy=pad+(avail-used)/2;list.forEach(n=>{n.y=yy;yy+=n.h+gap;});
  });
  all.forEach(n=>{n.outs.sort((a,b)=>nodes.get(a.target).y-nodes.get(b.target).y);n.ins.sort((a,b)=>nodes.get(a.source).y-nodes.get(b.source).y);});
  all.forEach(n=>{let c=0;n.outs.forEach(l=>{l.sy=n.y+c;l.sw=n.h*l.value/n.out;c+=l.sw;});c=0;n.ins.forEach(l=>{l.ty=n.y+c;l.tw=n.h*l.value/n.in;c+=l.tw;});});
  const col=o.color||(()=>C[0]);
  const svg=mkSvg(box,W,H,o.label||'Flow diagram');
  const ribbon=(x0,a0,a1,x1,b0,b1)=>{const xm=(x0+x1)/2;return `M${x0},${a0}C${xm},${a0} ${xm},${b0} ${x1},${b0}L${x1},${b1}C${xm},${b1} ${xm},${a1} ${x0},${a1}Z`;};
  const rib=svg.append('g');
  links.forEach(l=>{const s=nodes.get(l.source),t=nodes.get(l.target);
    rib.append('path').datum(l).attr('d',ribbon(s.x+nodeW,l.sy,l.sy+l.sw,t.x,l.ty,l.ty+l.tw)).attr('fill',col(l.cls)).attr('opacity',.34)
     .on('pointermove',function(ev){d3.select(this).attr('opacity',.62);tip.show(ev,[l.source+' to '+l.target,{t:money(l.value)+(o.unit||''),c:col(l.cls)},Math.round(l.value/s.out*1000)/10+'% of '+l.source]);})
     .on('pointerleave',function(){d3.select(this).attr('opacity',.34);tip.hide();});});
  all.forEach(n=>{
    svg.append('rect').attr('x',n.x).attr('y',n.y).attr('width',nodeW).attr('height',n.h).attr('rx',3).attr('fill',col(n.cls))
      .on('pointermove',ev=>tip.show(ev,[n.name,money(n.value)+(o.unit||'')])).on('pointerleave',()=>tip.hide());
    const val='$'+nf(Math.round(n.value));
    const t=svg.append('text').attr('class','mo-halo').attr('font-size',fs).style('fill','var(--mo-fg)').attr('y',n.y+n.h/2).style('pointer-events','none');
    if(n.layer===0){t.attr('x',n.x-8).attr('text-anchor','end');t.append('tspan').attr('x',n.x-8).attr('dy','-0.2em').text(n.name);t.append('tspan').attr('x',n.x-8).attr('dy','1.2em').text(val);}
    else if(!narrow){t.attr('x',n.x+nodeW+6).attr('dy','0.35em').attr('text-anchor','start').text(n.name+'  '+val);}
    else{const x0=n.x+nodeW+5;const room=n.layer===L?W-x0-2:(ml+(W-ml-mr-nodeW)*(n.layer+1)/L)-x0-4;const cw=fs*(n.layer===L?0.56:0.62);
      const words=(n.layer===L?n.name:n.name+' '+val).split(' ');const lines=[];let cur='';
      words.forEach(w=>{const tr=cur?cur+' '+w:w;if(tr.length*cw<=room||!cur)cur=tr;else{lines.push(cur);cur=w;}});if(cur)lines.push(cur);
      const maxL=Math.max(1,Math.floor((n.h+gap)/(fs*1.15)));const show=lines.length>maxL?lines.slice(0,maxL-1).concat([lines.slice(maxL-1).join(' ')]):lines;
      t.attr('text-anchor','start').attr('font-size',n.layer===L?fs:fs-0.5);
      show.forEach((ln,i)=>t.append('tspan').attr('x',x0).attr('dy',i===0?(0.35-(show.length-1)*0.575)+'em':'1.15em').text(ln));
      t.append('title').text(n.name+' '+val);}
  });
}

/* ---------- treemap ---------- */
function treemap(box,rootData,o){
  o=o||{};box.replaceChildren();const W=box.clientWidth;if(!W)return;const tip=mkTip(box);const narrow=W<560,H=narrow?380:430;
  const root=d3.hierarchy(rootData).sum(d=>d.value||0).sort((a,b)=>b.value-a.value);
  d3.treemap().size([W,H]).paddingInner(2).paddingTop(d=>d.depth===1?18:0).round(true)(root);
  const svg=mkSvg(box,W,H,o.label||'Treemap of holdings');const tot=root.value;
  root.children.forEach(grp=>{
    const gw=grp.x1-grp.x0;
    svg.append('rect').attr('x',grp.x0).attr('y',grp.y0).attr('width',gw).attr('height',grp.y1-grp.y0).attr('rx',3).attr('fill',grp.data.color).attr('opacity',.1);
    svg.append('rect').attr('x',grp.x0).attr('y',grp.y0).attr('width',gw).attr('height',3).attr('fill',grp.data.color);
    if(gw>46&&(grp.y1-grp.y0)>24)svg.append('text').attr('x',grp.x0+4).attr('y',grp.y0+13).attr('font-size',11).style('font-weight',600).style('fill','var(--mo-fg)').text((()=>{const s=grp.data.name+'  '+compact(grp.value);const maxc=Math.floor(gw/6.2);return s.length>maxc?(grp.data.name.length>maxc?grp.data.name.slice(0,Math.max(1,maxc-1))+'.':grp.data.name):s;})());
    (grp.children||[]).forEach(lf=>{
      const w=lf.x1-lf.x0,h=lf.y1-lf.y0;
      svg.append('rect').attr('x',lf.x0).attr('y',lf.y0).attr('width',Math.max(0,w)).attr('height',Math.max(0,h)).attr('rx',2).attr('fill',grp.data.color).attr('opacity',.34).attr('class','mo-leaf')
        .on('pointermove',function(ev){d3.select(this).attr('opacity',.6);tip.show(ev,o.tip?o.tip(lf.data,grp.data,tot):[lf.data.name,money(lf.value)]);}).on('pointerleave',function(){d3.select(this).attr('opacity',.34);tip.hide();});
      if(w>70&&h>34){const maxc=Math.floor((w-8)/6.3);const nm=lf.data.name.length>maxc?lf.data.name.slice(0,maxc-1)+'.':lf.data.name;
        svg.append('text').attr('x',lf.x0+5).attr('y',lf.y0+15).attr('font-size',11).style('fill','var(--mo-fg)').style('pointer-events','none').text(nm);
        svg.append('text').attr('x',lf.x0+5).attr('y',lf.y0+29).attr('font-size',11).style('fill','var(--mo-muted)').style('pointer-events','none').text(compact(lf.value));}
    });
  });
}

/* ---------- nearest-point hover layer ---------- */
function hoverLayer(svg,pts,x0,y0,w,h,onHit,onLeave,maxD){
  const dl=d3.Delaunay.from(pts,p=>p.px,p=>p.py);
  svg.append('rect').attr('x',x0).attr('y',y0).attr('width',w).attr('height',h).attr('fill','transparent').on('pointermove',function(ev){
    const [mx,my]=d3.pointer(ev,svg.node());const i=dl.find(mx,my);const p=pts[i];
    if(p&&Math.hypot(p.px-mx,p.py-my)<(maxD||40))onHit(p,ev);else onLeave();}).on('pointerleave',onLeave);
}

/* ---------- generic table ---------- */
function drawTable(tbl){
  const body=tbl.tBodies[0]||tbl.createTBody();body.replaceChildren();
  let r=rows(tbl.dataset.source);if(!r)return;
  const ths=[...tbl.querySelectorAll('th[data-field]')];const key=tbl.dataset.rowKey;
  for(const row of r){
    const tr=document.createElement('tr');tr.dataset.key=row[key];
    ths.forEach(th=>{
      const td=document.createElement('td');const f=th.dataset.fmt||'text';
      td.textContent=(F[f]||F.text)(row[th.dataset.field]);
      if(tbl.id==='t-liab'&&row[th.dataset.field]==null){const fl=th.dataset.field;td.textContent=fl==='rate_pct'?(row.type==='Support'||row.type==='Medical'?'not applicable':'rate not added'):fl==='monthly_payment'?(row.type==='Medical'?'none set yet':'payment not added'):fl==='balance'?(row.type==='Support'?'no balance':'not added'):td.textContent;}
      td.className=th.className;
      if(th.dataset.field===key)td.classList.add('key');
      if(th.dataset.val)td.dataset.val=row[th.dataset.field];
      tr.append(td);
    });
    body.append(tr);
  }
}
