/* ---------- wiring: pages, bar, More sheet, Back, deep links (IA.md 3) ----------
   Ten pages. Home is in the markup and loads at once; every other page is a <template id="tpl-<page>"> cloned in on first open and
   kept. The bar holds Home, Debt, Bills and Cash plus More, which opens a sheet (a modal dialog) with the other six. Each page draws
   only the functions that write to it (DRAW); while a page draws, an element that sits on another page is handed over as a detached
   copy (see $ in the helpers), so a function shared by two pages writes only to the one on screen. */
const PAGES=['home','debt','bills','cash','investments','retirement','progress','tasks','pay','data'];
const SHEET=['investments','retirement','progress','tasks','pay','data'];
window.MO_PAGES=PAGES.slice();
const META={home:['Home',()=>HOME_SUB],debt:['Debt','What you owe, the payments and the payoff plan'],bills:['Bills and spending','Every bill, the categories and the statements'],
  cash:['Cash and Save for','Runway, balances, savings goals and dollar drift'],investments:['Investments','What you hold in each 401(k)'],
  retirement:['Retirement',"Balance at 60 and your 401(k), in today's dollars"],progress:['Progress','Scores, quests, badges and the age ladder'],
  tasks:['Tasks','Every task and every piece of data to send'],pay:['Pay','Take-home pay, pay stubs and where gross pay goes'],data:['Data and backup','Backup, as-of dates and the self-test']};
/* every old link name still lands: old tab names, the old accordions and the names used before v4 */
const ALIAS={money:'home','tab-networth':'home','tab-overview':'home',more:'home',retire:'retirement','tab-retirement':'retirement','tab-motion':'retirement',
  'tab-debt':'debt','tab-bills':'bills','tab-holdings':'investments','tab-candidates':'investments','tab-add':'tasks:acc-queue',compare:'progress'};
const XP=t=>()=>drawExpected(t);
const DRAW={home:[drawHome,drawScores,drawHomeExtra,drawTrail,drawHomeTasks,XP('home'),drawSince,drawSeason,drawNetWorth,drawOverview,XP('money'),drawNwMilestones,drawCheckins,drawGlance,homeQuick],
  debt:[drawNetWorth,drawHouseStatus,drawPayoffPlan,drawPaycheckPlan,drawPayoffBasis,drawLtv,drawPoFields],
  bills:[drawCash,drawComing,drawBillHist],
  cash:[drawHomeGoals,drawCashTop,drawBalHist,drawCash,drawDriftAll,XP('cash'),drawRunway,drawGap],
  pay:[drawCash,drawStubTables],
  investments:[drawInvestments],
  retirement:[drawHome,drawHomeExtra,drawRetTab,drawPlanYear,drawPaceSteps],
  progress:[drawHomeExtra,drawCheckCount,drawRecap,()=>drawLadder('hm-ladder'),drawMoves,()=>drawLadder(),drawAgeStats,drawTry,drawBenchAge,drawProgress,drawBench,drawQuests,drawBadges],
  tasks:[drawData,drawNeedsList,drawTaskQueue],
  data:[drawAsof,drawBackupExtra]};
/* where each id lives, read from the page and the templates, plus the ids that draws build */
const ID2PAGE={};
document.querySelectorAll('template[id^="tpl-"]').forEach(t=>{const k=t.id.slice(4);t.content.querySelectorAll('[id]').forEach(e=>{ID2PAGE[e.id]=k;});});
document.querySelectorAll('#page-home [id]').forEach(e=>{if(!ID2PAGE[e.id])ID2PAGE[e.id]='home';});
Object.assign(ID2PAGE,{'po-res':'debt','po-next':'debt','po-about-dyn':'debt','tl-off':'debt','cf-about':'bills','bl-coming':'bills','po-compare':'debt','pc-stubs':'pay','pg-weeks':'progress','hm-planyear':'retirement','house-status':'debt','exp-home':'home','exp-money':'home','exp-cash':'cash'});
window.__idPage=ID2PAGE;
window.__tplNode=id=>{const k=ID2PAGE[id];const t=k&&document.getElementById('tpl-'+k);return t?t.content.getElementById(id):null;};
let current='home';
const NAV={stack:[],last:null};
const pageEl=k=>document.getElementById('page-'+k);
const pageOf=id=>{const e=document.getElementById(id);const s=e&&e.closest('.mo-page');return s?s.id.slice(5):ID2PAGE[id]||null;};
function resolvePage(name,id){if(id&&pageOf(id))return pageOf(id);if(PAGES.includes(name))return name;const a=ALIAS[name];return a?a.split(':')[0]:'home';}
function labelTables(){document.querySelectorAll('.mo-table').forEach(t=>{const hr=t.tHead&&t.tHead.rows.length?t.tHead.rows[t.tHead.rows.length-1]:null;const hs=hr?[...hr.cells].map(c=>c.textContent.trim()):[];[...t.tBodies].forEach(b=>[...b.rows].forEach(r=>[...r.cells].forEach((c,i)=>{if(hs[i])c.dataset.label=hs[i];})));});}
function draw(){
  applyTheme();aboutSync();const pg=current;moSinks.clear();window.__drawPage=pg;
  try{(DRAW[pg]||[]).forEach(f=>{try{f();}catch(e){console.error('draw '+(f.name||'ladder')+': '+e.message);}});}finally{window.__drawPage=null;moSinks.clear();}
  document.querySelectorAll('#page-'+pg+' .mo-table[data-source]').forEach(drawTable);labelTables();
  applyProfile();try{linkTiles(pg);}catch(e){console.error('tile links: '+e.message);}
}
/* user rule: a kind of debt, bill or account answered no is left out: any element tagged data-profile="<question id>" is hidden */
function applyProfile(){const P=rows('profile_calc');document.querySelectorAll('[data-profile]').forEach(e=>{const p=P&&P.find(x=>x.question_id===e.dataset.profile);e.hidden=!!p&&p.status==='no';});}
/* listeners for the static parts of a page, bound when the page is mounted */
function seg(id,key){const g=document.getElementById(id);if(!g||g.dataset.bound)return;g.dataset.bound='1';g.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{state[key]=b.dataset.v;g.querySelectorAll('button').forEach(o=>o.setAttribute('aria-pressed',String(o===b)));draw();}));}
function bindPage(root){
  root.querySelectorAll('[data-go]').forEach(b=>{if(!b.dataset.bound){b.dataset.bound='1';b.addEventListener('click',()=>go(b.dataset.go,b.dataset.open,{from:b}));}});
  root.querySelectorAll('details:not(.mx-about)').forEach(d=>d.addEventListener('toggle',()=>{if(d.open)draw();}));
  seg('tm-group','tmGroup');seg('po-view','poView');seg('po-basis','poBasis');
  const hs=root.querySelector('#hold-sort');if(hs)hs.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{state.sort={key:b.dataset.k,dir:b.dataset.k==='holding'?1:-1};hs.querySelectorAll('button').forEach(o=>o.setAttribute('aria-pressed',String(o===b)));holdTable();labelTables();}));
  const tg=root.querySelector('#po-trail-go');if(tg)tg.addEventListener('click',()=>goTo('home','po-trail',null,{from:tg}));
  const st=root.querySelector('#st-run');if(st)st.addEventListener('click',stRun);
  /* a page with two views (Progress, Tasks): one switch, the other view hidden; the page redraws so the shown view draws at full width */
  root.querySelectorAll('.mo-views').forEach(g=>g.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{g.querySelectorAll('[data-view]').forEach(o=>{o.setAttribute('aria-pressed',String(o===b));const v=document.getElementById(o.dataset.view);if(v)v.hidden=o!==b;});draw();})));
  if(root.querySelector('#bk-card')&&typeof window.__bkOnMount==='function')window.__bkOnMount();
}
function mount(k){let s=pageEl(k);if(s)return s;const t=document.getElementById('tpl-'+k);if(!t)return null;
  s=document.createElement('section');s.className='mo-page';s.id='page-'+k;s.hidden=true;s.setAttribute('aria-labelledby','ttl');s.append(t.content.cloneNode(true));t.before(s);bindPage(s);return s;}
const scroller=()=>{const app=document.getElementById('app');return app&&app.classList.contains('moS')?document.querySelector('.mo-main'):null;};
const scrollPos=()=>{const m=scroller();return m?m.scrollTop:window.scrollY;};
function toTop(){const m=scroller();if(m)m.scrollTop=0;else{window.scrollTo(0,0);const t=document.querySelector('.mo-top');if(t&&t.scrollIntoView)t.scrollIntoView({block:'start'});}}
/* a jump within the page keeps its own Back chip next to the target; the header button is for a page change */
function setBack(){const b=document.getElementById('back');if(!b)return;const prev=NAV.stack[NAV.stack.length-1];b.hidden=!prev||prev.page===current;if(prev){const n=META[prev.page]?META[prev.page][0]:prev.page;b.textContent='Back to '+n;b.setAttribute('aria-label','Back to '+n);}}
/* show a page. o.push: remember where we came from (a link, a Home row or the sheet); a bar tap clears the stack */
function navPush(from){NAV.stack.push({page:current,scroll:scrollPos(),focus:from&&from.id?from.id:null,key:from&&from.dataset?from.dataset.tileKey||null:null});if(NAV.stack.length>20)NAV.stack.shift();}
function show(id,o){o=o||{};if(!PAGES.includes(id))id=resolvePage(id);
  if(o.push&&current!==id)navPush(o.from);
  if(o.clear){NAV.stack=[];tlDropChip();}
  current=id;mount(id);closeSheet(false);
  document.querySelectorAll('.mo-page').forEach(p=>{p.hidden=p.id!=='page-'+id;});
  document.querySelectorAll('#tabs [data-page]').forEach(b=>{if(b.dataset.page===id)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  const mb=document.getElementById('morebtn');if(mb){if(SHEET.includes(id))mb.setAttribute('aria-current','page');else mb.removeAttribute('aria-current');}
  document.querySelectorAll('#sheet-grid [data-page]').forEach(b=>{if(b.dataset.page===id)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  $('ttl').textContent=META[id][0];const s=META[id][1];$('stl').textContent=typeof s==='function'?s():s;
  setBack();dash.setLink(id);draw();
}
function focusTitle(){const t=document.getElementById('ttl');if(t)t.focus({preventScroll:true});}
function focusTarget(t){const h=t.matches('h2,h3,summary')?t:(t.querySelector(':scope > h2, :scope > h3, :scope > summary')||t);const cb=h.querySelector(':scope > .mo-collbtn');if(cb){cb.focus({preventScroll:true});return;}if(!h.hasAttribute('tabindex')&&!/^(BUTTON|A|SUMMARY|INPUT)$/.test(h.tagName))h.tabIndex=-1;h.focus({preventScroll:true});}
/* go to a page and open one of its folds; the page that holds openId wins over the name, so old names keep working */
/* show the view that holds an element, on a page with two views */
function revealView(e){const v=e&&e.closest&&e.closest('.mo-view[hidden]');if(!v)return;const b=document.querySelector('[data-view="'+v.id+'"]');if(b)b.click();}
window.__moRedraw=()=>draw();
function go(id,openId,o){o=o||{};const pg=resolvePage(id,openId);const a=ALIAS[id];if(!openId&&a&&a.includes(':'))openId=a.split(':')[1];
  show(pg,{push:o.push!==false,from:o.from});toTop();
  if(openId){const d=$(openId);if(d){revealView(d);collReveal(d);if(d.tagName==='DETAILS')d.open=true;draw();d.scrollIntoView({block:'start'});focusTarget(d);return;}}
  focusTitle();}
function back(){const e=NAV.stack.pop();if(!e)return;tlDropChip();if(e.page!==current)show(e.page);else setBack();requestAnimationFrame(()=>{const m=scroller();if(m)m.scrollTop=e.scroll;else window.scrollTo(0,e.scroll);
  const find=()=>(e.key&&document.querySelector('[data-tile-key="'+CSS.escape(e.key)+'"]'))||(e.focus&&document.getElementById(e.focus));let n=find();if(n&&collReveal(n)){draw();n=find();}if(n){if(!n.hasAttribute('tabindex')&&!/^(BUTTON|A|SUMMARY|INPUT)$/.test(n.tagName))n.tabIndex=-1;if(e.key)n.scrollIntoView({block:'center'});n.focus({preventScroll:true});if(e.key)tlHighlight(n);}else focusTitle();});}
window.__moBack=back;window.__moNav=()=>({current,stack:NAV.stack.map(x=>x.page)});
/* the More sheet: a modal dialog above the bar. Focus moves to its first page, Tab stays inside, Escape and the scrim close it,
   and focus returns to More. */
function sheetOpen(){const s=document.getElementById('sheet');return !!s&&!s.hidden;}
function openSheet(){const s=document.getElementById('sheet'),sc=document.getElementById('scrim'),bar=document.querySelector('.mo-bar'),mb=document.getElementById('morebtn');if(!s)return;
  s.style.bottom=(bar?bar.offsetHeight:0)+'px';s.hidden=false;sc.hidden=false;mb.setAttribute('aria-expanded','true');
  const f=s.querySelector('#sheet-grid [aria-current="page"]')||s.querySelector('#sheet-grid button');if(f)f.focus({preventScroll:true});
  const r=s.getBoundingClientRect();if(r.top<0||r.bottom>innerHeight)s.scrollIntoView({block:'nearest'});}
function closeSheet(ret){const s=document.getElementById('sheet');if(!s||s.hidden)return;s.hidden=true;document.getElementById('scrim').hidden=true;
  const mb=document.getElementById('morebtn');mb.setAttribute('aria-expanded','false');if(ret!==false)mb.focus({preventScroll:true});}
window.__moSheet={open:openSheet,close:closeSheet,isOpen:sheetOpen};
document.querySelectorAll('#tabs [data-page]').forEach(b=>b.addEventListener('click',()=>{show(b.dataset.page,{clear:true});toTop();}));
{const mb=document.getElementById('morebtn');if(mb)mb.addEventListener('click',()=>{if(sheetOpen())closeSheet();else openSheet();});}
document.querySelectorAll('#sheet-grid [data-page]').forEach(b=>b.addEventListener('click',()=>{const k=b.dataset.page;closeSheet(false);show(k,{push:true,from:document.getElementById('morebtn')});toTop();focusTitle();}));
{const x=document.getElementById('sheet-close');if(x)x.addEventListener('click',()=>closeSheet());const sc=document.getElementById('scrim');if(sc)sc.addEventListener('click',()=>closeSheet());}
document.addEventListener('keydown',e=>{if(!sheetOpen())return;
  if(e.key==='Escape'){e.preventDefault();closeSheet();return;}
  if(e.key==='Tab'){const f=[...document.querySelectorAll('#sheet button')];const i=f.indexOf(document.activeElement);
    if(e.shiftKey&&i<=0){e.preventDefault();f[f.length-1].focus();}else if(!e.shiftKey&&(i<0||i===f.length-1)){e.preventDefault();f[0].focus();}}});
{const b=document.getElementById('back');if(b)b.addEventListener('click',back);}
bindPage(pageEl('home'));
/* Self-test panel (Data and backup, next to Backup): the rules live in their own file, selftest.js, listed last in index.html. It only defines
   window.MOC_SELFTEST; nothing in it runs until this button is pressed, and the page works the same when the file is missing. */
function stRun(){{const msg=$('st-msg'),out=$('st-out');out.replaceChildren();const T=window.MOC_SELFTEST;
  if(!T||typeof T.run!=='function'){msg.textContent='The self-test file did not load. The rest of the page is not affected; ask Claude to publish selftest.js again.';return;}
  let rs=null;try{rs=T.run();}catch(e){msg.textContent='The self-test stopped: '+(e&&e.message);return;}
  const bad=rs.filter(r=>!r.ok);msg.textContent=(rs.length-bad.length)+' of '+rs.length+' checks pass'+(bad.length?'. '+bad.length+' to look at, listed first.':'.');
  const list=a=>{const ul=el('ul','mo-list st-list');a.forEach(r=>{const li=el('li',r.ok?'ok':'bad');li.append(el('b',null,(r.ok?'Pass ':'Check ')+r.id+' '),document.createTextNode(r.name+(r.detail?': '+r.detail:'')));ul.append(li);});return ul;};
  if(bad.length)out.append(list(bad));const ok=rs.filter(r=>r.ok);if(ok.length){const d=el('details');d.append(el('summary',null,'Show the '+ok.length+' passing checks'),list(ok));out.append(d);}}}
/* tap on a chart shows its readout and keeps it until the next tap */
document.addEventListener('pointerdown',ev=>{
  document.querySelectorAll('.mo-tip').forEach(t=>{t._st=false;t.style.display='none';});
  if(ev.pointerType==='mouse')return;const tg=ev.target;if(!tg||!tg.dispatchEvent||!tg.closest||!tg.closest('.mo-chart,.mo-bl,.mo-meter,#ov-own,#cf-ess'))return;
  tg.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,clientX:ev.clientX,clientY:ev.clientY,pointerType:ev.pointerType}));
  document.querySelectorAll('.mo-tip').forEach(t=>{if(t.style.display==='block')t._st=true;});
},true);
let lastW=0,tmr=null;
if(window.ResizeObserver){new ResizeObserver(es=>{const w=Math.round(es[0].contentRect.width);if(Math.abs(w-lastW)>1){lastW=w;clearTimeout(tmr);tmr=setTimeout(draw,120);}}).observe(document.querySelector('.mo'));}
let first=true;
/* deep link on load: a page name, then an element id (its page found from where it sits, templates included), then an old name */
dash.onData(()=>{
  draw();
  if(first){first=false;show('home');const named=decodeURIComponent(location.hash.slice(1));
    if(named&&named!=='home'){if(PAGES.includes(named))show(named);else if(ID2PAGE[named]&&!/^(page|tpl)-/.test(named))goTo(ID2PAGE[named],named,null,{push:false});else if(ALIAS[named]){const [p,o]=ALIAS[named].split(':');go(p,o,{push:false});}}}
});


/* Backup and rebuild kit (v4). Files are offered only through the downloads capability (downloads.save); frame code never
   downloads directly, so there is no anchor fallback. "Saved" and the backup date appear only after save() resolves "saved".
   The last confirmed backup date is kept in the viewer's private dashboard data (data/users/<id>/backup) when the db capability
   is served, and in this browser's storage only as a fallback. Every dataset id is listed with its load status; a backup with a
   dataset that did not load is not offered. */
(function(){try{
const DS=/*DATASET_IDS: generated by tools/build_page.js from data_all*/["age_benchmarks","age_metrics_config","assets_other","assumptions","balance_log","bill_statements","bills","candidates","card_transactions","cash_events","contribution_limits","contribution_plan","contributions","data_queue","drift_history","dti_benchmarks","acct_b_holdings","holding_snapshots","income_pay","liabilities","ltv_benchmarks","milestones","mortgage_statements","acct_a_holdings","acct_a_sources","networth_history","payoff_settings","paystubs","plan_stats","plan_summary","price_history","retirement_plan","roth_plan","savings_goals","scores_config","scores_history","tasks","transfers"];
const CALCS=["coverage_calc","milestones_calc","drift_all","scores_calc","checkins_calc","badges_calc","quests_calc","recap_calc","seasons_calc"];
const DOCS={"age_benchmarks":{"title":"Age benchmarks","description":"National benchmarks by age group with sources, data year and dollar year.","source_name":"age_benchmarks.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"age_metrics_config":{"title":"Age metrics settings","description":"Settings for the age ladder: guideline and typical values shown as percent. One settings row.","source_name":"age_metrics_config.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"assets_other":{"title":"Other assets","description":"Truck, house, savings, checking, HSA cash and pending refund, as given or estimated.","source_name":"assets_other.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"assumptions":{"title":"Return assumptions","description":"Yearly returns after inflation, inflation, and the employer 401(k) match (0, stated by the owner).","source_name":"assumptions.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"balance_log":{"title":"Balance log","description":"Account balances you report, by date, for the dollar drift check.","source_name":"balance_log.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"bank_flows":{"title":"Bank flows","description":"Every credit and debit from the credit union statements, one row per movement, with category and linked debt or account. Extracted values only.","source_name":"bank_flows.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"bank_statements":{"title":"Bank statements","description":"One row per credit union account statement: balances, totals, dividends, rates and loan or card fields. Extracted values only.","source_name":"bank_statements.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"bill_statements":{"title":"Bill statements","description":"One row per utility or phone statement, by bill.","source_name":"bill_statements.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"bills":{"title":"Monthly bills","description":"Everyday monthly bills you have sent so far.","source_name":"bills.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"card_statements":{"title":"Card statements","description":"One row per card statement: balances, payments, interest, fees, minimum, due date and APR, tied to its card. Extracted values only.","source_name":"card_statements.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"card_transactions":{"title":"Card transactions","description":"Card charges and credits from statements, with categories, for spending categories.","source_name":"card_transactions.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"cash_events":{"title":"Cash events","description":"Known money movements between balance reports, used for dollar drift.","source_name":"cash_events.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"contribution_limits":{"title":"Contribution limits","description":"Tax-law contribution limits by plan year.","source_name":"contribution_limits.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"contribution_plan":{"title":"Contribution plan","description":"Chosen 401(k) percent per plan year.","source_name":"contribution_plan.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"contributions":{"title":"Retirement contributions","description":"Yearly 401(k), HSA and Roth contributions from pay stubs against limits.","source_name":"contributions.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"data_queue":{"title":"Data still to add","description":"Items needed from the user, each with an id, how the value arrived and a linked task when a statement is requested.","source_name":"data_queue.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"drift_history":{"title":"Dollar drift history","description":"Check points of reported minus expected balances per account.","source_name":"drift_history.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"dti_benchmarks":{"title":"DTI benchmarks","description":"Lender debt-to-income thresholds.","source_name":"dti_benchmarks.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"acct_b_holdings":{"title":"Second plan holdings","description":"Funds held in the second 401(k) with the value of each.","source_name":"acct_b_holdings.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"holding_snapshots":{"title":"Holding snapshots","description":"Dated share counts, prices and values per holding, one block per export.","source_name":"holding_snapshots.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"income_pay":{"title":"Income and pay","description":"Base and variable pay, verified from pay stubs.","source_name":"income_pay.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"liabilities":{"title":"Debts","description":"Every debt by category with a user-entered name: balance, rate and payment.","source_name":"liabilities.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"ltv_benchmarks":{"title":"Loan to value lines","description":"Sourced reference lines for the loan to value chart.","source_name":"ltv_benchmarks.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"milestones":{"title":"Milestones","description":"Derived milestones and badges with the date first seen.","source_name":"milestones.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"mortgage_statements":{"title":"Mortgage statements","description":"Extracted values from servicer statements, one row per statement, plus one row per annual Form 1098.","source_name":"mortgage_statements.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"acct_a_holdings":{"title":"First 401(k) holdings","description":"First 401(k) fund shares, prices and values from the latest export.","source_name":"acct_a_holdings.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"acct_a_sources":{"title":"First 401(k) money sources","description":"Estimated split by source and tax type, scaled to the latest fund total.","source_name":"acct_a_sources.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"networth_history":{"title":"Net worth history","description":"One row per month: assets, debts, retirement and net worth.","source_name":"networth_history.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"payoff_settings":{"title":"Payoff settings","description":"Saved choices for the debt payoff plan.","source_name":"payoff_settings.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"paystubs":{"title":"Pay stubs","description":"Ten semimonthly stubs, May to Oct 2026: taxes, deductions and take-home.","source_name":"paystubs.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"plan_stats":{"title":"Plan statement totals","description":"Ending balance, time-weighted return and allocation from the plan statement.","source_name":"plan_stats.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"plan_summary":{"title":"Plan balance sources","description":"Where the first account balance came from, first to last statement.","source_name":"plan_summary.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"price_history":{"title":"Fund price history","description":"Fund prices at the first and last statement dates.","source_name":"price_history.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"profile_answers":{"title":"What you have","description":"One answer per kind of debt, bill and account: yes, no or not asked yet. Nothing is assumed to exist.","source_name":"profile_answers.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"retirement_plan":{"title":"Retirement plan inputs","description":"Goals, ages, contribution limits and the chosen 401(k) percent.","source_name":"retirement_plan.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"savings_goals":{"title":"Savings goals","description":"Savings goals with target, date, amount saved and monthly amount, for the forecast. A goal_id none row means no goals are set.","source_name":"savings_goals.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"scores_config":{"title":"Score settings","description":"Components, weights and ranges for the Financial and Risk Scores. One settings row.","source_name":"scores_config.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"scores_history":{"title":"Score history","description":"Monthly score snapshots; trends show after 6 snapshots over 60 days.","source_name":"scores_history.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}},"tasks":{"title":"Tasks","description":"To-do list with due date, priority and a linked data request, to complete the data and improve the metrics.","source_name":"tasks.json","source_kind":"file","updated":{"at":"2026-01-01T00:00:00Z","by":"Claude"}}};
const RESTORE="# Restore the Money Operations Center from a backup kit\n\nThis file ships inside every rebuild kit (`dashboard-kit-YYYY-MM-DD.zip`, from More > Data and backup > Rebuild kit). The kit holds:\n\n- `datasets/<id>.json`: one file per dataset (manifest.json gives the count as dataset_count), each a JSON array of row objects, ready to upload as is\n- `csv/<id>.csv`: the same rows as spreadsheets. A view only: a blank cell can be null or empty text, and nested values are JSON text. Never restore from the CSVs\n- `docs/datasets.json`: each dataset's title, description, source file name, source kind and last update\n- `dash/meta.json`: the dashboard title\n- `schema.json`: every field of every dataset with its value types, and the schema version\n- `calcs/<id>.json`: worked out tables (for checking only; the page recomputes them)\n- `page/`: the page files (`index.html`, `app_a.js`, `app_b.js`, `app_c.js`) when the view that made the kit could read them\n- `overlay/task_edits.json`: task changes made with the buttons on the page that Claude has not folded into `tasks.json` yet, if any\n- `manifest.json`: the export time, the status of every dataset, a few check values, and the byte size and sha256 of every other file\n\nThe page keeps only values taken from your documents. Account numbers, addresses, loan IDs, tax IDs and family names are never stored, so none are in the kit. Keep your original downloaded statements (PDF or CSV) in your own folder.\n\n## Steps\n\n1. Unzip the kit into a new folder.\n2. Open `manifest.json`. Check that `datasets_ok` equals `dataset_count`. If a dataset is missing, use the previous month's kit for that one file, or ask Claude for it.\n3. Check the files against the manifest. On a Mac or Linux terminal: `shasum -a 256 datasets/*.json` and compare each line with the `sha256` for that path in `manifest.json`. Any mismatch means the file changed after the export: do not use it.\n4. Start a new chat with Claude and attach the kit (the zip, or the folder's files). Say: \"Rebuild my Money Operations Center dashboard from this backup kit. Follow RESTORE.md.\"\n5. Claude creates a new dashboard from the Dashboard type, then writes `dash/meta` with the title from `dash/meta.json`.\n6. For each `datasets/<id>.json`, Claude uploads the file as an asset, then writes the `datasets/<id>` document with the `title` and `description` from `docs/datasets.json`, `source: {kind: \"file\", url: <the new /_blob/ url>, name: \"<id>.json\", format: \"json\"}`, and `updated: {at: <now>, by: \"Claude\"}`. All are written in one batch.\n7. If `overlay/task_edits.json` exists, Claude applies those edits to `tasks.json` first (status, done_date, due_date, priority, snooze and added tasks), then uploads `tasks.json`.\n8. Claude writes the page: `files/index.html` and each `app_*.js` from `page/`. If `page/` is missing, ask Claude for the published page source (index.html v27 and the three app files) and use those.\n9. Open the new dashboard. More > Data and backup must say \"N of N datasets loaded\" with N the dataset_count. Compare Net worth, Total debts, Debt to income and the two scores with `check_values` in `manifest.json`; they must match to the cent.\n10. Save a new backup from the restored page, so the next restore starts from the new dashboard.\n\nBackups are due on the 1st of each month. A backup counts only when the page says \"Saved\"; if it says \"Not saved\", follow the reason it gives or ask Claude for the kit.\n";
const SCHEMA_VERSION='mo-backup-2';
const KEY='mo_last_backup';
const bad=/^(account_?(number|no|num)|acct_?(number|no)|routing.*|ssn|tax_?id|tin|loan_?(id|number|no))$/i;
function clean(v){if(Array.isArray(v))return v.map(clean);if(v&&typeof v==='object'){const o={};Object.keys(v).forEach(k=>{if(!bad.test(k))o[k]=clean(v[k]);});return o;}return v;}
const pad=n=>String(n).padStart(2,'0');
function stamp(){if(window.__TODAY)return window.__TODAY;const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
const use=name=>{try{return window.claude&&typeof window.claude.use==='function'?Promise.resolve(window.claude.use(name)).catch(()=>null):Promise.resolve(null);}catch(e){return Promise.resolve(null);}};
const ST={dl:undefined,db:null,uid:null,last:null,lastSrc:null,ready:false};
/* due rule: a backup is due on the 1st of each month. Next due = the 1st of the month after the last confirmed
   save; overdue when the last confirmed save is before the most recent 1st. With no save on record the first one is due on the 1st of next month. */
function bkDue(last,today,firstDue){const first=today.slice(0,8)+'01';
  if(!last){const ty=+today.slice(0,4),tm=+today.slice(5,7);const due=firstDue||((tm===12?ty+1:ty)+'-'+pad(tm===12?1:tm+1)+'-01');return {due,overdue:today>=due};}
  const y=+last.slice(0,4),m=+last.slice(5,7);const due=(m===12?y+1:y)+'-'+pad(m===12?1:m+1)+'-01';
  return {due,overdue:last<first};}
window.__bkDue=bkDue;
window.__bkInfo=()=>({last:ST.last,source:ST.lastSrc,downloads:ST.dl===undefined?'checking':ST.dl?'available':'unavailable',ready:ST.ready});
function status(){return DS.map(id=>{let d=null;try{d=dash.data(id);}catch(e){d=null;}const st=d&&d.status?d.status:'missing';const v=st==='ok'?d.data:null;
  return {id,status:st,rows:Array.isArray(v)?v.length:(v!=null?1:0),message:st==='ok'?null:(d&&d.message)||null};});}
window.__bkStatus=status;
/* SHA-256 (FIPS 180-4) on bytes; constants from the first primes */
const TWO32=Math.pow(2,32);
const SHA=(()=>{const pr=[];for(let n=2;pr.length<64;n++){let p=true;for(let i=2;i*i<=n;i++)if(n%i===0){p=false;break;}if(p)pr.push(n);}
  return {K:pr.map(p=>(Math.cbrt(p)%1)*TWO32|0),H:pr.slice(0,8).map(p=>(Math.sqrt(p)%1)*TWO32|0)};})();
function sha256(b){const l=b.length,nb=((l+9+63)>>6)<<6,m=new Uint8Array(nb);m.set(b);m[l]=0x80;const dv=new DataView(m.buffer);const bits=l*8;
  dv.setUint32(nb-4,bits>>>0);dv.setUint32(nb-8,Math.floor(bits/TWO32));const w=new Int32Array(64);let h=SHA.H.slice();
  for(let o=0;o<nb;o+=64){for(let i=0;i<16;i++)w[i]=dv.getUint32(o+i*4);
    for(let i=16;i<64;i++){const a=w[i-15],c=w[i-2];const s0=(a>>>7|a<<25)^(a>>>18|a<<14)^(a>>>3),s1=(c>>>17|c<<15)^(c>>>19|c<<13)^(c>>>10);w[i]=(w[i-16]+s0+w[i-7]+s1)|0;}
    let [A,B,C2,D,E,F2,G,H]=h;
    for(let i=0;i<64;i++){const S1=(E>>>6|E<<26)^(E>>>11|E<<21)^(E>>>25|E<<7),ch=(E&F2)^(~E&G),t1=(H+S1+ch+SHA.K[i]+w[i])|0;
      const S0=(A>>>2|A<<30)^(A>>>13|A<<19)^(A>>>22|A<<10),mj=(A&B)^(A&C2)^(B&C2),t2=(S0+mj)|0;H=G;G=F2;F2=E;E=(D+t1)|0;D=C2;C2=B;B=A;A=(t1+t2)|0;}
    h=[A,B,C2,D,E,F2,G,H].map((x,i)=>(x+h[i])|0);}
  return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');}
window.__sha256=s=>sha256(new TextEncoder().encode(s));
function csvCell(v){if(v==null)return '';if(typeof v==='object')v=JSON.stringify(v);v=String(v);return /[",\n\r]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}
function toCsv(d){const list=Array.isArray(d)?d:(d&&typeof d==='object'?[d]:[{value:d}]);const keys=[];list.forEach(r=>{if(r&&typeof r==='object')Object.keys(r).forEach(k=>{if(keys.indexOf(k)<0)keys.push(k);});else if(keys.indexOf('value')<0)keys.push('value');});
  return [keys.map(csvCell).join(',')].concat(list.map(r=>keys.map(k=>csvCell(r&&typeof r==='object'?r[k]:(k==='value'?r:''))).join(','))).join('\r\n')+'\r\n';}
const crcT=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t.push(c>>>0);}return t;})();
function crc(b){let c=0xFFFFFFFF;for(let i=0;i<b.length;i++)c=crcT[(c^b[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;}
function zip(files){const enc=new TextEncoder();const parts=[],cen=[];let off=0;
  files.forEach(f=>{const nm=enc.encode(f.name),d=f.bytes,c=crc(d);
    const lh=new DataView(new ArrayBuffer(30));lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);lh.setUint32(14,c,true);lh.setUint32(18,d.length,true);lh.setUint32(22,d.length,true);lh.setUint16(26,nm.length,true);
    parts.push(new Uint8Array(lh.buffer),nm,d);
    const ch=new DataView(new ArrayBuffer(46));ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint32(16,c,true);ch.setUint32(20,d.length,true);ch.setUint32(24,d.length,true);ch.setUint16(28,nm.length,true);ch.setUint32(42,off,true);
    cen.push(new Uint8Array(ch.buffer),nm);off+=30+nm.length+d.length;});
  let cs=0;cen.forEach(x=>cs+=x.length);const e=new DataView(new ArrayBuffer(22));e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,cs,true);e.setUint32(16,off,true);
  return new Blob(parts.concat(cen,[new Uint8Array(e.buffer)]),{type:'application/zip'});}
function schemaOf(v){const list=Array.isArray(v)?v:[v];const f={};list.forEach(r=>{if(r&&typeof r==='object')Object.keys(r).forEach(k=>{const x=r[k];const t=x===null?'null':Array.isArray(x)?'array':typeof x;(f[k]=f[k]||[]).indexOf(t)<0&&f[k].push(t);});});
  return Object.keys(f).map(k=>({field:k,types:f[k].sort()}));}
async function liveDocs(){/* the dashboard's own documents, when this view can read them */
  const out={docs:null,meta:null,files:null,overlay:null};if(!ST.db)return out;
  try{const s=await ST.db.collection('datasets').get();const o={};s.docs.forEach(d=>{const x=d.data()||{};o[d.id]={title:x.title||null,description:x.description||null,source_name:x.source&&x.source.name||null,source_kind:x.source&&x.source.kind||null,updated:x.updated||null};});if(Object.keys(o).length)out.docs=o;}catch(e){}
  try{const m=await ST.db.doc('dash/meta').get();if(m.exists)out.meta=m.data();}catch(e){}
  try{const f=await ST.db.collection('files').get();const o={};f.docs.forEach(d=>{const x=d.data()||{};if(typeof x.text==='string')o[d.id]=x.text;});if(Object.keys(o).length)out.files=o;}catch(e){}
  try{if(ST.uid){const t=await ST.db.collection('data/users/'+ST.uid+'/tasks/edits').get();if(t.size)out.overlay=t.docs.map(d=>Object.assign({doc_id:d.id},d.data()));}}catch(e){}
  return out;}
function checkValues(){const v={};try{const nw=rows('nw_rows');const n=nw&&nw.find(x=>x.item==='Net worth');if(n)v.net_worth=n.amount;const d=rows('dti_calc');if(d){v.total_debts=d[0].total_balance;v.dti_entered_pct=d[0].back_end_pct;}
  const s=rows('scores_calc');if(s&&s[0]){v.financial_score=s[0].financial.score;v.risk_score=s[0].risk.score;}}catch(e){}return v;}
async function build(){
  const st=status();const ok=st.filter(s=>s.status==='ok');const exported=new Date().toISOString();const day=stamp();
  const L=await liveDocs();const docs=L.docs||DOCS;
  const enc=new TextEncoder();const files=[];const add=(name,text)=>{const bytes=enc.encode(text);files.push({name,bytes,sha256:sha256(bytes)});};
  const datasets={},calcs={},schema={};
  DS.forEach(id=>{const v0=rows(id);if(v0==null)return;const v=typeof NESTED_CELLS!=='undefined'&&NESTED_CELLS[id]?v0.map(r=>parseRow(r,NESTED_CELLS[id])):v0;datasets[id]=clean(v);schema[id]=schemaOf(datasets[id]);});
  CALCS.forEach(id=>{const v=rows(id);if(v!=null)calcs[id]=clean(v);});
  DS.forEach(id=>{if(id in datasets)add('datasets/'+id+'.json',JSON.stringify(datasets[id],null,1)+'\n');});
  DS.forEach(id=>{if(id in datasets)add('csv/'+id+'.csv',toCsv(datasets[id]));});
  Object.keys(calcs).forEach(id=>add('calcs/'+id+'.json',JSON.stringify(calcs[id],null,1)+'\n'));
  add('docs/datasets.json',JSON.stringify(docs,null,1)+'\n');
  add('dash/meta.json',JSON.stringify(L.meta||{title:'Money Operations Center'},null,1)+'\n');
  add('schema.json',JSON.stringify({schema_version:SCHEMA_VERSION,datasets:schema},null,1)+'\n');
  if(L.files)Object.keys(L.files).sort().forEach(n=>add('page/'+n,L.files[n]));
  if(L.overlay)add('overlay/task_edits.json',JSON.stringify(L.overlay,null,1)+'\n');
  add('RESTORE.md',RESTORE);
  const manifest={schema_version:SCHEMA_VERSION,exported,day,dataset_count:DS.length,datasets_ok:ok.length,calc_count:Object.keys(calcs).length,
    statuses:st,docs_source:L.docs?'live store (datasets collection)':'catalogue built into the page',
    page_source:L.files?'included under page/':'not readable in this view: ask Claude for the page source',
    task_overlay:L.overlay?'included under overlay/':'none',check_values:checkValues(),
    files:files.map(f=>({path:f.name,bytes:f.bytes.length,sha256:f.sha256}))};
  const mtext=JSON.stringify(manifest,null,1)+'\n';files.push({name:'manifest.json',bytes:enc.encode(mtext)});
  const json={schema_version:SCHEMA_VERSION,exported,manifest,docs,meta:L.meta||{title:'Money Operations Center'},schema,restore_steps:RESTORE,datasets,calcs,page_files:L.files||null,task_overlay:L.overlay||null};
  return {st,ok,manifest,files,json,day};}
window.__bkBuild=build;
function msg(t){$('bk-msg').textContent=t;}
function fallback(show,why){const f=$('bk-fallback');if(!f)return;f.hidden=!show;if(show)f.textContent=(why?why+' ':'')+'Fallback: ask Claude in the chat for "the monthly backup kit"; it sends the same files (every dataset, the dataset list, the page source and RESTORE.md) as downloads.';}
function showLast(){const b=$('bk-last');if(!b)return;b.textContent='Last confirmed backup: '+(ST.last?(typeof fdy==='function'?fdy(ST.last):ST.last)+(ST.lastSrc==='db'?' (kept in your private dashboard data)':ST.lastSrc==='local'?' (this browser only)':' (this visit only)'):'none recorded');}
function showStatus(){const box=$('bk-status');if(!box)return;const st=status();const okn=st.filter(s=>s.status==='ok').length;box.replaceChildren();
  const p=el('p','mo-note',okn+' of '+DS.length+' datasets loaded'+(okn<DS.length?'. Not loaded: '+st.filter(s=>s.status!=='ok').map(s=>s.id+' ('+s.status+')').join(', ')+'.':', ready to back up.'));p.id='bk-count';box.append(p);
  const d=el('details','mo-fold');d.append(el('summary',null,'Every dataset and its status ('+DS.length+')'));const ul=el('ul','mo-bklist');st.forEach(s=>{ul.append(el('li',null,s.id+': '+s.status+(s.status==='ok'?', '+s.rows+(s.rows===1?' row':' rows'):'')));});d.append(ul);box.append(d);}
window.__bkShowStatus=showStatus;
async function remember(day,kind,n){ST.last=day;ST.lastSrc='visit';
  try{localStorage.setItem(KEY,day);ST.lastSrc='local';}catch(e){}
  if(ST.db&&ST.uid){try{await ST.db.doc('data/users/'+ST.uid+'/backup').set({last_saved:day,at:new Date().toISOString(),kind,datasets:n});ST.lastSrc='db';}catch(e){}}
  showLast();if(typeof window.__bkRedraw==='function')window.__bkRedraw();}
const REASON={declined:'Not saved: the save was declined.',rate_limited:'Not saved: a save prompt is already open or several were shown just now. Wait a minute, then try again.',too_large:'Not saved: the file is too large for that destination.',rejected_extension:'Not saved: this file type is not allowed here.',extension_not_enabled:'Not saved: this file type is switched off in this view.',bad_request:'Not saved: the file could not be prepared.'};
const GONE=['unavailable','not_granted','capability_disabled','capability_removed'];
function hideButtons(){const b=$('bk-btns');if(b)b.hidden=true;}
async function give(name,blob){
  if(!ST.dl){hideButtons();fallback(true,'Not saved: download is not available here.');return {ok:false,why:'Not saved: download is not available here.'};}
  try{const r=await ST.dl.save({filename:name,data:blob});
    if(r&&r.status==='saved')return {ok:true};
    if(r&&r.status==='delivered')return {ok:false,why:'Sent to the destination you chose; it is not counted as a saved backup.'};
    return {ok:false,why:'Not saved: no confirmation came back from the save.'};
  }catch(e){const code=e&&e.code||'unavailable';if(GONE.indexOf(code)>=0||!REASON[code]){hideButtons();return {ok:false,why:'Not saved: download is not available here.'};}return {ok:false,why:REASON[code]};}}
async function run(kind){
  const st=status();const miss=st.filter(s=>s.status!=='ok');showStatus();
  if(miss.length){msg('Not saved: '+miss.length+' of '+DS.length+' datasets did not load ('+miss.map(s=>s.id).join(', ')+'). A backup without them would be incomplete. Reload the page, or ask Claude for those files.');fallback(true);return;}
  msg('Preparing the files...');let B;try{B=await build();}catch(e){msg('Not saved: the files could not be prepared ('+(e&&e.message||'error')+').');fallback(true);return;}
  const blob=kind==='json'?new Blob([JSON.stringify(B.json,null,1)],{type:'application/json'}):zip(B.files);
  const name=(kind==='json'?'dashboard-backup-':'dashboard-kit-')+B.day+(kind==='json'?'.json':'.zip');
  const r=await give(name,blob);
  if(r.ok){await remember(B.day,kind,B.ok.length);msg('Saved '+B.ok.length+' of '+DS.length+' datasets'+(kind==='json'?' in one JSON file':' in the rebuild kit ('+B.files.length+' files with a sha256 manifest and RESTORE.md)')+'. Copy it to your cloud folder.');fallback(false);}
  else{msg(r.why);fallback(true);}}
/* the backup buttons live on the Data and backup page, which mounts on first open: one listener for both, and the state is redrawn on mount */
document.addEventListener('click',e=>{const b=e.target&&e.target.closest&&e.target.closest('#bk-json,#bk-csv');if(b)run(b.id==='bk-json'?'json':'zip');});
window.__bkOnMount=()=>{showLast();if(ST.ready&&!ST.dl){hideButtons();fallback(true,'Download is not available here.');}};
try{ST.last=localStorage.getItem(KEY);if(ST.last)ST.lastSrc='local';}catch(e){}
showLast();
(async()=>{const dl=await use('downloads');ST.dl=dl&&typeof dl.save==='function'?dl:null;
  if(!ST.dl){hideButtons();fallback(true,'Download is not available here.');}
  const db=await use('db');const u=await use('user');let uid=null;try{uid=u&&typeof u.id==='function'?await u.id():null;}catch(e){uid=null;}
  ST.db=db||null;ST.uid=uid;
  if(db&&uid){try{const s=await db.doc('data/users/'+uid+'/backup').get();if(s.exists){const x=s.data();if(x&&x.last_saved&&(!ST.last||x.last_saved>=ST.last)){ST.last=x.last_saved;ST.lastSrc='db';}}}catch(e){}}
  ST.ready=true;showLast();if(typeof window.__bkRedraw==='function')window.__bkRedraw();})();
}catch(e){console.error('backup: '+e.message);}})();

/* Bottom bar: measured app shell.
   Rest state (no script, no IntersectionObserver, or nothing clipped yet): the page is in normal flow and the bar is the last block.
   Once an IntersectionObserver (root null = the real top-level viewport, clipped by every ancestor and by the iframe) shows that the
   app is cut off at the visible bottom, the app becomes a fixed-height flex column (class moS) whose height is exactly the visible
   height, so the document fits whatever the host does: a fixed-height iframe never scrolls, an auto-sized iframe shrinks to one
   screen, and the bar is a plain flex footer at the visible bottom. No position:fixed, no transform, no 100vh.
   Two host kinds, decided at the first measurement:
   auto  = the document always fits the iframe (innerHeight >= content height), so the parent page scrolls. When the parent scrolls a
           frame that the host cannot shrink, the shell is kept on screen with a top spacer (padding). Room is re-probed after resizes.
   fixed = the document overflowed a stable iframe for 1.2 s, so the iframe is a real viewport; innerHeight changes are the signal.
   A sentinel column (100px slices, 101 thresholds each) gives the visible top and bottom edges with about 1px precision. */
(function(){try{
const app=document.getElementById('app'),bar=app.querySelector('.mo-bar'),main=app.querySelector('.mo-main'),top=app.querySelector('.mo-top'),ttl=document.getElementById('ttl');
const root=document.documentElement;
const S={kind:'',engaged:false,H:0,spacer:0,vt:null,vb:null,colBottom:null,fits:null,probing:false,avail:0,lastProbe:0,probeVt:null,small:0,shrinkOK:-1e9,ih0:0,io:'IntersectionObserver' in window,lastSig:'',stableSince:0,applied:0};
window.__moState=()=>Object.assign({},S,{mode:S.engaged?S.kind:'flow',innerHeight:window.innerHeight,scrollHeight:root.scrollHeight});
window.__moMode=()=>S.engaged?S.kind:'flow';
/* ---- debug readout: triple tap on the page title, text only ---- */
const dbg=document.createElement('pre');dbg.className='mo-dbg';top.appendChild(dbg);
let taps=[],dbgTimer=null;
function parentAccess(){try{if(window.top===window)return 'top-level (no parent)';const d=window.parent.document;return d?'parent readable (same origin)':'parent blocked';}catch(e){return 'parent blocked (cross-origin)';}}
function insets(){try{const d=document.createElement('div');d.style.cssText='position:absolute;visibility:hidden;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);padding-left:env(safe-area-inset-left,0px)';document.body.appendChild(d);const c=getComputedStyle(d);const r=c.paddingTop+' '+c.paddingBottom+' '+c.paddingLeft;d.remove();return r;}catch(e){return '?';}}
function contentH(){const cs=getComputedStyle(root);return Math.ceil(root.getBoundingClientRect().height+(parseFloat(cs.marginTop)||0)+(parseFloat(cs.marginBottom)||0));}
function dbgText(){
  const vv=window.visualViewport;const r=app.getBoundingClientRect(),b=bar.getBoundingClientRect();const hp=getComputedStyle(root);
  return ['mode: '+(S.engaged?S.kind+' shell':'flow (not engaged)')+(S.io?'':' (no IntersectionObserver)'),
   'shell H '+S.H+'  spacer '+S.spacer+'  avail '+Math.round(S.avail)+'  probing '+S.probing+'  applied '+S.applied,
   'visible top/bottom (IO): '+(S.vt===null?'none':Math.round(S.vt)+' / '+Math.round(S.vb))+'  column bottom '+(S.colBottom===null?'-':Math.round(S.colBottom)),
   'innerWidth x innerHeight: '+window.innerWidth+' x '+window.innerHeight,
   'doc scrollHeight '+root.scrollHeight+'  content '+contentH()+'  scrollY '+Math.round(window.scrollY)+'  fits '+S.fits,
   'visualViewport: '+(vv?Math.round(vv.width)+' x '+Math.round(vv.height)+' offsetTop '+Math.round(vv.offsetTop)+' scale '+vv.scale.toFixed(2):'none'),
   'screen: '+screen.width+' x '+screen.height+'  avail '+screen.availHeight+'  dpr '+window.devicePixelRatio,
   'app top/bottom '+Math.round(r.top)+' / '+Math.round(r.bottom)+'  bar top/bottom '+Math.round(b.top)+' / '+Math.round(b.bottom)+'  main scrollTop '+Math.round(main.scrollTop),
   'html padding top/bottom '+hp.paddingTop+' / '+hp.paddingBottom+'  safe-area t/b/l '+insets(),
   'frame: '+parentAccess()+'  origin '+location.origin,
   'claude.use: '+(window.claude&&typeof window.claude.use==='function'?'yes':'no')+'  IO '+S.io+'  RO '+('ResizeObserver' in window),
   (typeof liveShapeReport==='function'?liveShapeReport():'live shape: n/a'),
   'ua: '+navigator.userAgent].join('\n');
}
function dbgTick(){if(!dbg.classList.contains('on'))return;dbg.textContent=dbgText();dbgTimer=setTimeout(dbgTick,500);}
if(ttl){ttl.addEventListener('pointerdown',()=>{const t=performance.now();taps=taps.filter(x=>t-x<700);taps.push(t);if(taps.length>=3){taps=[];dbg.classList.toggle('on');clearTimeout(dbgTimer);if(dbg.classList.contains('on'))dbgTick();}});}
if(!S.io)return;
/* ---- sentinel column ---- */
const col=document.createElement('div');col.className='mo-sent';col.setAttribute('aria-hidden','true');app.insertBefore(col,app.firstChild);
/* in-flow probe after the app: while probing it extends the document to the screen height so a host that sizes the frame by its content grows it and the column can see how much of that is on screen */
const pr=document.createElement('div');pr.className='mo-probe';pr.setAttribute('aria-hidden','true');app.parentNode.insertBefore(pr,app.nextSibling);
const ents=new Map();let raf=0,timer=0,probeTimer=0,safety=[];
const th=[];for(let i=0;i<=100;i++)th.push(i/100);
const io=new IntersectionObserver(list=>{list.forEach(e=>ents.set(e.target,e));schedule();},{root:null,threshold:th});
function layoutCol(){
  const ctd=col.getBoundingClientRect().top+window.scrollY;
  let h=Math.max(app.offsetHeight,window.innerHeight-ctd);
  if(S.probing){const reach=Math.max(screen.height||0,screen.width||0,window.innerHeight);const ab=app.getBoundingClientRect().bottom+window.scrollY;pr.style.height=Math.max(0,Math.ceil(reach-ab-belowApp()))+'px';h=Math.max(h,reach-ctd);}
  else pr.style.height='';
  h=Math.max(100,Math.ceil(h));
  col.style.height=h+'px';
  const n=Math.min(800,Math.ceil(h/100));
  while(col.children.length<n){const i=document.createElement('i');col.appendChild(i);io.observe(i);}
  while(col.children.length>n){const i=col.lastChild;io.unobserve(i);ents.delete(i);col.removeChild(i);}
  for(let i=0;i<n;i++)col.children[i].style.height=(i===n-1?h-100*(n-1):100)+'px';
}
function geom(){let vt=Infinity,vb=-Infinity,any=false;ents.forEach(e=>{if(e.isIntersecting&&e.intersectionRect.height>0){any=true;if(e.intersectionRect.top<vt)vt=e.intersectionRect.top;if(e.intersectionRect.bottom>vb)vb=e.intersectionRect.bottom;}});return any?{vt,vb}:null;}
function schedule(){if(!raf)raf=requestAnimationFrame(()=>{raf=0;evaluate();});}
function later(ms){clearTimeout(timer);timer=setTimeout(()=>{timer=0;evaluate();},ms);}
function belowApp(){ /* content below the app in this document: root padding, anything after the app */
  const a=app.getBoundingClientRect(),b=document.body.getBoundingClientRect(),cs=getComputedStyle(root);
  return Math.max(0,b.bottom-a.bottom-pr.getBoundingClientRect().height)+(parseFloat(cs.paddingBottom)||0)+(parseFloat(cs.marginBottom)||0);
}
function applyShell(H,spacer){
  S.H=H;S.spacer=spacer;S.applied++;
  app.style.setProperty('--mo-h',(H+spacer)+'px');app.style.paddingTop=spacer?spacer+'px':'';
  layoutCol();
}
function startProbes(){if(!probeTimer)probeTimer=setInterval(()=>{if(document.visibilityState==='visible'&&!S.probing)probe();},10000);}
function engage(kind){
  S.kind=kind;S.engaged=true;S.ih0=window.innerHeight;
  const g=geom();const ct=col.getBoundingClientRect().top;
  const seen=g?Math.max(0,g.vt-ct):0; /* content offset that was at the visible top */
  app.classList.add('moS');
  if(kind==='fixed'){const sy=window.scrollY;if(sy>0){window.scrollTo(0,0);main.scrollTop=sy;}safety=[setTimeout(probe,3000),setTimeout(probe,8000)];}
  else{if(seen>0)main.scrollTop=Math.max(0,seen-top.offsetHeight);startProbes();}
}
function probe(){if(S.probing||!S.engaged)return;S.probing=true;S.lastProbe=performance.now();S.probeVt=S.vt;layoutCol();setTimeout(()=>{S.probing=false;layoutCol();later(60);},450);}
function evaluate(){
  const g=geom();const fits=window.innerHeight>=contentH()-1;S.fits=fits;
  if(!g){S.vt=S.vb=null;if(!S.engaged)later(400);return;} /* frame off screen or not rendered yet: wait */
  S.vt=g.vt;S.vb=g.vb;
  const appR=app.getBoundingClientRect(),colR=col.getBoundingClientRect();S.colBottom=colR.bottom;
  const now=performance.now();
  if(!S.engaged){
    layoutCol();
    if(appR.bottom<=g.vb+1){S.lastSig='';later(500);return;} /* nothing clipped: normal flow is right */
    if(fits){engage('auto');layoutCol();schedule();return;}
    const sig=window.innerHeight+':'+contentH()+':'+Math.round(g.vb)+':'+Math.round(appR.bottom);
    if(sig!==S.lastSig){S.lastSig=sig;S.stableSince=now;later(300);return;}
    if(now-S.stableSince>=1200){engage('fixed');layoutCol();schedule();return;}
    later(300);return;
  }
  /* engaged. Column top in view: the visible span is the available height and the shell takes it (keyboard, toolbar, rotation
     and the host's own frame size all land here). Column top scrolled out (the parent scrolled a frame it cannot shrink): keep
     the height and move the shell down with a top spacer so it stays on screen. */
  const ct=colR.top,cutTop=g.vt>ct+1,cutBottom=colR.bottom>g.vb+1,span=g.vb-g.vt;
  const hidden=Math.max(0,window.innerHeight-g.vb);
  const b=belowApp();
  let spacer=S.spacer,H=S.H;
  const following=S.kind==='auto'&&window.innerHeight>=contentH()-(S.probing?pr.offsetHeight:0)-1&&window.innerHeight>=contentH()-(S.probing?pr.offsetHeight:0)+8; /* the frame is taller than the document: a host that did not shrink it, so the shell can be moved inside it without growing it */
  if(S.kind==='fixed')spacer=0;
  else if(following){const maxSp=Math.max(0,Math.floor(window.innerHeight-b-ct-S.H));spacer=cutTop?Math.min(maxSp,Math.round(g.vt-ct)):0;}
  else if(!cutTop)spacer=0;
  if(S.kind==='fixed'&&fits&&window.innerHeight>S.ih0+50){S.kind='auto';safety.forEach(clearTimeout);startProbes();} /* a slow auto host grew the frame after all */
  if(S.kind==='fixed'){H=Math.max(240,Math.round(window.innerHeight-(ct+window.scrollY)-b));} /* the frame is the viewport: its height is the truth; the parent moving it does not shrink the shell */
  else if(!cutTop||following){
    if(cutBottom||S.probing){S.avail=span;S.probeVt=g.vt;}
    /* fully visible column, and either less room than last known or the frame moved on screen: look for more room once */
    else if(!cutTop&&!S.probing&&now-S.lastProbe>700&&(span<S.avail-1||S.probeVt===null||Math.abs(g.vt-S.probeVt)>1))probe();
    H=Math.max(240,Math.round(span-Math.max(0,b-hidden)));
    /* the shell never shrinks because the parent moved the frame (a frame entering from the bottom of the screen, a rubber band):
       in this kind a smaller visible span is taken only right after a resize or orientation change, and only when it persists */
    if(H<S.H-1){if(now-S.shrinkOK>1500)H=S.H;else if(!S.small){S.small=now;later(330);H=S.H;}else if(now-S.small<300){later(330);H=S.H;}}else S.small=0;
  }
  if(Math.abs(H-S.H)>1||spacer!==S.spacer)applyShell(H,spacer);
}
layoutCol();
if('ResizeObserver' in window){new ResizeObserver(()=>{layoutCol();schedule();}).observe(app);}
let lastW=window.innerWidth;
function sizeEvent(){S.shrinkOK=performance.now();layoutCol();schedule();if(S.engaged&&S.kind==='auto')probe();}
window.addEventListener('resize',sizeEvent);
if(window.visualViewport)window.visualViewport.addEventListener('resize',sizeEvent);
window.addEventListener('orientationchange',()=>{S.shrinkOK=performance.now();if(S.engaged)setTimeout(probe,300);});
if('ResizeObserver' in window){new ResizeObserver(()=>{const w=window.innerWidth;if(Math.abs(w-lastW)>1){lastW=w;sizeEvent();}}).observe(root);}
document.addEventListener('focusout',()=>{if(S.engaged&&S.kind==='auto')setTimeout(probe,350);});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')schedule();});
later(200);
}catch(e){}})();
