/* ---------- Overview ---------- */
const nwItem=(r,k)=>(r.find(x=>x.item===k)||{}).amount;
function drawOverview(){
  drawOvOwn();
  const ac=rows('account_calc');
  if(ac){const items=ac.filter(a=>a.now_usd>0).map(a=>({label:a.account,value:a.now_usd,color:acctColor(a.account),tip:null}));donut($('ov-donut'),items,{center:[compact(d3.sum(items,d=>d.value)),'in retirement accounts'],label:'Retirement balance by account'});}
}

function drawOvOwn(){
  const box=$('ov-own');if(!box)return;const st=rows('nw_steps');if(!st)return;box.replaceChildren();
  const ti=st.findIndex(s=>s.label==='Total assets');if(ti<0)return;
  const assets=st.slice(0,ti).map(s=>({label:s.label,value:s.value,color:ASSET_COL(s.type)}));
  const debts=st.slice(ti+1,st.length-1).map(s=>({label:s.label,value:-s.value,color:DEBT_COL(s)}));
  const aT=d3.sum(assets,x=>x.value),dT=d3.sum(debts,x=>x.value),mx=Math.max(aT,dT)||1;const tip=mkTip(box);
  const block=(title,items,T)=>{
    const head=el('div',null);head.style.cssText='display:flex;justify-content:space-between;gap:.5rem;margin:.4rem 0 .3rem;font-weight:600';head.append(el('span',null,title),el('span',null,money(T)));
    const wrap=el('div');wrap.style.width=(T/mx*100)+'%';const mt=el('div','mo-meter');mt.style.height='22px';mt.setAttribute('role','img');mt.setAttribute('aria-label',title+' '+money(T));
    items.forEach(it=>{const i=document.createElement('i');i.style.width=(it.value/T*100)+'%';i.style.background=it.color;i.style.minWidth='3px';
      i.addEventListener('pointermove',ev=>tip.show(ev,[it.label,money(it.value)+' ('+Math.round(it.value/T*1000)/10+'%)']));i.addEventListener('pointerleave',()=>tip.hide());mt.append(i);});
    wrap.append(mt);box.append(head,wrap,legendEl(items.map(it=>({label:it.label+' '+compact(it.value),color:it.color}))));};
  block('Assets',assets,aT);block('Debts',debts,dT);
}

/* ---------- Investments ---------- */
/* one builder for both fund tables: the first account (cost, gain or loss, return, trend) and the second (value and share only) */
const HCOL={holding:{l:'Fund'},asset_class:{l:'Type',h:1},value:{l:'Value',n:1},share_pct:{l:'Share of account',n:1,h:1},cost_basis:{l:'Cost basis',n:1,h:1},gain_loss:{l:'Gain or loss',n:1,h:1},return_pct:{l:'Return on cost',n:1},spark:{l:'Trend',ns:1}};
function holdTable(){
  const r=rows('all_holdings');if(!r)return;const AN=acctNames(rows('acct_a_sources'),rows('acct_b_holdings'));
  const build=(tbl,list,keys)=>{
    if(!tbl)return;const th=tbl.tHead;th.replaceChildren();const tr0=document.createElement('tr');
    keys.forEach(k=>{const c=HCOL[k];const t=document.createElement('th');if(c.n)t.className='num';if(c.h)t.classList.add('mo-hide-s');
      if(c.ns)t.textContent=c.l;else{const b=el('button','mo-sort',c.l);b.type='button';const s=state.sort;const on=s.key===k;b.setAttribute('aria-sort',on?(s.dir>0?'ascending':'descending'):'none');t.setAttribute('aria-sort',on?(s.dir>0?'ascending':'descending'):'none');
        b.addEventListener('click',()=>{state.sort=state.sort.key===k?{key:k,dir:-state.sort.dir}:{key:k,dir:(c.n?-1:1)};holdTable();});t.append(b);}
      tr0.append(t);});
    th.append(tr0);
    const s=state.sort;const data=[...list].sort((a,b)=>{const x=a[s.key],y=b[s.key];if(x==null&&y==null)return 0;if(x==null)return 1;if(y==null)return -1;return (typeof x==='string'?x.localeCompare(y):x-y)*s.dir;});
    const body=tbl.tBodies[0];body.replaceChildren();
    data.forEach(h=>{
      const tr=document.createElement('tr');
      keys.forEach(k=>{const c=HCOL[k];const d=document.createElement('td');if(k==='holding')d.className='key';else{const cl=[];if(c.n)cl.push('num');if(c.h)cl.push('mo-hide-s');if(cl.length)d.className=cl.join(' ');}
        if(k==='holding')d.textContent=h.holding;
        else if(k==='asset_class')d.textContent=h.asset_class;
        else if(k==='value')d.textContent=money(h.value);
        else if(k==='share_pct')d.textContent=pctf(h.share_pct);
        else if(k==='cost_basis')d.textContent=h.cost_basis==null?'n/a':money(h.cost_basis);
        else if(k==='gain_loss')d.textContent=h.gain_loss==null?'n/a':F.signed(h.gain_loss);
        else if(k==='return_pct'){d.append(el('span','mo-badge '+(h.return_pct==null?'none':h.return_pct>0?'up':h.return_pct<0?'down':'none'),h.return_pct==null?'no return yet':(h.return_pct>0?'▲ +':h.return_pct<0?'▼ ':'')+h.return_pct+'%'));}
        else if(k==='spark'&&h.spark&&h.spark.length>1){const w=el('span');w.style.cssText='display:inline-block;width:64px;vertical-align:middle';w.append(spark(h.spark,h.return_pct<0?'var(--mo-bad)':C[0]));d.append(w);}
        tr.append(d);});
      body.append(tr);});};
  build($('t-all'),r.filter(h=>h.account===AN.nb),['holding','asset_class','value','share_pct','cost_basis','gain_loss','return_pct','spark']);
  build($('t-hi'),r.filter(h=>h.account===AN.hi),['holding','asset_class','value','share_pct']);
}
function drawInvestments(){
  const hc=rows('holdings_calc'),ps=rows('plan_summary'),hist=rows('acct_a_hist'),ac=rows('account_calc'),sr=rows('acct_a_sources'),ah=rows('all_holdings');
  const AN=acctNames(sr,rows('acct_b_holdings'));
  const h1=$('inv-nb-h'),h2=$('inv-hi-h');if(h1)h1.textContent=AN.nb;if(h2)h2.textContent=AN.hi;
  /* all accounts: one hero total and the fund count; the account split sits in each section */
  if(hc){const h=hc[0];const hd=hist&&hist.length>1?deltaOf(hist[hist.length-1].value,hist[0].value):null;
    tiles($('inv-tiles'),[{hero:true,label:'All holdings, total',value:money(h.total_all),spark:hist&&hist.length>1?hist.map(x=>x.value):null,color:C[0],delta:hd&&Object.assign(hd,{text:hd.text+' since '+hist[0].date.slice(5)})},
      {label:'Funds held',value:String(h.funds),sub:'Across 2 accounts'}]);}
  const bc=rows('by_class');if(bc)donut($('inv-class'),bc.map(x=>({label:x.cls,value:x.value,color:classColor(x.cls)})),{center:[compact(d3.sum(bc,x=>x.value)),'all holdings'],label:'Holdings by asset class'});
  /* treemap, grouped by account or asset class */
  if(ah){const byAcct=state.tmGroup==='account';const g=new Map();
    ah.forEach(h=>{const k=byAcct?h.account:h.asset_class;if(!g.has(k))g.set(k,{name:k,color:byAcct?acctColor(k):classColor(k),children:[]});g.get(k).children.push({name:h.holding,value:h.value,account:h.account,cls:h.asset_class,ret:h.return_pct});});
    treemap($('inv-tree'),{name:'root',children:[...g.values()].sort((a,b)=>d3.sum(b.children,c=>c.value)-d3.sum(a.children,c=>c.value))},{label:'Treemap of holdings by '+(byAcct?'account':'asset class'),
      tip:(d,grp,t)=>[d.name,d.account+', '+d.cls,money(d.value)+' ('+Math.round(d.value/t*1000)/10+'% of all)',d.ret==null?'No return yet':'Return on cost '+(d.ret>0?'+':'')+d.ret+'%']});
    $('inv-tree').append(legendEl([...g.values()].map(x=>({label:x.name,color:x.color}))));}
  /* first account: the two source-type balances as an account split, gain or loss, market growth */
  if(hc&&ac){const h=hc[0];const g=ps&&ps.find(x=>x.item==='Market growth');
    const pre=ac.find(a=>a.account===AN.aPre),rt=ac.find(a=>a.account===AN.aRoth);
    const t=[{label:'Traditional (pre-tax)',value:pre?money(pre.now_usd):'Needs: sources'},{label:'Roth',value:rt?money(rt.now_usd):'Needs: sources'},
      {label:'Gain since current cost basis',value:F.signed(h.gain_total),sub:(h.gain_pct>0?'+':'')+h.gain_pct+'% on '+money(h.cost_basis)+' cost'}];
    if(g)t.push({label:'Market growth since start',value:money(g.amount)});tiles($('inv-nb-tiles'),t);}
  holdTable();
  if(ah)drawCostScatter($('inv-scatter'),ah.filter(h=>h.cost_basis>0));
  const ps2=rows('perf_series');if(ps2)drawGrowthLines($('growth'),ps2);
  const pcl=rows('plan_calc');
  if(pcl){const p=pcl[0];tiles($('plan-tiles'),[{label:'Plan\'s own return since start',value:pctf(p.personal_return_pct)},{label:'Per year, about',value:pctf(p.annualized_pct)},{label:'Share of balance that is market growth',value:pctf(p.growth_share_pct)},{label:'Balance on the last statement',value:money(p.ending_balance)}]);
    if(ps)waterfall($('inv-planwf'),ps.map(x=>({label:x.item,value:x.amount,kind:'delta'})).concat([{label:'Balance at last statement',value:p.ending_balance,kind:'total'}]),{H:300,up:C[0],down:C[1],label:'Where the balance came from'});}
  const pg=rows('price_growth');if(pg)drawSlope($('inv-slope'),pg);
  if(sr)donut($('inv-src'),sr.map((s,i)=>({label:s.source+' ('+(s.tax_type==='Pre-tax'?'Traditional':s.tax_type)+')',value:s.balance,color:C[[0,4,5,1,2,3][i%6]]})),{center:[compact(d3.sum(sr,s=>s.balance)),AN.nb],label:'Balance by source',tip:(d,t)=>[d.label,money(d.value)+' ('+Math.round(d.value/t*1000)/10+'%)']});
  /* second 401(k): funds held with value and share; performance needs cost basis or statements, which this account does not have yet */
  if(ah){const hv=ah.filter(h=>h.account===AN.hi);const tot=d3.sum(hv,d=>d.value);
    const hiT=$('inv-hi-tiles');if(hiT)tiles(hiT,[{label:'Balance',value:money(tot)},{label:'Funds held',value:String(hv.length)}]);
    const mx=Math.min(100,Math.max(10,d3.max(hv,d=>d.share_pct)*1.15));
    bullets($('inv-hi'),hv.map(d=>({label:d.holding,max:mx,bars:[[0,d.share_pct,C[1],1]],valueText:pctf(d.share_pct)+' ('+money(d.value)+')',tip:[d.holding,'Share of the account '+pctf(d.share_pct),'Value '+money(d.value)]})));}
}
function drawCostScatter(box,data){
  box.replaceChildren();const W=box.clientWidth;if(!W||!data.length)return;const tip=mkTip(box);
  const H=W<560?300:340,mg={l:50,r:14,t:14,b:42};
  const lo=Math.min(d3.min(data,d=>d.cost_basis),d3.min(data,d=>d.value))*0.7,hi=Math.max(d3.max(data,d=>d.cost_basis),d3.max(data,d=>d.value))*1.4;
  const x=d3.scaleLog([lo,hi],[mg.l,W-mg.r]),y=d3.scaleLog([lo,hi],[H-mg.b,mg.t]);
  const svg=mkSvg(box,W,H,'Scatter of cost basis against current value for each fund held, with a break-even diagonal');
  const tk=[100,300,1000,3000,10000,30000,100000].filter(v=>v>=lo&&v<=hi);
  hgrid(svg,tk,y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).tickValues(tk).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickValues(tk).tickFormat(v=>compact(v)).tickSize(4).tickPadding(6));
  svg.append('text').attr('x',(mg.l+W-mg.r)/2).attr('y',H-4).attr('text-anchor','middle').attr('font-size',11).style('fill','var(--mo-muted)').text('Cost basis (what you paid)');
  svg.append('text').attr('transform',`translate(12 ${(mg.t+H-mg.b)/2}) rotate(-90)`).attr('text-anchor','middle').attr('font-size',11).style('fill','var(--mo-muted)').text('Value now');
  svg.append('line').attr('x1',x(lo)).attr('y1',y(lo)).attr('x2',x(hi)).attr('y2',y(hi)).attr('stroke','var(--mo-muted)').attr('stroke-width',1.2);
  svg.append('text').attr('x',W-mg.r-6).attr('y',H-mg.b-8).attr('text-anchor','end').attr('font-size',11).style('fill','var(--mo-muted)').text('Diagonal line: value equals cost');
  const pts=data.map(d=>({...d,px:x(d.cost_basis),py:y(d.value)}));
  const dots=svg.append('g').selectAll('circle').data(pts).join('circle').attr('cx',d=>d.px).attr('cy',d=>d.py).attr('r',7).attr('fill',d=>classColor(d.asset_class)).attr('stroke','var(--mo-card)').attr('stroke-width',2);
  [...pts].sort((a,b)=>b.value-a.value).slice(0,3).forEach(d=>svg.append('text').attr('class','mo-halo').attr('x',d.px-10).attr('y',d.py+(d.gain_loss>=0?-8:4)).attr('text-anchor','end').attr('font-size',10).style('fill','var(--mo-fg)').text(d.holding.length>18?d.holding.slice(0,17)+'.':d.holding));
  hoverLayer(svg,pts,mg.l,mg.t,W-mg.l-mg.r,H-mg.t-mg.b,(p,ev)=>{dots.attr('r',d=>d===p?9:7);tip.show(ev,[p.holding,{t:'Cost basis '+money(p.cost_basis),c:classColor(p.asset_class)},'Value now '+money(p.value),(p.gain_loss>=0?'Gain ':'Loss ')+money(Math.abs(p.gain_loss))+' ('+(p.return_pct>0?'+':'')+p.return_pct+'%)']);},()=>{dots.attr('r',7);tip.hide();},36);
  box.append(legendEl([...new Set(data.map(d=>d.asset_class))].map(c=>({label:c,color:classColor(c)}))));
}
function drawGrowthLines(box,data){
  box.replaceChildren();const W=box.clientWidth;if(!W)return;const tip=mkTip(box);const narrow=W<560;
  const funds=d3.group(data,d=>d.fund);const order=[...new Set(data.sort((a,b)=>a.order-b.order).map(d=>d.point))];
  const fin=[...funds].map(([f,rs])=>({f,rs:rs.sort((a,b)=>a.order-b.order),last:rs[rs.length-1].return_pct})).sort((a,b)=>b.last-a.last);
  const best=fin.slice(0,3),worst=fin.slice(-3);const colMap=new Map();[...best,...worst].forEach((o,i)=>colMap.set(o.f,C[i]));
  const H=narrow?300:340,mg={l:42,r:narrow?10:130,t:14,b:30};
  const x=d3.scalePoint(order,[mg.l+8,W-mg.r]);
  const ymin=Math.min(0,d3.min(fin,o=>d3.min(o.rs,r=>r.return_pct))),ymax=Math.max(0,d3.max(fin,o=>d3.max(o.rs,r=>r.return_pct)));
  const y=d3.scaleLinear([ymin-2,ymax+2],[H-mg.b,mg.t]).nice();
  const svg=mkSvg(box,W,H,'Return on cost over time for each holding');
  hgrid(svg,y.ticks(5),y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(v=>v+'%').tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickSize(4).tickPadding(6));
  svg.append('line').attr('x1',mg.l).attr('x2',W-mg.r).attr('y1',y(0)).attr('y2',y(0)).attr('stroke','var(--mo-muted)').attr('stroke-width',1);
  const ln=d3.line().x(d=>x(d.point)).y(d=>y(d.return_pct));
  [...fin].reverse().forEach(o=>{const c=colMap.get(o.f);svg.append('path').attr('d',ln(o.rs)).attr('fill','none').attr('stroke',c||'var(--mo-muted)').attr('stroke-opacity',c?1:.4).attr('stroke-width',c?2.4:1.4).attr('stroke-linejoin','round');
    o.rs.forEach(r=>svg.append('circle').attr('cx',x(r.point)).attr('cy',y(r.return_pct)).attr('r',c?3.5:2.5).attr('fill',c||'var(--mo-muted)').attr('fill-opacity',c?1:.5).attr('stroke','var(--mo-card)').attr('stroke-width',1.5));});
  if(!narrow){const ends=[...best,...worst].map(o=>({o,ty:y(o.last)})).sort((a,b)=>a.ty-b.ty);for(let i=1;i<ends.length;i++)if(ends[i].ty-ends[i-1].ty<13)ends[i].ty=ends[i-1].ty+13;
    ends.forEach(e=>svg.append('text').attr('x',W-mg.r+6).attr('y',e.ty).attr('dy','0.32em').attr('font-size',10.5).style('fill','var(--mo-fg)').text((e.o.f.length>16?e.o.f.slice(0,15)+'.':e.o.f)+' '+(e.o.last>0?'+':'')+e.o.last+'%'));}
  const hit=svg.append('rect').attr('x',mg.l).attr('y',mg.t).attr('width',W-mg.l-mg.r+10).attr('height',H-mg.t-mg.b).attr('fill','transparent');
  hit.on('pointermove',ev=>{const [mx]=d3.pointer(ev,svg.node());const pt=order.reduce((a,b)=>Math.abs(x(b)-mx)<Math.abs(x(a)-mx)?b:a);
    const get=o=>o.rs.find(r=>r.point===pt);const lines=[pt==='Avg cost'?'At average cost':'Export of '+pt];
    [...best,...worst].forEach(o=>{const r=get(o);if(r)lines.push({t:o.f+': '+(r.return_pct>0?'+':'')+r.return_pct+'%',c:colMap.get(o.f)});});
    const others=fin.filter(o=>!colMap.has(o.f)).map(get).filter(Boolean).map(r=>r.return_pct);if(others.length)lines.push('Other '+others.length+' funds: '+d3.min(others)+'% to '+d3.max(others)+'%');tip.show(ev,lines);}).on('pointerleave',()=>tip.hide());
  box.append(legendEl([...best,...worst].map(o=>({label:o.f,color:colMap.get(o.f)})).concat([{label:'Other funds',color:'var(--mo-muted)',op:.5}])));
}
function drawSlope(box,data){
  box.replaceChildren();const W=box.clientWidth;if(!W)return;const tip=mkTip(box);const narrow=W<560;
  const H=narrow?300:320,mg={l:46,r:narrow?96:150,t:14,b:36};
  const idx=data.map(d=>({...d,end_idx:100+d.growth_pct}));
  const sd=d3.min(data,d=>d.start_date),ed=d3.max(data,d=>d.end_date);const L0=fdy(sd).replace(/ \d+,/,''),L1=fdy(ed).replace(/ \d+,/,'');
  const x=d3.scalePoint([L0,L1],[mg.l+20,W-mg.r]);
  const y=d3.scaleLinear([Math.min(70,d3.min(idx,d=>d.end_idx)-5),d3.max(idx,d=>d.end_idx)+8],[H-mg.b,mg.t]).nice();
  const svg=mkSvg(box,W,H,'Fund price growth since '+L0+', indexed to 100');
  hgrid(svg,y.ticks(5),y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(5).tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickSize(4).tickPadding(6));
  const ends=idx.map((d,i)=>({d,i,ty:y(d.end_idx)})).sort((a,b)=>a.ty-b.ty);for(let i=1;i<ends.length;i++)if(ends[i].ty-ends[i-1].ty<13)ends[i].ty=ends[i-1].ty+13;
  idx.forEach((d,i)=>{const c=C[i%C.length];
    svg.append('line').attr('x1',x(L0)).attr('x2',x(L1)).attr('y1',y(100)).attr('y2',y(d.end_idx)).attr('stroke',c).attr('stroke-width',2.4).attr('stroke-linecap','round');
    svg.append('circle').attr('cx',x(L0)).attr('cy',y(100)).attr('r',3.5).attr('fill',c);svg.append('circle').attr('cx',x(L1)).attr('cy',y(d.end_idx)).attr('r',4).attr('fill',c).attr('stroke','var(--mo-card)').attr('stroke-width',2);
    svg.append('line').attr('x1',x(L0)).attr('x2',x(L1)).attr('y1',y(100)).attr('y2',y(d.end_idx)).attr('stroke','transparent').attr('stroke-width',16)
      .on('pointermove',ev=>tip.show(ev,[d.fund,{t:'Price '+d.start_price+' to '+d.end_price,c:c},(d.growth_pct>0?'+':'')+d.growth_pct+'% in total, about '+d.annualized_pct+'% a year',d.note||'']
        .filter(Boolean))).on('pointerleave',()=>tip.hide());});
  ends.forEach(e=>svg.append('text').attr('x',W-mg.r+8).attr('y',e.ty).attr('dy','0.32em').attr('font-size',10.5).style('fill','var(--mo-fg)').text((narrow?e.d.fund.slice(0,10):e.d.fund.length>18?e.d.fund.slice(0,17)+'.':e.d.fund)+' '+(e.d.growth_pct>0?'+':'')+Math.round(e.d.growth_pct)+'%'));
  svg.append('text').attr('x',mg.l).attr('y',mg.t-2).attr('font-size',10).style('fill','var(--mo-muted)').text('Price index, first statement = 100');
}

/* ---------- Retirement tab ---------- */
function drawRetTab(){
  const a=rows('age60_calc'),nd=rows('need_calc'),cc=rows('contrib_calc');
  if(a&&nd&&cc){const x=a[0];const k=cc[0];
    tiles($('ret-tiles'),[{label:'Short of the '+compact(x.goal_low)+' low goal today',value:money(x.gap_now)},{label:'Extra per month to max every account',value:money(x.extra_month)},
      {label:'401(k) per paycheck now',value:money(k.per_paycheck_now)},{label:'Per paycheck to max the 401(k)',value:money(k.per_paycheck_max)},{label:'Total saving per year to reach the low goal',value:money(nd[0].need_7_annual)}]);}
  drawRetire();
}

/* ---------- Net worth and debt ---------- */
const DEBT_COL=l=>isCard(l)?(isClosed(l)?'#1d6f85':C[6]):({Mortgage:C[0],HELOC:C[1],Personal:C[2],Auto:C[3],Tax:C[4],Support:C[5]})[l.type]||C[7%C.length];
const ASSET_COL=t=>({Retirement:C[2],'Real estate':C[0],Vehicle:C[4],Cash:C[6],HSA:C[3]})[t]||C[7];
function retTile(nw){const hist=rows('acct_a_hist');const hd=hist&&hist.length>1?deltaOf(hist[hist.length-1].value,hist[0].value):null;
  return {label:'Retirement accounts',value:money(nwItem(nw,'Retirement accounts')),spark:hist&&hist.length>1?hist.map(h=>h.value):null,delta:hd&&Object.assign(hd,{text:hd.text+' since '+fd(hist[0].date)}),color:C[0]};}
function drawNetWorth(){
  const nw=rows('nw_rows'),hc=rows('home_calc'),pc=rows('pending_calc'),dti=rows('dti_calc'),st=rows('nw_steps'),lb=rows('liabilities');
  if(nw&&hc&&pc&&dti&&st){const assets=st.find(s=>s.label==='Total assets').value;const nt=nwTrend();
    tiles($('nw-tiles'),[{hero:true,label:'Net worth, known items',value:money(nwItem(nw,'Net worth')),sub:'Retirement, house, truck, savings, checking and uninvested HSA',delta:nt.delta,spark:nt.spark},{label:'Total assets',value:money(assets)},{label:'Total debts',value:money(dti[0].total_balance)},retTile(nw),
      {label:'Cash, savings and checking',value:money(nwItem(nw,'Cash, savings and checking')),sub:cashSub()},
      {label:'HSA, uninvested',value:money(nwItem(nw,'HSA, uninvested')||0),sub:'Counted in net worth. Medical use only'},
      {label:'Debts missing a payment',value:String(dti[0].missing_payments),sub:dti[0].missing_payments?dti[0].missing_names.map(n=>{const l=(lb||[]).find(x=>x.name===n);return n+': '+(l&&l.rate_pct==null?'rate and minimum':'minimum payment')+' not added';}).join('; '):'Every debt has a payment'},
      {label:'Home equity',value:money(hc[0].equity),sub:'Loan to value '+pctf(hc[0].ltv_pct)+', first lien '+pctf(hc[0].first_lien_pct)},{label:'Net if sold',value:compact(hc[0].net_proceeds_low)+' to '+compact(hc[0].net_proceeds_high),sub:'After 6% to 8% selling costs'},
      {label:'Tax refunds pending',value:money(pc[0].pending_refunds),sub:'Not counted. '+money(pc[0].after_offset)+' left if the earlier balance is taken first'}]);
    try{missingReview(dti);}catch(e){console.error('draw missingReview: '+e.message);}
    waterfall($('nw-wf'),st,{up:C[0],down:C[1],label:'Waterfall from assets through each debt to net worth'});
    const ai=st.slice(0,st.findIndex(s=>s.label==='Total assets')).map(s=>({label:s.label,value:s.value,color:ASSET_COL(s.type)}));
    donut($('nw-assets'),ai,{center:[compact(assets),'assets'],label:'Assets by type'});
  }
  drawNWHistory();
  const hs=rows('house_split');
  if(hs){const col={Mortgage:C[0],HELOC:C[1],'Your equity':C[2]};const tot=d3.sum(hs,x=>x.amount);donut($('nw-house'),hs.map(x=>({label:x.part,value:x.amount,color:col[x.part]})),{center:[pctf(Math.round(hs.find(x=>x.part==='Your equity').amount/tot*1000)/10),'equity'],label:'House value split'});}
  if(hc){const h=hc[0];tiles($('house-tiles'),[{label:'Value (your estimate)',value:money(h.value)},{label:'Mortgage plus HELOC',value:money(h.balance)},{label:'Bought for',value:money(h.purchase_price)},{label:'Gain since purchase',value:money(h.gain_since_purchase)}]);}
  if(lb){
    donut($('debt-donut'),lb.filter(l=>l.balance>0).map(l=>({label:l.name,value:l.balance,color:DEBT_COL(l),rate:l.rate_pct})),{center:[compact(d3.sum(lb,l=>l.balance||0)),'owed'],label:'Debt balance by debt',tip:(d,t)=>[d.label,money(d.value)+' ('+Math.round(d.value/t*1000)/10+'%)',d.rate==null?'Rate not added':d.rate+'% rate']});
    donut($('debt-pay'),lb.filter(l=>l.monthly_payment>0).map(l=>({label:l.name,value:l.monthly_payment,color:DEBT_COL(l)})),{center:[money(Math.round(d3.sum(lb,l=>l.monthly_payment||0))),'per month'],label:'Monthly payment by debt',tip:(d,t)=>[d.label,money(d.value)+' per month ('+Math.round(d.value/t*1000)/10+'% of debt payments)']});
    drawBubble($('debt-bubble'),lb.filter(l=>l.balance>0&&l.rate_pct>0&&l.monthly_payment>0));
  }
  if(lb){const rk=lb.filter(l=>l.balance>0&&l.rate_pct>0).sort((a,b)=>b.rate_pct-a.rate_pct);let tx='';
    if(rk.length){tx=rk[0].name+' at '+rk[0].rate_pct+'% is the highest rate';if(rk.length>1)tx+=', and '+rk[1].name+' at '+rk[1].rate_pct+'% is second';tx+='. ';
      const cd=rk.filter(l=>openCard(l)),ln=rk.filter(l=>!openCard(l));
      if(cd.length&&ln.length&&openCard(rk[0]))tx+='A card costs no interest when the statement balance is paid in full by the due date, so the highest rate you are paying on a loan is '+ln[0].name+' at '+ln[0].rate_pct+'%, where extra payments save the most interest.';
      else tx+='Extra payments on the highest rate save the most interest.';}
    $('bubble-rank').textContent=tx;}
  if(lb){const off=lb.filter(l=>l.balance>0&&l.type!=='Medical'&&!(l.rate_pct>0&&l.monthly_payment>0)).map(l=>l.name+' ('+[l.rate_pct==null?'rate':null,l.monthly_payment==null?'payment':null].filter(Boolean).join(' and ')+' not added)');
    $('bubble-off').textContent=off.length?'Left off because a rate or payment is not added: '+off.join(', ')+'.':'';}
  {const pc=$('debt-pay-chips');if(pc){pc.replaceChildren();const dti0=(rows('dti_calc')||[])[0];if(dti0&&dti0.missing_payments)pc.append(aboutChip(dti0.missing_payments+(dti0.missing_payments===1?' debt has':' debts have')+' no payment, total is a floor','warn'));}}
  drawPayoff();drawDTI();
}
function drawNWHistory(){
  const box=$('nw-hist');box.replaceChildren();const h=rows('networth_history');const W=box.clientWidth;if(!h||!W)return;const tip=mkTip(box);
  const data=[...h].sort((a,b)=>a.date<b.date?-1:1).map(d=>({...d,t:new Date(d.date+'T00:00:00')}));
  const H=220,mg={l:56,r:16,t:16,b:30};
  const t0=data[0].t,t1=data.length>1?data[data.length-1].t:new Date(+t0+30*86400000);
  const few=data.length<3;
  const x=few?d3.scalePoint(data.map(d=>d.date),[mg.l+50,W-mg.r-50]):d3.scaleTime([t0,t1],[mg.l,W-mg.r]);
  const xp=d=>few?x(d.date):x(d.t);
  const lo=d3.min(data,d=>d.net_worth),hi=d3.max(data,d=>d.net_worth);const pad=Math.max(5000,(hi-lo)*.2);
  const y=d3.scaleLinear([Math.max(0,lo-pad),hi+pad],[H-mg.b,mg.t]).nice();
  const xpN=data.filter(d=>d.basis==='expected').length;/* an expected point is not a bank reading: said in the chart name and its readout */
  const svg=mkSvg(box,W,H,'Net worth over time'+(xpN?'. '+(xpN===1?'One point is':xpN+' points are')+' expected from confirmed events, not a bank reading':''));
  hgrid(svg,y.ticks(4),y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(4).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(few?d3.axisBottom(x).tickFormat(fd).tickSize(4).tickPadding(6):d3.axisBottom(x).ticks(4).tickSize(4).tickPadding(6));
  if(!few){const ar=d3.area().x(xp).y0(y(y.domain()[0])).y1(d=>y(d.net_worth)).curve(d3.curveMonotoneX);svg.append('path').attr('d',ar(data)).attr('fill',C[0]).attr('opacity',.18);
    svg.append('path').attr('d',d3.line().x(xp).y(d=>y(d.net_worth)).curve(d3.curveMonotoneX)(data)).attr('fill','none').attr('stroke',C[0]).attr('stroke-width',2.5);}
  svg.append('g').selectAll('circle').data(data).join('circle').attr('cx',xp).attr('cy',d=>y(d.net_worth)).attr('r',5).attr('fill',C[0]).attr('stroke','var(--mo-card)').attr('stroke-width',2);
  const last=data[data.length-1];(few?data:[last]).forEach(d=>svg.append('text').attr('class','mo-halo').attr('x',few?xp(d):xp(d)+10).attr('y',y(d.net_worth)-12).attr('text-anchor',few?'middle':'start').attr('font-size',12).style('fill','var(--mo-fg)').text(money(d.net_worth)));
  const pts=data.map(d=>({...d,px:xp(d),py:y(d.net_worth)}));
  hoverLayer(svg,pts,mg.l,mg.t,W-mg.l-mg.r,H-mg.t-mg.b,(p,ev)=>tip.show(ev,[p.date,'Net worth '+money(p.net_worth),'Assets '+money(p.assets),'Debts '+money(p.debts)].concat(p.basis==='expected'?['Expected, not a bank reading']:[])),()=>tip.hide(),60);
  $('nw-hist-note').textContent=data.length>2?'Net worth at the end of each month you recorded, known items only. Hover a point for assets and debts.':(data.length>1?'Dots only, no line, until there are three history rows. '+last.note+' Hover a point for assets and debts.':'This is the first point, '+last.date+'. A line is drawn once there are three history rows.');
}
function drawBubble(box,data){
  box.replaceChildren();const W=box.clientWidth;if(!W||!data.length)return;const tip=mkTip(box);
  const H=W<560?300:320,mg={l:44,r:16,t:20,b:44};
  const x=d3.scaleLog([Math.min(1000,d3.min(data,d=>d.balance)*0.5),d3.max(data,d=>d.balance)*2],[mg.l+10,W-mg.r]);
  const y=d3.scaleLinear([0,Math.ceil(d3.max(data,d=>d.rate_pct)*1.15)],[H-mg.b,mg.t]).nice();
  const r=d3.scaleSqrt([0,d3.max(data,d=>d.monthly_payment)],[0,24]);
  const svg=mkSvg(box,W,H,'Bubble chart of interest rate against balance for each debt, sized by monthly payment');
  hgrid(svg,y.ticks(5),y,mg.l,W-mg.r);
  const tk=[1000,3000,10000,30000,100000,300000].filter(v=>v>=x.domain()[0]&&v<=x.domain()[1]);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(v=>v+'%').tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickValues(tk).tickFormat(v=>compact(v)).tickSize(4).tickPadding(6));
  svg.append('text').attr('x',(mg.l+W-mg.r)/2).attr('y',H-4).attr('text-anchor','middle').attr('font-size',11).style('fill','var(--mo-muted)').text('Balance owed');
  svg.append('text').attr('x',mg.l+12).attr('y',mg.t+2).attr('font-size',10.5).style('fill','var(--mo-muted)').text('Higher rate, smaller balance: pay down first');
  const pts=data.map(d=>({...d,px:x(d.balance),py:y(d.rate_pct)}));
  const cs=svg.append('g').selectAll('circle').data(pts).join('circle').attr('cx',d=>d.px).attr('cy',d=>d.py).attr('r',d=>Math.max(6,r(d.monthly_payment))).attr('fill',d=>DEBT_COL(d)).attr('fill-opacity',.8).attr('stroke','var(--mo-card)').attr('stroke-width',2);
  svg.append('g').selectAll('text').data(pts).join('text').attr('class','mo-halo').attr('x',d=>d.px).attr('y',d=>d.py-Math.max(6,r(d.monthly_payment))-5).attr('text-anchor','middle').attr('font-size',10.5).style('fill','var(--mo-fg)').style('pointer-events','none').text(d=>d.name.length>16?d.name.split(' ')[0]:d.name);
  hoverLayer(svg,pts,mg.l,mg.t,W-mg.l-mg.r,H-mg.t-mg.b,(p,ev)=>{cs.attr('stroke-width',d=>d===p?3.5:2);tip.show(ev,[p.name,{t:p.rate_pct+'% rate',c:DEBT_COL(p)},money(p.balance)+' owed',money(p.monthly_payment)+' per month']);},()=>{cs.attr('stroke-width',2);tip.hide();},60);
}
function drawPayoff(){
  const box=$('debt-payoff');box.replaceChildren();const pr=rows('payoff_calc');const W=box.clientWidth;if(!pr||!W)return;const tip=mkTip(box);
  let ds=pr.filter(d=>d.balances.length>1);if(state.poView==='small')ds=ds.filter(d=>d.type!=='Mortgage');if(!ds.length)return;
  const M=d3.max(ds,d=>d.balances.length-1);const months=d3.range(M+1);
  const rowsM=months.map(mi=>{const o={m:mi};ds.forEach(d=>{o[d.name]=mi<d.balances.length?d.balances[mi]:0;});return o;});
  const keys=ds.map(d=>d.name);const stack=d3.stack().keys(keys)(rowsM);
  const H=W<560?300:320,mg={l:52,r:12,t:12,b:32};
  const x=d3.scaleLinear([0,M],[mg.l,W-mg.r]);const ymax=d3.max(stack[stack.length-1],d=>d[1]);const y=d3.scaleLinear([0,ymax*1.04],[H-mg.b,mg.t]).nice();
  const svg=mkSvg(box,W,H,'Stacked area of debt balances over time as scheduled payments continue');
  hgrid(svg,y.ticks(5),y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  const start=new Date(ds[0].start_date+'T00:00:00Z');/* index 0 is today's balance; payment i is made in the current month plus i - 1 (the payoff plan's start) */
  const lab=mi=>{if(!mi)return 'Now';const d=new Date(start);d.setUTCMonth(d.getUTCMonth()+mi-1);return d.toLocaleString('en-US',{month:'short',year:'numeric',timeZone:'UTC'});};
  const yrStep=M>200?5:M>100?2:1;const xt=d3.range(0,M+1,12*yrStep);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickValues(xt).tickFormat(mi=>String(start.getUTCFullYear()+Math.round(mi/12))).tickSize(4).tickPadding(6));
  const colOf=n=>DEBT_COL(ds.find(d=>d.name===n));
  const ar=d3.area().x(d=>x(d.data.m)).y0(d=>y(d[0])).y1(d=>y(d[1]));
  stack.forEach(s=>svg.append('path').attr('d',ar(s)).attr('fill',colOf(s.key)).attr('opacity',.85).attr('stroke','var(--mo-card)').attr('stroke-width',1));
  const cross=svg.append('line').attr('y1',mg.t).attr('y2',H-mg.b).attr('stroke','var(--mo-fg)').attr('stroke-width',1).style('display','none');
  svg.append('rect').attr('x',mg.l).attr('y',mg.t).attr('width',W-mg.l-mg.r).attr('height',H-mg.t-mg.b).attr('fill','transparent')
    .on('pointermove',ev=>{const [mx]=d3.pointer(ev,svg.node());const mi=Math.max(0,Math.min(M,Math.round(x.invert(mx))));cross.style('display',null).attr('x1',x(mi)).attr('x2',x(mi));
      const lines=[lab(mi)];let tot=0;[...ds].reverse().forEach(d=>{const v=rowsM[mi][d.name];tot+=v;if(v>0)lines.push({t:d.name+': '+money(Math.round(v)),c:DEBT_COL(d)});});lines.push('Total owed '+money(Math.round(tot)));tip.show(ev,lines);})
    .on('pointerleave',()=>{cross.style('display','none');tip.hide();});
  box.append(legendEl(ds.map(d=>({label:d.name,color:DEBT_COL(d)}))));
  const tb=document.createElement('table');tb.className='mo-table';tb.style.marginTop='.5rem';
  {const th=document.createElement('thead');const hr=document.createElement('tr');[['Debt',null],['Rate','num'],['Payment','num'],['Paid off','num'],['Interest still to pay','num mo-hide-s']].forEach(([t,k])=>hr.append(el('th',k,t)));th.append(hr);tb.append(th);}
  const bd=document.createElement('tbody');
  pr.forEach(d=>{const tr=document.createElement('tr');[[d.name,'key'],[d.rate_pct==null?(d.type==='Medical'?'no interest':'rate not added'):d.rate_pct+'%','num'],[d.payment==null?(d.type==='Medical'?'none set yet':'not added'):money(d.payment),'num'],[d.months==null?(d.type==='Medical'?'ask for a payment plan':d.payoff):lab(d.months),'num'],[d.interest_total==null||d.rate_pct==null?'not modeled':money(d.interest_total),'num mo-hide-s']].forEach(([t,c])=>{const td=document.createElement('td');td.className=c;td.textContent=t;tr.append(td);});bd.append(tr);});
  tb.append(bd);const sc=el('div','mo-scroll');sc.append(tb);const th2=$('po-tbl-host');if(th2){th2.replaceChildren(sc);}else box.append(sc);
  {const off=pr.filter(d=>d.balances.length<=1).map(d=>d.name);const ta=$('tl-off');if(ta)ta.textContent=off.length?'Not charted, no payment entered: '+off.join(', ')+'.':'';}
}
function drawDTI(){
  const box=$('debt-dti');const bm=rows('dti_benchmarks'),dc=rows('dti_calc');if(!bm||!dc)return;
  const classic=bm.find(b=>b.standard==='Classic guideline')||bm.find(b=>b.front_end_pct!=null&&b.back_end_pct!=null),conv=bm.find(b=>b.standard==='Conventional')||[...bm].filter(b=>b.back_end_pct!=null).sort((a,b)=>a.back_end_pct-b.back_end_pct)[1];const d=dc[0];const mx=60;
  if(!classic||!conv){box.replaceChildren(needsEl('Needs: lender reference rows (dti_benchmarks)'));return;}
  const status=(v,a,b)=>v<=a?'within the classic guideline':v<=b?'above the guideline, under the conventional ceiling':'past typical ceilings';
  bullets(box,[
    {label:'Total debt ratio',sub:'All payments over gross pay',max:mx,zones:[[0,classic.back_end_pct,'var(--mo-ok)',.35],[classic.back_end_pct,conv.back_end_pct,'var(--mo-warn)',.35],[conv.back_end_pct,mx,'var(--mo-bad)',.3]],bars:[[0,d.back_end_pct,'var(--mo-fg)',.9]],valueText:pctf(d.back_end_pct)+', '+status(d.back_end_pct,classic.back_end_pct,conv.back_end_pct),
     tip:['Total debt ratio '+pctf(d.back_end_pct),money(d.debt_payments)+' of debt payments over '+money(d.base_monthly)+' gross a month','Classic guideline '+classic.back_end_pct+'%, conventional ceiling '+conv.back_end_pct+'%','With bonus and equity: '+pctf(d.back_end_with_variable_pct),d.missing_payments?d.missing_payments+' debts still missing a payment. At 4% of card balances: '+pctf(d.back_end_est_pct):'No debts missing a payment']},
    {label:'Housing ratio',sub:'Mortgage and HELOC over gross pay',max:mx,zones:[[0,classic.front_end_pct,'var(--mo-ok)',.35],[classic.front_end_pct,mx,'var(--mo-bad)',.3]],bars:[[0,d.front_end_pct,'var(--mo-fg)',.9]],valueText:pctf(d.front_end_pct)+', '+(d.front_end_pct<=classic.front_end_pct?'within the classic guideline':'past the classic guideline'),
     tip:['Housing ratio '+pctf(d.front_end_pct),money(d.housing_payments)+' of mortgage and HELOC payments','Classic guideline '+classic.front_end_pct+'%']}]
    .concat(d.rent_monthly>0&&!d.rent_in_standard?[{label:'Total debt ratio with rent',sub:'Debt payments plus '+money(d.rent_monthly)+' rent over gross pay',max:mx,zones:[[0,classic.back_end_pct,'var(--mo-ok)',.35],[classic.back_end_pct,conv.back_end_pct,'var(--mo-warn)',.35],[conv.back_end_pct,mx,'var(--mo-bad)',.3]],bars:[[0,d.back_end_with_rent_pct,'var(--mo-fg)',.9]],valueText:pctf(d.back_end_with_rent_pct)+', '+status(d.back_end_with_rent_pct,classic.back_end_pct,conv.back_end_pct),
     tip:['Total debt ratio with rent '+pctf(d.back_end_with_rent_pct),money(d.debt_payments)+' of debt payments plus '+money(d.rent_monthly)+' rent ('+d.rent_names.join(', ')+') over '+money(d.base_monthly)+' gross a month','Not in the standard ratio while a mortgage is on file']}]:[]));
  {const os=$('dti-oblig');if(os)os.textContent='Total monthly obligations '+money2(d.obligations_monthly)+' a month, '+money2(d.obligations_annual)+' a year.';}
  {const ob=$('dti-oblig-note');if(ob)ob.textContent='Total monthly obligations '+money2(d.obligations_monthly)+' a month, '+money2(d.obligations_annual)+' a year: every monthly bill '+money2(d.obligations_bills)+(d.rent_monthly>0?' (rent '+money2(d.rent_monthly)+' included once)':'')+' plus debt payments entered '+money2(d.obligations_debts)+'.'+(d.missing_names&&d.missing_names.length?' Not counted until its payment is entered: '+d.missing_names.join(', ')+'.':'')+(d.rent_monthly>0?(d.rent_in_standard?' No mortgage is on file, so the rent is in the standard ratios above.':' The headline ratio leaves the rent out while a mortgage is on file; the line with rent shows it in.'):'');}
  const en=$('dti-est-long'),es=$('dti-est');
  if(es)es.textContent=d.missing_payments?d.missing_payments+(d.missing_payments===1?' debt has':' debts have')+' no payment entered, so the ratio leaves '+(d.missing_payments===1?'it':'them')+' out.'+(d.est_card_payment>0?' Estimate at 4% of card balances: '+pctf(d.back_end_est_pct)+'.':''):'';
  if(en){if(d.missing_payments&&d.est_card_payment>0){en.textContent='Without a minimum for '+d.missing_names.join(' and ')+' ('+money(d.est_card_balance)+' in card balances), the total ratio above leaves them out. An estimate at 4% of those card balances ('+money(d.est_card_payment)+' a month) would give a second figure: total debt ratio '+pctf(d.back_end_est_pct)+', '+status(d.back_end_est_pct,classic.back_end_pct,conv.back_end_pct)+'. Add the real minimums to replace the estimate.';}
    else if(d.missing_payments){en.textContent=d.missing_payments+' debts have no payment entered, so the ratio above leaves them out. A medical bill with no payment plan is not counted in the ratio at all.';}
    else en.textContent='';}
  $('dti-leg').replaceChildren(...legendEl([{label:'Within the classic guideline',color:'var(--mo-ok)',op:.5},{label:'Up to the conventional ceiling',color:'var(--mo-warn)',op:.5},{label:'Past typical ceilings',color:'var(--mo-bad)',op:.5},{label:'Your ratio (dark bar)',color:'var(--mo-fg)'}]).children);
}

/* ---------- Cash flow ---------- */
function drawPaycheck(){
  const pt=rows('paycheck_calc');if(pt)tiles($('pc-tiles'),[{label:'Take-home per paycheck',value:money(pt[0].take_home),sub:'As of '+pt[0].pay_date},{label:'Take-home per month',value:money(pt[0].take_home_month),sub:'Two paychecks'},{label:'Taxes withheld',value:pctf(pt[0].tax_rate_pct),sub:'Of gross pay'},{label:'Saved from each check',value:money(pt[0].saved_per_check),sub:'401(k) plus your HSA part'},{label:'Paychecks on file',value:String(pt[0].stub_count),sub:'Too few to call a trend'}]);
  const pb=(rows('paystub_baseline')||[]).filter(x=>x.latest)[0];const pbx=$('pb-tiles');if(pbx){if(pb)tiles(pbx,[{label:'Tax rate so far',value:pctf(pb.tax_rate_pct),sub:'Year to date'},{label:'Kept as take-home',value:pctf(pb.take_home_pct),sub:'Year to date'},{label:'Saved so far',value:money(pb.saved_ytd),sub:pctf(pb.saved_pct)+' of gross'}]);else pbx.replaceChildren();}
  const box=$('pc-chart');box.replaceChildren();const s=rows('paystubs');const W=box.clientWidth;if(!s||!W)return;const tip=mkTip(box);
  const data=[...s].sort((a,b)=>a.pay_date<b.pay_date?-1:1);
  const keys=[['take_home_core','Take-home',C[0]],['federal_tax','Federal tax',C[1]],['state_tax','State tax',C[2]],['fica','Social Security and Medicare',C[3]],['k401_you','401(k)',C[4]],['hsa_you','HSA, your part',C[5]],['benefits','Health benefits',C[6]],['garnishment','Support withholding',C[7]]];
  const H=300,mg={l:56,r:16,t:16,b:44};
  const x=d3.scaleBand(data.map(d=>d.pay_date),[mg.l,W-mg.r]).padding(.22);
  const y=d3.scaleLinear([0,10000],[H-mg.b,mg.t]);
  const svg=mkSvg(box,W,H,'Each paycheck split into take-home, taxes and deductions');
  hgrid(svg,y.ticks(5),y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  const stack=d3.stack().keys(keys.map(k=>k[0]))(data);
  stack.forEach((ser,i)=>{svg.append('g').selectAll('rect').data(ser).join('rect').attr('x',(d,j)=>x(data[j].pay_date)).attr('width',x.bandwidth()).attr('y',d=>y(d[1])).attr('height',d=>Math.max(0,y(d[0])-y(d[1])-1)).attr('fill',keys[i][2]);});
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`).call(d3.axisBottom(x).tickSize(0).tickPadding(8).tickFormat(d=>d.slice(5).replace('-','/'))).selectAll('text').attr('font-size',10);
  const mark=(date,label)=>{const d=data.find(q=>q.pay_date>=date);if(!d)return;const xx=x(d.pay_date)-x.step()*x.paddingOuter()-x.step()*.11;svg.append('line').attr('x1',xx).attr('x2',xx).attr('y1',mg.t).attr('y2',H-mg.b).attr('stroke','var(--mo-fg)').attr('stroke-dasharray','4 3').attr('opacity',.7);svg.append('text').attr('class','mo-halo').attr('x',xx+4).attr('y',mg.t+10).attr('font-size',10).style('fill','var(--mo-fg)').text(label);};
  {const f=k=>{const s=data.find(q=>q[k]>0);return s&&data.indexOf(s)>0?s.pay_date:null;};const a=f('k401_you'),g=f('garnishment');if(a)mark(a,'401(k) starts');if(g)mark(g,'Withholding starts');}
  const hits=data.map(d=>({d,px:x(d.pay_date)+x.bandwidth()/2,py:H/2}));
  svg.append('rect').attr('x',mg.l).attr('y',mg.t).attr('width',W-mg.l-mg.r).attr('height',H-mg.t-mg.b).attr('fill','transparent').on('pointermove',function(ev){const [mx]=d3.pointer(ev,svg.node());let b=hits[0];hits.forEach(h=>{if(Math.abs(h.px-mx)<Math.abs(b.px-mx))b=h;});const d=b.d;tip.show(ev,[d.pay_date+' (gross '+money(d.gross)+')'].concat(keys.filter(k=>d[k[0]]>0).map(k=>({c:k[2],t:k[1]+' '+money(d[k[0]])})),['Employer HSA '+money(d.hsa_employer)+' on top','Deposited '+money(d.net_pay)+(d.other_additions?' (includes '+money(d.other_additions)+' other)':'')]));}).on('pointerleave',()=>tip.hide());
  box.append(legendEl(keys.map(k=>({label:k[1],color:k[2]}))));
}
function drawCash(){
  drawPaycheck();drawDrift();drawGoals();
  const bc=rows('bills_calc'),ps=rows('pay_split'),dc=rows('dti_calc');
  if(bc&&ps){const b=bc[0],rw=one('runway_calc'),TM=rw&&rw.this_month,bt=one('bills_takehome')||{};aboutSync();const th=bt.take_home_month==null?null:bt.take_home_month;
    if(th==null){const tb=$('cf-tiles');tiles(tb,[{label:'Take-home pay per month',value:calcWhy(['bills_calc'],'Needs: a pay stub and paychecks per year')},{label:'Bills per month',value:money(b.total_monthly),sub:money(b.total_annual)+' a year'}]);}
    else{const tl=[{label:'Take-home pay per month',value:money(th),sub:'Estimate'},{label:'Debt payments',value:money(ps[0].amount),sub:pctf(Math.round(ps[0].amount/th*1000)/10)+' of take-home'+(dc&&dc[0].missing_payments?', '+dc[0].missing_payments+' not counted':'')},{label:'Bills per month',value:money(b.total_monthly),sub:pctf(bt.pct_of_take_home)+' of take-home, '+money(b.total_annual)+' a year'}];
      if(TM&&TM.left!=null)tl.push({label:'Left over this month',value:money(TM.left),sub:'Before everyday spending'});
      tiles($('cf-tiles'),tl);srcTip($('cf-tiles').querySelector('.mo-tv'),'Source: the latest pay stub take-home times paychecks per year, divided by 12. Details in About this');}
    const ca=$('cf-about');if(ca){ca.replaceChildren();const ab=[];
      ab.push(th==null?'Take-home per month needs a pay stub and paychecks per year.':'Take-home pay per month is the take-home on the latest pay stub ('+money2(bt.take_home_per_paycheck)+') times '+bt.paychecks_per_year+' paychecks a year, divided by 12. It is an estimate. The shares above are of take-home. The debt ratio and the cash flow chart on Pay use gross pay ('+money(bt.gross_monthly)+' a month).');
      ab.push('Gross split, for reference: debt payments '+money(ps[0].amount)+' ('+pctf(Math.round(ps[0].amount/ps[0].base*1000)/10)+' of gross), bills '+money(b.total_monthly)+' ('+pctf(b.pct_of_gross)+' of gross), saving from pay '+money(ps[2].amount)+' ('+pctf(Math.round(ps[2].amount/ps[0].base*1000)/10)+' of gross), taxes and everything else '+money(ps[3].amount)+' (what is left of gross pay).');
      if(TM&&TM.left!=null)ab.push('Left over this month = take-home '+money2(TM.take_home)+' minus bills '+money2(TM.bills)+' minus debt payments '+money2(TM.debt)+' (mortgage included).'+(TM.withheld?' '+money2(TM.withheld)+' of support is withheld from pay before take-home, so it is not counted again.':'')+' Everyday spending is not measured yet, so left over is before it. Needs: bank and card exports.');
      ca.append(aboutFold('cf',ab));}}
  const pf=rows('pay_flow');
  if(pf){const cm={debt:C[1],bills:C[2],save:C[0],rest:'var(--mo-muted)'};sankey($('cf-sankey'),pf,{color:c=>cm[c]||C[7],H:520,Hn:640,unit:' a month',label:'Where gross monthly pay goes'});
    $('cf-sankey').append(legendEl([{label:'Debt payments',color:C[1]},{label:'Bills',color:C[2]},{label:'Saving from pay',color:C[0]},{label:'Taxes and everything else',color:'var(--mo-muted)'}]));}
  const cat=rows('bills_cat');if(cat)donut($('cf-donut'),cat.map((x,i)=>({label:x.category,value:x.total,color:C[i%C.length]})),{center:[money(d3.sum(cat,x=>x.total)),'per month'],label:'Bills by category',tip:(d,t)=>[d.label,money(d.value)+' per month ('+Math.round(d.value/t*1000)/10+'%)',money(d.value*12)+' a year']});
  if(bc){const box=$('cf-ess');box.replaceChildren();const b=bc[0];const mt=el('div','mo-meter');const a1=document.createElement('i'),a2=document.createElement('i');a1.style.width=(b.essential_monthly/b.total_monthly*100)+'%';a1.style.background=C[0];a2.style.flex='1';a2.style.background=C[1];mt.append(a1,a2);
    const tip=mkTip(box);[[a1,'Essential',b.essential_monthly],[a2,'Optional',b.optional_monthly]].forEach(([n,l,v])=>{n.addEventListener('pointermove',ev=>tip.show(ev,[l,money(v)+' per month ('+Math.round(v/b.total_monthly*1000)/10+'%)']));n.addEventListener('pointerleave',()=>tip.hide());});
    box.append(mt);
    box.append(legendEl([{label:'Essential '+money(b.essential_monthly),color:C[0]},{label:'Optional '+money(b.optional_monthly),color:C[1]}]));mt.style.height='18px';mt.style.marginTop='.5rem';box.style.minHeight='0';}
}

/* ---------- Dollar drift ---------- */
function wrapLabel(t,cx,y,label,narrow,step){
  if(narrow){t.attr('text-anchor','end').attr('transform',`rotate(-40 ${cx+4} ${y-2})`).attr('x',cx+4).text(label.length>24?label.slice(0,23)+'...':label);return;}
  t.attr('text-anchor','middle');const maxc=Math.max(7,Math.floor(step/6.4));const words=label.split(' ');const lines=[];let cur='';
  words.forEach(w=>{if((cur+' '+w).trim().length>maxc&&cur){lines.push(cur);cur=w;}else cur=(cur+' '+w).trim();});if(cur)lines.push(cur);
  lines.slice(0,4).forEach((ln,k)=>t.append('tspan').attr('x',cx).attr('dy',k?'1.15em':0).text(ln));
}
function swatchSpan(kind,text){
  const s=el('span');const i=el('i','mo-sw');
  if(kind==='hatch'){i.style.background='repeating-linear-gradient(45deg,var(--mo-muted) 0 2px,transparent 2px 5px)';i.style.border='1px solid var(--mo-muted)';}
  else if(kind==='dash'){i.style.background='transparent';i.style.border='2px dashed var(--mo-warn)';}
  else i.style.background='var(--mo-fg)';
  s.append(i,document.createTextNode(text));return s;
}
function drawBridge(box,r){
  box.replaceChildren();
  if(!r){box.append(el('p','mo-note','No reporting period yet. Two reported balances for the same account make one.'));return;}
  const W=box.clientWidth;if(!W)return;const tip=mkTip(box);const narrow=W<560;
  const ok=r.status==='ok';
  const S=[{label:'Opening reported '+fd(r.from),kind:'total',state:'ok',value:r.opening,tip:[r.scope+' reported on '+fd(r.from),money(r.opening)]}];
  r.items.forEach(it=>S.push({label:(it.amount>0?'Plus ':'Minus ')+fd(it.date)+' '+it.label,kind:'delta',state:it.placed?'ok':'unplaced',value:it.amount,
    tip:[(it.amount>0?'Known inflow: ':'Known outflow: ')+it.label,F.signed(it.amount)].concat(it.placed?['Counted in the expected closing']:['Account not confirmed','Left out of the expected closing until you say which account'],it.stub?['Pay stub check: '+it.stub]:[])}));
  S.push({label:'Expected closing',kind:'total',state:ok?'ok':'needs',value:r.expected,tip:ok?['Expected closing',money(r.expected),'Opening plus inflows minus outflows']:['Expected closing','Needs: '+r.needs.join('; ')]});
  S.push({label:'Reported closing '+fd(r.to),kind:'total',state:'ok',value:r.reported,tip:[r.scope+' reported on '+fd(r.to),money(r.reported)]});
  S.push({label:'Dollar drift',kind:'drift',state:ok?'ok':'needs',value:r.drift,tip:ok?['Dollar drift',signed2(r.drift),'Reported closing minus expected closing']:['Dollar drift','Needs: '+r.needs.join('; '),'No number is shown because nothing is guessed']});
  let cum=r.opening;
  S.forEach((s,i)=>{
    if(s.kind==='delta'){s.y0=cum;s.y1=cum+s.value;cum=s.y1;}
    else if(s.label==='Expected closing'){s.y0=0;s.y1=ok?s.value:null;}
    else if(s.kind==='drift'){s.y0=ok?r.expected:0;s.y1=ok?r.reported:null;}
    else{s.y0=0;s.y1=s.value;}
  });
  const tops=S.flatMap(s=>[s.y0,s.y1]).filter(v=>v!=null);
  const ymax=Math.max(...tops,1)*1.14;
  const m={t:30,r:8,b:narrow?110:84,l:narrow?50:60};const H=narrow?390:350;
  const x=d3.scaleBand(d3.range(S.length),[m.l,W-m.r]).paddingInner(.22).paddingOuter(.1);
  const y=d3.scaleLinear([0,ymax],[H-m.b,m.t]).nice();
  const ph=(y(0)-y(y.domain()[1]))*.16;
  const svg=mkSvg(box,W,H,'Bridge from the opening reported balance to the reported closing balance, with the dollar drift');
  const df=svg.append('defs');const pat=df.append('pattern').attr('id','dr-hatch').attr('width',6).attr('height',6).attr('patternUnits','userSpaceOnUse').attr('patternTransform','rotate(45)');
  pat.append('line').attr('x1',0).attr('y1',0).attr('x2',0).attr('y2',6).attr('stroke-width',2).style('stroke','var(--mo-muted)');
  hgrid(svg,y.ticks(5),y,m.l,W-m.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  S.forEach((s,i)=>{
    const bx=x(i),bw=x.bandwidth();let top,h;
    if(s.y1==null){top=y(0)-ph;h=ph;}else{top=Math.min(y(s.y0),y(s.y1));h=Math.max(2,Math.abs(y(s.y0)-y(s.y1)));}
    const r0=svg.append('rect').attr('x',bx).attr('y',top).attr('width',bw).attr('height',h).attr('rx',2);
    if(s.state==='ok'){
      const col=s.kind==='total'?'var(--mo-fg)':s.kind==='drift'?(Math.abs(s.value)<0.005?'var(--mo-ok)':'var(--mo-warn)'):s.value>=0?C[0]:C[1];
      r0.attr('fill',col).attr('opacity',s.kind==='total'?.85:1);
    }else if(s.state==='unplaced'){r0.attr('fill','url(#dr-hatch)').style('stroke','var(--mo-muted)').attr('stroke-width',1.5);}
    else{r0.attr('fill','none').style('stroke','var(--mo-warn)').attr('stroke-width',2).attr('stroke-dasharray','5 3');}
    const lbl=s.state==='needs'?'Needs':s.kind==='delta'?F.signed(s.value):s.kind==='drift'?signed2(s.value):money(s.value);
    svg.append('text').attr('class','mo-halo').attr('x',bx+bw/2).attr('y',top-5).attr('text-anchor','middle').attr('font-size',narrow?10:11).style('fill',s.state==='needs'?'var(--mo-warn)':'var(--mo-fg)').text(lbl);
    if(s.state==='unplaced'&&!narrow)svg.append('text').attr('class','mo-halo').attr('x',bx+bw/2).attr('y',top-18).attr('text-anchor','middle').attr('font-size',10).style('fill','var(--mo-muted)').text('account unconfirmed');
    const t=svg.append('text').attr('y',H-m.b+14).attr('font-size',narrow?10:11).style('fill','var(--mo-muted)');wrapLabel(t,bx+bw/2,H-m.b+14,s.label,narrow,x.step());
    r0.on('pointermove',ev=>tip.show(ev,s.tip)).on('pointerleave',()=>tip.hide());
  });
  box.append(el('div'));
  const lg=el('div','mo-legend');lg.style.marginTop='.5rem';lg.append(swatchSpan('solid','Calculated from your reported balances and confirmed events'),swatchSpan('hatch','Known amount, account unconfirmed (not in the calculation)'),swatchSpan('dash','Needs: cannot be calculated yet'));box.append(lg);
  $('dr-bridge-note').textContent=(ok?'Period '+fd(r.from)+' to '+fd(r.to)+' for '+r.scope+'. Drift is the reported closing minus the expected closing.':'Period '+fd(r.from)+' to '+fd(r.to)+' for '+r.scope+'. Needs: '+r.needs.join('; ')+'. The hatched bars are known amounts that cannot be placed in this account yet, so the expected closing and the dollar drift are left blank. Nothing is guessed.');
}
function drawDriftChart(box,pts){
  box.replaceChildren();const W=box.clientWidth;if(!W)return;const tip=mkTip(box);
  const n=pts.length;const H=250,mg={l:62,r:18,t:16,b:32};
  const dates=[...new Set(pts.map(p=>p.to))].sort();
  const x=d3.scalePoint(dates,[mg.l+30,W-mg.r-30]).padding(.5);
  const xp=p=>dates.length?(dates.length===1?(mg.l+W-mg.r)/2:x(p.to)):0;
  const vals=pts.map(p=>p.drift);const lo=Math.min(0,...vals),hi=Math.max(0,...vals);const pad=Math.max(100,(hi-lo)*.25);
  const y=d3.scaleLinear([lo-pad,hi+pad],[H-mg.b,mg.t]).nice();
  const svg=mkSvg(box,W,H,'Dollar drift over time with a zero baseline');
  hgrid(svg,y.ticks(4),y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(4).tickFormat(v=>(v<0?'-':v>0?'+':'')+compact(Math.abs(v))).tickSize(0).tickPadding(6));
  svg.append('line').attr('x1',mg.l).attr('x2',W-mg.r).attr('y1',y(0)).attr('y2',y(0)).attr('stroke','var(--mo-fg)').attr('stroke-width',1.5);
  svg.append('text').attr('class','mo-halo').attr('x',W-mg.r-2).attr('y',y(0)-5).attr('text-anchor','end').attr('font-size',10).style('fill','var(--mo-muted)').text('$0, calculation matches what you reported');
  if(dates.length){const ax=svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`);
    dates.forEach(d=>ax.append('text').attr('x',dates.length===1?(mg.l+W-mg.r)/2:x(d)).attr('y',16).attr('text-anchor','middle').text(fd(d)));}
  else svg.append('text').attr('x',(mg.l+W-mg.r)/2).attr('y',(y(0)+H-mg.b)/2).attr('text-anchor','middle').attr('font-size',12).style('fill','var(--mo-muted)').text(W<480?'No drift point yet':'No drift point yet. The first one appears once a period can be calculated.');
  const scopes=[...new Set(pts.map(p=>p.scope))];const col=s=>C[scopes.indexOf(s)%C.length];
  if(n>=3)scopes.forEach(s=>{const sp=pts.filter(p=>p.scope===s).sort((a,b)=>a.to<b.to?-1:1);if(sp.length>1)svg.append('path').attr('d',d3.line().x(xp).y(p=>y(p.drift))(sp)).attr('fill','none').attr('stroke',col(s)).attr('stroke-width',2.5);});
  const P=pts.map(p=>({...p,px:xp(p),py:y(p.drift)}));
  svg.append('g').selectAll('circle').data(P).join('circle').attr('cx',p=>p.px).attr('cy',p=>p.py).attr('r',5.5).attr('fill',p=>col(p.scope)).attr('stroke','var(--mo-card)').attr('stroke-width',2);
  svg.append('g').selectAll('text').data(P).join('text').attr('class','mo-halo').attr('x',p=>p.px).attr('y',p=>p.py-11).attr('text-anchor','middle').attr('font-size',11).style('fill','var(--mo-fg)').text(p=>signed2(p.drift));
  if(P.length)hoverLayer(svg,P,mg.l,mg.t,W-mg.l-mg.r,H-mg.t-mg.b,(p,ev)=>tip.show(ev,[p.scope+', '+fd(p.from)+' to '+fd(p.to),'Dollar drift '+signed2(p.drift),'Reported '+money(p.reported)+', expected '+money(p.expected)]),()=>tip.hide(),50);
  if(scopes.length>1)box.append(legendEl(scopes.map(s=>({label:s,color:col(s)}))));
  $('dr-chart-note').textContent=n>=3?'Dots are drift points, joined by a line within each account. Closer to the $0 line means the calculation is closer to what you reported.':n+' of 3 points needed to join the dots with a line. '+(n?'Every point that exists is shown as a dot.':'No point can be calculated yet, so the chart shows only the $0 line.');
}
function drawDrift(){
  const dr=rows('drift_calc'),bl=rows('balance_log'),ev=rows('cash_events');
  if(!dr||!bl||!ev)return;
  const ok=dr.filter(r=>r.status==='ok').sort((a,b)=>a.to<b.to?-1:1);
  const waiting=dr.filter(r=>r.status!=='ok');
  const latest=ok.length?ok[ok.length-1]:null;
  tiles($('dr-tiles'),[
    {label:'Latest dollar drift',value:latest?signed2(latest.drift):'Not calculated yet',sub:latest?latest.scope+', '+fd(latest.from)+' to '+fd(latest.to):'Waiting on the items listed below'},
    {label:'Drift points so far',value:ok.length+' of 3',sub:'3 are needed before a line joins the dots'},
    {label:'Periods waiting on you',value:String(waiting.length),sub:'Each one says what is missing'}]);
  const sn=$('dr-sentence');
  if(latest){const dv=latest.drift;sn.className='mo-take';sn.textContent=dv===0?'On '+fdy(latest.to)+', '+latest.scope+' matches known movements.':'On '+fdy(latest.to)+', '+latest.scope+' was reported '+money2(Math.abs(dv))+(dv<0?' lower':' higher')+' than known movements explain.';}
  else{sn.className='mo-take mo-needs';sn.textContent='Needs: a period with every balance and money movement confirmed before drift can be stated.';}
  const cand=dr.filter(r=>r.opening!=null).sort((a,b)=>a.to<b.to?1:a.to>b.to?-1:(a.status==='ok'?-1:1));
  drawBridge($('dr-bridge'),cand[0]||null);
  const tb=$('t-drift').tBodies[0];tb.replaceChildren();
  dr.forEach(r=>{const tr=document.createElement('tr');tr.append(el('td','key',r.scope+', '+fd(r.from)+' to '+fd(r.to)));
    if(r.status==='ok'){[money(r.opening),money(r.inflows),money(r.outflows),money(r.expected),money(r.reported),signed2(r.drift)].forEach(v=>tr.append(el('td','num',v)));}
    else{const td=el('td','mo-needs','Needs: '+r.needs.join('; '));td.colSpan=6;tr.append(td);}
    tb.append(tr);});
  const sendBox=$('dr-send');sendBox.replaceChildren();
  const send=[...new Set(waiting.flatMap(r=>r.send))];
  if(send.length){sendBox.append(el('h3',null,'What to send'));const ul=el('ul','mo-list');send.forEach(s=>ul.append(el('li',null,s)));sendBox.append(ul);}
  const accts=[...new Set(bl.map(b=>b.account))];
  const single=accts.filter(a=>new Set(bl.filter(b=>b.account===a).map(b=>b.date)).size===1).map(a=>a+' ('+fd(bl.find(b=>b.account===a).date)+')');
  $('dr-single').textContent=single.length?'Reported on one date so far, so there is no period to measure yet: '+single.join(', ')+'.':'';
  drawDriftChart($('dr-chart'),ok);
  const one=ev.filter(e=>e.recurring==='N'&&e.counts_as_spend==='N'&&e.amount<0);
  $('dr-onetime').textContent=one.length?'One time transfers ('+one.map(e=>money(Math.abs(e.amount))+' on '+fd(e.date)).join(', ')+') are cash movements only. They are not bills, spending or debt, so they are not in the bills total, the monthly bills share or debt to income.':'';
}
/* ---------- Savings goals ---------- */
const fdy=s=>typeof s==='string'&&s.length>=10?MN[+s.slice(5,7)-1]+' '+(+s.slice(8,10))+', '+s.slice(0,4):'date not set';
const fmy=s=>MN[+s.slice(5,7)-1]+' '+s.slice(0,4);
const plural=(n,w)=>n+' '+w+(n===1?'':'s');
function goalRing(host,g){
  const S=128,R=S/2;const wrap=el('div','mo-sg-ring');host.append(wrap);const tip=mkTip(wrap);
  const svg=d3.select(wrap).append('svg').attr('class','mo-svg').attr('width',S).attr('height',S).attr('viewBox',`0 0 ${S} ${S}`).attr('role','img').attr('aria-label',g.name+' progress, '+Math.round(g.pct*100)+' percent saved');
  const gg=svg.append('g').attr('transform',`translate(${R},${R})`);
  const arc=d3.arc().innerRadius(R*0.72).outerRadius(R-3).cornerRadius(3);
  gg.append('path').attr('d',arc({startAngle:0,endAngle:2*Math.PI})).style('fill','var(--mo-line)');
  const col=g.state==='reached'||g.state==='ahead'||g.state==='on'?'var(--mo-ok)':g.state==='behind'||g.state==='late'?'var(--mo-warn)':C[0];
  if(g.pct>0)gg.append('path').attr('d',arc({startAngle:0,endAngle:Math.max(0.02,g.pct*2*Math.PI)})).style('fill',col);
  svg.append('text').attr('x',R).attr('y',R+2).attr('text-anchor','middle').style('font-family','var(--mo-font)').style('font-size','24px').style('fill','var(--mo-fg)').text((g.pct>=1?100:Math.floor(g.pct*1000)/10)+'%');
  svg.append('text').attr('x',R).attr('y',R+20).attr('text-anchor','middle').style('font-size','11px').style('fill','var(--mo-muted)').text('saved');
  svg.on('pointermove',ev=>tip.show(ev,[g.name,'Saved '+money(g.saved),'Target '+money(g.target),g.saved>=g.target?'Target reached':'Still to save '+money(g.target-g.saved)])).on('pointerleave',()=>tip.hide());
}
function goalChart(box,g){
  box.replaceChildren();const W=box.clientWidth;if(!W)return;const tip=mkTip(box);
  const narrow=W<480;const H=narrow?250:290;const mg={l:narrow?50:58,r:narrow?14:22,t:28,b:30};
  const P=g.series.map(p=>({...p,dt:new Date(p.date+'T00:00:00Z')}));
  const dTarget=new Date(g.target_date+'T00:00:00Z');
  const d0=P[0].dt,d1=new Date(Math.max(P[P.length-1].dt,dTarget));
  const x=d3.scaleUtc([d0,d1],[mg.l,W-mg.r]);
  const gm=g.months_to_goal!=null&&g.months_to_goal<P.length?P[g.months_to_goal].balance:g.target;const ymax=Math.min(Math.max(g.target,d3.max(P,p=>p.balance)),Math.max(g.target*1.3,gm*1.1))*1.08;
  const y=d3.scaleLinear([0,ymax],[H-mg.b,mg.t]).nice();
  const svg=mkSvg(box,W,H,'Forecast balance by month for '+g.name+' against the target of '+money(g.target)+' and the target date '+fdy(g.target_date));
  hgrid(svg,y.ticks(4),y,mg.l,W-mg.r);
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(${mg.l},0)`).call(d3.axisLeft(y).ticks(4).tickFormat(v=>compact(v)).tickSize(0).tickPadding(6));
  svg.append('g').attr('class','mo-axis').attr('transform',`translate(0,${H-mg.b})`)
    .call(d3.axisBottom(x).ticks(narrow?3:6).tickFormat(d=>(P.length<7?MN[d.getUTCMonth()]+' '+d.getUTCDate():MN[d.getUTCMonth()]+' '+String(d.getUTCFullYear()).slice(2))).tickSize(0).tickPadding(8));
  const ty=y(g.target);
  svg.append('line').attr('x1',mg.l).attr('x2',W-mg.r).attr('y1',ty).attr('y2',ty).style('stroke','var(--mo-fg)').attr('stroke-width',1.5).attr('stroke-dasharray','6 4');
  svg.append('text').attr('class','mo-halo').attr('x',mg.l+4).attr('y',ty+15).attr('font-size',11).style('fill','var(--mo-fg)').text('Target '+money(g.target));
  const tx=x(dTarget);
  svg.append('line').attr('x1',tx).attr('x2',tx).attr('y1',mg.t-6).attr('y2',H-mg.b).style('stroke','var(--mo-warn)').attr('stroke-width',1.5).attr('stroke-dasharray','2 3');
  const left=tx>W*0.6;
  svg.append('text').attr('class','mo-halo').attr('x',left?tx-5:tx+5).attr('y',mg.t-12).attr('text-anchor',left?'end':'start').attr('font-size',11).style('fill','var(--mo-fg)').text('Target date '+fdy(g.target_date));
  svg.append('clipPath').attr('id','sgclip-'+g.goal_id).append('rect').attr('x',mg.l-4).attr('y',mg.t-6).attr('width',W-mg.l-mg.r+8).attr('height',H-mg.b-mg.t+6);
  svg.append('path').attr('clip-path','url(#sgclip-'+g.goal_id+')').attr('d',d3.line().x(p=>x(p.dt)).y(p=>y(p.balance))(P)).attr('fill','none').attr('stroke',C[0]).attr('stroke-width',2.5).attr('stroke-linejoin','round');
  if(P.length<=40)svg.append('g').attr('clip-path','url(#sgclip-'+g.goal_id+')').selectAll('circle').data(P).join('circle').attr('cx',p=>x(p.dt)).attr('cy',p=>y(p.balance)).attr('r',2.5).attr('fill',C[0]);
  if(g.months_to_goal!=null&&g.months_to_goal<P.length){const q=P[g.months_to_goal];
    svg.append('circle').attr('cx',x(q.dt)).attr('cy',y(q.balance)).attr('r',6).attr('fill',C[2]).style('stroke','var(--mo-card)').attr('stroke-width',2);
    const lf=x(q.dt)>W*0.65;
    svg.append('text').attr('class','mo-halo').attr('x',x(q.dt)+(lf?-9:9)).attr('y',y(q.balance)-10).attr('text-anchor',lf?'end':'start').attr('font-size',11).style('fill','var(--mo-fg)').text(g.months_to_goal===0?'Reached':'Reaches target '+fmy(q.date));}
  const cross=svg.append('line').attr('y1',mg.t).attr('y2',H-mg.b).style('stroke','var(--mo-muted)').attr('stroke-width',1).style('display','none');
  const dot=svg.append('circle').attr('r',5).attr('fill',C[0]).style('stroke','var(--mo-card)').attr('stroke-width',2).style('display','none');
  const bis=d3.bisector(p=>p.dt).center;
  svg.append('rect').attr('x',mg.l).attr('y',mg.t).attr('width',W-mg.l-mg.r).attr('height',H-mg.t-mg.b).attr('fill','transparent').on('pointermove',function(ev){
    const [mx]=d3.pointer(ev,svg.node());const p=P[bis(P,x.invert(mx))];if(!p)return;
    cross.attr('x1',x(p.dt)).attr('x2',x(p.dt)).style('display',null);dot.attr('cx',x(p.dt)).attr('cy',y(p.balance)).style('display',null);
    const gap=g.target-p.balance;
    tip.show(ev,[fdy(p.date)+(p.k?', month '+p.k:', start'),'Balance '+money(p.balance),'Target '+money(g.target),gap>0.004?'Short by '+money(gap):'Target met, over by '+money(-gap)]);
  }).on('pointerleave',()=>{tip.hide();cross.style('display','none');dot.style('display','none');});
  box.append(legendEl([{label:'Forecast balance',color:C[0],line:'solid'},{label:'Target amount',color:'var(--mo-fg)',line:'dash'},{label:'Target date',color:'var(--mo-warn)',line:'dot'}]));
}
function goalBlock(g){
  const b=el('div','mo-sg');
  const head=el('div','mo-sg-head');head.append(el('h3',null,g.name||g.goal_id),el('span','mo-chip',g.goal_status||'No status'));
  if(g.account&&g.account!=='Not confirmed')head.append(el('span','mo-chip','Held in '+g.account));
  b.append(head);
  if(g.state==='needs'){
    b.append(el('p','mo-needs','Needs: '+g.needs.join(', ')));
    b.append(el('p','mo-note','No progress, months to goal or chart is shown until these are in. Nothing is estimated.'+(g.rate_given?'':' Optional: the savings interest rate. Until you give one, 0 percent is used.')));
    return b;
  }
  const top=el('div','mo-sg-top');b.append(top);goalRing(top,g);
  const facts=el('div','mo-sg-facts');top.append(facts);
  const rd=(l,v,s,main)=>{const d=el('div','mo-rd'+(main?' main':''));d.append(el('span','mo-tl',l),el('b',null,v));if(s)d.append(el('span','mo-ts',s));facts.append(d);};
  rd('Saved so far',money(g.saved),'of '+money(g.target)+' as of '+fdy(g.as_of));
  const m=g.months_to_goal;
  if(m===0)rd('Months to goal','Reached','Saved is at or above the target');
  else if(m==null)rd('Months to goal','Not reached','At '+money(g.monthly)+' a month the target is not reached within 100 years');
  else rd('Months to goal',plural(m,'month'),'Reaches '+money(g.target)+' in '+fmy(g.goal_date)+' at '+money(g.monthly)+' a month');
  if(g.needed_monthly==null)rd('Needed per month','Not set','Target date '+fdy(g.target_date)+' is today or has passed');
  else rd('Needed per month',money(g.needed_monthly),'To hit '+fdy(g.target_date)+' ('+plural(g.n_target,'month')+')');
  let st,sub,ok=true;
  if(g.state==='reached'){st='Goal reached';sub='Saved is at or above the target';}
  else if(g.state==='late'){st='Behind';sub='The target date is today or has passed. '+money(g.shortfall)+' is still to save';ok=false;}
  else if(g.state==='ahead'){st='Ahead';sub=money(g.monthly)+' a month is '+money(g.extra_monthly)+' more than needed. Reaches the target '+plural(g.early_months,'month')+' early';}
  else if(g.state==='on'){st='On track';sub=money(g.monthly)+' a month reaches the target in '+fmy(g.goal_date);}
  else{st='Behind by '+money(g.gap_monthly)+' a month';sub='Needs '+money(g.needed_monthly)+' a month, you put in '+money(g.monthly);ok=false;}
  const sd=el('div','mo-rd main');sd.append(el('span','mo-tl','Status'),el('b',null,st),el('span','mo-ts',sub));sd.querySelector('b').style.color=ok?'var(--mo-ok)':'var(--mo-warn)';facts.append(sd);
  const cb=el('div','mo-chart');cb.style.minHeight='250px';b.append(cb);b._draw=()=>goalChart(cb,g);
  b.append(el('p','mo-note',(g.rate_given?'Forecast uses a '+g.rate_pct+'% yearly rate, added monthly.':'No interest rate given, so the forecast uses 0%.')+' Each month adds '+money(g.monthly)+' at month end, starting from '+fdy(g.as_of)+'.'+(g.goal_status==='Paused'?' This goal is paused, so its monthly amount is not in the total per month.':g.goal_status==='Done'?' This goal is marked done.':'')));
  return b;
}
function drawGoals(){
  const gc=rows('goals_calc');if(!gc){$('sg-tiles').replaceChildren();$('sg-tiles').hidden=true;$('sg-goals').replaceChildren(needsEl(calcWhy(['goals_calc'],'Needs: the savings goals dataset')));return;}
  const s=gc[0],goals=gc.slice(1);
  if(!goals.length){$('sg-tiles').replaceChildren();$('sg-tiles').hidden=true;$('sg-goals').replaceChildren(el('p','mo-note mo-nogoal','No goals set yet. Tell Claude what you are saving for.'));return;}
  const specs=[];
  specs.push({label:'Total saved for goals',value:s.total_saved!=null?money(s.total_saved):'Not known yet',sub:s.total_saved!=null?plural(s.count,'goal'):'Needs: amount saved for '+s.saved_needs.join(', ')});
  specs.push({label:'Going to goals each month',value:s.total_monthly!=null?money(s.total_monthly):'Not known yet',sub:s.total_monthly!=null?'Active goals only':'Needs: monthly amount for '+s.monthly_needs.join(', ')});
  if(s.earmark_needs){specs.push({label:'Earmarked in Savings',value:'Not known yet',sub:'Needs: '+s.earmark_needs});specs.push({label:'Unassigned in Savings',value:'Not known yet',sub:'Needs: '+s.earmark_needs});}
  else{specs.push({label:'Earmarked in Savings',value:money(s.earmarked),sub:'Goal money held in the Savings account'});
    specs.push({label:'Unassigned in Savings',value:money(s.unassigned),sub:s.unassigned<0?'Goals claim more than the Savings balance of '+money(s.savings_balance):'Savings balance of '+money(s.savings_balance)+' on '+fdy(s.savings_asof)+' minus earmarked'});}
  $('sg-tiles').hidden=false;tiles($('sg-tiles'),specs);
  $('sg-tiles').querySelectorAll('.mo-ts').forEach(n=>{if(n.textContent.startsWith('Needs:'))n.classList.add('mo-needs');});
  const box=$('sg-goals');box.replaceChildren();
  if(!goals.length){box.append(el('p','mo-note mo-nogoal','No goals set yet. Tell Claude what you are saving for.'));return;}
  goals.forEach(g=>{const blk=goalBlock(g);box.append(blk);if(blk._draw)blk._draw();});
}
/* ---------- Data and tasks ---------- */
function drawData(){
  const q=rows('data_queue');
  if(q){const box=$('dq-meter');box.replaceChildren();const qc=dqCounts(q);const n=qc.provided;const mt=el('div','mo-meter');mt.setAttribute('role','img');mt.setAttribute('aria-label',n+' of '+q.length+' items provided');const i1=document.createElement('i');i1.style.width=(n/q.length*100)+'%';i1.style.background='var(--mo-ok)';mt.append(i1);box.append(el('div','mo-note',n+' of '+q.length+' items provided, '+qc.needed+' still needed'+(qc.requested?' ('+qc.requested+' a statement to confirm a screenshot)':'')+(qc.observations?', '+qc.observations+(qc.observations===1?' observation':' observations'):'')+(qc.todo?', '+qc.todo+' for the dashboard to do':'')),mt);}
}


const RI=m=>m.rates[state.ret?state.ret.rate:1];
function retBuildHead(m){
  const seg=$('ret-rate');seg.replaceChildren();
  [['Cautious',0],['Base',1],['Bold',2]].forEach(([n,i])=>{const b=el('button',null,n+' '+m.rates[i]+'%');b.type='button';b.dataset.v=String(i);b.addEventListener('click',()=>{state.ret.rate=i;retRefresh();});seg.append(b);});
  const rg=$('rh-age');rg.min=String(m.age0);rg.max=String(m.age1);rg.step='1';rg.value=String(m.age1);
  rg.addEventListener('input',()=>{state.ret.age=+rg.value;retRefresh();});
  $('rh-age1').textContent=String(m.age1);
}
function retHead(m){
  const rate=RI(m),age=state.ret.age,y=age-m.age0;
  [...$('ret-rate').children].forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.v===state.ret.rate)));
  const val=k=>Math.round(y?(k==='you'?retBal(m,state.ret.v,rate,y):retFixed(m,k,rate,y)).total:m.start);
  const box=$('rh-read');box.replaceChildren();
  [['today',"On today's pay stubs"],['plan','At the limit (maxed)'],['you','Your setting below']].forEach(([k,lab])=>{const d=el('div','mo-rd');const b=el('b',null,money(val(k)));b.style.color=RC[k];d.append(el('span','mo-tl',lab),b);box.append(d);});
  $('rh-agev').textContent='Age '+age+(y?' (in '+y+' years)':' (now)');
  $('rh-note').textContent='At age '+age+', '+rate+'% a year after inflation, in today\'s dollars. Drag the slider to read any age, or tap the chart below.';
}

const money2=v=>v==null||Number.isNaN(v)?'n/a':(v<0?'-':'')+'$'+d3.format(',.2f')(Math.abs(v));
const signed2=v=>v==null?'n/a':(v>0?'+':v<0?'-':'')+money2(Math.abs(v));
function nwTrend(){const nwh=rows('networth_history');if(!nwh)return {};const sp=nwh.length>2?nwh.map(x=>x.net_worth):null;const few=nwh.length===2?[...nwh].sort((a,b)=>a.date<b.date?-1:1):null;
  let delta=null;if(sp){const d=deltaOf(sp[sp.length-1],sp[sp.length-2]);delta=Object.assign(d,{text:d.text+' since the last entry'});}else if(few){const d=deltaOf(few[1].net_worth,few[0].net_worth);delta=Object.assign(d,{text:d.text+' since '+fd(few[0].date)});}
  return {spark:sp,delta};}
