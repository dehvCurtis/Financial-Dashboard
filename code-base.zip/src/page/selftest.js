/* selftest.js: the in-page self-test, a separate page file listed last in index.html. The live runtime runs every page file at start,
   so this file only defines window.MOC_SELFTEST; the rules run when the Self-test button is pressed (More, next to Backup).
   The rules are page/invariants.js, inlined here by tools/build_split.js at the INVARIANTS marker, so the browser-free suite
   (tests/inv_run.js) and this panel check exactly the same rules. A file that fails to load changes nothing else on the page. */
'use strict';
/*INVARIANTS*/
window.MOC_SELFTEST={version:'1',run:function(){
  var dd=function(id){try{return dash.data(id);}catch(e){return null;}};
  var get=function(id){var d=dd(id);return d&&d.status==='ok'?(d.data||d.value):null;};
  var status=function(id){var d=dd(id);return d?d.status:'missing';};
  var calcs=Object.keys(window.CALC_IN||{}).sort();
  var out=MOC_INVARIANTS(get,status,calcs);
  /* page checks on what is drawn now */
  var txt=(document.getElementById('app')||document.body).innerText||'';
  out.push({id:'P1',name:'No NaN, undefined or Infinity on screen',ok:!/\b(NaN|undefined|Infinity)\b/.test(txt),detail:''});
  out.push({id:'P2',name:'No card says a calc did not run',ok:!/Did not run:/.test(txt),detail:''});
  var pg=window.MO_PAGES||[];var miss=pg.filter(function(k){return !document.querySelector('#tabs [data-page="'+k+'"],#sheet [data-page="'+k+'"]')||!(document.getElementById('page-'+k)||document.getElementById('tpl-'+k));});
  out.push({id:'P4',name:'Every page has a place in the bar or the More sheet, and its content',ok:pg.length>0&&!miss.length,detail:miss.length?'missing: '+miss.join(', '):pg.length+' pages'});
  var de=document.documentElement;out.push({id:'P3',name:'The page does not scroll sideways',ok:de.scrollWidth<=de.clientWidth+1,detail:de.scrollWidth+' wide for '+de.clientWidth});
  return out;}};
