#!/bin/bash
# One command for every suite.
#   bash runall.sh --full        build, then every suite: the browser-free ones in parallel, the browser checks in one shared browser.
#                                 A clean full run writes work/last_full.json (sha256 of the page sources, data and tests); the publish
#                                 script refuses to run unless that record matches the tree as it is.
#   bash runall.sh               affected only: what changed since the last full run decides what runs (tools/affected.js): data only
#                                 gives the unit tests of the calcs that read it (dependency map) plus the rule suites and the render and
#                                 parity checks; any code or test change runs everything but the host modes.
# Options: DATA_EXTRA=dir1:dir2 adds staged data folders to the data independent suites (default: none).
cd "$(dirname "$0")"
FULL=0; [ "$1" = "--full" ] && FULL=1
mkdir -p work out
T0=$(date +%s)
node tools/build_page.js > work/build.log 2>&1 && node tools/build_split.js >> work/build.log 2>&1 || { echo 'build failed'; exit 1; }
mkdir -p tests/results tests/logs
if [ $FULL = 1 ]; then { node tools/tiles_inventory.js && node tools/tiles_inventory.js --blank && node tools/docs_facts.js; } > tests/logs/docs_facts.log 2>&1 || { echo 'docs facts failed (needs Chromium)'; exit 1; }; fi
if [ $FULL = 1 ]; then PLAN='{"unit":"","browser":""}'; else PLAN=$(node tools/affected.js); fi
UNIT_ONLY=$(node -e "const p=JSON.parse(process.argv[1]);process.stdout.write(p.unit==null?'skip':p.unit)" "$PLAN")
BR_ONLY=$(node -e "const p=JSON.parse(process.argv[1]);process.stdout.write(p.browser==null?'skip':p.browser)" "$PLAN")
echo "plan: unit ${UNIT_ONLY:-all} | browser ${BR_ONLY:-all}"
pids=()
[ "$UNIT_ONLY" != skip ] && { ONLY=$UNIT_ONLY node tests/unit.js > tests/logs/unit.log 2>&1 & pids+=($!); }
node tests/inv_run.js > tests/logs/inv_run.log 2>&1 & pids+=($!)
node tests/data_rules.js > tests/logs/data_rules.log 2>&1 & pids+=($!)
node tests/static_scan.js > tests/logs/static_scan.log 2>&1 & pids+=($!)
node tests/backup_verify.js > tests/logs/backup_verify.log 2>&1 & pids+=($!)
node tests/docs_check.js > tests/logs/docs_check.log 2>&1 & pids+=($!)
if [ "$BR_ONLY" != skip ]; then if [ -n "$BR_ONLY" ]; then node tests/browser.js --only "$BR_ONLY" > tests/logs/browser.log 2>&1 & else node tests/browser.js > tests/logs/browser.log 2>&1 & fi; pids+=($!); fi
if [ "$BR_ONLY" != skip ]; then node tests/inject.js > tests/logs/inject.log 2>&1 & pids+=($!); fi
fail=0; for p in "${pids[@]}"; do wait $p || fail=1; done
node tools/results.js $FULL $(( $(date +%s) - T0 )) || fail=1
exit $fail
