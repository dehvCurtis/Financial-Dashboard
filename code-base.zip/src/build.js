// usage: node build.js <datadir> <page.html> <out harness.html>
// Hotfix v4.1: the harness runs the page on the live Dashboard runtime's own code (tools/runtime/runtime_extract.js, cut verbatim by AST
// from artifact-type/app.js sha256 1bf5600158ecf3abd820ed9775f119d93d938eff2c47fafc377f806f0cf22641 by S/fable_rca/extract.js):
// each JSON file goes through the runtime parser (xa0, ya0, h9, Jn0, UL: numbers, booleans, strings and null stay, a {value: scalar} cell
// is unwrapped, every other nested object or array cell becomes its JSON text, a key missing from a row is null, every row carries the
// union of columns, a file with no rows fails to load), and every calc runs in the runtime's calc engine (M_0: a calc that throws has
// status error with its own message, a calc downstream of it has status error with "<calc> didn't run." and never runs; calc results are
// structured clones; dataset rows are fresh shallow copies on each read). The page draws once while everything is loading, then again
// when loaded, and each production part runs as the runtime runs a page file: Function("dash", "(function () {" + text + "}).call(this);").
// Live emulation is the default. STRICT=0 is the plain mode (the parsed JSON rows handed over as they are) for baseline builds of old
// pages and for the both shapes check in tests/live_shape.js. Confirm the live shape on the page with the triple tap debug readout
// ("cells as JSON text: ...", "calcs that did not run: ...").
const fs=require('fs');const path=require('path');
const [MO,PG,OUT]=process.argv.slice(2);
const MODE=process.env.STRICT==='0'?'plain':'real';
const page=fs.readFileSync(PG,'utf8');
const texts={};let nested=0;
for(const f of fs.readdirSync(MO))if(f.endsWith('.json')){const t=fs.readFileSync(path.join(MO,f),'utf8');texts[f.replace('.json','')]=t;
  try{const raw=JSON.parse(t);const rows=Array.isArray(raw)?raw:raw&&typeof raw==='object'?['rows','data','results'].map(k=>raw[k]).find(Array.isArray):null;
    if(!rows||!rows.length||!rows.every(r=>r&&typeof r==='object'&&!Array.isArray(r)))console.log('STORE WOULD REJECT '+f);
    else rows.forEach(r=>{for(const k in r){const v=r[k];if(v!==null&&typeof v==='object'&&!(!Array.isArray(v)&&Object.hasOwn(v,'value')&&typeof v.value!=='object'))nested++;}});}catch(e){console.log('STORE WOULD REJECT '+f+' (not JSON)');}}
const extract=fs.readFileSync(__dirname+'/tools/runtime/runtime_extract.js','utf8');
const d3=fs.readFileSync(__dirname+'/node_modules/d3/dist/d3.min.js','utf8');
const shim=`window.__TEXTS=${JSON.stringify(texts)};
window.__MODE=${JSON.stringify(MODE)};
${extract}
const __runs=new Map();
for(const id of Object.keys(window.__TEXTS)){
  if(window.__MODE==='plain'){let raw=null;try{raw=JSON.parse(window.__TEXTS[id]);}catch(e){}
    const rows=Array.isArray(raw)?raw:raw&&typeof raw==='object'?(raw.rows||raw.data||raw.results):null;
    if(!Array.isArray(rows)||!rows.length){__runs.set(id,{status:'failed',message:'The file has no rows this dashboard can read.',at:Date.now()});continue;}
    __runs.set(id,{status:'ok',table:{columns:Object.keys(rows[0]),rows},at:Date.now(),ms:0});continue;}
  let G=null;try{G=xa0(window.__TEXTS[id],'json');}catch(e){G=null;}
  if(G===null||G.columns.length===0)__runs.set(id,{status:'failed',message:'The file has no rows this dashboard can read.',at:Date.now()});
  else __runs.set(id,{status:'ok',table:G,at:Date.now(),ms:0});
}
window.__LOADED=false;
function f95(Z,J,Q){let $=b95(Z),X=lS(Z);return {status:'ok',data:$,columns:[...Z.columns],rows:$,message:'',refreshing:Q,meta:X};}
function Cs(id){if(!__runs.has(id))return ZH('missing','No dataset \\u201c'+id+'\\u201d in this dashboard.');
  if(!window.__LOADED)return ZH('loading','');
  const Q=__runs.get(id);if(Q.status==='ok')return f95(Q.table,void 0,false);return ZH('error',Q.message);}
window.__REPORTS=new Map();window.__STOPS=[];
const __q=M_0({has:(B)=>__runs.has(B),input:Cs,stateOf:(B)=>[__runs.get(B),window.__LOADED?__runs.get(B):{status:'running'}],post:(B)=>{window.__REPORTS.set(B.id,B);}});
window.__ENGINE=__q;
const __draws=[];const __logged=new Set();
const __stop=(file,err)=>{window.__STOPS.push('This page\\u2019s code stopped ('+file+'): '+(err instanceof Error?err.message:String(err)));console.error('STOPPED '+file+': '+(err&&err.stack||err));};
window.dash={
  data(B){if(!u1(B))return Cs(B);const H=__q.under(B);if(H===void 0)return Cs(B);const M=__q.data(B);
    if(M.status==='error'&&!/didn\\u2019t run/.test(M.message||'')&&!__logged.has(B)){__logged.add(B);console.log('CALC ERROR '+B+': '+M.message);}
    return {status:M.status,data:M.value,columns:[],rows:[],message:M.message,refreshing:false,meta:[],value:M.value};},
  onData(B){if(typeof B!=='function')return;const H=()=>{try{B();}catch(M){__stop('a dash.onData callback',M);}};__draws.push(H);H();},
  calc:(B,H)=>{__q.define(B,H);},
  loader(){},format:(x)=>String(x),colors:['#2a6fdb','#e0783a','#2f9e6f','#8b5cc7','#c8a415','#d1477a','#3b9ab2','#7a7a7a'],
  refresh(){},params:()=>({}),setParams(){},resetParams(){},setLink(){},scale:{},ticks:{},path:{},svg:{}};
window.__redraw=()=>{for(const J of __draws)J();};
`;
const m=page.match(/<script>([\s\S]*)<\/script>/);
const body=page.replace(m[0],'');
const SP=require('./tools/split.js').split(m[1]);
const run=(text,file)=>'<script>try{Function("dash","(function () {"+'+JSON.stringify(text+'\n//# sourceURL='+file).replace(/<\/script/gi,'<\\/script')+'+"\\n}).call(this);")(window.dash);}catch(X){window.__STOPS.push("This page\\u2019s code stopped ('+file+'): "+(X&&X.message));console.error("STOPPED '+file+': "+(X&&X.stack||X));}</script>';
fs.writeFileSync(OUT,`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
:root{--color-fg:#1a1d24;--color-fg-muted:#5d6572;--color-panel:#fff;--color-bg:#f4f5f7;--color-border-line:#dfe2e8;--color-ok:#1f8f5f;--color-warn:#b7791f;--color-bad:#c0392b;--cds-radius:8px;--cds-gap-sm:.6rem;--cds-pad-xs:.3rem;--cds-pad-sm:.6rem;--cds-font-size-caption:.8rem;--cds-font-weight-medium:600;--cds-chart-grid:#e6e8ec;--cds-chart-reference:#888;--cds-surface-popover:#fff;--cds-border:#cfd3da;--cds-shadow-popover:0 4px 14px rgba(0,0,0,.15);--cds-chart-status-critical:#c0392b;--cds-gap-md:1rem;--cds-pad-md:1rem}
body{margin:0;padding:12px;background:var(--color-bg);color:var(--color-fg);font:15px system-ui,sans-serif}</style></head><body><div id="dash-root">${body}</div><script>${d3}</script><script>${shim}</script>${SP.parts.map((p,i)=>run(p,'app_'+String.fromCharCode(97+i)+'.js')).join('')}${process.env.NO_SELFTEST==='1'?'':run(require('./tools/selftest_build.js').text(),'selftest.js')}
<script>window.__LOADED=true;requestAnimationFrame(()=>{window.__redraw();window.__DONE=true;});</script></body></html>`);
console.log((MODE==='real'?'live store emulation (real runtime parser and calc engine): '+nested+' nested cells delivered as JSON text':'plain mode: parsed rows handed over as they are')+'\nbuilt',OUT);
