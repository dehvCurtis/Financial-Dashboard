// Browser checks, one shared Chromium for the whole run. Small layout checks, behaviors that need a real page, and the parity proof that
// the browser-free engine gives exactly what the page computes. Expected values come from the data or the engine, never typed in.
//   parity   : every calc in the page (live store emulation) equals tools/engine.js on the same data, current data
//   render   : current data, staged data, fixture, fixture with no rows; light and dark; desktop 1000: no page error, no NaN or undefined,
//              no "Did not run", no dash, no sideways scroll, every chart has an accessible name, the bar sits at the bottom
//   marks    : chart marks per tab (with every fold open) equal the approved inventory (tools/inventory.js --check writes and compares)
//   behavior : backup and rebuild kit, task actions through the db overlay and without it, the payoff card lock against the published
//              page, the triple tap readout (live cell shape), a broken setting names the calc that stopped, the self-test panel (and the
//              page without its file), sliders stay in sync, reduced motion
//   nav      : lazy pages, the More sheet as a modal dialog (opened by a real tap), Back, deep links and old names, Home order, Home rows
//              equal their page numbers, reduced motion
//   links    : tile links (TILE_MAP.md 6): every mapped tile is a link, every jump lands, Back chip, keyboard, Needs tiles plain
//   quick    : Home quick look: the collapsible sections (closed by default, header counts equal the data, a link opens them, open state
//              remembered and the page works without storage, no content lost) and no description text on Home over a length limit
//   hosts    : five iframe host modes, the fixed shell, keyboard resize, rotation, no IntersectionObserver
// usage: node tests/browser.js [--only render,behavior,...]
'use strict';
const fs=require('fs');const path=require('path');const crypto=require('crypto');const {execFileSync}=require('child_process');
const W=require('./lib/web');const {ROOT,S,PAGE,launch,harness,open,tab,openAll,marks}=W;const {results,save}=require('./lib/fx');const E=require(ROOT+'/tools/engine.js');
const only=(()=>{const i=process.argv.indexOf('--only');return i>0?process.argv[i+1].split(','):null;})();const want=k=>!only||only.includes(k);
const rec=(name,ok,info)=>{results.push({name,ok:!!ok,info:info==null?'':String(info).slice(0,300)});console.log(ok?'PASS':'FAIL',name,ok?'':(info==null?'':String(info).slice(0,300)));};
const texts=dir=>{const t={};for(const f of fs.readdirSync(dir))if(f.endsWith('.json'))t[f.slice(0,-5)]=fs.readFileSync(path.join(dir,f),'utf8');return t;};
const sent=t=>{const raw=JSON.parse(t);const rows=Array.isArray(raw)?raw:raw.rows;const s={};Object.keys(rows[0]||{}).forEach(k=>s[k]=null);return JSON.stringify(Array.isArray(raw)?[s]:{rows:[s]});};
const STAGED=[S+'/staged/data_all'].concat((process.env.DATA_EXTRA||'').split(':').filter(Boolean)).filter((d,i,a)=>fs.existsSync(d)&&a.indexOf(d)===i);
const FX=texts(ROOT+'/tests/fixtures/base');const EMPTY={};for(const k in FX)EMPTY[k]=sent(FX[k]);
const txt=(p,id)=>p.evaluate(i=>{const e=document.getElementById(i);return e?e.innerText:null;},id);
const vis=(p,id)=>p.evaluate(i=>{const e=document.getElementById(i);return !!e&&!e.hidden&&getComputedStyle(e).display!=='none'&&e.offsetParent!==null;},id);
const tabsOf=W.pagesOf;
(async()=>{const t0=Date.now();const b=await launch();
const H={current:harness('current',ROOT+'/data_all'),fixture:harness('fixture',FX),empty:harness('empty',EMPTY)};STAGED.forEach((d,i)=>{H['staged'+(i||'')]=harness('staged'+(i||''),Object.assign({},texts(ROOT+'/data_all'),texts(d)));});

if(want('parity')){const p=await open(b,H.current);const ids=Object.keys(E.run({page:PAGE,data:ROOT+'/data_all'}).inputs);
  const pg=await p.evaluate(ids=>{const o={};ids.forEach(i=>{const d=dash.data(i);o[i]={status:d.status,value:d.status==='ok'?d.data:null};});return o;},ids);
  const nd=E.run({page:PAGE,data:ROOT+'/data_all'}).calcs;const fl=require(ROOT+'/tools/calcdiff.js').flat;
  /* equal to the last bit of a double: Math.pow can differ in the final binary digit between two V8 builds */
  const same=(a,b)=>{const x=fl(a,''),y=fl(b,'');const ks=new Set(Object.keys(x).concat(Object.keys(y)));for(const k of ks){const u=x[k],v=y[k];if(typeof u==='number'&&typeof v==='number'){if(Math.abs(u-v)>1e-9*Math.max(1,Math.abs(u)))return false;}else if(JSON.stringify(u)!==JSON.stringify(v))return false;}return true;};
  const diff=ids.filter(i=>pg[i].status!==nd[i].status||!same(pg[i].value,nd[i].value));
  rec('parity: all '+ids.length+' calcs in the page equal the browser-free engine',!diff.length,diff.join(', '));await p.close();}

if(want('render')){
  const scan=async(p,label,tabs)=>{const bad={nan:[],dnr:[],dash:[],wide:[],aria:[],bar:[]};for(const t of tabs){await tab(p,t);await openAll(p,t);
    const r=await p.evaluate(t=>{const pg=document.getElementById('page-'+t);const tx=pg?pg.innerText:'';const de=document.documentElement;const bar=document.querySelector('.mo-bar');const br=bar?bar.getBoundingClientRect():null;
      const charts=[...(pg?pg.querySelectorAll('.mo-chart svg'):[])].filter(s=>{const c=s.getBoundingClientRect();return c.width>=8;});
      return {nan:/\b(NaN|undefined|Infinity)\b/.test(tx),dnr:/Did not run:/.test(tx),dash:/[\u2013\u2014]/.test(tx),wide:de.scrollWidth>de.clientWidth+1,
        aria:charts.filter(s=>!(s.getAttribute('aria-label')||s.closest('[aria-label]')||s.querySelector('title'))).length,bar:br?Math.abs(br.bottom-innerHeight)>2:true};},t);
    for(const k in bad)if(r[k])bad[k].push(t+(typeof r[k]==='number'?' x'+r[k]:''));}
  rec(label+': no NaN, undefined or Infinity on any tab',!bad.nan.length,bad.nan.join(', '));rec(label+': no card says a calc did not run',!bad.dnr.length,bad.dnr.join(', '));
  rec(label+': no em or en dash on screen',!bad.dash.length,bad.dash.join(', '));rec(label+': no sideways scroll',!bad.wide.length,bad.wide.join(', '));
  rec(label+': every chart has an accessible name',!bad.aria.length,bad.aria.join(', '));rec(label+': the bottom bar sits at the bottom of the screen',!bad.bar.length,bad.bar.join(', '));
  rec(label+': no page or console error',!p._errs.length,p._errs.slice(0,3).join(' | '));};
  for(const [name,h,opt] of [['current data',H.current,{}],['current data, dark',H.current,{dark:true}],['fixture',H.fixture,{}],['fixture with no rows',H.empty,{}]].concat(STAGED.map((d,i)=>['staged '+path.relative(S,d),H['staged'+(i||'')],{}]))){
    const p=await open(b,h,opt);await scan(p,name,await tabsOf(p));
    if(name==='fixture with no rows'){const n=await p.evaluate(()=>document.querySelectorAll('.mo-needs').length+[...document.querySelectorAll('.mo-page')].reduce((s,pg)=>s+(pg.innerText.match(/Needs:/g)||[]).length,0));rec(name+': cards without data say what they need',n>0,n+' Needs lines');}
    await p.close();}
  {const p=await open(b,H.current,{viewport:{width:1000,height:800}});const r=await p.evaluate(()=>{const a=document.getElementById('app').getBoundingClientRect();const bar=document.querySelector('.mo-bar').getBoundingClientRect();return {l:a.left,r:innerWidth-a.right,bar:Math.abs(bar.bottom-innerHeight)};});
    rec('desktop 1000: centered column and bar at the bottom',Math.abs(r.l-r.r)<=2&&r.l>0&&r.bar<=2,JSON.stringify(r));await p.close();}
  {const p=await open(b,H.current,{reduced:true});const n=await p.evaluate(()=>[...document.querySelectorAll('*')].filter(e=>{const s=getComputedStyle(e);return parseFloat(s.transitionDuration)>0.01||parseFloat(s.animationDuration)>0.01;}).length);rec('reduced motion: no transitions or animations',n===0,n);await p.close();}}

if(want('marks')){const p=await open(b,H.current);const all=[];const inv=[];for(const t of await tabsOf(p)){await tab(p,t);await openAll(p,t);
    await p.evaluate(()=>{const x=document.querySelector('#po-basis button[data-v="plan"]');if(x)x.click();});await p.waitForTimeout(200);(await marks(p,t)).forEach(m=>all.push(Object.assign({tab:t},m)));
    inv.push(...await p.evaluate(t=>{const pg=document.getElementById('page-'+t);const o=[];if(!pg)return o;pg.querySelectorAll('[id]').forEach(e=>{const k=e.matches('.mo-card')?'card':e.matches('details')?'fold':e.matches('.mo-accpage,.mo-view')?'section':e.matches('table')?'table':e.matches('.mo-chart')?'chart':e.matches('.mo-tiles,[id$="-tiles"]')?'tiles':e.matches('[data-source]')?'el':null;if(!k)return;
      const h=e.querySelector('h2,h3,summary');o.push({tab:t,id:e.id,kind:k,source:e.getAttribute('data-source')||'',head:h?h.textContent.trim().slice(0,60):''});});
      pg.querySelectorAll('[data-go],[data-open],[data-goto]').forEach(e=>o.push({tab:t,id:e.id||'',kind:'link',source:'',head:(e.dataset.go||'')+(e.dataset.open?':'+e.dataset.open:'')+(e.dataset.goto||''),text:e.textContent.trim().slice(0,50)}));return o;},t));}
  const by={};all.forEach(m=>{by[m.id]=(by[m.id]||0)+1;});fs.mkdirSync(ROOT+'/work',{recursive:true});fs.writeFileSync(ROOT+'/work/marks_now.json',JSON.stringify({total:all.length,by},null,1));
  const appr=ROOT+'/tests/lib/marks_approved.json';if(process.env.APPROVE_MARKS==='1'||!fs.existsSync(appr))fs.writeFileSync(appr,JSON.stringify({total:all.length,by},null,1));
  const A=JSON.parse(fs.readFileSync(appr,'utf8'));const miss=Object.keys(A.by).filter(k=>(by[k]||0)!==A.by[k]);const extra=Object.keys(by).filter(k=>!(k in A.by));
  fs.writeFileSync(ROOT+'/work/inventory_now.json',JSON.stringify(inv,null,1));const ia=ROOT+'/tests/lib/inventory_approved.json';
  if(process.env.APPROVE_MARKS==='1'||!fs.existsSync(ia))fs.writeFileSync(ia,JSON.stringify(inv.filter(x=>x.kind!=='link').map(x=>x.id).sort(),null,1));
  {const want3=JSON.parse(fs.readFileSync(ia,'utf8'));const have=new Set(inv.map(x=>x.id));const gone=want3.filter(i=>!have.has(i));rec('inventory: every approved card, chart, table, fold and tile row id is still on the page ('+want3.length+')',!gone.length,gone.join(', '));}
  rec('chart marks: '+all.length+' now, '+A.total+' approved; every element keeps its count',all.length===A.total&&!miss.length&&!extra.length,'changed: '+miss.map(k=>k+' '+(by[k]||0)+'/'+A.by[k]).join(', ')+' new: '+extra.join(', '));await p.close();}

if(want('behavior')){
  /* backup and rebuild kit on the fixture: every dataset the page lists, saved only on a confirmed save */
  const ids=Object.keys(FX).sort();const N=ids.length;
  const lastSave=p=>p.evaluate(async()=>{const s=window.__saves[window.__saves.length-1];if(!s)return null;return s;});
  {const p=await open(b,H.fixture,{mode:{save:'saved'}});await tab(p,'data');
   const listed=await p.evaluate(()=>(window.__bkInfo&&window.__bkInfo().ids)||null);
   rec('backup: status line counts every dataset as loaded',new RegExp('\\b'+N+' of '+N+' datasets loaded').test(await txt(p,'bk-count')),await txt(p,'bk-count'));
   rec('backup: no confirmed backup before the first save',/none recorded/.test(await txt(p,'bk-last')));
   await p.click('#bk-json');await p.waitForTimeout(1200);const m=await txt(p,'bk-msg');const j=await p.evaluate(async()=>{const s=window.__saves[window.__saves.length-1];return s&&s.data?{filename:s.filename,text:await s.data.text()}:null;});
   rec('backup JSON: Saved message names every dataset',new RegExp('^Saved '+N+' of '+N+' datasets').test(m),m);
   if(j&&j.text){const J=JSON.parse(j.text);const ks=Object.keys(J.datasets).sort();
     rec('backup JSON: file named for today, datasets only (calcs kept apart)',/^dashboard-backup-\d{4}-\d{2}-\d{2}\.json$/.test(j.filename)&&JSON.stringify(ks)===JSON.stringify(ids)&&!Object.keys(J.calcs||{}).some(k=>ids.includes(k)),j.filename+' '+ks.length);
     const same=ids.filter(i=>{const raw=JSON.parse(FX[i]);const src=Array.isArray(raw)?raw:raw.rows;const kit=J.datasets[i];return Array.isArray(kit)&&src.length===kit.length&&src.every((r,n)=>Object.keys(r).every(x=>JSON.stringify(r[x])===JSON.stringify(kit[n][x])));}).length;
     rec('backup JSON: every dataset equals its source file (nested cells parsed back)',same===N,same+' of '+N);
     const eng=E.run({page:PAGE,data:ROOT+'/tests/fixtures/base'});const nw=(eng.calcs.nw_rows.value.find(r=>r.item==='Net worth')||{}).amount;
     rec('backup JSON: manifest counts, docs, schema and check values that match the page',J.manifest.dataset_count===N&&J.manifest.datasets_ok===N&&Object.keys(J.docs).length===N&&Object.values(J.docs).every(d=>d.title&&d.title.length<=30)&&Math.abs(J.manifest.check_values.net_worth-nw)<0.005,JSON.stringify(J.manifest.check_values));
     rec('backup JSON: no identifier keys',!/"(account_?(number|no)|routing[a-z_]*|ssn|tax_?id|tin|loan_?(id|number))"\s*:/i.test(j.text));}
   else rec('backup JSON: a file was offered',false,'no file');
   rec('backup: date recorded after a confirmed save, in the private db doc',(await p.evaluate(()=>(window.__store['data/users/u_test/backup']||{}).last_saved))==='2026-10-17',await txt(p,'bk-last'));
   await p.click('#bk-csv');await p.waitForTimeout(1800);const z=await p.evaluate(async()=>{const s=window.__saves[window.__saves.length-1];return s&&s.data?{filename:s.filename,b:Array.from(new Uint8Array(await s.data.arrayBuffer()))}:null;});
   if(z){const zp=ROOT+'/work/kit_test.zip';fs.writeFileSync(zp,Buffer.from(z.b));const lst=execFileSync('unzip',['-Z1',zp]).toString().split('\n').filter(Boolean);
     const man=JSON.parse(execFileSync('unzip',['-p',zp,'manifest.json']).toString());const ok=man.files.filter(f=>{const buf=execFileSync('unzip',['-p',zp,f.path],{maxBuffer:1<<26});return crypto.createHash('sha256').update(buf).digest('hex')===f.sha256&&buf.length===f.bytes;}).length;
     rec('rebuild kit: valid zip with datasets, csv, manifest, RESTORE.md, docs, meta and schema; sha256 and size match',/No errors/.test(execFileSync('unzip',['-t',zp]).toString())&&ids.every(i=>lst.includes('datasets/'+i+'.json')&&lst.includes('csv/'+i+'.csv'))&&['manifest.json','RESTORE.md','docs/datasets.json','dash/meta.json','schema.json'].every(f=>lst.includes(f))&&ok===man.files.length,ok+' of '+man.files.length);}
   else rec('rebuild kit: a zip was offered',false);
   rec('backup: no page error',!p._errs.length,p._errs.join(' | '));await p.close();}
  for(const [mode,re,hide] of [[{save:'declined'},/^Not saved/,false],[{save:'rate_limited'},/^Not saved/,false],[{save:'delivered'},/not counted as a saved backup/,false]]){
    const p=await open(b,H.fixture,{mode});await tab(p,'data');
    await p.click('#bk-json');await p.waitForTimeout(1000);const m=await txt(p,'bk-msg');
    rec('backup '+mode.save+': not counted, no date, a visible fallback',re.test(m)&&/none recorded/.test(await txt(p,'bk-last'))&&await vis(p,'bk-fallback'),m);await p.close();}
  for(const [name,mode] of [['no downloads capability',{downloads:null}],['no window.claude',{claude:false}]]){const p=await open(b,H.fixture,{mode});await tab(p,'data');
    rec('backup with '+name+': buttons hidden, the reason shown, no date',!(await vis(p,'bk-btns'))&&await vis(p,'bk-fallback')&&/none recorded/.test(await txt(p,'bk-last')),await txt(p,'bk-fallback'));await p.close();}
  {const bad=Object.assign({},FX);const victim=Object.keys(FX).sort()[0];bad[victim]='[]';const h=harness('fixture_badfile',bad);const p=await open(b,h,{mode:{save:'saved'}});await tab(p,'data');
   await p.click('#bk-json');await p.waitForTimeout(1000);const m=await txt(p,'bk-msg');
   rec('backup: a dataset that did not load blocks the save and is named',/^Not saved/.test(m)&&m.includes(victim)&&(await p.evaluate(()=>window.__saves.length))===0,m);await p.close();}
  {const p=await open(b,H.fixture,{mode:{save:'saved'}});const u=await p.evaluate(()=>window.__bkDue?[__bkDue('2026-10-17','2026-10-20'),__bkDue('2026-10-17','2026-11-01'),__bkDue('2026-12-05','2026-12-20'),__bkDue('2026-11-01','2026-11-01')]:null);
   rec('backup due rule: due on the 1st of the next month, overdue from that day',!!u&&u[0].due==='2026-11-01'&&!u[0].overdue&&u[1].overdue&&u[2].due==='2027-01-01'&&!u[3].overdue,JSON.stringify(u));
   const sh=await p.evaluate(()=>window.__sha256?[__sha256(''),__sha256('abc')]:null);rec('backup: the page sha256 equals node crypto',!!sh&&sh[0]===crypto.createHash('sha256').update('').digest('hex')&&sh[1]===crypto.createHash('sha256').update('abc').digest('hex'));await p.close();}
  /* task actions on the fixture: the first ranked task */
  {const p=await open(b,H.fixture,{mode:{}});await p.click('#hm-need-tog');await p.waitForTimeout(200);const first=await p.evaluate(()=>{const r=dash.data('task_rank_calc');return r.status==='ok'?r.data[0].tasks[0].id:null;});
   const before=await txt(p,'hm-tasks');const btn=await p.$('#hm-tasks button[data-act="done"]')||await p.$('#hm-tasks button');
   if(btn){await btn.click();await p.waitForTimeout(800);}
   const edit=await p.evaluate(id=>window.__store['data/users/u_test/tasks/edits/'+id]||null,first);
   rec('task Done: writes the private task edit (Done, done date, not verified) and leaves the Home list',!!edit&&edit.status==='Done'&&edit.done_date==='2026-10-17'&&!(await txt(p,'hm-tasks')).includes(first+' ')&&before.includes(first),JSON.stringify(edit));
   rec('task actions: no page error',!p._errs.length,p._errs.join(' | '));await p.close();}
  {const p=await open(b,H.fixture,{mode:{db:false}});await p.click('#hm-need-tog');await p.waitForTimeout(200);const btn=await p.$('#hm-tasks button');if(btn){await btn.click();await p.waitForTimeout(600);}
   const t=await txt(p,'hm-need');rec('task Done without the db: a ready message for Claude, nothing saved',/Claude/.test(t)&&/cannot save|can.t save|not saved/i.test(t),t.slice(0,200));await p.close();}
  /* payoff plan card lock: identical text to the published page on the same data, apart from the approved interest labels */
  const REF=fs.existsSync(ROOT+'/work/baseline/index_page.html')?ROOT+'/work/baseline/index_page.html':null;
  if(REF){for(const [name,dd] of [['fixture',FX],['current data',ROOT+'/data_all']]){const hn=harness('ref_'+name.replace(/\W/g,''),dd,REF),hc=name==='fixture'?H.fixture:H.current;
    const grab=async h=>{const p=await open(b,h);const pg=(await tabsOf(p)).includes('debt')?'debt':'money';await tab(p,pg);await openAll(p,pg);const t=await p.evaluate(()=>{const e=document.getElementById('po-plan');return e?[...e.querySelectorAll('.mx-nextpay .amt')].map(x=>x.innerText.trim()).join('\n'):null;});await p.close();return t;};
    const a=await grab(hn),c2=await grab(hc);rec('payoff Next move: the action line says the same as the published page ('+name+')',a!=null&&a===c2,a===c2?'':'published: '+(a||'').slice(0,160)+' | now: '+(c2||'').slice(0,160));}}
  /* live cell shape: the triple tap readout names the cells that arrive as JSON text, and no calc stopped */
  {const p=await open(b,H.current);const ro=await p.evaluate(()=>typeof liveShapeReport==='function'?liveShapeReport():(window.liveShapeReport?window.liveShapeReport():null));
   const want2=[];for(const [k,t] of Object.entries(texts(ROOT+'/data_all'))){const raw=JSON.parse(t);const rows=Array.isArray(raw)?raw:raw.rows;let n=0;rows.forEach(r=>{for(const c in r){const v=r[c];if(v&&typeof v==='object'&&!(!Array.isArray(v)&&'value' in v&&typeof v.value!=='object'))n++;}});if(n)want2.push(k+' '+n);}
   rec('live shape: the readout lists every nested cell as JSON text and no calc that did not run',!!ro&&ro.includes('cells as JSON text: '+want2.sort().join(', '))&&/calcs that did not run: none/.test(ro),ro);await p.close();}
  {const bad=Object.assign({},FX);const sc=JSON.parse(FX.scores_config);sc.rows[0].financial=JSON.stringify({components:5});bad.scores_config=JSON.stringify(sc);const h=harness('fixture_badcfg',bad);const p=await open(b,h);
   const t=await txt(p,'hm-scores')||'';rec('a broken setting: the score card names the calc that stopped instead of a blank',/Did not run: scores_calc/.test(t)||/Needs/.test(t),t.slice(0,160));await p.close();}
  /* self-test panel */
  {const p=await open(b,H.current);await tab(p,'data');await p.click('#st-run');await p.waitForTimeout(400);const m=await txt(p,'st-msg');const n=await p.evaluate(()=>document.querySelectorAll('#st-out li').length);
   const mm=m&&m.match(/^(\d+) of (\d+) checks pass/);rec('self-test panel: runs every rule on the loaded data and all pass',!!mm&&mm[1]===mm[2]&&+mm[2]===n&&n>10,m);await p.close();}
  {const h=harness('nost',ROOT+'/data_all');const t=fs.readFileSync(h,'utf8');fs.writeFileSync(h,t.replace(/<script>try\{Function\("dash","\(function \(\) \{"\+"\/\* selftest\.js[\s\S]*?<\/script>/,''));
   const p=await open(b,h);await tab(p,'data');await p.click('#st-run');await p.waitForTimeout(300);const m=await txt(p,'st-msg');
   rec('self-test panel: without its file the page still works and says the file did not load',/did not load/.test(m)&&!p._errs.length,m);await p.close();}
  /* sliders stay in sync */
  {const p=await open(b,H.fixture);await tab(p,'debt');await openAll(p,'debt');const r=await p.evaluate(()=>{const rg=document.getElementById('po-rg'),inp=document.getElementById('po-in');if(!rg||!inp)return null;rg.value=String(Math.round(+rg.max/2));rg.dispatchEvent(new Event('input',{bubbles:true}));return {rg:rg.value,inp:inp.value};});
   rec('payoff slider and its box stay in sync',!!r&&Math.abs(+r.rg-+String(r.inp).replace(/[^0-9.]/g,''))<1,JSON.stringify(r));await p.close();}}

/* navigation (S3): the bar, the More sheet as a real dialog, Back, deep links and old names, lazy pages, Home order and Home rows */
if(want('nav')){
  {const p=await open(b,H.current);const r=await p.evaluate(()=>({pages:[...document.querySelectorAll('.mo-page')].map(x=>x.id),tpl:[...document.querySelectorAll('template[id^="tpl-"]')].map(x=>x.id.slice(4)),
      outside:[...document.querySelectorAll('[data-source]')].filter(e=>!e.closest('#page-home')).map(e=>e.id),bar:[...document.querySelectorAll('#tabs [data-page]')].map(x=>x.dataset.page),sheet:[...document.querySelectorAll('#sheet [data-page]')].map(x=>x.dataset.page),all:MO_PAGES.slice()}));
   rec('lazy pages: at load only Home is in the page, the other pages wait in templates',r.pages.join()==='page-home'&&r.tpl.length===r.all.length-1&&r.tpl.every(k=>r.all.includes(k)),JSON.stringify(r.pages)+' '+r.tpl.join());
   rec('lazy pages: only Home cards outside templates load data at once',r.outside.length===0,r.outside.join(', '));
   rec('every page is in the bar or the More sheet exactly once',r.bar.concat(r.sheet).sort().join()===r.all.slice().sort().join()&&r.bar.length===4,r.bar.join()+' | '+r.sheet.join());
   /* the More sheet opens on a real tap */
   await p.evaluate(()=>{window.__links=[];const f=dash.setLink;dash.setLink=x=>{window.__links.push(x);};});
   await p.click('#morebtn');await p.waitForTimeout(250);
   const s=await p.evaluate(()=>{const sh=document.getElementById('sheet'),r=sh.getBoundingClientRect(),bar=document.querySelector('.mo-bar').getBoundingClientRect();
     return {open:!sh.hidden&&r.height>100&&getComputedStyle(sh).visibility!=='hidden',exp:document.getElementById('morebtn').getAttribute('aria-expanded'),role:sh.getAttribute('role'),modal:sh.getAttribute('aria-modal'),
       inside:sh.contains(document.activeElement),onscreen:r.top>=0&&r.bottom<=innerHeight+1,abovebar:Math.abs(r.bottom-bar.top)<=2,popup:document.getElementById('morebtn').getAttribute('aria-haspopup'),
       topEl:(()=>{const e=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return e&&sh.contains(e);})()};});
   rec('More: a tap opens the sheet, a modal dialog above the bar, on screen and on top',s.open&&s.exp==='true'&&s.role==='dialog'&&s.modal==='true'&&s.popup==='dialog'&&s.onscreen&&s.abovebar&&s.topEl,JSON.stringify(s));
   rec('More: focus moves into the sheet',s.inside,JSON.stringify(s));
   const n=await p.evaluate(()=>document.querySelectorAll('#sheet button').length);let trapped=true;for(let i=0;i<n+2;i++){await p.keyboard.press('Tab');if(!(await p.evaluate(()=>document.getElementById('sheet').contains(document.activeElement))))trapped=false;}
   await p.keyboard.press('Shift+Tab');if(!(await p.evaluate(()=>document.getElementById('sheet').contains(document.activeElement))))trapped=false;
   rec('More: Tab and Shift+Tab stay inside the sheet',trapped);
   await p.keyboard.press('Escape');await p.waitForTimeout(150);const e=await p.evaluate(()=>({hidden:document.getElementById('sheet').hidden,focus:document.activeElement&&document.activeElement.id,exp:document.getElementById('morebtn').getAttribute('aria-expanded')}));
   rec('More: Escape closes the sheet and focus returns to More',e.hidden&&e.focus==='morebtn'&&e.exp==='false',JSON.stringify(e));
   await p.click('#morebtn');await p.waitForTimeout(200);const bar=await p.evaluate(()=>document.querySelector('.mo-bar').getBoundingClientRect().top);await p.mouse.click(195,Math.max(20,bar-500>0?40:10));await p.waitForTimeout(150);
   rec('More: a tap on the dimmed page closes the sheet',await p.evaluate(()=>document.getElementById('sheet').hidden));
   /* a page from the sheet: title, More marked current, Back to Home, the host link follows */
   await p.click('#morebtn');await p.waitForTimeout(200);await p.click('#sheet [data-page="investments"]');await p.waitForTimeout(400);
   const v=await p.evaluate(()=>({ttl:document.getElementById('ttl').textContent,page:!document.getElementById('page-investments').hidden,more:document.getElementById('morebtn').getAttribute('aria-current'),back:!document.getElementById('back').hidden&&document.getElementById('back').textContent,focus:document.activeElement&&document.activeElement.id,links:window.__links.slice()}));
   rec('sheet page: shown with its title, More marked as the current place, Back offered, focus on the title',v.page&&v.ttl==='Investments'&&v.more==='page'&&v.back==='Back to Home'&&v.focus==='ttl',JSON.stringify(v));
   rec('every page change sets the host link to the page name',v.links[v.links.length-1]==='investments',JSON.stringify(v.links));
   await p.click('#back');await p.waitForTimeout(400);const bk=await p.evaluate(()=>({home:!document.getElementById('page-home').hidden,back:document.getElementById('back').hidden,cur:document.querySelector('#tabs [aria-current="page"]').dataset.page}));
   rec('Back returns to the page before and is then gone',bk.home&&bk.back&&bk.cur==='home',JSON.stringify(bk));
   /* a Home row opens its page at its main card; Back comes back to the row */
   const rowsH=await p.evaluate(()=>[...document.querySelectorAll('#hm-glance button[data-glance]')].map(x=>({id:x.id,g:x.dataset.glance,same:x.dataset.same,val:x.querySelector('.val,.need').textContent})));
   rec('Home: one row per subject, each opens a page',rowsH.length>=8&&rowsH.every(x=>(x.g||'').includes(':')),JSON.stringify(rowsH.map(x=>x.g)));
   const r0=rowsH.find(x=>x.g.startsWith('debt:'));if(r0){await p.click('#'+r0.id);await p.waitForTimeout(700);
     const j=await p.evaluate(t=>{const e=document.getElementById(t);const r=e.getBoundingClientRect();const tb=document.querySelector('.mo-top').getBoundingClientRect().bottom;return {page:!document.getElementById('page-debt').hidden,inview:r.top>=tb-60&&r.top<innerHeight,back:document.getElementById('back').textContent};},r0.g.split(':')[1]);
     await p.click('#back');await p.waitForTimeout(500);const f=await p.evaluate(()=>document.activeElement&&document.activeElement.id);
     rec('Home row: opens its page with the card in view, and Back returns focus to the row',j.page&&j.inview&&j.back==='Back to Home'&&f===r0.id,JSON.stringify(j)+' focus '+f);}
   /* a bar tap clears Back */
   await p.click('#morebtn');await p.waitForTimeout(150);await p.click('#sheet [data-page="tasks"]');await p.waitForTimeout(300);await p.click('#tabs [data-page="cash"]');await p.waitForTimeout(300);
   rec('a bar tap clears Back',await p.evaluate(()=>document.getElementById('back').hidden));
   /* Home rows show the number their page shows */
   const bad=[];for(const x of rowsH){const num=(x.val.match(/-?\$?[\d,]+(\.\d+)?%?/)||[])[0];if(!num||!x.same)continue;const pg=await p.evaluate(id=>window.__idPage[id],x.same);await tab(p,pg);
     const t=await p.evaluate(id=>{const e=document.getElementById(id);return e?e.textContent:null;},x.same);/* textContent: the source may sit in a closed fold */if(t==null){if(x.same!=='sg-tiles')bad.push(x.g+' no '+x.same);continue;}if(!t.includes(num))bad.push(x.g+' '+num+' not in '+x.same);}
   rec('Home rows: each number equals the one its page shows',!bad.length,bad.join('; '));
   rec('navigation: no page or console error',!p._errs.length,p._errs.slice(0,3).join(' | '));await p.close();}
  /* Home order (IA.md 2.2) */
  {const p=await open(b,H.current);const ord=await p.evaluate(()=>[...document.getElementById('page-home').children].map(e=>e.id).filter(Boolean));
   const want=['cs-checkin','hm-need','hm-hero','nw-fold','hm-glance','hm-season','hm-payoff','po-trail','hm-scores'];const idx=want.map(i=>ord.indexOf(i));
   const inner=await p.evaluate(()=>{const n=document.getElementById('hm-need');return [...n.querySelectorAll('#hm-move,#hm-tasks')].map(e=>e.id).join();});
   rec('Home order: check-in, next move, top tasks, net worth, subjects, season, payoff and trail, scores',idx.every(i=>i>=0)&&idx.every((v,i)=>!i||v>idx[i-1])&&inner==='hm-move,hm-tasks',ord.join(','));
   const fold=await p.evaluate(()=>{const d=document.getElementById('nw-fold');return {closed:!d.open,has:['hm-tiles','nw-tiles','nw-wf','ov-own','nw-assets','ov-donut','t-assets'].filter(i=>!d.querySelector('#'+i))};});
   rec('Home: the net worth fold is closed and holds how it adds up',fold.closed&&!fold.has.length,JSON.stringify(fold));await p.close();}
  /* deep links and every old name */
  {const cases=[['debt','debt',null],['money','home',null],['retire','retirement',null],['tab-motion','retirement',null],['tab-debt','debt',null],['tab-bills','bills',null],['tab-holdings','investments',null],
     ['tab-candidates','investments',null],['tab-add','tasks','acc-queue'],['compare','progress',null],['more','home',null],['tab-overview','home',null],['rt-age','progress',null],['po-plan','debt',null],['bk-card','data',null]];const bad=[];
   for(const [hash,pg,fold] of cases){const p=await open(b,H.current,{hash});const r=await p.evaluate(([pg,fold])=>{const s=document.getElementById('page-'+pg);const f=fold&&document.getElementById(fold);return {shown:!!s&&!s.hidden,fold:fold?!!f&&(f.tagName!=='DETAILS'||f.open)&&f.getClientRects().length>0:true};},[pg,fold]);
     if(!r.shown||!r.fold||p._errs.length)bad.push(hash+' '+JSON.stringify(r)+(p._errs[0]||''));await p.close();}
   rec('deep links: page names, element ids and every old link name land on the right page',!bad.length,bad.join('; '));}
  /* reduced motion: the sheet does not slide */
  {const p=await open(b,H.current,{reduced:true});await p.click('#morebtn');await p.waitForTimeout(100);const d=await p.evaluate(()=>getComputedStyle(document.getElementById('sheet')).transitionDuration);
   rec('reduced motion: the sheet opens without a slide',parseFloat(d)===0,d);await p.close();}}

/* tile links (TILE_MAP.md 6): every mapped tile is a link where it shows a value, each jump lands on its target with the heading in
   view, highlighted and focused, the Back chip returns to the tile, nothing else looks like a link, keyboard works, Needs tiles stay plain */
if(want('links')){
  /* reduced motion makes each scroll immediate, so every jump can be checked quickly; one smooth jump is checked after */
  {const p=await open(b,H.current,{reduced:true});const pages=await tabsOf(p);const found={},bad=[],miss=[];
   for(const pg of pages){await tab(p,pg);await openAll(p,pg);
     const r=await p.evaluate(pg=>TILE_LINKS.map(([k,f])=>{const n=tlFind(f);if(!n)return null;const s=n.closest('.mo-page');if(!s||s.id!=='page-'+pg)return null;
       const v=n.querySelector('.mo-tv,.mx-big,.v,b');const needs=/^(Needs|Did not run|n\/a|Not known yet|Not calculated yet)/i.test(((v||n).textContent||'').trim())||!!n.querySelector('button');/* a tile that holds a button (Review) is not a link: no link holds a button */const rc=n.getBoundingClientRect();
       return {k,needs,linked:n.dataset.gotoId===TILE_LINKS.find(x=>x[0]===k)[2],role:n.getAttribute('role'),tab:n.tabIndex,aria:n.getAttribute('aria-label')||'',w:rc.width,h:rc.height,name:TILE_LINKS.find(x=>x[0]===k)[3]};}).filter(Boolean),pg);
     r.forEach(x=>{found[x.k]=Object.assign(x,{page:pg});if(!x.needs&&!(x.linked&&x.role==='link'&&x.tab===0&&x.aria.includes('Open '+x.name)&&x.w>=44&&x.h>=44))bad.push(x.k+' '+JSON.stringify({l:x.linked,r:x.role,t:x.tab,w:Math.round(x.w),h:Math.round(x.h)}));});}
   const all=await p.evaluate(()=>TILE_LINKS.map(x=>x[0]));const cond=k=>/^sg-/.test(k);/* the goal tiles show only when a goal exists */
   all.forEach(k=>{if(!found[k]&&!cond(k))miss.push(k);});
   rec('tile links: every mapped tile is on the page ('+(all.length-miss.length)+' of '+all.length+'; goal tiles only with a goal)',!miss.length,miss.join(', '));
   rec('tile links: each one with a value is a link with role, tab stop, a name that says what opens, and 44 px or more',!bad.length,bad.slice(0,8).join('; '));
   const extra=await p.evaluate(()=>{const keys=new Set(TILE_LINKS.map(x=>x[0]).concat(['hm-goals']));return [...document.querySelectorAll('[data-goto-id]')].filter(n=>!keys.has(n.dataset.tileKey)||(n.tagName!=='BUTTON'&&n.querySelector('button,a,input,select,summary'))).map(n=>n.dataset.tileKey||n.id);});
   rec('tile links: nothing outside the map looks like a link, and no link holds a button',!extra.length,extra.join(', '));
   /* every jump and its Back chip */
   const jb=[];let n=0;
   for(const k of Object.keys(found).filter(k=>!found[k].needs)){const x=found[k];await tab(p,x.page);await p.evaluate(()=>{const c=document.querySelector('.mo-back');if(c)c.remove();});
     const ok=await p.evaluate(k=>{const e=document.querySelector('[data-tile-key="'+k+'"]');if(!e)return false;e.click();return true;},k);if(!ok){jb.push(k+' not clickable');continue;}await p.waitForTimeout(260);
     const r=await p.evaluate(k=>{const map=TILE_LINKS.find(x=>x[0]===k);let t=document.getElementById(map[2]);const o=map[4]||{};if((!t||!t.getClientRects().length)&&o.fb)t=document.getElementById(o.fb);if(!t)return {err:'no target'};
       const s=t.closest('.mo-page');const tb=document.querySelector('.mo-top').getBoundingClientRect().bottom;const chip=document.querySelector('.mo-back');const top=(chip||t).getBoundingClientRect().top;
       const content=t.querySelector('svg,table tbody tr,li,.mo-tile,.mo-bl,.mo-meter')||(t.textContent||'').trim().length>60||t.matches('h2,h3');
       return {page:!!s&&!s.hidden,vis:t.getClientRects().length>0,inview:top>=tb-14&&top<innerHeight-44,hl:t.classList.contains('mo-hl'),focus:document.activeElement===t,chip:!!chip&&/^Back to /.test(chip.textContent),content:!!content};},k);
     if(r.err||!(r.page&&r.vis&&r.inview&&r.hl&&r.focus&&r.chip&&r.content)){jb.push(k+' '+JSON.stringify(r));continue;}
     if(n++<12||k==='hm-po-free'){await p.click('.mo-back');await p.waitForTimeout(260);const bk=await p.evaluate(([k,pg])=>{const e=document.querySelector('[data-tile-key="'+k+'"]');const s=document.getElementById('page-'+pg);return {page:!!s&&!s.hidden,focus:document.activeElement===e,chip:!document.querySelector('.mo-back')};},[k,x.page]);
       if(!(bk.page&&bk.focus&&bk.chip))jb.push(k+' back '+JSON.stringify(bk));}}
   rec('tile links: each jump shows the target page, opens its folds, puts the heading under the top bar, highlights and focuses the target, with a Back chip',!jb.filter(x=>!/ back /.test(x)).length,jb.filter(x=>!/ back /.test(x)).slice(0,6).join('; '));
   rec('tile links: the Back chip returns to the tile, focused, and goes away',!jb.filter(x=>/ back /.test(x)).length,jb.filter(x=>/ back /.test(x)).slice(0,6).join('; '));
   rec('tile links: the plan chart link presses Your payoff plan first',await p.evaluate(()=>{const b=document.querySelector('#po-basis button[data-v="plan"]');const c=document.getElementById('po-planchart');return !!b&&b.getAttribute('aria-pressed')==='true'&&!!c&&!c.hidden&&!!c.querySelector('svg');}));
   rec('tile links: no page or console error',!p._errs.length,p._errs.slice(0,3).join(' | '));await p.close();}
  {const p=await open(b,H.current);await tab(p,'retirement');await openAll(p,'retirement');await p.evaluate(()=>document.querySelector('#ret-tiles [data-goto-id]').click());await p.waitForTimeout(1500);
   const r=await p.evaluate(()=>{const c=document.querySelector('.mo-back');const tb=document.querySelector('.mo-top').getBoundingClientRect().bottom;return c?Math.round(c.getBoundingClientRect().top-tb):null;});
   rec('tile links: with motion on, the smooth scroll ends with the Back chip under the top bar',r!=null&&Math.abs(r)<=14,r);
   /* keyboard */
   await tab(p,'home');await p.evaluate(()=>{document.getElementById('nw-fold').open=true;});await p.waitForTimeout(300);const fo=await p.evaluate(()=>{const e=document.querySelector('#hm-tiles [data-goto-id]');e.focus();return document.activeElement===e;});await p.keyboard.press('Enter');await p.waitForSelector('.mo-back',{timeout:10000}).catch(()=>{});
   const kb=await p.evaluate(()=>!!document.querySelector('.mo-back'));rec('tile links: Enter on a focused tile jumps',kb);await p.close();}
  {const p=await open(b,H.empty);const bad=[];for(const pg of await tabsOf(p)){await tab(p,pg);await openAll(p,pg);
     bad.push(...await p.evaluate(()=>[...document.querySelectorAll('[data-goto-id]')].filter(n=>n.tagName!=='BUTTON').filter(n=>{const v=n.querySelector('.mo-tv,.mx-big,.v,b');return /^(Needs|Did not run|n\/a)/i.test(((v||n).textContent||'').trim());}).map(n=>n.dataset.tileKey)));}
   rec('tile links: with no data, a tile that shows a Needs value is not a link',!bad.length,bad.join(', '));await p.close();}}

/* Home quick look (S5a). LIMIT is the longest visible text block allowed on Home outside Needs lines, chips, headings, list item titles,
   table cells and the closed detail folds (QUICK_LIMIT overrides it). Nothing here names a figure or a sentence from the data. */
if(want('quick')){const LIMIT=+(process.env.QUICK_LIMIT||70);
  const st=p=>p.evaluate(()=>[...document.querySelectorAll('#page-home .mo-coll')].map(c=>{const b=c.querySelector(':scope > .mo-collh > .mo-collbtn'),bd=c.querySelector(':scope > .mo-collbody');
    return {id:c.id,exp:b&&b.getAttribute('aria-expanded'),ctl:b&&b.getAttribute('aria-controls')===(bd&&bd.id),hidden:!!bd&&bd.hidden,status:((c.querySelector('.mo-collst')||{}).textContent||'').trim(),tx:bd?bd.textContent.replace(/\s+/g,' ').trim():''};}));
  const long=p=>p.evaluate(L=>{const pg=document.getElementById('page-home');const bad=[];
    pg.querySelectorAll('p,span,small,div,li,b,strong').forEach(e=>{if(e.closest('details:not([open])')||e.closest('details')||e.closest('.mo-sr,svg,td,th,.mx-chip,.mo-needs,h2,h3,button'))return;
      let own='';e.childNodes.forEach(n=>{if(n.nodeType===3)own+=n.textContent;});own=own.replace(/\s+/g,' ').trim();if(own.length<=L)return;
      if(/^Needs\b/.test(own)||(e.tagName==='B'&&e.closest('li'))||!e.checkVisibility())return;bad.push((e.closest('[id]')||{}).id+': '+own.length);});return bad;},LIMIT);
  {const p=await open(b,H.current);const s0=await st(p);
   const first=await p.evaluate(()=>{const c=document.querySelector('#page-home > .mo-card');return c&&c.id;});
   rec('quick: the weekly check-in and Needs attention are collapsible, closed by default, header button controls the body; the check-in is the first card on Home',
     s0.length===2&&s0.every(x=>x.exp==='false'&&x.hidden&&x.ctl)&&first==='cs-checkin'&&s0.map(x=>x.id).join()==='cs-checkin,hm-need',JSON.stringify(s0.map(x=>[x.id,x.exp,x.hidden,x.ctl]))+' first '+first);
   const cnt=await p.evaluate(()=>{const tv=tasksView();const open=tv.filter(t=>t.status!=='Done'&&!snoozed(t)).length;const q=rows('data_queue');const K=one('checkins_calc');
     const num=id=>((document.getElementById(id)||{}).textContent||'').match(/\d+/g)||[];return {need:num('hm-need-status').map(Number),want:[open,dqCounts(q).needed],ck:num('cs-checkin-status').map(Number),ckWant:[K.count,K.total]};});
   rec('quick: the header counts equal the data (open tasks and data still needed; weeks checked in of the weeks shown)',JSON.stringify(cnt.need)===JSON.stringify(cnt.want)&&JSON.stringify(cnt.ck)===JSON.stringify(cnt.ckWant),JSON.stringify(cnt));
   const bad0=await long(p);
   await p.click('#cs-checkin-tog');await p.click('#hm-need-tog');await p.waitForTimeout(300);const s1=await st(p);
   const kids=await p.evaluate(()=>['hm-move','hm-tasks','hm-tasklist','hm-datalist'].filter(i=>{const e=document.getElementById(i);return !e||!e.closest('#hm-need-body')||!e.checkVisibility();}));
   const bad1=await long(p);await p.click('#cs-checkin-tog');await p.click('#hm-need-tog');await p.waitForTimeout(300);const s2=await st(p);
   rec('quick: a tap opens each section and its body shows every part; closed or open the body holds the same content',s1.every(x=>x.exp==='true'&&!x.hidden)&&s2.every(x=>x.exp==='false'&&x.hidden)&&!kids.length&&s0.every((x,i)=>x.tx.length>0&&x.tx===s1[i].tx&&x.tx===s2[i].tx),JSON.stringify(s1.map(x=>[x.id,x.exp]))+' missing '+kids.join(',')+' same '+s0.map((x,i)=>x.tx===s1[i].tx));
   rec('quick: no visible text block on Home over '+LIMIT+' characters except Needs lines, chips, headings, list titles and table cells (closed and open)',!bad0.length&&!bad1.length,bad0.concat(bad1).slice(0,8).join('; '));
   const q=await p.evaluate(()=>{const qs=[...document.querySelectorAll('[data-quiet]')];return {n:qs.length,out:qs.filter(e=>!e.closest('#page-home')).length,
     lost:qs.filter(e=>!e.textContent.trim()||getComputedStyle(e).position!=='absolute').length,esc:qs.filter(e=>e.closest('[hidden]')?false:!e.offsetParent||!e.offsetParent.closest('#page-home')).length,tip:qs.filter(e=>{const t=e.textContent.trim();let a=e.previousElementSibling;while(a&&(a.classList.contains('mo-sr')||a.hidden||a.classList.contains('mo-chart')))a=a.previousElementSibling;a=a||e.parentElement;return !(a&&a.title&&a.title.includes(t.slice(0,40)));}).length};});
   rec('quick: each description moved off the screen keeps its words for screen readers and as the tooltip of the element before it; none outside Home, and none adds page scroll',q.n>0&&!q.out&&!q.lost&&!q.tip&&!q.esc,JSON.stringify(q));
   const nh=await p.evaluate(()=>{const c=document.getElementById('nw-hist').closest('.mo-card');const svg=c.querySelector('#nw-hist svg');
     const vp=[...c.querySelectorAll('p')].filter(e=>e.checkVisibility()&&!e.closest('#nw-ms,.mo-sr')).length;return {h:!!c.querySelector(':scope > h2'),svg:!!svg&&!!svg.getAttribute('aria-label'),vp};});
   rec('quick: Net worth over time shows its title and the chart with an accessible name, and no paragraph text',nh.h&&nh.svg&&nh.vp===0,JSON.stringify(nh));
   await p.close();}
  /* the choice is remembered per viewer; with storage blocked the page still works and starts closed */
  {const p=await open(b,H.current);await p.click('#hm-need-tog');await p.waitForTimeout(200);await p.reload();await p.waitForFunction(()=>window.__DONE===true);await p.waitForTimeout(300);const s=await st(p);
   const p2=await open(b,H.current,{mode:{storage:false}});const s2=await st(p2);await p2.click('#cs-checkin-tog');await p2.waitForTimeout(200);const s3=await st(p2);
   rec('quick: an opened section stays open after a reload; with storage blocked the sections start closed and still open on a tap, with no page error',
     s.find(x=>x.id==='hm-need').exp==='true'&&s.find(x=>x.id==='cs-checkin').exp==='false'&&s2.every(x=>x.exp==='false')&&s3.find(x=>x.id==='cs-checkin').exp==='true'&&!p2._errs.length,JSON.stringify([s,s2,s3].map(a=>a.map(x=>x.exp)))+' '+p2._errs.slice(0,2).join('|'));
   await p.close();await p2.close();}
  /* a link into a closed section opens it first: a tile link, a deep link, goTo, and Back to a tile inside one */
  {const r=[];{const p=await open(b,H.current);const t=await p.evaluate(()=>{const n=[...document.querySelectorAll('#page-home [data-goto-id]')].find(n=>{const g=document.getElementById(n.dataset.gotoId);return g&&g.closest('.mo-coll')&&!n.closest('.mo-coll');});if(!n)return null;n.click();return n.dataset.gotoId;});
     await p.waitForTimeout(500);r.push(['tile',t,t&&await p.evaluate(id=>{const c=document.getElementById(id).closest('.mo-coll');return c.querySelector('.mo-collbtn').getAttribute('aria-expanded')==='true'&&document.getElementById(id).checkVisibility();},t)]);await p.close();}
   for(const id of ['hm-tasks','cs-checkin']){const p=await open(b,H.current,{hash:id});await p.waitForTimeout(300);r.push(['deep',id,await p.evaluate(id=>{const e=document.getElementById(id);const c=e.closest('.mo-coll');return c.querySelector('.mo-collbtn').getAttribute('aria-expanded')==='true'&&e.checkVisibility();},id)]);await p.close();}
   {const p=await open(b,H.current);await tab(p,'debt');await p.evaluate(()=>goTo('home','hm-move'));await p.waitForTimeout(300);r.push(['goTo','hm-move',await p.evaluate(()=>document.getElementById('hm-move').checkVisibility()&&document.getElementById('hm-need-tog').getAttribute('aria-expanded')==='true')]);await p.close();}
   rec('quick: a tile link, a deep link and goTo into a closed section open it first and land on a visible target',r.every(x=>x[1]&&x[2]),JSON.stringify(r));}
  /* with no data the headers say what is missing instead of a count */
  {const p=await open(b,H.empty);const s=await st(p);rec('quick: with no data both sections still render closed and their header names what is missing',s.length===2&&s.every(x=>x.exp==='false'&&x.status.length>0),JSON.stringify(s.map(x=>[x.id,x.status])));await p.close();}}

/* About this folds and the quick look rule (user rule, stage 6h): every changed card has one closed fold with the same label; warnings stay
   visible with the fold closed; Cash lists no bills; Bills shows take-home; the gauge never shows NaN or a negative; the slider moves the date.
   Nothing here uses a figure or a sentence from the user's data: values come from the fixture and the engine. */
if(want('about')){
  const fxE=ed=>{const t=Object.assign({},FX);for(const k in ed){const raw=JSON.parse(t[k]);const w=!Array.isArray(raw);const rows=w?raw.rows:raw;ed[k](rows);t[k]=JSON.stringify(w?{rows}:rows);}return t;};
  const CARDS={debt:['card-owe','card-pay','po-plan','pp-plan','card-timeline','card-rate','card-dti','card-house'],cash:['cs-runway','cs-balhist','cash-bal'],bills:['cf-grp','bl-coming','card-cats','card-ess','card-every'],investments:['inv-c-class','inv-c-map','inv-c-funds','inv-c-scatter','inv-c-growth','inv-c-since','inv-c-src','inv-c-hi'],retirement:['ret-head','pct-card','ret-main','ret-c-limits','ret-c-pace','ret-c-paths'],pay:['pb-card'],data:['bk-card','asof-card','st-card']};
  const visInPage=(p,sel)=>p.evaluate(s=>{const n=[...document.querySelectorAll(s)];return n.length>0&&n.every(e=>e.getClientRects().length>0&&!e.closest('details:not([open])')&&!e.closest('[hidden]'));},sel);
  for(const [name,h] of [['fixture',H.fixture],['current data',H.current]]){const p=await open(b,h);const miss=[],open0=[],label=[],place=[];
    for(const t of Object.keys(CARDS)){await tab(p,t);for(const id of CARDS[t]){const r=await p.evaluate(id=>{const c=document.getElementById(id);if(!c)return {none:true};
        const ds=[...c.querySelectorAll(':scope details.mx-about')];const needsOnly=!!c.querySelector('.mo-needs')&&!ds.length&&!c.querySelector('svg,.mo-tile,.mx-kvl');
        return {n:ds.length,open:ds.some(d=>d.open),label:ds.map(d=>d.querySelector('summary').textContent),last:ds.length?ds.every(d=>{let n=d.nextElementSibling;return !n;}):true,needsOnly};},id);
        if(r.none||(!r.n&&!r.needsOnly))miss.push(t+':'+id);else if(r.n){if(r.open)open0.push(id);if(r.label.some(l=>l!=='About this'))label.push(id);if(!r.last)place.push(id);}}}
    rec('About this ('+name+'): every changed card on Debt, Cash, Bills, Investments, Retirement, Pay and Data has its fold',!miss.length,miss.join(', '));
    rec('About this ('+name+'): every fold is closed by default',!open0.length,open0.join(', '));
    rec('About this ('+name+'): one label, the same place (last on the card)',!label.length&&!place.length,label.concat(place).join(', '));await p.close();}
  /* the fold opens from the keyboard, its state survives a switch change and a redraw, a number points at it */
  {const p=await open(b,H.fixture);await tab(p,'debt');
   await p.focus('#about-po > summary');await p.keyboard.press('Enter');await p.waitForTimeout(100);const k1=await p.evaluate(()=>document.getElementById('about-po').open);
   await p.click('#po-strat button[data-v="highest"]');await p.waitForTimeout(200);const k2=await p.evaluate(()=>document.getElementById('about-po').open);
   await p.evaluate(()=>draw());await p.waitForTimeout(100);const k3=await p.evaluate(()=>document.getElementById('about-po').open);
   await p.evaluate(()=>{document.querySelector('#about-timeline > summary').click();});await p.waitForTimeout(100);await p.click('#po-basis button[data-v="plan"]');await p.waitForTimeout(300);const k4=await p.evaluate(()=>document.getElementById('about-timeline').open);
   rec('About this: opens from the keyboard and stays open after a strategy switch, a redraw and a timeline switch',k1&&k2&&k3&&k4,[k1,k2,k3,k4].join());
   await p.evaluate(()=>{document.getElementById('about-po').open=false;ABOUT_OPEN.po=false;});await p.evaluate(()=>draw());
   await p.click('#po-next .mx-srcnum');await p.waitForTimeout(150);const sn=await p.evaluate(()=>({open:document.getElementById('about-po').open,focus:document.activeElement&&document.activeElement.parentElement&&document.activeElement.parentElement.id}));
   rec('source on tap: tapping the next move opens its About this and moves focus to it',sn.open&&sn.focus==='about-po',JSON.stringify(sn));
   const w=await p.evaluate(()=>{const b=document.querySelector('#po-next .why'),u=document.getElementById('po-why');if(!b||!u)return null;const a={exp:b.getAttribute('aria-expanded'),hid:u.hidden};b.click();return [a,{exp:b.getAttribute('aria-expanded'),hid:u.hidden}];});
   rec('Why: closed by default, a tap shows the other reasons',!!w&&w[0].exp==='false'&&w[0].hid&&w[1].exp==='true'&&!w[1].hid,JSON.stringify(w));
   rec('About this: no page error',!p._errs.length,p._errs.join(' | '));await p.close();}
  /* the slider moves the debt free date and the interest, and the strategy chips are one choice of three */
  {const p=await open(b,H.fixture);await tab(p,'debt');const r=await p.evaluate(()=>{const rg=document.getElementById('po-rg'),inp=document.getElementById('po-in');if(!rg||!inp)return null;
      const rd=()=>({date:document.querySelector('#po-tiles .mo-tv').textContent,chips:[...document.querySelectorAll('#po-tiles .mx-chip')].map(c=>c.textContent).join('|')});
      const set=v=>{rg.value=String(v);rg.dispatchEvent(new Event('input',{bubbles:true}));return rd();};const lo=set(0);const hi=set(rg.max);const sg=[...document.querySelectorAll('#po-strat button')].map(x=>x.getAttribute('aria-pressed'));
      return {lo,hi,inp:inp.value,max:rg.max,pressed:sg};});
   rec('slider: moving the extra changes the debt free date and the interest, and the box follows',!!r&&r.lo.date!==r.hi.date&&r.lo.chips!==r.hi.chips&&+r.inp===+r.max,JSON.stringify(r));
   rec('strategy: three chips, exactly one pressed',!!r&&r.pressed.length===3&&r.pressed.filter(x=>x==='true').length===1,JSON.stringify(r&&r.pressed));await p.close();}
  /* warnings stay visible with every fold closed */
  {const hp=harness('about_past',fxE({liabilities:r=>{r.find(x=>x.liability_id==='L4').days_past_due=5;r.find(x=>x.liability_id==='L7').monthly_payment=null;}}));const p=await open(b,hp);await tab(p,'debt');
   const a=await visInPage(p,'#po-next .mx-chip.bad'),c=await visInPage(p,'#debt-pay-chips .mx-chip'),d=await visInPage(p,'#dti-est:not(:empty)'),e=await p.evaluate(()=>document.querySelectorAll('details.mx-about[open]').length);
   rec('warnings stay visible with the fold closed: past due on the next move, a debt with no payment on the payments card and the debt ratio',a&&c&&d&&e===0,JSON.stringify({pastdue:a,floor:c,dti:d,open:e}));await p.close();}
  {const hp=harness('about_low',fxE({assets_other:r=>{r.filter(x=>x.type==='Cash').forEach(x=>{x.value_point=100;});}}));const p=await open(b,hp,{mode:{today:'2026-11-30'}});await tab(p,'cash');
   const a=await visInPage(p,'#cs-runway .mx-chip.warn'),c=await visInPage(p,'#cash-bal .mx-bal:not(.hero) .mx-chip.warn'),e=await p.evaluate(()=>document.querySelectorAll('#page-cash details.mx-about[open]').length);
   rec('warnings stay visible with the fold closed: under 1 month on the runway and a stale balance on its card',a&&c&&e===0,JSON.stringify({low:a,stale:c,open:e}));await p.close();}
  /* Cash: balance cards are the name and the number; no bills anywhere; the word essentials */
  {const p=await open(b,H.fixture);await tab(p,'cash');await openAll(p,'cash');const bills=JSON.parse(FX.bills);const names=(Array.isArray(bills)?bills:bills.rows).map(x=>x.name).filter(Boolean);
   const r=await p.evaluate(names=>{const pg=document.getElementById('page-cash');const tx=pg.innerText;const heads=[...pg.querySelectorAll('h2,h3')].map(h=>h.textContent.trim());
      const tiles=[...pg.querySelectorAll('#cash-bal .mx-bal:not(.hero) .mo-tile')].map(t=>({kids:[...t.children].filter(c=>!c.classList.contains('mx-chip')).map(c=>c.className),text:t.innerText}));
      return {listed:names.filter(n=>tx.includes(n)),heads:heads.filter(h=>/^(This month|Coming up)$/i.test(h)),kv:!!document.querySelector('#cs-runway .mx-kvl'),mustpay:/must-pay/i.test(tx),ess:/essentials/i.test(document.getElementById('cs-runway').innerText),tiles};},names);
   rec('Cash: no card lists bills (no This month, no Coming up, no bill names)',!r.listed.length&&!r.heads.length&&!r.kv,JSON.stringify({listed:r.listed,heads:r.heads,kv:r.kv}));
   rec('Cash: the word essentials, never must-pay',r.ess&&!r.mustpay,JSON.stringify({ess:r.ess,mustpay:r.mustpay}));
   rec('Cash: a balance card shows only its name and its number (no as-of date or source on the face)',r.tiles.length>0&&r.tiles.every(t=>t.kids.join()==='mo-tl,mo-tv'&&!/as of|source/i.test(t.text)),JSON.stringify(r.tiles));await p.close();}
  /* the gauge: finite, never negative, on every data shape */
  for(const [name,dd] of [['fixture',FX],['fixture, cash below zero',fxE({assets_other:r=>{r.filter(x=>x.type==='Cash').forEach(x=>{x.value_point=-300;});}})],['fixture, no cash rows',fxE({assets_other:r=>{r.splice(0,r.length,...r.filter(x=>x.type!=='Cash'));}})]]){
    const hh=harness('gauge_'+name.replace(/\W/g,''),dd);const p=await open(b,hh);await tab(p,'cash');
    const r=await p.evaluate(()=>{const g=document.querySelector('#cs-runway .gfg');if(!g)return {none:true,tx:document.getElementById('cs-runway').innerText};const d=g.getAttribute('stroke-dasharray').split(' ').map(Number);const big=document.querySelector('#cs-runway .big');
      const tk=document.querySelector('#cs-runway .gtick');return {d,big:big&&big.innerText,tick:[tk.getAttribute('x1'),tk.getAttribute('y1')].map(Number),nan:/NaN|undefined|Infinity/.test(document.getElementById('cs-runway').innerHTML)};});
    rec('gauge ('+name+'): never NaN, never negative, ends inside the arc',r.none?!/NaN|undefined|Infinity/.test(r.tx):(!r.nan&&r.d.length===2&&r.d.every(x=>isFinite(x)&&x>=0)&&r.d[0]<=r.d[1]+0.01&&r.tick.every(isFinite)),JSON.stringify(r));await p.close();}
  /* Bills: take-home, labeled; Coming up is here; the debt ratio keeps gross */
  {const p=await open(b,H.fixture);await tab(p,'bills');const eng=E.run({page:PAGE,data:ROOT+'/tests/fixtures/base'});const th=eng.calcs.bills_takehome.value[0],bc=eng.calcs.bills_calc.value[0];
   const r=await p.evaluate(()=>{const t=[...document.querySelectorAll('#cf-tiles .mo-tile')].map(x=>({l:x.querySelector('.mo-tl').textContent,v:x.querySelector('.mo-tv').textContent,s:(x.querySelector('.mo-ts')||{}).textContent||''}));
      return {tiles:t,coming:!!document.querySelector('#bl-coming h2')&&/Coming up/.test(document.querySelector('#bl-coming h2').textContent),items:document.querySelectorAll('#bl-coming .mx-kvr').length};});
   const fm=v=>'$'+Math.round(v).toLocaleString('en-US');const take=r.tiles.find(x=>/take-home/i.test(x.l)),bl=r.tiles.find(x=>/^Bills/.test(x.l));
   rec('Bills: monthly take-home pay (stub x paychecks a year / 12) replaces gross, labeled take-home',!!take&&take.v===fm(th.take_home_month)&&!r.tiles.some(x=>/gross/i.test(x.l)),JSON.stringify(r.tiles));
   rec('Bills: the share line is bills as a share of take-home, not of gross',!!bl&&bl.s.includes('of take-home')&&!/of gross/.test(bl.s)&&bl.s.includes(String(th.pct_of_take_home).replace(/\.0$/,'')),bl&&bl.s);
   rec('Bills: Coming up is on the page with its list',r.coming&&r.items>0,JSON.stringify({c:r.coming,n:r.items}));
   await tab(p,'debt');const dti=await p.evaluate(()=>document.getElementById('debt-dti').innerText);const eg=eng.calcs.dti_calc.value[0];
   rec('Debt to income stays on gross pay (headline value and the with-rent line unchanged)',dti.includes(String(Math.round(eg.back_end_pct*10)/10).replace(/\.0$/,''))&&/gross/i.test(dti),dti.slice(0,160));await p.close();}
  /* layout: no sideways scroll and 44 px targets on the new controls at 390 */
  {const p=await open(b,H.current);const bad=[];for(const t of Object.keys(CARDS)){await tab(p,t);const r=await p.evaluate(()=>{const de=document.documentElement;
      const small=[...document.querySelectorAll('.mo-page:not([hidden]) details.mx-about > summary,.mo-page:not([hidden]) .mx-srcnum,.mo-page:not([hidden]) .why,.mo-page:not([hidden]) #po-strat button,.mo-page:not([hidden]) #po-reset')].filter(e=>{const rc=e.getBoundingClientRect();return rc.width>0&&(rc.height<43.5||rc.width<43.5);}).map(e=>e.className||e.tagName);
      return {wide:de.scrollWidth>de.clientWidth+1,small};},t);if(r.wide||r.small.length)bad.push(t+' '+JSON.stringify(r));}
   rec('layout 390: no sideways scroll and every new control is 44 px or more',!bad.length,bad.join('; '));await p.close();}
}

if(want('about')){
  /* user changes of stage 6i: limit chip on the percent slider, two held-account sections, no task rows on Progress */
  for(const [name,h] of [['fixture',H.fixture],['current data',H.current]]){const p=await open(b,h);
    await tab(p,'retirement');const lim=await p.evaluate(()=>{const i=document.getElementById('pct-in'),r=document.getElementById('pct-rg'),c=document.getElementById('pct-limit');if(!i||!c)return null;
      const set=v=>{i.value=String(v);i.dispatchEvent(new Event('input',{bubbles:true}));i.dispatchEvent(new Event('change',{bubbles:true}));return !c.hidden&&c.getClientRects().length>0;};
      const low=set(0.5);const high=set(15);return {low,high,text:c.textContent.trim()};});
    rec('Limit chip ('+name+'): hidden below the limit, shown with the words Limit reached at it',!!lim&&!lim.low&&(lim.high||name==='fixture')&&/Limit reached/.test(lim.text),JSON.stringify(lim));
    await tab(p,'investments');const inv=await p.evaluate(()=>{const s=[...document.querySelectorAll('#page-investments section.inv-sec')];return {n:s.length,heads:s.map(x=>(x.querySelector('h2')||{}).textContent||''),sep:s.length===2&&s[0].id!==s[1].id,after:!document.querySelector('#page-investments [id="inv-rollover"],#page-investments #t-flow')};});
    rec('Investments ('+name+'): two separate held-account sections, each with its own heading and no move tiles',inv.n===2&&inv.sep&&inv.heads.every(x=>x.trim().length>0)&&inv.after,JSON.stringify(inv));
    await tab(p,'progress');const pg=await p.evaluate(()=>{const e=document.getElementById('page-progress');return e?(e.textContent.match(/(^|[^A-Za-z0-9])K\d+(?![A-Za-z0-9])/g)||[]).length:-1;});
    rec('Progress ('+name+'): no task rows (tasks live on the Tasks page)',pg===0,String(pg));await p.close();}
}
if(want('hosts')){const HH=fs.readFileSync(H.current,'utf8');const REP='<script>setInterval(()=>parent.postMessage({h:Math.ceil(document.body.getBoundingClientRect().bottom+window.scrollY)},"*"),100)</script>';const k=HH.lastIndexOf('</body>');const Hs=HH.slice(0,k)+REP+HH.slice(k);
  const parent=kind=>`<!doctype html><html><head><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>body{margin:0;background:#cde}.sp{height:1500px}iframe{display:block;width:100%;border:0;height:${kind.startsWith('fixed')?'844px':'200px'}}</style></head><body><div class=sp></div><iframe id=f></iframe><div class=sp></div><script>
const f=document.getElementById('f');const kind=${JSON.stringify(kind)};if(kind.endsWith('same')||kind==='auto-body')f.src='file://${H.current}';if(kind.endsWith('sand')){f.setAttribute('sandbox','allow-scripts');f.srcdoc=window.__HTML;}
if(kind==='auto-body')setInterval(()=>{try{const d=f.contentDocument;const h=Math.ceil(d.body.getBoundingClientRect().bottom+f.contentWindow.scrollY);if(h&&h!==f.offsetHeight)f.style.height=h+'px';}catch(e){}},100);
if(kind==='auto-same')setInterval(()=>{try{const h=f.contentDocument.documentElement.scrollHeight;if(h&&h!==f.offsetHeight)f.style.height=h+'px';}catch(e){}},100);
if(kind==='auto-sand')addEventListener('message',e=>{if(e.source===f.contentWindow&&e.data.h&&e.data.h!==f.offsetHeight)f.style.height=e.data.h+'px';});<\/script></body></html>`;
  const iphone={viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true};
  for(const kind of ['auto-same','auto-body','auto-sand','fixed-same','fixed-sand']){const ctx=await b.newContext(iphone);const p=await ctx.newPage();await p.addInitScript(h=>{window.__HTML=h;},Hs);
    const pf=ROOT+'/work/h/parent_'+kind+'.html';fs.writeFileSync(pf,parent(kind));await p.goto('file://'+pf);await p.evaluate(()=>scrollTo(0,1500));await p.waitForTimeout(2500);
    const fr=p.frames().find(x=>x!==p.mainFrame());const bad=[];
    for(const t of ['home','tasks']){await fr.evaluate(t=>{const b=document.querySelector('#tabs [data-page="'+t+'"]');if(b){b.click();return;}document.getElementById('morebtn').click();document.querySelector('#sheet [data-page="'+t+'"]').click();},t);await p.waitForTimeout(600);
      const Hd=await p.evaluate(()=>document.documentElement.scrollHeight);for(let y=0;y<=Hd;y+=Math.max(120,Math.floor(Hd/12))){await p.evaluate(y=>scrollTo(0,y),y);await p.waitForTimeout(260);
        const s=await p.evaluate(()=>{const r=document.getElementById('f').getBoundingClientRect();return {top:r.top,bottom:r.bottom,ih:innerHeight};});const bb=await fr.evaluate(()=>document.querySelector('.mo-bar').getBoundingClientRect().bottom);
        const visH=Math.min(s.ih,s.bottom)-Math.max(0,s.top);if(visH<260)continue;const abs=s.top+bb;const target=(kind.startsWith('fixed')||s.top>1)?Math.min(s.bottom,s.top+s.ih):Math.min(s.ih,s.bottom);if(Math.abs(abs-target)>2)bad.push(t+'@'+y);}}
    rec('host '+kind+': the bar stays at the bottom of the screen or frame while the parent scrolls',!bad.length,bad.slice(0,6).join(', '));await ctx.close();}
  {const p=await open(b,H.current);const res=[];for(const t of await tabsOf(p)){await tab(p,t);const r=await p.evaluate(()=>{const bar=document.querySelector('.mo-bar').getBoundingClientRect();return Math.abs(bar.bottom-innerHeight)<=1;});if(!r)res.push(t);}
   await p.setViewportSize({width:390,height:500});await p.waitForTimeout(500);const kb=await p.evaluate(()=>Math.abs(document.querySelector('.mo-bar').getBoundingClientRect().bottom-innerHeight)<=1);
   await p.setViewportSize({width:844,height:390});await p.waitForTimeout(500);const land=await p.evaluate(()=>Math.abs(document.querySelector('.mo-bar').getBoundingClientRect().bottom-innerHeight)<=1);
   rec('phone: bar at the bottom on every tab, after the keyboard shrinks the screen and in landscape',!res.length&&kb&&land,'tabs '+res.join(',')+' keyboard '+kb+' landscape '+land);await p.close();}
  {const ctx=await b.newContext({viewport:{width:390,height:844}});const p=await ctx.newPage();await p.addInitScript(()=>{delete window.IntersectionObserver;window.__TODAY='2026-10-17';});await p.goto('file://'+H.current);await p.waitForFunction(()=>window.__DONE===true);await p.waitForTimeout(300);
   const r=await p.evaluate(()=>{const bar=document.querySelector('.mo-bar').getBoundingClientRect();return bar.height>0;});rec('no IntersectionObserver: the page falls back and still shows the bar',r);await ctx.close();}}
await b.close();const o=save('browser');console.log('browser run '+Math.round((Date.now()-t0)/1000)+' s');})().catch(e=>{console.error(e);process.exit(1);});
