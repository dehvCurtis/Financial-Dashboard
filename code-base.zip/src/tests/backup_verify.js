// tools/verify_backup.js against synthetic backups built from tests/fixtures/base (invented data): a good JSON file, a good kit zip, a legacy
// Claude-made file, and one deliberate defect at a time, each of which must be caught. When the browser suite has left a kit made by the
// real page code (work/kit_test.zip), that kit is verified too, so the spec and the page code cannot drift apart unnoticed.
'use strict';
const fs=require('fs');const path=require('path');const {ROOT,T,yes,save}=require('./lib/fx');const L=require(ROOT+'/tools/backup_lib');const M=require(ROOT+'/tools/make_synthetic_backup');const V=require(ROOT+'/tools/verify_backup');
const tmp=ROOT+'/work/bk_test';fs.rmSync(tmp,{recursive:true,force:true});fs.mkdirSync(tmp,{recursive:true});
const b=M.build(ROOT+'/tests/fixtures/base','2026-01-01');
const wj=(name,j)=>{const f=path.join(tmp,name);fs.writeFileSync(f,JSON.stringify(j,null,1));return f;};
const wz=(name,files)=>{const f=path.join(tmp,name);fs.writeFileSync(f,L.writeZip(files));return f;};
const clone=o=>JSON.parse(JSON.stringify(o));
const failed=r=>r.filter(x=>!x.pass).map(x=>x.name);
const caught=(r,re)=>failed(r).some(n=>re.test(n));
T([],'verify_backup: a good JSON backup passes every check',()=>yes(!failed(V.verify(wj('good.json',b.json))).length,failed(V.verify(wj('good.json',b.json))).join(', ')));
T([],'verify_backup: a good rebuild kit zip passes every check (hashes, CSV row counts)',()=>{const r=V.verify(wz('good.zip',b.files));return yes(!failed(r).length,failed(r).join(', '));});
T([],'verify_backup: a legacy Claude-made JSON (exported, datasets) is read, with no hash check',()=>{const r=V.verify(wj('legacy.json',{exported:'2026-01-01T00:00:00Z',note:'example',datasets:b.json.datasets}));return yes(!failed(r).length&&r.form==='legacy json',failed(r).join(', '));});
T([],'verify_backup: a changed row is caught by the sha256 check',()=>{const j=clone(b.json);j.datasets.bills[0].monthly_amount=1;return yes(caught(V.verify(wj('t1.json',j)),/^sha256 datasets\/bills/));});
T([],'verify_backup: a changed byte in a zip file is caught',()=>{const f=b.files.map(x=>x.name==='datasets/bills.json'?{name:x.name,bytes:Buffer.from(x.bytes.toString().replace('"bill_id"','"bill_ix"'))}:x);return yes(caught(V.verify(wz('t2.zip',f)),/^sha256 datasets\/bills/));});
T([],'verify_backup: a missing required key is caught',()=>{const j=clone(b.json);delete j.schema;return yes(caught(V.verify(wj('t3.json',j)),/^key schema$/));});
T([],'verify_backup: a wrong schema version is caught',()=>{const j=clone(b.json);j.schema_version='mo-backup-9';return yes(caught(V.verify(wj('t4.json',j)),/schema_version/));});
T([],'verify_backup: a row count that differs from the manifest is caught',()=>{const j=clone(b.json);j.datasets.bills.pop();return yes(caught(V.verify(wj('t5.json',j)),/^rows bills$/));});
T([],'verify_backup: a dataset that did not load (status not ok) is caught',()=>{const j=clone(b.json);j.manifest.statuses[0].status='failed';j.manifest.datasets_ok-=1;return yes(caught(V.verify(wj('t6.json',j)),/status ok|datasets_ok/));});
T([],'verify_backup: an empty dataset (the store cannot load it) is caught',()=>{const j=clone(b.json);j.datasets.bills=[];return yes(caught(V.verify(wj('t7.json',j)),/non-empty array/));});
T([],'verify_backup: a dash character in a dataset is caught',()=>{const j=clone(b.json);j.datasets.bills[0].name='A \u2014 B';return yes(caught(V.verify(wj('t8.json',j)),/dash/));});
T([],'verify_backup: an account number field is caught',()=>{const j=clone(b.json);j.datasets.bills[0].account_number='x';return yes(caught(V.verify(wj('t9.json',j)),/account number/));});
T([],'verify_backup: a kit with a missing CSV is caught',()=>yes(caught(V.verify(wz('t10.zip',b.files.filter(x=>x.name!=='csv/bills.csv'))),/^(csv present bills|file present csv\/bills\.csv)$/)));
T([],'verify_backup: a zip with no manifest is caught',()=>yes(caught(V.verify(wz('t11.zip',b.files.filter(x=>x.name!=='manifest.json'))),/manifest\.json present/)));
/* hostile or damaged input: every one must come back as a failed check, never a crash and never a pass */
const failsClosed=(name,content)=>{const f=path.join(tmp,name);fs.writeFileSync(f,content);let r;try{r=V.verify(f);}catch(e){return yes(false,'threw '+e.message);}return yes(r.some(x=>!x.pass),'no check failed');};
T([],'verify_backup: hostile JSON shapes (null, number, string, array, wrong types in the manifest) fail closed',()=>{
  const cases={'h1.json':'null','h2.json':'5','h3.json':'"x"','h4.json':'[]','h5.json':'',
   'h6.json':JSON.stringify({schema_version:'mo-backup-2',exported:1,manifest:{schema_version:1,exported:1,day:1,dataset_count:0,datasets_ok:0,statuses:'x',files:'y'},docs:1,meta:1,schema:1,datasets:{}}),
   'h7.json':JSON.stringify({schema_version:'mo-backup-2',exported:1,manifest:{schema_version:1,exported:1,day:1,dataset_count:0,datasets_ok:0,statuses:[null],files:[null]},docs:1,meta:1,schema:1,datasets:{}}),
   'h8.json':JSON.stringify({schema_version:'mo-backup-2',exported:1,manifest:{schema_version:1,exported:1,day:1,dataset_count:1,datasets_ok:1,statuses:[],files:[{path:5}]},docs:1,meta:1,schema:1,datasets:{x:'str'}}),
   'h9.json':JSON.stringify({exported:'x',datasets:{a:[[1]],b:null}})};
  for(const k in cases)failsClosed(k,cases[k]);return true;});
T([],'verify_backup: truncated, garbled and tiny zips fail closed',()=>{const good=L.writeZip(b.files);failsClosed('z1.zip','PK');failsClosed('z2.zip',Buffer.concat([Buffer.from('PK'),Buffer.alloc(100)]));
  failsClosed('z3.zip',good.slice(0,good.length-30));failsClosed('z4.zip',good.slice(0,200));const g=Buffer.from(good);g.writeUInt32LE(0xfffffff0,g.length-6);failsClosed('z5.zip',g);return true;});
T([],'verify_backup: a zip with an unsafe entry name (parent folder, absolute path) is refused',()=>{const ok=[];for(const nm of ['../evil.json','/abs.json','a/../../b.json']){const f=path.join(tmp,'slip.zip');fs.writeFileSync(f,L.writeZip(b.files.concat([{name:nm,bytes:Buffer.from('{}')}])));const r=V.verify(f);ok.push(r.some(x=>!x.pass&&/zip readable/.test(x.name)));}return yes(ok.every(Boolean),JSON.stringify(ok));});
T([],'verify_backup: a deflate bomb is refused instead of expanded in memory',()=>{const zlib=require('zlib');const lim=L.ZIP_LIMITS.fileBytes;const big=Buffer.alloc(lim+1024,0x20);const d=zlib.deflateRawSync(big);
  /* hand-built stored-header zip whose entry is deflated and declares a small size */
  const nm=Buffer.from('manifest.json');const lh=Buffer.alloc(30);lh.writeUInt32LE(0x04034b50,0);lh.writeUInt16LE(8,8);lh.writeUInt32LE(d.length,18);lh.writeUInt32LE(100,22);lh.writeUInt16LE(nm.length,26);
  const ch=Buffer.alloc(46);ch.writeUInt32LE(0x02014b50,0);ch.writeUInt16LE(8,10);ch.writeUInt32LE(d.length,20);ch.writeUInt32LE(100,24);ch.writeUInt16LE(nm.length,28);ch.writeUInt32LE(0,42);
  const off=30+nm.length+d.length;const e=Buffer.alloc(22);e.writeUInt32LE(0x06054b50,0);e.writeUInt16LE(1,8);e.writeUInt16LE(1,10);e.writeUInt32LE(46+nm.length,12);e.writeUInt32LE(off,16);
  const f=path.join(tmp,'bomb.zip');fs.writeFileSync(f,Buffer.concat([lh,nm,d,ch,nm,e]));const r=V.verify(f);return yes(r.some(x=>!x.pass&&/zip readable/.test(x.name)),JSON.stringify(r.slice(0,2)));});
T([],'safe_out: a tool will not empty a root, home, working or code base folder',()=>{const {spawnSync}=require('child_process');const run=d=>spawnSync('node',['-e',"require('"+ROOT+"/tools/safe_out').safeOut(process.argv[1])",d]).status;
  return yes(run('/')===2&&run(require('os').homedir())===2&&run(ROOT)===2&&run(path.join(ROOT,'work','x_scratch'))===0,'unexpected status');});
const kit=ROOT+'/work/kit_test.zip';
if(fs.existsSync(kit))T([],'verify_backup: the kit made by the real page code (browser suite) passes every check',()=>{const r=V.verify(kit);return yes(!failed(r).length,failed(r).slice(0,5).join(', '));});
save('backup_verify');
