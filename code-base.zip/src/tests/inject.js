// Injection check on the real page: every text field of the invented dataset gets markup, a script tag and a javascript: URL appended
// (the same value everywhere it recurs, so cross references still match), the page is built on that data, every page is opened with every
// fold open, and nothing may execute, create an element from the data, or gain a link or an event attribute. The payload must show as text.
'use strict';
const fs=require('fs');const W=require('./lib/web');const ROOT=W.ROOT;
const results=[];const rec=(name,ok,info)=>{results.push({name,ok:!!ok,info});console.log((ok?'PASS ':'FAIL ')+name+(ok||!info?'':' ('+info+')'));};
const PAY='<img src=x onerror=window.__pwn=1><script>window.__pwn=2</script> javascript:window.__pwn=3';
const SKIP=/(status|kind|type|class|side|direction|category|area|priority|freq|schedule|mode|_id$|^id$|key$|date|month|day|unit|period|state|strategy|grade|tier|basis|cadence|method|flag|bucket|group|role|tag|level|severity|scope|sort|view|stage)/i;
(async()=>{
  const SRC=ROOT+'/data_all',DST=ROOT+'/work/inject_data';fs.rmSync(DST,{recursive:true,force:true});fs.mkdirSync(DST,{recursive:true});
  const map=new Map();let n=0;const mut=(k,v)=>{if(typeof v!=='string'||v.length<4||SKIP.test(k)||/^[\d\-.,:% $/]+$/.test(v))return v;n++;if(!map.has(v))map.set(v,v+' '+PAY);return map.get(v);};
  for(const f of fs.readdirSync(SRC).filter(x=>x.endsWith('.json'))){const raw=JSON.parse(fs.readFileSync(SRC+'/'+f,'utf8'));const rows=Array.isArray(raw)?raw:raw.rows;
    const out=rows.map(r=>{const o={};for(const k in r)o[k]=mut(k,r[k]);return o;});fs.writeFileSync(DST+'/'+f,JSON.stringify(Array.isArray(raw)?out:Object.assign({},raw,{rows:out})));}
  rec('fixture: many text fields carry the payload',n>200,String(n));
  const b=await W.launch();let H;try{H=W.harness('inject',DST);}catch(e){rec('page builds on the payload data',false,e.message);await b.close();return fin();}
  const p=await W.open(b,H,{});const dialogs=[];p.on('dialog',d=>{dialogs.push(d.message());d.dismiss();});
  const base=await p.evaluate(()=>document.querySelectorAll('script').length);let shown=false;const bad=[];
  for(const t of W.TABS){await W.tab(p,t);await W.openAll(p,t);await p.waitForTimeout(120);
    const r=await p.evaluate(()=>({pwn:window.__pwn,imgs:document.querySelectorAll('img').length,scripts:document.querySelectorAll('script').length,links:document.querySelectorAll('a[href],iframe,object,embed,form,base').length,
      on:[...document.querySelectorAll('*')].filter(e=>[...e.attributes].some(a=>/^on/i.test(a.name))).length,txt:document.body.innerText.includes('<img src=x onerror')}));
    if(r.txt)shown=true;if(r.pwn!==undefined||r.imgs||r.scripts!==base||r.links||r.on)bad.push(t+' '+JSON.stringify(r));}
  rec('page: no script ran, no img, script, link, frame or on* attribute came from data (all 10 pages, folds open)',!bad.length&&!dialogs.length,bad.join('; ')+dialogs.join(','));
  rec('page: the payload is shown as plain text',shown);
  rec('page: no page error on payload data',!p._errs.length,p._errs.slice(0,3).join(' | '));
  await p.close();await b.close();fin();
  function fin(){const pass=results.filter(x=>x.ok).length;fs.mkdirSync(ROOT+'/tests/results',{recursive:true});fs.writeFileSync(ROOT+'/tests/results/inject.json',JSON.stringify({file:'inject',pass,fail:results.length-pass,results},null,1));console.log('inject: '+pass+' pass, '+(results.length-pass)+' fail');process.exitCode=results.length-pass?1:0;}
})();
