// tools/check_docs.js must pass on documents generated from the code and must fail when a document and the code disagree. Browser-free:
// it reuses work/tiles_now.json and work/facts.json (run tools/tiles_inventory.js and tools/docs_facts.js first; runall.sh does).
'use strict';
const fs=require('fs');const path=require('path');const {execFileSync,spawnSync}=require('child_process');const {ROOT,T,yes,save}=require('./lib/fx');
const tmp=ROOT+'/work/docs_test';fs.rmSync(tmp,{recursive:true,force:true});
execFileSync('node',[ROOT+'/tools/gen_docs.js','--out',tmp],{cwd:ROOT,stdio:'pipe'});
const chk=dir=>{const r=spawnSync('node',[ROOT+'/tools/check_docs.js','--docs',dir,'--no-render'],{cwd:ROOT});return {code:r.status,out:r.stdout.toString()};};
const copy=name=>{const d=tmp+'_'+name;fs.rmSync(d,{recursive:true,force:true});fs.cpSync(tmp,d,{recursive:true});return d;};
const edit=(d,f,fn)=>{const p=path.join(d,f);fs.writeFileSync(p,fn(fs.readFileSync(p,'utf8')));};
/* README names INDEX.md and REPORT.md, which are written by the bundle script; give the copies stand-ins */
const fill=d=>{['INDEX.md','REPORT.md'].forEach(f=>{if(!fs.existsSync(path.join(d,f)))fs.writeFileSync(path.join(d,f),'# stand in\n');});return d;};
fill(tmp);
T([],'check_docs: documents generated from the code pass every check',()=>{const r=chk(tmp);return yes(r.code===0,r.out.split('\n').filter(l=>/^FAIL/.test(l)).join('; '));});
T([],'check_docs: a tile row removed from TILES.md is caught',()=>{const d=copy('a');edit(d,'TILES.md',t=>{const L=t.split('\n');const i=L.findIndex(l=>/^\| hm-t-assets \|/.test(l));if(i<0)throw new Error('no hm-t-assets row');L.splice(i,1);return L.join('\n');});const r=chk(d);return yes(r.code===1&&/FAIL every rendered tile id|FAIL TILES.md has the same number/.test(r.out));});
T([],'check_docs: a tile row for a tile that does not render is caught',()=>{const d=copy('b');edit(d,'TILES.md',t=>{const L=t.split('\n');const i=L.findIndex(l=>/^\| hm-t-assets \|/.test(l));L.splice(i+1,0,L[i].replace('hm-t-assets','hm-t-ghost'));return L.join('\n');});const r=chk(d);return yes(r.code===1&&/FAIL TILES.md lists no tile that does not render/.test(r.out));});
T([],'check_docs: a dataset section removed from DATA_MODEL.md is caught',()=>{const d=copy('c');edit(d,'DATA_MODEL.md',t=>t.replace(/^### bills\s*$/m,'### bills_gone'));const r=chk(d);return yes(r.code===1&&/FAIL DATA_MODEL.md has a section for every dataset/.test(r.out));});
T([],'check_docs: a calc section for a calc that does not exist is caught',()=>{const d=copy('e');edit(d,'CALCS.md',t=>t+'\n### ghost_calc\n');const r=chk(d);return yes(r.code===1&&/FAIL CALCS.md names no calc that does not exist/.test(r.out));});
T([],'check_docs: a check id missing from CORRELATIONS.md is caught',()=>{const d=copy('f');edit(d,'CORRELATIONS.md',t=>t.replace(/^\| C1 \|.*$/m,''));const r=chk(d);return yes(r.code===1&&/FAIL CORRELATIONS.md lists every check/.test(r.out));});
T([],'check_docs: a profile question missing from QUESTIONS.md is caught',()=>{const d=copy('g');edit(d,'QUESTIONS.md',t=>t.replace(/^\| \d+ \| debt_mortgage \|.*$/m,''));const r=chk(d);return yes(r.code===1&&/FAIL QUESTIONS.md lists every profile question/.test(r.out));});
T([],'check_docs: an em dash in a document is caught',()=>{const d=copy('h');edit(d,'GLOSSARY.md',t=>t+'\nA \u2014 B\n');const r=chk(d);return yes(r.code===1&&/FAIL no em or en dash/.test(r.out));});
T([],'check_docs: an unexpanded marker is caught',()=>{const d=copy('i');edit(d,'GLOSSARY.md',t=>t+'\n{{GEN:counts}}\n');const r=chk(d);return yes(r.code===1&&/FAIL no unexpanded marker/.test(r.out));});
/* the starter files: every dataset loads under the runtime parser and no calc errors on them (the first run of a new dashboard) */
const E=require(ROOT+'/tools/engine');
execFileSync('node',[ROOT+'/tools/make_templates.js',ROOT+'/work/templates_test'],{cwd:ROOT,stdio:'pipe'});
T([],'templates: the starter files of every dataset load and all calcs run on them',()=>{const r=E.run({page:ROOT+'/out/index_page.html',data:ROOT+'/work/templates_test',today:'2026-10-17'});const bad=Object.entries(r.calcs).filter(([k,v])=>v.status!=='ok').map(x=>x[0]);return yes(!bad.length&&Object.keys(r.calcs).length>=50,'not ok: '+bad.join(', '));});
T([],'templates: no starter file holds a value except null in a user, history or queue dataset',()=>{const DN=require(ROOT+'/docs_src/dataset_notes.json');const bad=[];Object.keys(DN).forEach(id=>{if(['reference','config'].includes(DN[id].class))return;const raw=JSON.parse(fs.readFileSync(ROOT+'/work/templates_test/'+id+'.json','utf8'));const rows=Array.isArray(raw)?raw:raw.rows;if(rows.length!==1||Object.values(rows[0]).some(v=>v!==null))bad.push(id);});return yes(!bad.length,bad.join(', '));});
fs.rmSync(ROOT+'/work/templates_test',{recursive:true,force:true});
fs.readdirSync(ROOT+'/work').filter(f=>/^docs_test/.test(f)).forEach(f=>fs.rmSync(ROOT+'/work/'+f,{recursive:true,force:true}));
save('docs_check');
