// Static rules on the source tree (browser-free):
//  1. page code: no innerHTML or other HTML string sinks, no inline on* handlers, no external URLs, no em or en dash;
//  2. user terms (vendor, lender, account, place and product names derived from the data by tests/lib/owner_terms.js) in page code:
//     none beyond tests/lib/literal_allow.json, a shrinking list of sites still to convert; ALLOW_EMPTY=1 requires the list to be empty;
//  3. tests and tooling docs: no user term, no user figure (any amount from the datasets or from a calc output on them with cents or
//     4 or more significant digits) and no long user text; the fixture folder is scanned too.
'use strict';
const fs=require('fs');const path=require('path');const {ROOT,PAGE,T,yes,save}=require('./lib/fx');const OT=require('./lib/owner_terms');const E=require(ROOT+'/tools/engine.js');
const ls=(d,re)=>fs.existsSync(d)?fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?ls(path.join(d,e.name),re):re.test(e.name)?[path.join(d,e.name)]:[]):[];
const pageFiles=ls(ROOT+'/page',/\.(js|html|css)$/);const rd=f=>fs.readFileSync(f,'utf8');const rel=f=>path.relative(ROOT,f);
const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
function countTerms(text,terms){const hits={};for(const w of terms.words){const m=text.match(new RegExp('(^|[^A-Za-z0-9])'+esc(w)+'(?![A-Za-z0-9])','g'));if(m)hits[w]=m.length;}
  for(const p of terms.full){let i=0,c=0;while((i=text.indexOf(p,i))>=0){c++;i+=p.length;}if(c)hits['"'+p+'"']=c;}return hits;}
T([],'page code: no innerHTML, outerHTML, insertAdjacentHTML or document.write',()=>{const bad=pageFiles.filter(f=>/\.(innerHTML|outerHTML)\s*=|insertAdjacentHTML|document\.write/.test(rd(f)));return yes(!bad.length,bad.map(rel).join(', '));});
T([],'page markup: no inline on* handler attributes',()=>{const bad=pageFiles.filter(f=>/\.html$/.test(f)&&/<[^>]+\son[a-z]+\s*=/i.test(rd(f)));return yes(!bad.length,bad.map(rel).join(', '));});
T([],'page code: no external URL',()=>{const bad=pageFiles.filter(f=>/https?:\/\/(?!www\.w3\.org\/2000\/svg)/.test(rd(f).replace(/\/\/[^\n]*https?:[^\n]*/g,'')));return yes(!bad.length,bad.map(rel).join(', '));});
T([],'page code, tests, tools and docs: no em or en dash',()=>{const files=pageFiles.concat(ls(ROOT+'/tests',/\.(js|json|md|py)$/),ls(ROOT+'/tools',/\.(js|py|sh|md)$/),ls(ROOT+'/out',/\.md$/)).filter(f=>!/results/.test(f));const bad=files.filter(f=>/[\u2013\u2014]/.test(rd(f)));return yes(!bad.length,bad.map(rel).join(', '));});
const terms=OT.names(ROOT+'/data_all');
const allowF=ROOT+'/tests/lib/literal_allow.json';const allow=fs.existsSync(allowF)?JSON.parse(rd(allowF)):{};
const pageHits={};pageFiles.forEach(f=>{const h=countTerms(rd(f),terms);if(Object.keys(h).length)pageHits[rel(f)]=h;});
T([],'page code: user names only where the conversion list still allows them (new ones fail)',()=>{const bad=[];for(const f in pageHits)for(const w in pageHits[f]){const a=(allow[f]||{})[w]||0;if(pageHits[f][w]>a)bad.push(f+' '+w+' x'+pageHits[f][w]);}return yes(!bad.length,bad.join('; '));});
const left=Object.values(pageHits).reduce((s,h)=>s+Object.values(h).reduce((a,b)=>a+b,0),0);
T([],'page code: user names left to convert = '+left+(process.env.ALLOW_EMPTY==='1'?' (must be 0)':''),()=>process.env.ALLOW_EMPTY==='1'?yes(left===0,JSON.stringify(pageHits)):true);
if(process.env.WRITE_ALLOW==='1')fs.writeFileSync(allowF,JSON.stringify(pageHits,null,1));
/* tests, fixtures and tooling docs */
/* fixture copies of the shared settings and public reference tables hold published statistics, not household figures */
const PUBLIC=/[\\/]fixtures[\\/]base[\\/](age_benchmarks|age_metrics_config|scores_config|dti_benchmarks|ltv_benchmarks)\.json$/;
const testFiles=ls(ROOT+'/tests',/\.(js|json|py|md)$/).filter(f=>!/[\\/]results[\\/]|common_words|literal_allow|doc_titles|owner_terms\.js/.test(f)&&!/[\\/]tests_legacy[\\/]/.test(f));const hhFiles=testFiles.filter(f=>!PUBLIC.test(f));
const docFiles=['out/TOOLING.md'].map(f=>path.join(ROOT,f)).filter(fs.existsSync);
T([],'tests, fixtures and tooling docs: no user name',()=>{const bad=[];testFiles.concat(docFiles).forEach(f=>{const h=countTerms(rd(f),terms);if(Object.keys(h).length)bad.push(rel(f)+' '+Object.keys(h).join(','));});return yes(!bad.length,bad.join('; '));});
const R=E.run({page:PAGE,data:ROOT+'/data_all',today:'2026-10-17'});const figs=OT.figures(ROOT+'/data_all',Object.values(R.calcs).map(c=>c.value)).filter(n=>!/^(19|20|21)\d\d$/.test(n));
T([],'tests and fixtures: no user figure ('+figs.length+' figures checked)',()=>{const bad=[];hhFiles.forEach(f=>{const t=rd(f);figs.forEach(n=>{if(new RegExp('(^|[^0-9.])'+esc(n)+'(?![0-9])').test(t)||(n.length>4&&/^\d{4,}$/.test(n)&&new RegExp('(^|[^0-9.])'+n.replace(/\B(?=(\d{3})+(?!\d))/g,',')+'(?![0-9])').test(t)))bad.push(rel(f)+' '+n);});});return yes(!bad.length,bad.slice(0,20).join('; '));});
/* identifiers and the page's own words (enumerations the code also uses) are structure, not user text */
const ENUM=['screenshot, statement requested'];const pageText=pageFiles.concat(ls(ROOT+'/tools',/\.js$/)).map(rd).join('\n');/* text the page or a tool writes is vocabulary */const longText=OT.texts(ROOT+'/data_all').filter(s=>!/^[a-z0-9_]+$/.test(s)&&!pageText.includes(s)&&!ENUM.includes(s));
T([],'tests and fixtures: no user text',()=>{const bad=[];hhFiles.forEach(f=>{const t=rd(f);longText.forEach(s=>{if(t.includes(s))bad.push(rel(f)+' "'+s.slice(0,40)+'"');});});return yes(!bad.length,bad.slice(0,10).join('; '));});
save('static_scan');
