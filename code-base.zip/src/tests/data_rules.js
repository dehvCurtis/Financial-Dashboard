// Data rules that hold for any data folder (current data and every staged folder), browser-free. Nothing here names a figure.
//  shape: what the live store accepts (non-empty array of plain rows, or {rows:[...]}), at most 256 KB, the real parser loads it;
//  catalog: every data file has a doc title of at most 30 characters (tests/doc_titles.json) and the reverse;
//  privacy: no account, routing, card, SSN or tax id numbers, no emails, no keys named like identifiers, no em or en dash;
//  ids: unique ids per dataset; debts and bills are generic rows (a category plus a user-entered name);
//  links: statement requests and their tasks point at each other; task.queue_id and data_queue.task_id resolve;
//  nested cells: every object or array cell sits in a column the page parses (NESTED_CELLS in the page);
//  basis: every money row (assets, debts, bills, cash events, balance readings) has a source line, an as-of date, a value_basis from the fixed list and a source_kind from the fixed list;
//  existence (user rule): profile_answers, when present, is a non-empty array with valid answers.
'use strict';
const fs=require('fs');const path=require('path');const {ROOT,PAGE,T,yes,is,save}=require('./lib/fx');const E=require(ROOT+'/tools/engine.js');
const S=path.resolve(ROOT,'..');
/* staged folders are scanned only when named (DATA_EXTRA=dir1:dir2); no stale folder is scanned by default */
const dirs=[ROOT+'/data_all'].concat((process.env.DATA_EXTRA||'').split(':').filter(Boolean).filter(d=>fs.existsSync(d)));
const titles=JSON.parse(fs.readFileSync(ROOT+'/tests/doc_titles.json','utf8'));
const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
const script=E.pageScript(PAGE);const nested=(()=>{const m=script.match(/const NESTED_CELLS=(\{[^;]*\});/);return m?Function('return '+m[1])():{};})();
const ID={liabilities:'liability_id',bills:'bill_id',assets_other:'asset_id',tasks:'id',data_queue:'queue_id',cash_events:'event_id',balance_log:'log_id',card_transactions:'txn_id',contributions:'account_id',income_pay:'income_id',savings_goals:'goal_id',profile_answers:'question_id',milestones:'milestone_id'};
const IDKEY=/(^|_)(account_?(number|no|num)|acct_?(no|num)|routing|aba|ssn|social_security|tin|ein|tax_?id|loan_?(id|number)|card_?number|iban|swift|member_?number)$/i;
for(const dir of dirs){const lab=path.relative(S,dir);const own=fs.readdirSync(dir).filter(f=>f.endsWith('.json'));const files=[...new Set(own.concat(fs.readdirSync(ROOT+'/data_all').filter(f=>f.endsWith('.json'))))].sort();const R={};
  /* a staged folder made before a dataset was added gets that dataset from the current data (the merge adds it) */
  for(const f of files){const t=fs.readFileSync(path.join(own.includes(f)?dir:ROOT+'/data_all',f),'utf8');let raw=null;try{raw=JSON.parse(t);}catch(e){}R[f.slice(0,-5)]={t,raw,rows:raw==null?null:Array.isArray(raw)?raw:plain(raw)?['rows','data','results'].map(k=>raw[k]).find(Array.isArray):null};}
  const run=E.run({page:PAGE,data:Object.fromEntries(Object.entries(R).map(([k,v])=>[k,v.t])),today:'2026-10-17'});
  T([],lab+': every file is a non-empty list of plain rows the live parser loads, at most 256 KB',()=>{const bad=Object.keys(R).filter(k=>{const x=R[k];return !x.rows||!x.rows.length||!x.rows.every(plain)||Buffer.byteLength(x.t)>256*1024||run.datasets[k].status!=='ok';});return yes(!bad.length,bad.join(', '));});
  T([],lab+': every dataset has a doc title of at most 30 characters, and every title a file',()=>{const ids=Object.keys(R).sort();const miss=ids.filter(k=>!['candidates','roth_plan','transfers'].includes(k)).filter(k=>!(typeof titles[k]==='string'&&titles[k].length&&titles[k].length<=30));const extra=Object.keys(titles).filter(k=>!R[k]);return yes(!miss.length&&!extra.length,'no title: '+miss.join(',')+'; no file: '+extra.join(','));});
  T([],lab+': no em or en dash in any dataset',()=>{const bad=Object.keys(R).filter(k=>/[\u2013\u2014]/.test(R[k].t));return yes(!bad.length,bad.join(', '));});
  T([],lab+': no identifier keys, no long digit runs outside links, no emails',()=>{const bad=[];for(const k in R){(R[k].rows||[]).forEach(r=>{for(const c in r){if(IDKEY.test(c)&&c!=='ytd_social_security')bad.push(k+'.'+c);const v=r[c];
      const s=typeof v==='string'?v:v&&typeof v==='object'?JSON.stringify(v):'';if(!s)continue;const noUrl=s.replace(/https?:\/\/\S+/g,'');
      if(/\b\d{3}-\d{2}-\d{4}\b/.test(noUrl)||/(?<![\d.,])\d{9,}(?![\d.,])/.test(noUrl)||/\b\d{4}[ -]\d{4}[ -]\d{4}[ -]\d{4}\b/.test(noUrl))bad.push(k+'.'+c+' number');if(/[\w.+-]+@[\w-]+\.[\w.]+/.test(noUrl))bad.push(k+'.'+c+' email');}});}return yes(!bad.length,[...new Set(bad)].slice(0,12).join(', '));});
  T([],lab+': ids are unique in each dataset',()=>{const bad=[];for(const k in ID){const x=R[k];if(!x||!x.rows)continue;const ids=x.rows.map(r=>r[ID[k]]).filter(v=>v!=null&&v!=='none');if(new Set(ids).size!==ids.length)bad.push(k);}return yes(!bad.length,bad.join(', '));});
  T([],lab+': debts and bills are generic rows: a category and a user-entered name on every row',()=>{const bad=[];(R.liabilities&&R.liabilities.rows||[]).forEach(l=>{if(l.liability_id!=null&&(!l.type||!l.name))bad.push(l.liability_id);});(R.bills&&R.bills.rows||[]).forEach(b=>{if(b.bill_id!=null&&(!b.category||!b.name))bad.push(b.bill_id);});return yes(!bad.length,bad.join(', '));});
  T([],lab+': task and data request links resolve both ways; every statement request has an open task',()=>{const q=(R.data_queue&&R.data_queue.rows)||[],t=(R.tasks&&R.tasks.rows)||[];const bad=[];
    q.forEach(r=>{if(r.task_id){const k=t.find(x=>x.id===r.task_id);if(!k)bad.push(r.queue_id+' to missing '+r.task_id);}if(r.status==='Statement requested'){const k=t.find(x=>x.id===r.task_id);if(!k||k.status==='Done'||k.queue_id!==r.queue_id)bad.push(r.queue_id+' request without its open task');}});
    t.forEach(k=>{if(k.queue_id){const r=q.find(y=>y.queue_id===k.queue_id);if(!r||r.task_id!==k.id)bad.push(k.id+' to '+k.queue_id+' one way');}});return yes(!bad.length,bad.join('; '));});
  T([],lab+': every object or array cell sits in a column the page parses',()=>{const bad=[];for(const k in R)(R[k].rows||[]).forEach(r=>{for(const c in r){const v=r[c];if(v&&typeof v==='object'&&!(plain(v)&&'value' in v&&typeof v.value!=='object')&&!((nested[k]||[]).includes(c)))bad.push(k+'.'+c);}});return yes(!bad.length,[...new Set(bad)].join(', '));});
  T([],lab+': dates are ISO (YYYY-MM-DD) in every date column',()=>{const bad=[];for(const k in R)(R[k].rows||[]).forEach(r=>{for(const c in r){if(!/(^|_)date$|^as_of(_date)?$|_on$|^created$|^next_due$|^late_after$|^first_pay_date$|^period_(start|end)$/.test(c))continue;const v=r[c];if(v!=null&&!(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}/.test(v)))bad.push(k+'.'+c);}});return yes(!bad.length,[...new Set(bad)].slice(0,12).join(', '));});
  T([],lab+': due days are 1 to 31 and last paid months are YYYY-MM',()=>{const bad=[];['bills','liabilities'].forEach(k=>(R[k]&&R[k].rows||[]).forEach(r=>{if(r.due_day!=null&&!(Number.isInteger(r.due_day)&&r.due_day>=1&&r.due_day<=31))bad.push(k+' '+(r.bill_id||r.liability_id)+' due_day');if(r.statement_due_day!=null&&!(Number.isInteger(r.statement_due_day)&&r.statement_due_day>=1&&r.statement_due_day<=31))bad.push(k+' statement_due_day');if(r.last_paid!=null&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(r.last_paid))bad.push(k+' '+(r.bill_id||r.liability_id)+' last_paid');}));return yes(!bad.length,bad.join(', '));});
  T([],lab+': a closed account has a closed date and a generic category',()=>{const bad=(R.liabilities&&R.liabilities.rows||[]).filter(l=>/^closed$/i.test(l.account_status||'')&&(!l.closed_date||/^closed /i.test(l.type||''))).map(l=>l.liability_id);return yes(!bad.length,bad.join(', '));});
  {const VB=['reported','stated','derived','expected','estimated'],SK=['statement','app_screen','document','owner_stated','calculation','assumption'];
   const MONEY={assets_other:{id:'asset_id',money:r=>r.value_point,date:r=>r.as_of_date},liabilities:{id:'liability_id',money:r=>r.balance!=null?r.balance:r.monthly_payment,date:r=>r.as_of_date},
     bills:{id:'bill_id',money:r=>r.monthly_amount,date:r=>r.as_of_date},cash_events:{id:'event_id',money:r=>r.amount,date:r=>r.date},balance_log:{id:'log_id',money:r=>r.reported_balance,date:r=>r.date}};
   T([],lab+': every money row has a source line, an as-of date, a value_basis and a source_kind from the fixed lists',()=>{const bad=[];for(const k in MONEY){const M=MONEY[k];((R[k]&&R[k].rows)||[]).forEach(r=>{const id=r[M.id];if(id==null||String(id).toLowerCase()==='none')return;const has=M.money(r)!=null;
       if(!(typeof r.source==='string'&&r.source.trim().length>3))bad.push(k+' '+id+' source');if(!/^\d{4}-\d\d-\d\d/.test(M.date(r)||''))bad.push(k+' '+id+' as-of date');
       if(has&&!VB.includes(r.value_basis))bad.push(k+' '+id+' value_basis');if(!SK.includes(r.source_kind))bad.push(k+' '+id+' source_kind');
       if(k==='liabilities'&&r.monthly_payment!=null&&!['reported','stated','derived','expected','estimated'].includes(r.payment_basis))bad.push(k+' '+id+' payment_basis');});}
     return yes(!bad.length,bad.slice(0,12).join(', '));});
   T([],lab+': cash_events kind is one of pay_deposit, transfer, payment, purchase, hold, cash (the words live in kind_label)',()=>{const K=['pay_deposit','transfer','payment','purchase','hold','cash'];const bad=((R.cash_events&&R.cash_events.rows)||[]).filter(e=>e.event_id!=null&&!K.includes(e.kind)).map(e=>e.event_id);return yes(!bad.length,bad.join(', '));});
   T([],lab+': the free text column value_basis_note holds notes only, value_basis never holds free text; no expected_is_reported flag is left',()=>{const bad=[];for(const k of ['assets_other','liabilities'])((R[k]&&R[k].rows)||[]).forEach(r=>{if('expected_is_reported' in r)bad.push(k+' expected_is_reported');if(r.value_basis!=null&&!VB.includes(r.value_basis))bad.push(k+' value_basis text');});return yes(!bad.length,bad.slice(0,8).join(', '));});}
  if(R.profile_answers)T([],lab+': profile answers: non-empty, answers are yes, no or unknown, a category on every real row',()=>{const r=R.profile_answers.rows||[];return yes(r.length>0&&r.every(x=>['yes','no','unknown'].includes(x.answer)&&(x.question_id==='none'||!!x.category)),JSON.stringify(r.filter(x=>!['yes','no','unknown'].includes(x.answer))).slice(0,200));});
}
{const m=script.match(/const DOCS=(\{.*?\});\n/);const D=m?JSON.parse(m[1]):{};const ids=fs.readdirSync(ROOT+'/data_all').filter(f=>f.endsWith('.json')).map(f=>f.slice(0,-5));
 T([],'backup catalogue in the page names every dataset (title at most 30 characters, a description)',()=>{const miss=ids.filter(i=>!D[i]||!D[i].title||D[i].title.length>30||!D[i].description);return yes(!miss.length,miss.join(', '));});}
/* data_offpage: datasets kept in the database and the file backup but not loaded by the page. They follow the same privacy rules as the loaded ones. */
{const od=ROOT+'/data_offpage';if(fs.existsSync(od)){const fl=fs.readdirSync(od).filter(f=>f.endsWith('.json'));
 T([],'data_offpage: every file is a non-empty list of plain rows, no dash, no identifier key, no long digit run, no email, and the page loads none of them',()=>{const bad=[];const loaded=new Set(fs.readdirSync(ROOT+'/data_all').map(f=>f.replace(/\.json$/,'')));
  for(const f of fl){const t=fs.readFileSync(path.join(od,f),'utf8');let j=null;try{j=JSON.parse(t);}catch(e){}const rows=Array.isArray(j)?j:null;
   if(!rows||!rows.length||!rows.every(plain))bad.push(f+' shape');if(/[\u2013\u2014]/.test(t))bad.push(f+' dash');if(loaded.has(f.replace(/\.json$/,'')))bad.push(f+' also in data_all');
   (rows||[]).forEach(r=>{for(const c in r){if(IDKEY.test(c))bad.push(f+'.'+c);const s=typeof r[c]==='string'?r[c].replace(/https?:\/\/\S+/g,''):'';if(/\b\d{3}-\d{2}-\d{4}\b/.test(s)||/(?<![\d.,])\d{9,}(?![\d.,])/.test(s)||/[\w.+-]+@[\w-]+\.[\w.]+/.test(s))bad.push(f+'.'+c+' digits or email');}});}
  return yes(!bad.length,[...new Set(bad)].slice(0,12).join(', '));});}}
/* answers index (tools/answers.js): written for the data, FRESH while the data is unchanged, STALE after any change, no dash, and nothing is read from it by a calc */
{const {spawnSync}=require('child_process');const tmp=ROOT+'/work/answers_test';fs.rmSync(tmp,{recursive:true,force:true});fs.mkdirSync(tmp+'/data',{recursive:true});
 for(const f of fs.readdirSync(ROOT+'/data_all'))fs.copyFileSync(ROOT+'/data_all/'+f,tmp+'/data/'+f);
 const run=a=>spawnSync('node',[ROOT+'/tools/answers.js','--today','2026-10-17','--data',tmp+'/data','--out',tmp+'/answers.json'].concat(a),{cwd:ROOT});
 const w=run([]);
 T([],'answers index: written for the data, with a basis on every headline that reads asset, debt or bill rows, and no dash',()=>{const ok=w.status===0&&fs.existsSync(tmp+'/answers.json');if(!ok)return yes(false,'not written: '+String(w.stderr||w.stdout).slice(0,200));
   const j=JSON.parse(fs.readFileSync(tmp+'/answers.json','utf8'));const bad=j.headlines.filter(h=>h.value!=null&&h.rows.some(r=>/^(assets_other|liabilities|bills)\//.test(r))&&!h.basis).map(h=>h.id);
   return yes(!bad.length&&j.headlines.length>20&&!/[\u2013\u2014]/.test(JSON.stringify(j))&&j.data_hash.length===64,bad.join(', '));});
 T([],'answers index: --check prints FRESH on the data it was written for and STALE once a dataset changes',()=>{const a=run(['--check']);fs.appendFileSync(tmp+'/data/bills.json','\n');const b=run(['--check']);
   return yes(a.status===0&&/^FRESH/.test(String(a.stdout))&&b.status===1&&/^STALE/.test(String(b.stdout)),String(a.stdout)+'|'+String(b.stdout));});
 fs.rmSync(tmp,{recursive:true,force:true});}
save('data_rules');
