// Invariant rules (page/invariants.js) on every data set the suite knows, browser-free:
//   current data (data_all), each staged data folder (DATA_EXTRA, colon separated; default none),
//   the fixture, the fixture with every dataset reduced to its no-rows sentinel, and the fixture and current data with each single dataset
//   reduced to its sentinel (the "zero rows" rule: no calc may throw for a missing category).
// Data independence: the same rules pass on every folder; nothing here names a figure.
'use strict';
const fs=require('fs');const path=require('path');const {ROOT,PAGE,FX,texts,save,results}=require('./lib/fx');
const E=require(ROOT+'/tools/engine.js');const INV=require(ROOT+'/page/invariants.js');
const S=path.resolve(ROOT,'..');
const extra=(process.env.DATA_EXTRA!=null?process.env.DATA_EXTRA.split(':').filter(Boolean):[S+'/staged/data_all']).filter(d=>fs.existsSync(d));
const sent=t=>{const raw=JSON.parse(t);const rows=Array.isArray(raw)?raw:raw.rows;const s={};Object.keys(rows[0]||{}).forEach(k=>s[k]=null);return JSON.stringify(Array.isArray(raw)?[s]:{rows:[s]});};
function check(label,data,quiet){const r=E.run({page:PAGE,data,today:'2026-10-17'});const ids=Object.keys(r.inputs);
  const get=id=>{if(r.calcs[id])return r.calcs[id].status==='ok'?r.calcs[id].value:null;const d=r.datasets[id];return d&&d.status==='ok'?d.rows:null;};
  const st=id=>r.calcs[id]?r.calcs[id].status:(r.datasets[id]||{}).status;
  const rs=INV(get,st,ids);const bad=rs.filter(x=>!x.ok);
  if(r.stopped)bad.push({id:'I0',name:'page script runs',detail:r.stopped.split('\n')[0]});
  if(quiet&&!bad.length){results.push({name:label+': all '+rs.length+' rules',ok:true});console.log('PASS',label+': all '+rs.length+' rules');return;}
  if(!quiet)rs.forEach(x=>{results.push({name:label+': '+x.id+' '+x.name,ok:x.ok,info:x.detail});console.log(x.ok?'PASS':'FAIL',label+': '+x.id+' '+x.name,x.ok?'':x.detail);});
  else bad.forEach(x=>{results.push({name:label+': '+x.id+' '+x.name,ok:false,info:x.detail});console.log('FAIL',label+': '+x.id+' '+x.name,x.detail);});}
const cur=texts(ROOT+'/data_all');const fx=texts(FX);
check('current data',cur);
/* a staged folder made before a dataset was added gets that dataset from the current data (the merge adds it) */
extra.forEach(d=>check('staged '+path.relative(S,d),Object.assign({},cur,texts(d))));
check('fixture',fx);
const empty={};for(const k in fx)empty[k]=sent(fx[k]);check('fixture, every dataset empty',empty);
for(const [lab,base] of [['fixture',fx],['current data',cur]])for(const k of Object.keys(base).sort()){const d=Object.assign({},base);d[k]=sent(base[k]);check(lab+' without '+k,d,true);}
save('inv_run');
